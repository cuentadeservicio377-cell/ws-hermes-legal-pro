---
name: opencode-go-integration
description: Integración completa de OpenCode Go en Hermes Neo — conexión, modelos, generación de assets, build y tech. Usar cuando Pablo mencione OpenCode, opencode-go, o necesite modelos adicionales.
trigger: Cuando Pablo mencione OpenCode, opencode-go, necesite modelos adicionales, o quiera generar assets/build con OpenCode.
---

# OpenCode Go Integration Skill

## Estado
✅ Conectado y operativo (28abr2026)

## Credenciales
- API Key: `sk-Q0QpvTFvTQF4xYREGyQIObJhKxbMvHdv7Sc02gsrwcnimUsDYu8fRAIrbFRZChiW`
- Endpoint: `https://opencode.ai/zen/go/v1`
- Configuración: `~/.hermes/.env` (OPENCODE_GO_API_KEY)

## Modelos Disponibles (100+)

### Tier OpenCode Go (recomendados)
| Modelo | Uso | Notas |
|--------|-----|-------|
| `deepseek-v4-pro` | Código, razonamiento complejo | ✅ Probado, funciona perfecto |
| `kimi-k2.6` | General, coding, análisis | Nuestro modelo principal |
| `kimi-k2.5` | General, más rápido | Fallback de k2.6 |
| `glm-5` / `glm-5.1` | General, chino-inglés | Alternativa |
| `qwen3.5-plus` / `qwen3.6-plus` | Código, matemáticas | Especializado |
| `deepseek-v4-flash` | Rápido, tareas simples | Más económico |

### Tier OpenAI (via OpenCode)
| Modelo | Uso |
|--------|-----|
| `gpt-5.4` | General, razonamiento |
| `gpt-5.4-mini` | Rápido, tareas simples |
| `gpt-5.5` | Última versión |

### Tier NVIDIA (via OpenCode)
| Modelo | Uso |
|--------|-----|
| `nvidia/deepseek-ai/deepseek-v4-pro` | Código |
| `nvidia/meta/llama-3.2-11b-vision-instruct` | Visión (⚠️ No probado si funciona) |
| `nvidia/microsoft/phi-3.5-vision-instruct` | Visión alternativa |
| `nvidia/black-forest-labs/flux.1-dev` | Generación de imágenes |

## Scripts

### Bridge Python
Ubicación: `~/.hermes/scripts/opencode_bridge.py`

```bash
# Generar texto/código
python ~/.hermes/scripts/opencode_bridge.py generate "prompt aquí" deepseek-v4-pro

# Generar imagen (si el modelo soporta)
python ~/.hermes/scripts/opencode_bridge.py generate-image "prompt" 16:9

# Analizar archivo
python ~/.hermes/scripts/opencode_bridge.py analyze-file /ruta/al/archivo
```

### Uso directo con curl
```bash
curl -s https://opencode.ai/zen/go/v1/chat/completions \
  -H "Authorization: Bearer $OPENCODE_GO_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-v4-pro",
    "messages": [{"role":"user","content":"prompt"}],
    "max_tokens": 4000,
    "temperature": 0.7
  }'
```

## Limitaciones Conocidas
- ❌ Visión nativa no confirmada (llama-3.2-vision no respondió)
- ✅ Para visión: usar Google Cloud Vision API (token en `~/.hermes/.env.google_apis`)
- ⚠️ Rate limits desconocidos — monitorizar uso

## Integración en Skills

### Para skills de marketing (ws-campaign-hackathon)
Añadir en `generate-assets`:
```bash
# Usar OpenCode para generación de texto creativo
python ~/.hermes/scripts/opencode_bridge.py generate \
  "Crea un tagline para campaña Eleutheria sobre libertad creativa" \
  deepseek-v4-pro
```

### Para skills de video (ws-video-machine)
Añadir en `generate-visuals`:
```bash
# Usar OpenCode para descripciones de escenas
python ~/.hermes/scripts/opencode_bridge.py generate \
  "Describe visualmente una escena de martillo rompiendo pantalla digital, estilo 80s" \
  deepseek-v4-pro
```

## Flujo de Trabajo Nocturno (Ejemplo)
```bash
# 1. Generar assets
python ~/.hermes/scripts/opencode_bridge.py generate-image \
  "Hero image: martillo rompiendo pantalla digital, synthwave 80s" 16:9

# 2. Generar copy
python ~/.hermes/scripts/opencode_bridge.py generate \
  "Tagline para campaña de libertad creativa, estilo Apple 1984" \
  gpt-5.4

# 3. Auditar resultados
python ~/.hermes/scripts/opencode_bridge.py generate \
  "Audita este video: [descripción]. Puntuación 1-10 en impacto, claridad, emoción" \
  deepseek-v4-pro
```

## Trabajo Nocturno Programado

Pablo puede solicitar trabajo nocturno con cronjobs. Ejemplo:

```bash
# Generar múltiples versiones de video
0 2 * * * /bin/bash -c 'source ~/.hermes/.env && python ~/.hermes/scripts/opencode_bridge.py generate "Crea guion video v1" deepseek-v4-pro > /tmp/v1.txt'
0 3 * * * /bin/bash -c 'source ~/.hermes/.env && python ~/.hermes/scripts/opencode_bridge.py generate "Audita v1 y mejora" deepseek-v4-pro > /tmp/v2.txt'
0 6 * * * /bin/bash -c 'python ~/.hermes/scripts/opencode_bridge.py generate "Compara v1 y v2, recomienda mejor" deepseek-v4-pro > /tmp/final.txt'
```

## Troubleshooting

### "No such file or directory"
- Verificar que `~/.hermes/scripts/opencode_bridge.py` existe
- Si no existe, recrear desde skill

### "401 Unauthorized"
- Verificar `OPENCODE_GO_API_KEY` en `~/.hermes/.env`
- Si expiró, pedir nueva a Pablo

### "Model not found"
- Verificar modelo en lista: `python ~/.hermes/scripts/opencode_bridge.py list`
- Usar modelo alternativo de la lista

## Actualización
Última actualización: 28abr2026
Próxima revisión: Cuando Pablo solicite nuevos modelos o cambios de endpoint