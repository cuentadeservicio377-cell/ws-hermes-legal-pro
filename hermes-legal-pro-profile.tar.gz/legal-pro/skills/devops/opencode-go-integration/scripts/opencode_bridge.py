#!/usr/bin/env python3
"""
OpenCode Go Bridge para Hermes Neo
Conecta con OpenCode Go API para generación de texto, código e imágenes.

Uso:
  python opencode_bridge.py generate "prompt" [modelo]
  python opencode_bridge.py generate-image "prompt" [aspect-ratio]
  python opencode_bridge.py analyze-file /ruta/al/archivo
  python opencode_bridge.py list

Configuración: ~/.hermes/.env (OPENCODE_GO_API_KEY)
"""

import os
import sys
import json
import requests
from pathlib import Path
from dotenv import load_dotenv

# Cargar .env
load_dotenv(os.path.expanduser("~/.hermes/.env"))

# Configuración
API_KEY = os.getenv("OPENCODE_GO_API_KEY")
BASE_URL = "https://opencode.ai/zen/go/v1"
DEFAULT_MODEL = "deepseek-v4-pro"

def load_api_key():
    """Carga API key de .env"""
    if not API_KEY:
        print("❌ Error: OPENCODE_GO_API_KEY no encontrada en ~/.hermes/.env")
        sys.exit(1)
    return API_KEY

def generate_text(prompt, model=None, max_tokens=4000, temperature=0.7):
    """Genera texto/código con OpenCode Go"""
    api_key = load_api_key()
    model = model or DEFAULT_MODEL
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": temperature
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/chat/completions",
            headers=headers,
            json=data,
            timeout=120
        )
        response.raise_for_status()
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        else:
            return json.dumps(result, indent=2)
    except Exception as e:
        return f"❌ Error: {e}"

def generate_image(prompt, aspect_ratio="16:9", model="nvidia/black-forest-labs/flux.1-dev"):
    """Genera imagen con OpenCode Go (si el modelo soporta)"""
    api_key = load_api_key()
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": model,
        "messages": [{"role": "user", "content": f"Generate image: {prompt}. Aspect ratio: {aspect_ratio}"}],
        "max_tokens": 4000
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/chat/completions",
            headers=headers,
            json=data,
            timeout=120
        )
        response.raise_for_status()
        result = response.json()
        
        # Guardar resultado
        output_dir = Path("/tmp/opencode_outputs")
        output_dir.mkdir(exist_ok=True)
        
        output_file = output_dir / f"image_{os.urandom(4).hex()}.json"
        with open(output_file, 'w') as f:
            json.dump(result, f, indent=2)
        
        return f"✅ Resultado guardado en: {output_file}"
    except Exception as e:
        return f"❌ Error: {e}"

def analyze_file(file_path, model="deepseek-v4-pro"):
    """Analiza un archivo con OpenCode Go"""
    api_key = load_api_key()
    
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
        
        # Para archivos de texto
        try:
            text_content = content.decode('utf-8')[:10000]  # Limitar a 10k chars
            prompt = f"Analyze this file:\n\n{text_content}\n\nProvide summary and key insights."
        except:
            prompt = f"Analyze this binary file: {file_path}. Size: {len(content)} bytes."
        
        return generate_text(prompt, model)
    except Exception as e:
        return f"❌ Error: {e}"

def list_models():
    """Lista modelos disponibles (basado en documentación)"""
    models = {
        "OpenCode Go": [
            "deepseek-v4-pro",
            "deepseek-v4-flash",
            "kimi-k2.6",
            "kimi-k2.5",
            "glm-5",
            "glm-5.1",
            "qwen3.5-plus",
            "qwen3.6-plus"
        ],
        "OpenAI (via OpenCode)": [
            "gpt-5.4",
            "gpt-5.4-mini",
            "gpt-5.5"
        ],
        "NVIDIA (via OpenCode)": [
            "nvidia/deepseek-ai/deepseek-v4-pro",
            "nvidia/meta/llama-3.2-11b-vision-instruct",
            "nvidia/microsoft/phi-3.5-vision-instruct",
            "nvidia/black-forest-labs/flux.1-dev"
        ]
    }
    
    print("📋 Modelos disponibles en OpenCode Go:")
    for provider, model_list in models.items():
        print(f"\n🔹 {provider}:")
        for m in model_list:
            print(f"   • {m}")
    
    return models

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "generate":
        if len(sys.argv) < 3:
            print("❌ Uso: python opencode_bridge.py generate \"prompt\" [modelo]")
            sys.exit(1)
        
        prompt = sys.argv[2]
        model = sys.argv[3] if len(sys.argv) > 3 else None
        
        print(f"🤖 Generando con {model or DEFAULT_MODEL}...")
        result = generate_text(prompt, model)
        print(result)
    
    elif command == "generate-image":
        if len(sys.argv) < 3:
            print("❌ Uso: python opencode_bridge.py generate-image \"prompt\" [aspect-ratio]")
            sys.exit(1)
        
        prompt = sys.argv[2]
        aspect = sys.argv[3] if len(sys.argv) > 3 else "16:9"
        
        print(f"🎨 Generando imagen ({aspect})...")
        result = generate_image(prompt, aspect)
        print(result)
    
    elif command == "analyze-file":
        if len(sys.argv) < 3:
            print("❌ Uso: python opencode_bridge.py analyze-file /ruta/al/archivo")
            sys.exit(1)
        
        file_path = sys.argv[2]
        print(f"📄 Analizando: {file_path}")
        result = analyze_file(file_path)
        print(result)
    
    elif command == "list":
        list_models()
    
    else:
        print(f"❌ Comando desconocido: {command}")
        print(__doc__)
        sys.exit(1)

if __name__ == "__main__":
    main()
