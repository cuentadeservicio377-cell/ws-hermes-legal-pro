---
title: WSL2 CUDA/cuDNN Toolkit Setup
description: Install NVIDIA CUDA Toolkit and cuDNN on WSL2 Ubuntu without breaking the Windows host GPU passthrough. WSL2 uses Windows host drivers; do NOT install Linux drivers inside WSL2.
category: devops
tags: [wsl2, cuda, nvidia, cudnn, gpu, docker]
name: wsl2-cuda-setup
---

# WSL2 CUDA Toolkit Setup

WSL2 uses the **Windows host NVIDIA driver** for GPU passthrough. Installing Linux NVIDIA drivers inside WSL2 overrides this passthrough and breaks CUDA support.

## Prerequisites

- WSL2 with GPU support enabled (Windows 11 or recent Windows 10)
- `nvidia-smi` works from Windows PowerShell/CMD
- Ubuntu 22.04 or 24.04 inside WSL2

## Important WSL2 Constraints

1. **No Linux drivers**: Do NOT install `nvidia-driver-*` or `cuda-drivers` packages. WSL2 uses the Windows host driver.
2. **No kernel headers**: `linux-headers-$(uname -r)` is not available in Ubuntu repos for WSL2 kernels.
3. **Large downloads**: The CUDA toolkit is ~3.6 GB. Foreground `apt-get install` may timeout.

## Step 1: Install CUDA Toolkit Only

Run these commands manually in WSL2:

```bash
sudo apt-get update
sudo apt-get install -y --no-install-recommends build-essential apt-transport-https ca-certificates gnupg curl

# Add NVIDIA CUDA repository keyring
curl -fsSL https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2404/x86_64/cuda-archive-keyring.gpg | \
  sudo tee /usr/share/keyrings/cuda-archive-keyring.gpg > /dev/null

# Add CUDA repository
echo "deb [signed-by=/usr/share/keyrings/cuda-archive-keyring.gpg] \
  https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2404/x86_64/ /" | \
  sudo tee /etc/apt/sources.list.d/cuda.list > /dev/null

sudo apt-get update

# Install toolkit ONLY — NOT drivers
sudo apt-get install -y --no-install-recommends cuda-toolkit-12-8
```

## Step 2: Install cuDNN

Download and extract cuDNN into the CUDA installation:

```bash
CUDNN_TAR="cudnn-linux-x86_64-9.8.0.tar.xz"

sudo rm -f /usr/local/cuda/lib64/libcudnn* /usr/local/cuda/include/cudnn*

curl -fsSL "https://developer.download.nvidia.com/compute/cudnn/redist/cudnn/linux-x86_64/${CUDNN_TAR}" \
  -o "/tmp/${CUDNN_TAR}"

sudo tar -xJf "/tmp/${CUDNN_TAR}" -C /usr/local/cuda --strip-components=1

rm "/tmp/${CUDNN_TAR}"
```

## Step 3: Set Environment Variables

Add CUDA to PATH and library path:

```bash
echo 'PATH="/usr/local/cuda/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"' | \
  sudo tee /etc/environment > /dev/null

echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}' | \
  sudo tee /etc/profile.d/cuda.sh > /dev/null
```

Apply in current session:

```bash
source /etc/profile.d/cuda.sh
```

## Step 4: Docker GPU Support (nvidia-container-toolkit)

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
  gpg --dearmor | sudo tee /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg > /dev/null

distribution=$(. /etc/os-release;echo "$ID$VERSION_ID")

echo "deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] \
  https://nvidia.github.io/libnvidia-container/stable/deb/$distribution /" | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list > /dev/null

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker || true
```

## Step 5: Verify Installation

```bash
source /etc/profile.d/cuda.sh
nvcc --version
nvidia-smi
python3 -c "import torch; print('CUDA available:', torch.cuda.is_available())"
```

## Handling Large Downloads (Timeout Workaround)

`apt-get install cuda-toolkit-12-8` downloads ~3.6 GB and commonly exceeds default timeouts.

### Option A: Background via terminal tool (Hermes Agent)
Save setup commands to `/tmp/setup-cuda/setup_cuda.sh`, then run in background with auto-notification:

```bash
# In Hermes terminal tool:
terminal(background=true, command="cd /tmp/setup-cuda && sudo bash setup_cuda.sh", notify_on_complete=true, timeout=1200)
```

This allows the agent to continue working while CUDA installs and auto-notifies when complete.

### Option B: Manual nohup
```bash
nohup bash setup_cuda.sh > /tmp/cuda_setup.log 2>&1 &
tail -f /tmp/cuda_setup.log
```

### Option C: Resume after timeout
If `apt-get` times out mid-install, the packages may already be cached. Re-run the install command — apt will skip already-downloaded packages.

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `nvidia-smi` fails in WSL2 | Linux NVIDIA drivers were installed | `sudo apt remove --purge 'nvidia-*'` then `wsl --shutdown` from Windows |
| `Unable to locate package linux-headers-*` | Expected — WSL2 kernels differ from stock Ubuntu | Skip kernel headers; not needed for toolkit-only install |
| `apt` hangs or times out | Single package exceeds 3 GB | Use background process (see above) or increase timeout |
| CUDA version mismatch errors | Windows driver too old for toolkit | Update Windows NVIDIA driver to latest |
| `curl: (22) The requested URL returned error: 404` for cuDNN | NVIDIA changed redist URL or version | Browse `https://developer.download.nvidia.com/compute/cudnn/redist/cudnn/linux-x86_64/` to find the current tar.xz filename, then update `CUDNN_TAR` in the script. Common failure: cuDNN 9.8.0 may be pulled; try the latest version shown in the directory listing. |
| cuDNN download extremely slow or stalls | CDN rate limiting or large file | Use `wget --tries=3 --timeout=60` instead of `curl`, or download on host and copy into WSL2 |
