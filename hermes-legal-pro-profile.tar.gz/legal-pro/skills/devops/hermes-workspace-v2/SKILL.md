---
name: hermes-workspace-v2
description: Install, verify, and adapt Hermes Workspace V2 to an existing local Hermes Agent gateway instead of treating it as a blind one-liner install.
version: 1.0.1
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, workspace, web-ui, gateway, install, adaptation]
---

# Hermes Workspace V2

Use this when the user wants to install or evaluate `outsourc-e/hermes-workspace` / `hermes-workspace.com` and adapt it to an already-running Hermes environment.

## Why this skill exists

A real install revealed a few non-obvious points:
- the website one-liner is reasonable, but inspect it first
- the repo README and installer drift in places
- the cleanest path is often **attach Hermes Workspace to the existing Hermes gateway** instead of reinstalling Hermes
- successful validation should use the workspace health endpoints, not only whether `pnpm dev` started

## Recommended approach

### 1. Inspect before executing
Check the installer head first:

```bash
curl -fsSL https://hermes-workspace.com/install.sh | sed -n '1,240p'
```

Look for:
- repo URL
- install directory
- whether it installs Hermes itself
- whether it modifies `~/.hermes`
- whether it links bundled skills

## 2. Verify the live Hermes state first
Use the existing local Hermes if it is already healthy.

```bash
hermes status
hermes doctor
```

If the gateway is already running locally, prefer attaching the workspace to it.

## 3. Clone into a controlled project path
Prefer a repo path under the user's workspace instead of blindly installing under `$HOME`.

Example:

```bash
gh repo clone outsourc-e/hermes-workspace /path/to/projects/active/hermes-workspace -- --depth 1
```

Keep a second read-only reference clone if helpful:

```bash
gh repo clone outsourc-e/hermes-workspace /path/to/research/hermes-workspace -- --depth 1
```

## 4. Configure `.env` for the real local gateway
Copy `.env.example` to `.env` and set the gateway URL.

Minimal adapted `.env`:

```env
HERMES_API_URL=http://127.0.0.1:8642
```

If the local Hermes gateway is protected by an API token, set the matching workspace token in `.env` as well. Do not paste secret values into notes or commits.

## 5. Install dependencies
This repo is heavy; allow time.

```bash
cd /path/to/hermes-workspace
pnpm install
```

If it takes too long, run in background and poll.

## 6. Build before declaring success
Do not stop after dependency install. Run a real build.

```bash
pnpm build
```

In the observed install, `pnpm build` succeeded even though `pnpm approve-builds` had previously shown ignored build scripts warnings.

## 7. Start dev server and verify through HTTP endpoints
Run:

```bash
pnpm dev
```

Then verify with actual endpoints exposed by the workspace itself:

```bash
curl http://127.0.0.1:3000/api/healthcheck
curl http://127.0.0.1:3000/api/connection-status
python3 - <<'PY'
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:3000', timeout=20) as r:
    print(r.status)
    print(r.read(200).decode('utf-8','ignore'))
PY
```

Expected good signals:
- `/api/healthcheck` → `{"ok":true}`
- `/api/connection-status` → `{"ok":true,...}`
- root `/` returns HTTP 200

## Important experiential findings

### README/install drift
During the real install, the installer script delegated to Nous's official installer, but the README still claimed in one place that it installs `hermes-agent` from PyPI. Treat the installer as source of truth over that README line.

### Existing gateway path is better than reinstall
If Hermes is already running locally and healthy, the least-risk path is:
- clone workspace
- set `HERMES_API_URL`
- set workspace auth token only if the gateway already requires one
- `pnpm install`
- `pnpm build`
- `pnpm dev`

This is safer than re-running an all-in-one installer that might duplicate or drift the current setup.

### Port reality
Website/docs may mention different defaults in different places. In the observed run, the workspace dev server actually listened on port `3000`. Always verify with `ss -ltnp` instead of trusting docs.

### Runtime mismatch: `pnpm build` does not imply `pnpm start` works
A later validation run showed another important nuance:
- `pnpm build` can succeed and produce `dist/client` + `dist/server`
- but `pnpm start` may still fail because the script expects:

```bash
.output/server/index.mjs
```

If that file is missing, do not assume the app is actually startable via the package's default start command. Verify the start target exists before reporting a production-style boot path.

### When `pnpm dev` or `vite preview` listen but never answer HTTP
In one real run:
- `pnpm dev` bound port `3000`
- `vite preview` bound port `4173`
- but both accepted TCP connections and then hung without returning HTTP bytes

So verification must distinguish:
- **port open**
- **real HTTP response**

Use both:

```bash
ss -ltnp | grep ':3000 '\ncurl -I --max-time 10 http://127.0.0.1:3000/
```

If the socket is open but `curl` times out, the app is not actually reviewable yet.

### Static fallback for manual visual review
If the built app exists in `dist/client` and the SSR/dev server path is hanging, a temporary fallback is:

```bash
npx serve -s dist/client -l 4173
```

This is useful only for **root-level visual inspection**. In the observed run:
- `http://127.0.0.1:4173/` returned 200
- direct deep links like `/juridico` and `/onyx` returned 404 under that static server setup

So report this fallback honestly as:
- suitable for opening the shell from `/`
- **not** equivalent to a fully working routed app

## Verification checklist

Before saying it is installed:
- [ ] `hermes status` is healthy enough
- [ ] workspace repo cloned to intended location
- [ ] `.env` contains `HERMES_API_URL`
- [ ] `pnpm install` completed
- [ ] `pnpm build` completed
- [ ] `pnpm dev` is running
- [ ] `/api/healthcheck` returns ok
- [ ] `/api/connection-status` reports a healthy backend attachment
- [ ] root page returns HTTP 200

## Reporting format

When done, report:
- install path
- whether it was attached to existing Hermes or installed standalone
- exact non-secret env adaptation applied
- build result
- health endpoint results
- whether to treat it as a parallel panel or a replacement candidate

## Recommendation learned from experience

Do **not** replace the existing Hermes dashboard blindly after first install.
Treat Hermes Workspace V2 as a **parallel web control panel** first, then evaluate:
- chat
- memory
- skills
- terminal
- conductor
- operations

Only after that decide whether it should become the primary web surface.
