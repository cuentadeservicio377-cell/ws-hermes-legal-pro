---
name: hermes-openai-codex-provider
description: Configure Hermes Agent to use OpenAI Codex OAuth (ChatGPT account) as the free main provider — zero API cost. Covers auth flow, supported models, config commands, and pitfalls discovered during setup.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, openai-codex, oauth, provider, free, cost-saving]
    related_skills: [hermes-agent]
---

# Hermes + OpenAI Codex OAuth Provider

Use your existing ChatGPT/OpenAI account (OAuth) as the main Hermes provider — no API key charges. This uses the same auth as the Codex CLI desktop app.

## When to Use

- User is paying for OpenAI API usage and wants to switch to their ChatGPT subscription
- openai-codex provider errors after token expiry and needs re-auth
- Need to know which models are available on this provider

## Prerequisites

- Active ChatGPT Plus/Pro subscription (or Codex access on your OpenAI account)
- Hermes Agent installed

## Step 1 — Authenticate

NOTE: `hermes login` no longer exists. Use `hermes auth add` instead.

Must run in background with PTY because the command blocks waiting for browser confirmation:

```bash
terminal(command="hermes auth add openai-codex --type oauth --no-browser", background=true, pty=true)
```

Poll output to get the device code:

```bash
process(action="wait", session_id="<id>", timeout=20)
```

Output will contain:

```
1. Open this URL: https://auth.openai.com/codex/device
2. Enter this code: XXXX-XXXXX
Waiting for sign-in...
```

Tell the user to go to https://auth.openai.com/codex/device and enter the code. Wait for confirmation, then poll again:

```bash
process(action="poll", session_id="<id>")
```

Success output: `Added openai-codex OAuth credential #1: "openai-codex-oauth-1"`

Verify:

```bash
hermes auth list
# Should show: openai-codex (1 credentials)
```

## Step 2 — Discover Available Models

Standard OpenAI model names (gpt-4o, o4-mini, o1, etc.) DO NOT work on this provider. Must query the Codex-specific endpoint:

```python
import json, urllib.request

with open('/root/.hermes/auth.json') as f:
    auth = json.load(f)
token = auth['credential_pool']['openai-codex'][0]['access_token']

req = urllib.request.Request(
    'https://chatgpt.com/backend-api/codex/models?client_version=1.0.0',
    headers={'Authorization': f'Bearer {token}'}
)
with urllib.request.urlopen(req, timeout=10) as r:
    data = json.loads(r.read())
    for m in data['models']:
        print(m['slug'], '-', m.get('context_window'), 'tokens')
```

As of April 2026, available models:

- gpt-5.4 — 272,000 tokens
- gpt-5.4-mini — 272,000 tokens
- gpt-5.3-codex — 272,000 tokens
- gpt-5.2 — 272,000 tokens

Recommended policy:

- Use `gpt-5.4-mini` as the default when optimizing for low cost / general daily use
- Use `gpt-5.4` as the default when optimizing for stronger reasoning / planning
- Keep `gpt-5.4-mini` as `smart_model_routing.cheap_model` either way

## Step 3 — Configure Hermes

### Cost-first default

```bash
hermes config set model.provider openai-codex
hermes config set model.default gpt-5.4-mini
hermes config set smart_model_routing.cheap_model.model gpt-5.4-mini
hermes config set smart_model_routing.cheap_model.provider openai-codex
hermes config set model.base_url ""
```

### Reasoning-first default

```bash
hermes config set model.provider openai-codex
hermes config set model.default gpt-5.4
hermes config set smart_model_routing.cheap_model.model gpt-5.4-mini
hermes config set smart_model_routing.cheap_model.provider openai-codex
hermes config set model.base_url ""
```

## Step 4 — Smoke Test

```bash
hermes chat -q "Say exactly: CODEX_OK" --provider openai-codex -m "gpt-5.4-mini"
```

Success: response contains CODEX_OK and exits cleanly.

## Token Expiry / Re-Authentication

OAuth tokens expire. When you see auth errors, repeat Step 1. Previous credential is replaced automatically.

## Audit multiple credentials before assuming account rotation

In this environment, Hermes can show multiple `openai-codex` credentials while they still point to the **same OpenAI account**. OpenCode can also be authenticated to that same account. Do not assume that two credentials means two different subscriptions or a real fallback split.

### Hermes: inspect configured Codex credentials

```bash
hermes auth list
```

For a deeper audit, inspect `/root/.hermes/auth.json` and compare the `openai-codex` entries. Safe fields to check:
- `label`
- `source`
- `priority`
- `last_refresh`
- decoded JWT payload fields such as:
  - `https://api.openai.com/auth.chatgpt_account_id`
  - `https://api.openai.com/auth.chatgpt_plan_type`
  - `https://api.openai.com/profile.email`

If two Hermes credentials decode to the same `chatgpt_account_id`, same plan, and same masked email, they are duplicates of the same account rather than separate fallbacks.

### OpenCode: inspect its auth separately

OpenCode stores auth at:

```bash
~/.local/share/opencode/auth.json
```

Useful non-secret fields to compare:
- `openai.accountId`
- `openai.type`
- `openai.expires`
- whether `nvidia` is also present for lightweight lanes

### Decision rule

Before cleaning up auth or planning token/cost routing, answer these three questions:
1. Which OpenAI account is Hermes using?
2. Which OpenAI account is OpenCode using?
3. Are they intentionally the same, or should they be split?

If Hermes and OpenCode share the same OpenAI `account_id`, then there is **no real account separation** and token pressure will still converge on the same subscription.

### Cleanup / separation pattern

- Keep one Hermes `openai-codex` credential per intended account unless you explicitly need duplicates.
- Remove an unwanted Hermes credential with:

```bash
hermes auth remove openai-codex <index-or-label>
```

- Re-auth Hermes to a different account with:

```bash
hermes auth add openai-codex --type oauth --no-browser
```

- Re-auth OpenCode separately if you want it on a different OpenAI account:

```bash
opencode providers logout
opencode providers login
```

Then re-check both stores before assuming the split is real.

## Subagentes / Copilot ACP (CRÍTICO para delegate_task)

OpenAI Codex como motor secundario requiere **GitHub Copilot CLI** para el Agent Client Protocol (ACP). Sin esto, `delegate_task` falla con "Could not start Copilot ACP command 'claude'".

### Instalación de Copilot CLI

```bash
# Instalar paquete @github/copilot
npm install -g @github/copilot

# Crear symlink en PATH
ln -sf /root/.hermes/node/bin/copilot /usr/local/bin/copilot

# Verificar instalación
copilot --version
# Output: GitHub Copilot CLI 1.0.39
```

### Configurar ACP en Hermes

```bash
# Añadir a ~/.bashrc o ~/.profile
export HERMES_COPILOT_ACP_COMMAND=/usr/local/bin/copilot
```

O en `.env`:
```
HERMES_COPILOT_ACP_COMMAND=/usr/local/bin/copilot
```

### Verificar funcionamiento

```bash
# Prueba directa
delegate_task(
    goal="Responde 'funciona'",
    context="Prueba técnica",
    acp_command="copilot"
)
```

Éxito: subagente responde usando gpt-5.3-codex en ~20-60 segundos.

### Configuración en skills de máquinas

Todas las skills que usen subagentes deben especificar:
```
**Motor de subagentes:** OpenAI Codex (gpt-5.3-codex) vía Copilot ACP
**Comando ACP:** `copilot`
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
```

## Pitfalls

1. `hermes login` was removed — always use `hermes auth add openai-codex --type oauth --no-browser`
2. Run auth in background PTY — the command blocks waiting for browser confirmation; foreground with short timeout will always fail
3. Standard model names fail — gpt-4o, o4-mini, o3, o1, gpt-4.1 etc. all return HTTP 400 "not supported when using Codex with a ChatGPT account"
4. The token uses a special endpoint — https://chatgpt.com/backend-api/codex (not api.openai.com); direct API calls to api.openai.com return 403 or 401
5. auth.json stores the token at credential_pool > openai-codex > [0] > access_token
6. Hermes provider transport is codex_responses — not standard OpenAI chat completions
7. **delegate_task FALLA si falta Copilot CLI** — instalar @github/copilot y configurar HERMES_COPILOT_ACP_COMMAND
8. **OpenCode Go da 403 desde WSL** — Cloudflare bloquea User-Agent; usar solo como backup teórico
