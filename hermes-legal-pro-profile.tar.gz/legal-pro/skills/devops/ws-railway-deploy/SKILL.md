---
name: ws-railway-deploy
description: Deploy de aplicaciones web en Railway para WS Capital. Flujo completo desde autenticación CLI hasta verificación post-deploy. Incluye deploy desde GitHub o código local, configuración de variables de entorno, y troubleshooting común.
version: 1.0.0
author: Hermes Neo
license: MIT
metadata:
  hermes:
    tags: [railway, deploy, devops, ws-capital, hosting, cloud]
---

# WS Railway Deploy

## Propósito

Deploy de aplicaciones web en Railway para proyectos WS Capital. Cubre autenticación, deploy desde GitHub o local, configuración de variables de entorno, y verificación post-deploy.

## Trigger

Usar este skill cuando:
- Se necesita deployar una aplicación en Railway
- El usuario dice "opción B" o "deploy en Railway" para un proyecto
- Se necesita migrar un servicio existente a Railway
- Se necesita crear un nuevo proyecto en Railway

## Pre-requisitos

1. Railway CLI instalado (`railway --version`)
2. Cuenta de Railway con tarjeta de crédito agregada (para proyectos privados)
3. Token de Railway o capacidad de autenticación por navegador
4. Código fuente en GitHub o localmente

## FASE 1: Autenticación en Railway

### Opción A: MCP Railway (recomendado — no requiere CLI auth)
Cuando Railway CLI no permite login no-interactivo ("Cannot login in non-interactive mode"), usar el MCP de Railway directamente:

```
# 1. Listar proyectos existentes
mcp_railway_list_projects

# 2. Obtener servicios del proyecto
mcp_railway_list_services projectId="PROJECT_ID"

# 3. Redeployar servicio existente
mcp_railway_redeploy projectId="PROJECT_ID" environmentId="ENV_ID" serviceId="SERVICE_ID"
```

**Ventaja:** No requiere autenticación CLI interactiva. Funciona directamente con el token del entorno.

### Opción B: Token vía CLI (automatización con scripts)
```bash
# El usuario proporciona el token
export RAILWAY_TOKEN="token_del_usuario"
railway login --browserless
# Ingresar el token cuando se solicite
```

### Opción C: Navegador (interactivo)
```bash
railway login
# Abre navegador para autenticación OAuth
```

### Verificación de autenticación
```bash
railway whoami
# Debe mostrar información del usuario
```

**Si falla:** Railway CLI puede estar instalado pero NO autenticado. Fallback a MCP Railway (Opción A).

## FASE 2: Localización del proyecto

### Si el proyecto está en GitHub:
```bash
# Verificar que el repo existe y es accesible
gh repo view OWNER/REPO --json url,name,private
# Si es privado, debe hacerse público temporalmente para deploy inicial
# o usar Railway API con token de GitHub
```

### Si el proyecto está localmente:
```bash
# Buscar en ubicaciones estándar WS Capital
find /mnt/c/Users/DELL/Documents -name "*NOMBRE_PROYECTO*" -type d 2>/dev/null
find /mnt/c/Users/DELL/Desktop -name "*NOMBRE_PROYECTO*" -type d 2>/dev/null
find ~/projects -name "*NOMBRE_PROYECTO*" -type d 2>/dev/null
```

### Si no se encuentra el proyecto:
1. Preguntar al usuario por la URL del repositorio de GitHub
2. O preguntar por la ruta local del código
3. O clonar desde GitHub: `gh repo clone OWNER/REPO`

## FASE 3: Configuración del proyecto Railway

### Crear proyecto nuevo:
```bash
# En el directorio del proyecto (si es local)
cd /ruta/al/proyecto
railway init
# Seguir prompts: crear proyecto nuevo o vincular a existente
```

### O usar Railway API (GraphQL v2):
```bash
# Crear proyecto via API
curl -X POST https://backboard.railway.app/graphql/v2 \
  -H "Authorization: Bearer $RAILWAY_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "mutation { projectCreate(input: {name: \"NOMBRE_PROYECTO\"}) { id name } }"
  }'
```

## FASE 4: Deploy

### Deploy vía MCP Railway (método preferido para no-interactivo)

**Prerequisitos:**
- Proyecto Railway existente con servicio configurado
- Código en GitHub (repo público o vinculado)
- `.railway_project_id` en el directorio del proyecto (opcional)

**Flujo completo MCP:**
```
# 1. Verificar proyecto y servicios
mcp_railway_list_projects
mcp_railway_list_services projectId="PROJECT_ID"

# 2. Hacer push a GitHub (si hay cambios locales)
git push origin master  # o main

# 3. Redeployar servicio (Railway detecta el nuevo commit automáticamente)
mcp_railway_redeploy projectId="PROJECT_ID" environmentId="ENV_ID" serviceId="SERVICE_ID"
# → Retorna deploymentId

# 4. Verificar estado del build con Railway Agent
mcp_railway_railway_agent projectId="PROJECT_ID" serviceId="SERVICE_ID" \\
  environmentId="ENV_ID" threadId="THREAD_ID_DEL_PASO_3" \\
  message="Check deployment DEPLOYMENT_ID status"

# 5. Esperar BUILD_IMAGE (puede tardar 1-3 minutos)
# Revisar hasta que status sea SUCCESS

# 6. Generar dominio público si no existe
mcp_railway_railway_agent projectId="PROJECT_ID" serviceId="SERVICE_ID" \\
  environmentId="ENV_ID" threadId="THREAD_ID" \\
  message="Generate a public domain for service SERVICE_ID"

# 7. Verificar URL funcional
curl https://URL_ASIGNADA.railway.app/api/health
```

**Estados de deploy a monitorear:**
- `INITIALIZING` → `BUILDING` → `SUCCESS` | `FAILED`
- Pasos internos: SNAPSHOT_CODE → BUILD_IMAGE → CREATE_CONTAINER → CONFIGURE_NETWORK → DRAIN_INSTANCES

### Deploy desde GitHub (CLI):
```bash
# Vincular repositorio GitHub
railway link
# Seleccionar proyecto

# Configurar deploy desde GitHub
railway variables set RAILWAY_DOCKERFILE_PATH=Dockerfile  # si aplica

# Deploy
railway up
```

### Deploy desde código local:
```bash
cd /ruta/al/proyecto
railway up
```

### Usando Railway API para deploy desde GitHub:
```bash
# Necesita: projectId, repo, branch
curl -X POST https://backboard.railway.app/graphql/v2 \
  -H "Authorization: Bearer $RAILWAY_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "mutation { githubRepoDeploy(input: {projectId: \"PROJECT_ID\", repo: \"OWNER/REPO\", branch: \"main\"}) { id status } }"
  }'
```

## FASE 5: Configuración de variables de entorno

```bash
# Establecer variables de entorno
railway variables set KEY1=value1
railway variables set KEY2=value2

# Ver variables
railway variables

# Para aplicaciones Python/FastAPI comunes:
railway variables set PORT=8000
railway variables set HOST=0.0.0.0
```

## FASE 6: Verificación post-deploy

### Verificar estado del deploy:
```bash
railway status
# Debe mostrar: Deploying, Success, o Healthy
```

### Ver logs:
```bash
railway logs
# Revisar errores de inicio
```

### Verificar URL:
```bash
railway domain
# Muestra la URL asignada por Railway
```

### Probar endpoint:
```bash
curl https://URL_ASIGNADA.railway.app/health  # o endpoint de salud
```

## Troubleshooting común

### MCP Railway: "Method not found" o "Output validation error"
- Algunos métodos MCP de Railway pueden fallar con errores de validación
- **Solución:** Usar `mcp_railway_railway_agent` con mensajes en lenguaje natural para delegar al agente de Railway
- Ejemplo: `message="Check deployment DEPLOYMENT_ID status"`

### Railway CLI: "Cannot login in non-interactive mode"
- Railway CLI requiere TTY interactivo para login
- **Solución:** Usar MCP Railway (FASE 1, Opción A) en lugar de CLI

### "Unauthorized. Please login with `railway login`"
- Railway CLI no está autenticado
- Solución: FASE 1 — autenticar con token o navegador, o usar MCP Railway

### "Repository not found" o "Cannot access private repo"
- Repos privados de GitHub requieren hacerse públicos temporalmente
- O usar Railway API con token de GitHub configurado
- Solución: `gh repo edit OWNER/REPO --visibility public` (temporal)

### Build falla o tarda mucho
- BUILD_IMAGE puede tardar 1-3 minutos dependiendo de dependencias
- **Solución:** Esperar y verificar con Railway Agent en intervalos de 30-60 segundos
- Si falla: revisar `requirements.txt`, `Procfile`, o logs del build

### "Application crashed" o "Cannot find module"
- Dependencias faltantes o comando de inicio incorrecto
- Solución: verificar package.json / requirements.txt / Procfile

### "Port already in use" o "Cannot bind to port"
- Railway asigna puerto dinámico via $PORT
- Solución: usar `os.environ.get('PORT', 8000)` en la app

### Dominio no asignado automáticamente
- Railway no siempre genera dominio automáticamente en redeploys
- **Solución:** Usar Railway Agent para generar dominio explícitamente (FASE 4, paso 6)

### Deploy SUCCESS pero app no responde
- Verificar que el servicio esté escuchando en `0.0.0.0` (no `localhost`)
- Verificar que el Procfile apunte al archivo correcto (ej: `app_cloud:app` vs `app:app`)
- Verificar variables de entorno requeridas
- **Solución:** `curl URL/api/health` o endpoint de verificación

### App CRASHED post-deploy: "Could not import module" o import errors
- El código intenta importar módulos que dependen de archivos locales inexistentes en cloud
- Causa común: rutas hardcodeadas (`/mnt/c/...`, `/root/...`), credenciales locales, archivos de config
- **Patrón de fix — Graceful Degradation:**
  ```python
  # ANTES (crashea en cloud):
  from local_module import get_data  # Depende de archivos locales
  
  # DESPUÉS (funciona en cloud con fallback):
  try:
      from local_module import get_data
      LOCAL_AVAILABLE = True
  except Exception as e:
      print(f"[WARNING] Módulo local no disponible: {e}")
      LOCAL_AVAILABLE = False
      def get_data():
          return DEMO_DATA  # Datos de ejemplo en memoria
  ```
- **Verificación:** Revisar logs del deploy con Railway Agent: `message="Check deployment DEPLOYMENT_ID logs and errors"`
- **Solución:** Hacer todos los imports de módulos locales opcionales con `try/except` + funciones fallback que retornen datos demo

### Google Sheets / OAuth credentials break in cloud (rutas locales no existen)
Cuando una app usa Google Sheets API con credenciales OAuth almacenadas localmente (`/root/.hermes/google_token.json`, `/mnt/c/Users/.../client_secret_*.json`), estas rutas NO existen en Railway.

**Patrón de migración — Variables de entorno:**
```python
# google_sheets_adapter.py — ANTES (solo local):
TOKEN_FILE = '/root/.hermes/google_token.json'
CLIENT_SECRET_FILE = '/mnt/c/Users/.../client_secret_*.json'

def get_sheets_service():
    with open(TOKEN_FILE) as f:
        token_data = json.load(f)
    with open(CLIENT_SECRET_FILE) as f:
        client_config = json.load(f)['installed']
    # ... credenciales ...

# DESPUÉS (local + cloud con variables de entorno):
import os

SPREADSHEET_ID = os.environ.get('GOOGLE_SHEETS_SPREADSHEET_ID')
TOKEN_JSON = os.environ.get('GOOGLE_TOKEN_JSON')
CLIENT_SECRET_JSON = os.environ.get('GOOGLE_CLIENT_SECRET_JSON')

def get_sheets_service():
    if TOKEN_JSON and CLIENT_SECRET_JSON:
        # Modo Railway (variables de entorno)
        token_data = json.loads(TOKEN_JSON)
        client_config = json.loads(CLIENT_SECRET_JSON)['installed']
    else:
        # Modo local (archivos)
        with open('/root/.hermes/google_token.json') as f:
            token_data = json.load(f)
        with open('/mnt/c/Users/.../client_secret_*.json') as f:
            client_config = json.load(f)['installed']
    # ... credenciales ...
```

**Variables de entorno a configurar en Railway:**
- `GOOGLE_SHEETS_SPREADSHEET_ID` = ID del spreadsheet (ej: `15XLjP...`)
- `GOOGLE_TOKEN_JSON` = Contenido completo del archivo `google_token.json` como string JSON
- `GOOGLE_CLIENT_SECRET_JSON` = Contenido completo del archivo `client_secret_*.json` como string JSON

**Cómo extraer valores para variables:**
```bash
# En local/WSL, preparar variables:
python3 -c "
import json
with open('/root/.hermes/google_token.json') as f:
    print('GOOGLE_TOKEN_JSON=' + json.dumps(json.load(f)))
with open('/mnt/c/Users/.../client_secret_*.json') as f:
    print('GOOGLE_CLIENT_SECRET_JSON=' + json.dumps(json.load(f)))
with open('/ruta/.spreadsheet_id') as f:
    print('GOOGLE_SHEETS_SPREADSHEET_ID=' + f.read().strip())
"
```

**Configuración en Railway Dashboard:**
1. Ir a railway.app → Proyecto → Variables
2. Agregar las 3 variables con los valores extraídos
3. Redeployar el servicio

**Nota de seguridad:** Las credenciales OAuth contienen `refresh_token` — nunca compartir en chat. Extraer localmente y configurar directamente en Railway Dashboard.

### Caso borde: Usuario sin acceso a computadora (mobile-only)
Cuando el usuario está afuera, no puede acceder a la computadora donde están las credenciales, y necesita que el deploy funcione AHORA:

**Problema:**
- No se pueden extraer credenciales para variables de entorno
- GitHub bloquea push de archivos con secretos (secret scanning)
- Railway rechaza configurar credenciales sensibles vía agente
- El sistema local SÍ funciona, pero el cloud NO

**Solución — Modo híbrido local + cloud:**
1. **Verificar que el sistema local funcione** (curl localhost:8080/api/health)
2. **Si funciona:** Proporcionar IP local al usuario para acceso desde red interna
3. **Para cloud:** Usar graceful degradation con datos demo hasta que el usuario pueda configurar credenciales
4. **NUNCA** incluir credenciales en commits (GitHub las bloquea)
5. **NUNCA** compartir tokens/refresh_tokens en chat (quedan expuestos)

**Comunicación al usuario:**
- "El sistema local funciona con datos reales en: http://IP_LOCAL:8080"
- "Para acceso desde cualquier lugar, necesitarás configurar credenciales en Railway cuando tengas acceso a tu computadora"
- "El dashboard en Railway funciona con datos demo por ahora"

**Flujo de recuperación cuando el usuario regresa:**
1. Usuario accede a computadora
2. Extrae credenciales localmente (sin compartir en chat)
3. Configura variables en Railway Dashboard directamente
4. Redeploy automático con datos reales

## Reglas de ejecución

1. **SIEMPRE verificar autenticación antes de cualquier comando** (CLI o MCP)
2. **SIEMPRE confirmar ubicación del código antes de deploy**
3. **SIEMPRE preferir MCP Railway cuando CLI no permite login no-interactivo**
4. **SIEMPRE verificar estado del build con Railway Agent post-deploy**
5. **SIEMPRE generar/verificar dominio público después de deploy exitoso**
6. **SIEMPRE probar URL con curl antes de declarar deploy completado**
7. **SIEMPRE configurar variables de entorno necesarias**
8. **NUNCA deployar sin confirmar con el usuario primero**
9. **NUNCA hacer público un repo privado sin confirmar con el usuario**

## Patrón: Fallback a Datos Demo en Cloud (Graceful Degradation)

Cuando una app local usa archivos Excel, JSON locales, credenciales OAuth, o módulos con rutas hardcodeadas que no existen en cloud:

```python
# En el archivo principal (app.py, app_cloud.py, main.py):

# 1. Intentar importar módulo local
try:
    from local_adapter import get_eventos_data, get_finanzas_data
    LOCAL_MODE = True
except Exception as e:
    print(f"[WARNING] Modo local no disponible: {e}")
    LOCAL_MODE = False

# 2. Definir datos demo
DEMO_DATA = [
    {"id": "DEMO-1", "nombre": "Evento Demo 1", "fecha": "2025-06-01", ...},
    {"id": "DEMO-2", "nombre": "Evento Demo 2", "fecha": "2025-07-15", ...},
]

# 3. Funciones fallback
def get_eventos_data():
    if LOCAL_MODE:
        try:
            from local_adapter import get_eventos_data as local_get
            return local_get()
        except:
            pass
    return DEMO_DATA

def get_finanzas_data():
    if LOCAL_MODE:
        try:
            from local_adapter import get_finanzas_data as local_get
            return local_get()
        except:
            pass
    # Calcular desde datos demo
    total = sum(e["total"] for e in DEMO_DATA)
    return {"total": total, "eventos": DEMO_DATA}
```

**Rutas hardcodeadas que crashean en cloud:**
- `/mnt/c/Users/...` (Windows vía WSL)
- `/root/ws-...` (directorios locales de desarrollo)
- `~/.hermes/...` (configuración local)
- Archivos de credenciales OAuth (`client_secret_*.json`, `token.json`)
- Archivos Excel locales (`.xlsx`)

**Beneficios:**
- App funciona inmediatamente en cloud sin configurar credenciales
- Usuario ve datos de ejemplo en lugar de error 500
- Backend real se puede conectar después sin cambiar código
- Frontend puede desarrollarse/testearse independientemente del backend

**Cuándo usar:**
- MVP inicial en cloud antes de configurar BD/credenciales
- Apps que dependen de archivos locales (Excel, JSON, credenciales OAuth)
- Demos donde los datos reales no son críticos
- Testing de frontend sin backend disponible

## Notas técnicas

- Railway auto-detecta el tipo de proyecto (Python, Node, etc.)
- Para Python: necesita `requirements.txt` o `pyproject.toml`
- Para Node: necesita `package.json`
- Procfile opcional: `web: python app.py` o `web: node server.js`
- Railway asigna dominio automático: `https://nombre-proyecto.railway.app`
- Plan gratuito disponible pero con límites (sleep after inactivity)
- **MCP Railway funciona sin autenticación CLI interactiva** — usar como fallback cuando CLI falla
- **Railway Agent MCP** permite verificar estado de deploy y generar dominios en lenguaje natural

## Patrón: Fallback a Datos Demo en Cloud

Cuando una app local usa archivos Excel, JSON locales, o credenciales que no existen en cloud:

```python
# En el archivo principal (app.py, app_cloud.py, main.py):

# 1. Intentar importar módulo local
try:
    from local_adapter import get_eventos_data, get_finanzas_data
    LOCAL_MODE = True
except Exception as e:
    print(f"[WARNING] Modo local no disponible: {e}")
    LOCAL_MODE = False

# 2. Definir datos demo
DEMO_DATA = [
    {"id": "DEMO-1", "nombre": "Evento Demo 1", "fecha": "2025-06-01", ...},
    {"id": "DEMO-2", "nombre": "Evento Demo 2", "fecha": "2025-07-15", ...},
]

# 3. Funciones fallback
def get_eventos_data():
    if LOCAL_MODE:
        try:
            from local_adapter import get_eventos_data as local_get
            return local_get()
        except:
            pass
    return DEMO_DATA

def get_finanzas_data():
    if LOCAL_MODE:
        try:
            from local_adapter import get_finanzas_data as local_get
            return local_get()
        except:
            pass
    # Calcular desde datos demo
    total = sum(e["total"] for e in DEMO_DATA)
    return {"total": total, "eventos": DEMO_DATA}
```

**Beneficios:**
- App funciona inmediatamente en cloud sin configurar credenciales
- Usuario ve datos de ejemplo en lugar de error 500
- Backend real se puede conectar después sin cambiar código
- Frontend puede desarrollarse/testearse independientemente del backend

**Cuándo usar:**
- MVP inicial en cloud antes de configurar BD/credenciales
- Apps que dependen de archivos locales (Excel, JSON, credenciales OAuth)
- Demos donde los datos reales no son críticos
- Testing de frontend sin backend disponible

## Lecciones aprendidas

- Railway CLI puede estar instalado pero NO autenticado (verificar con `railway whoami`)
- MCP de Railway puede fallar con errores de validación en métodos directos — usar Railway Agent como fallback
- Repos privados de GitHub deben hacerse públicos temporalmente para deploy inicial
- Siempre verificar que el proyecto existe localmente o en GitHub antes de proceder
- **BUILD_IMAGE puede tardar varios minutos** — usar Railway Agent para monitoreo en tiempo real
- **Dominio público no siempre se genera automáticamente** — solicitar explícitamente vía Railway Agent
- **El thread ID del Railway Agent es persistente** — reutilizarlo para consultas follow-up del mismo deploy
- **Apps locales crashean en cloud por dependencias locales** — hacer imports opcionales con `try/except` + datos demo
- **Rutas hardcodeadas (`/mnt/c/...`, `/root/...`) no existen en cloud** — usar variables de entorno o graceful degradation
- **Google Sheets, OAuth, archivos locales deben ser opcionales en cloud** — implementar fallback a datos en memoria
- **Cuando Railway CLI dice "Cannot login in non-interactive mode"** → usar MCP Railway directamente (no requiere CLI auth)
- **Cuando el deploy dice SUCCESS pero la app está CRASHED** → revisar logs con Railway Agent: error típico es "Could not import module" por imports locales fallidos
- **SyntaxError en f-strings con backslash** — Python no permite `f"...\..."` dentro de expresiones f-string. Solución: usar variable intermedia: `sep = '\\'; f"{drive}:{sep}{rest.replace('/', sep)}"`
- **Cuando el usuario está afuera sin acceso a computadora** → verificar sistema local funcione, dar IP de red interna, usar datos demo en cloud hasta que pueda configurar credenciales
- **Cuando GitHub bloquea push por secret scanning (GH013)** → crear rama limpia (`git checkout --orphan clean-branch`), eliminar archivos con secretos del historial, push a nueva rama, configurar Railway para usar la rama limpia
- **Cuando Railway usa commit viejo en vez del más reciente** → Railway cachea commits. Solución: crear nueva rama limpia (`git checkout --orphan clean-branch`), push a nueva rama, configurar Railway para usar esa rama. Esperar a que Railway detecte el nuevo commit puede tardar indefinidamente.
- **Cuando el adapter no exporta las funciones que app_cloud.py espera** → error "cannot import name 'get_eventos_data'". Solución: agregar funciones wrapper en el adapter que llamen a las funciones existentes (ej: `get_eventos_data()` → `read_eventos()`)
- **SyntaxError en f-strings con backslash** — Python no permite `f"...\..."` dentro de expresiones f-string. Solución: usar variable intermedia: `sep = '\\'; f"{drive}:{sep}{rest.replace('/', sep)}"`
- **Railway API token permissions** — un token puede funcionar para crear proyectos (`projectCreate`) pero NO para deployar desde GitHub (`githubRepoDeploy` retorna "Bad Access"). Para deploy automatizado completo, el token necesita permisos de deploy adicionales en Railway.
- **Railway CLI token storage** — `~/.railway/config.json` y `config.yml` no funcionan para autenticación no-interactiva. El CLI requiere OAuth interactivo. Para automatización, usar Railway API GraphQL directamente con `Authorization: Bearer TOKEN` header.
- **GitHub push protection (GH013) bloquea commits con secretos** — incluso si se borra el archivo en commit posterior, GitHub detecta secretos en el historial. Solución: `git checkout --orphan clean-branch` para crear rama sin historial, o usar `git filter-repo`/`filter-branch` para eliminar secretos del historial completo.
