# PLAN MAESTRO DE INTEGRACIÓN HERMES ↔ WS CAPITAL
# Versión 2.0 (corregido después de auditoría real)
# Fecha: 2026-05-01
# Principio: INTEGRACIÓN, no acumulación

---

## LECCIÓN CRÍTICA: Integración vs Acumulación

**Pablo corrigió (2026-05-01):** NUNCA instalar skills genéricas del hub sin auditar nuestro sistema primero. Nuestras skills locales son SUPERIORES a las genéricas del hub.

**Error cometido:** Instalé `business-contract` y `tech-lawyer` del hub sin revisar que `willow-legal-complete` ya cubre todo (23 templates, 5 agentes, Kami v3, bridge API, modo standalone). Fue un error de lógica: acumular en vez de integrar.

**Principio corregido:**
1. INTEGRAR features nativas de Hermes para AMPLIFICAR nuestros sistemas superiores
2. NO acumular skills genéricas del hub que compitan con lo que ya construimos
3. AUDITAR nuestro sistema antes de instalar CUALQUIER cosa del hub

---

## COMPARATIVA: Nuestros Sistemas vs Hub Genérico

| Nuestro Sistema | Hub Genérico | Por qué el nuestro gana |
|-----------------|-------------|------------------------|
| `willow-legal-complete` | `business-contract` + `tech-lawyer` | Motor de documentos propio, validación de sustancia, diseño editorial, modo offline |
| `ws-video-studio-system` | Cualquier skill de "content creation" | Producción real con dashboard v2.1, SmartCut, estructura 5 fases |
| `deep-research-system` | `scrapling` + `duckduckgo-search` | 4 agentes paralelos, Eugen Swarms, reportes estructurados |
| `ws-growth-director` | `ai-seo` + `content-strategy` | Director de growth completo, 5 piezas/semana |
| `ws-interconnected-ops` | Cualquier skill de "productivity" | 7 departamentos, routing, handoffs, Excel PM, vaults |
| `onyx-lite-extension-pattern` | `notion-api` genérica | Extensión de Onyx con dominio legal propio |

---

## CÓMO CADA FEATURE NATIVA AMPLIFICA NUESTROS SISTEMAS

| Feature | Sistema que amplifica | Cómo |
|---------|----------------------|------|
| `/goal` | Willow, Video, Growth | Persistencia de objetivos entre turns |
| `/background` | Deep Research, Video | Paralelismo para research y generación de assets |
| `/model` | Build, Growth | Switch inteligente según tipo de tarea |
| `/branch` | Growth, Willow | Experimentos seguros sin perder hilo |
| `/snapshot` + `/rollback` | Todos | Protección antes de cambios grandes |
| `/steer` | Todos | Corrección de dirección sin reiniciar |
| `/insights` | Admin & Ops | Control de costos por departamento |
| `/cron` | Todos | Automatización de operaciones recurrentes |
| `/kanban` | Todos | Visibilidad de pipeline de proyectos |
| `/queue` | Todos | Multitarea sin perder ideas |
| `/reasoning` | Todos | Eficiencia de tokens (low para rápido, high para complejo) |

---

## CHECKLIST ANTES DE INSTALAR CUALQUIER SKILL DEL HUB

- [ ] ¿Ya tenemos una skill local que cubre esto?
- [ ] ¿La skill del hub COMPLEMENTA o COMPITE con nuestro sistema?
- [ ] ¿Audité nuestro sistema antes de considerar instalar?
- [ ] ¿Estoy pensando en integración o en acumulación?
- [ ] ¿Esta skill llena un gap genuino que no hemos construido?

---

## GAPS REALES IDENTIFICADOS (post-auditoría)

1. **Goals no usados** — 3 proyectos activos, 0 goals persistentes
2. **Background jobs no usados** — Research y generación bloquean conversación
3. **Kanban vacío** — No hay visibilidad de pipeline
4. **Snapshot/rollback no usado** — Sin protección para cambios grandes
5. **MCP servers limitados** — Solo Railway, falta GitHub/PostgreSQL
6. **Email no integrado** — `himalaya` instalado pero no configurado para ops
7. **Plataformas limitadas** — Solo Telegram
8. **Insights no revisados** — Sin control de costos

---

## ACCIONES INMEDIATAS (Quick Wins)

1. ✅ Desinstalar skills genéricas innecesarias (`business-contract`, `tech-lawyer`, `agentmail`, `stripe-manager`)
2. ✅ Activar `disk-cleanup` plugin
3. ✅ Activar `moa` toolset
4. 🔄 Crear `/goal` para proyectos activos (Hackathon, Willow, Paola)
5. 🔄 Poblar `/kanban` con proyectos activos
6. 🔄 Revisar `/insights` para baseline de costos

---

*Documento generado después de corrección por Pablo*
*Principio: INTEGRACIÓN, no acumulación*
