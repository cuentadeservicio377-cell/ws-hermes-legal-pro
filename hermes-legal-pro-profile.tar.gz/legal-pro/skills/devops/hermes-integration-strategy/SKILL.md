---
name: hermes-integration-strategy
description: Estrategia de integración de features nativas de Hermes Agent con sistemas existentes de WS Capital. NO acumular skills genéricas del hub — integrar para amplificar. Usar cuando se necesite evaluar features, plugins, skills, o MCP servers para el laboratorio.
version: 1.0.0
author: Hermes Neo + Pablo
date: 2026-05-01
metadata:
  hermes:
    tags: [hermes, integration, strategy, ws-capital, features, skills-evaluation]
    category: devops
---

# Hermes Integration Strategy

## Principio Fundamental

> **INTEGRAR features nativas de Hermes para AMPLIFICAR nuestros sistemas superiores.**
> **NO acumular skills genéricas del hub que compitan con lo que ya construimos.**

---

## Lección Crítica (2026-05-01)

**Pablo corrigió:** Instalé `business-contract` y `tech-lawyer` del hub sin auditar que `willow-legal-complete` ya cubre todo (23 templates, 5 agentes, Kami v3, bridge API, modo standalone). Error de lógica: acumular en vez de integrar.

**Consecuencia:** Skills genéricas desinstaladas inmediatamente. Plan Maestro reescrito con lógica correcta.

---

## Nuestros Sistemas vs Hub Genérico

| Nuestro Sistema | Qué hace | Hub Genérico | Por qué el nuestro gana |
|-----------------|----------|-------------|------------------------|
| `willow-legal-complete` | Firma legal completa | `business-contract` + `tech-lawyer` | Motor Kami v3, 23 templates, 5 agentes, modo offline |
| `ws-video-studio-system` | Producción audiovisual | Cualquier skill de "content creation" | Dashboard v2.1, SmartCut, estructura 5 fases |
| `deep-research-system` | Investigación profunda | `scrapling` + `duckduckgo-search` | 4 agentes paralelos, Eugen Swarms |
| `ws-growth-director` | Director de growth | `ai-seo` + `content-strategy` | 5 piezas/semana, campañas, métricas |
| `ws-interconnected-ops` | Sistema nervioso | Cualquier skill de "productivity" | 7 departamentos, routing, handoffs, Excel PM |
| `onyx-lite-extension-pattern` | Extensión Onyx | `notion-api` genérica | Dominio legal propio, chat-first |

---

## Checklist: Antes de Instalar CUALQUIER Skill del Hub

1. **Auditar sistema propio:** ¿Ya tenemos una skill local que cubre esto?
2. **Evaluar relación:** ¿La skill del hub COMPLEMENTA o COMPITE?
3. **Pensar estratégicamente:** ¿Integración o acumulación?
4. **Verificar gap genuino:** ¿Llena algo que NO hemos construido?
5. **Si compite → NO instalar.** Usar nuestro sistema.
6. **Si complementa → Evaluar esfuerzo vs valor.**

---

## Cómo Cada Feature Nativa Amplifica Nuestros Sistemas

| Feature Hermes | Sistema que amplifica | Cómo |
|----------------|----------------------|------|
| `/goal` | Willow, Video, Growth | Persistencia de objetivos entre turns |
| `/background` | Deep Research, Video | Paralelismo para research y generación |
| `/model` | Build, Growth | Switch inteligente según tarea |
| `/branch` | Growth, Willow | Experimentos seguros |
| `/snapshot` + `/rollback` | Todos | Protección antes de cambios grandes |
| `/steer` | Todos | Corrección de dirección sin reiniciar |
| `/insights` | Admin & Ops | Control de costos por departamento |
| `/cron` | Todos | Automatización recurrente |
| `/kanban` | Todos | Visibilidad de pipeline |
| `/reasoning` | Todos | Eficiencia de tokens |

---

## Técnica de Instalación Headless

Cuando SÍ se necesite instalar una skill del hub (después de pasar el checklist):

```bash
# Para skills que requieren confirmación interactiva:
echo "y" | hermes skills install <identifier>

# Ejemplo:
echo "y" | hermes skills install official/email/agentmail
```

Esto evita que el prompt interactivo cancele la instalación en contextos no-TTY.

---

## Gaps Reales Identificados (Post-Auditoría)

1. **Goals no usados** — 3 proyectos activos, 0 goals persistentes
2. **Background jobs no usados** — Research bloquea conversación
3. **Kanban vacío** — Sin visibilidad de pipeline
4. **Snapshot/rollback no usado** — Sin protección
5. **MCP servers limitados** — Solo Railway
6. **Email no integrado** — `himalaya` sin configurar
7. **Plataformas limitadas** — Solo Telegram
8. **Insights no revisados** — Sin control de costos

---

## Plan de Integración por Fases

### Fase 1: Quick Wins (< 1 hora)
- Activar `disk-cleanup` plugin
- Activar `moa` toolset
- Crear `/goal` para proyectos activos
- Poblar `/kanban`
- Revisar `/insights`

### Fase 2: Esta Semana (1-4 horas)
- Configurar `himalaya` email
- Agregar GitHub MCP
- Usar `/background` para research
- Crear `/snapshot` antes de cambios

### Fase 3: Este Mes
- Agregar PostgreSQL MCP (queryear Onyx)
- Evaluar Slack gateway
- Crear skill `ws-goal-orchestrator`

---

## Archivos Relacionados

- `~/.hermes/PLAN-MAESTRO-INTEGRACION.md` — Plan completo v2.0
- `~/.hermes/HERMES-61-FEATURES.md` — Mapeo de 61 features
- `~/.hermes/PROJECTS.md` — Proyectos activos

---

*Versión: 1.0.0 | Creado: 2026-05-01 | Principio: INTEGRACIÓN, no acumulación*
