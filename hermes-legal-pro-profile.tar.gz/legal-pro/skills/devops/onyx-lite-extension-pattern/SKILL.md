---
name: onyx-lite-extension-pattern
description: Extend Onyx Lite with custom domain services using its native PostgreSQL and Docker network. Use for adding legal, sales, events, or any vertical on top of Onyx. Supports multi-instance deployments and local document generation.
trigger: When you need to build a backend module that extends Onyx Lite without modifying Onyx core code, or deploy multiple Onyx instances on the same host.
---

# Onyx Lite Extension Pattern

## Prerequisites
- Onyx Lite running in Docker (`onyx-stack-lite` compose project)
- PostgreSQL exposed on host port 5432 (or accessible inside Docker network)
- Python 3.11+ and `venv` available

## Architecture
```
Onyx Lite Container (localhost:3000)
  └── PostgreSQL (onyx-postgres:5432 inside Docker, localhost:5432 on host)

Domain Bridge API (FastAPI, localhost:3001+)
  └── Connects to PostgreSQL via Docker network or host port
  └── Shares DB namespace, uses prefixed tables (e.g., `legal_`, `events_`)
  └── Generates local documents (HTML/PDF) instead of cloud services
```

## Steps

### 1. Ensure PostgreSQL is reachable
```bash
docker ps | grep onyx-postgres
# If not exposing 5432, add port mapping or connect via Docker network
```

### 2. Create extension tables inside Onyx DB
Connect to Onyx PostgreSQL and create tables with a domain prefix (e.g., `legal_`, `events_`) to avoid collisions with Onyx native tables (`user_`, `chat_`, `persona`, etc.).

Key native tables to know:
- `user_project` — map to your domain "matters/cases/deals/events"
- `user_file` — map to domain "documents/evidence"
- `chat_session` — map to domain "conversations/threads"
- `persona` — map to domain "agents/roles" (seed domain-specific agents)

### 3. Scaffold FastAPI Bridge API
```bash
mkdir <domain>-bridge && cd <domain>-bridge
python3 -m venv venv && source venv/bin/activate
pip install fastapi uvicorn sqlalchemy psycopg2-binary python-dotenv
```

Create `main.py` with SQLAlchemy models prefixed by domain, CRUD routers, and document generation endpoints.

### 4. Multi-instance deployment (same host)
When running multiple Onyx instances (e.g., Willow legal on 3000 + Paola events on 3002):

**Critical: Set `HOST_PORT_80` in `.env` to avoid nginx port 80 conflicts:**
```bash
# In docker-compose .env for the second instance
echo "HOST_PORT_80=82" >> .env
echo "HOST_PORT=3002" >> .env
```

**Port mapping strategy:**
| Instance | Onyx Web | Onyx API | Postgres | Nginx | Bridge API |
|----------|----------|----------|----------|-------|------------|
| First (Willow) | 3000 | 8080 | 5432 | 80 | 3001 |
| Second (Paola) | 3002 | 8082 | 5433 | 82 | 3003 |

**Docker compose overlay pattern:**
```yaml
# docker-compose.<domain>.yml
name: <domain>
services:
  api_server:
    ports: ["8082:8080"]
  web_server:
    ports: ["3002:3000"]
  relational_db:
    ports: ["5433:5432"]
  nginx:
    ports: []  # Or ["82:80"] if needed
```

Run with:
```bash
cd onyx/deployment/docker_compose
docker compose -f docker-compose.yml -f docker-compose.onyx-lite.yml \
               -f /path/to/docker-compose.<domain>.yml up -d
```

### 5. Bridge API in Docker with template assets
When the bridge API needs file templates (e.g., Kami HTML templates for document generation):

**Dockerfile must COPY templates:**
```dockerfile
COPY runtime/<domain>_api.py /app/
COPY runtime/document_generator.py /app/
COPY references/kami/templates /app/references/kami/templates
```

**Update template paths for container:**
```python
# In document_generator.py
KAMI_TEMPLATES_DIR = Path("/app/references/kami/templates")  # Inside container
```

**Volume mount for generated documents:**
```yaml
volumes:
  - "/mnt/c/Users/.../Paola Meneses Decoracion:/mnt/c/Users/.../Paola Meneses Decoracion"
```

### 6. Build cache gotcha
Docker build caching may hide changes. If endpoints aren't updating:
```bash
# Option 1: Build without cache
docker compose build --no-cache paola_bridge

# Option 2: Copy files directly into running container
docker cp ./runtime/paola_api.py paola-bridge-api:/app/paola_api.py
docker restart paola-bridge-api
```

### 7. Document generation (local, no cloud)
Replace Google Workspace/Drive/Sheets with local HTML documents using Kami or similar templates:

```python
def generate_cotizacion(event_data: dict, elements: list, total: int) -> dict:
    template = KAMI_TEMPLATES_DIR / "letter-en.html"
    variables = {
        "LETTER_SUBJECT": f"Cotizacion — {event_data['client_name']}",
        "BODY": f"...",
        # Fill all {{PLACEHOLDERS}}
    }
    html_content = fill_template(template, variables)
    output_path = PAOLA_BASE_DIR / "Cotizaciones" / safe_name / "Cotizacion.html"
    output_path.write_text(html_content)
    return {"html_path": str(output_path)}
```

**Kami design system colors:**
- Parchment: `#f5f4ed` (page background)
- Ink-blue (brand): `#1B365D` (accent, CTA, title bars)
- Serif: Newsreader / Source Serif 4
- Sans: Inter

### 8. Seed domain agents as Onyx personas
```sql
INSERT INTO persona (name, deleted, description, is_listed, is_public, builtin_persona, system_prompt, starter_messages, datetime_aware, replace_base_system_prompt)
VALUES (
    'Ventas Paola', false, 'Ejecutivo comercial', true, true, false,
    'Eres el agente de Ventas... Genera documentos locales via POST /api/paola/events/{id}/documents/generate-cotizacion',
    '[{"name":"Hola","message":"En que puedo ayudarte?"}]'::jsonb,
    true, false
);
```

### 9. Validation checklist
- [ ] Onyx Lite loads at configured port (e.g., localhost:3002)
- [ ] No nginx port 80 conflicts with existing instances
- [ ] Extension API responds at its port
- [ ] Extension tables visible in PostgreSQL
- [ ] Document generation creates HTML files locally
- [ ] Agent personas appear in Onyx chat selector
- [ ] Create/read operations work end-to-end

## Pitfalls
- **Do not modify Onyx native tables directly** — extend via foreign keys or separate prefixed tables.
- **Port collisions** — Onyx nginx binds to 80 and 3000 by default via `HOST_PORT_80` and `HOST_PORT`. Always set these in `.env` for additional instances.
- **Auth** — Onyx Lite auth is local. For production, align JWT or session auth between Onyx and extension.
- **Build inside Docker** — `next build` must run inside the Onyx container, not on WSL directly.
- **Docker build cache** — Changes to `paola_api.py` may not reflect without `--no-cache` or manual `docker cp`.
- **Template paths inside container** — Paths must match between local dev (`/mnt/c/...`) and container (`/app/...`).
- **Volume mounts on WSL** — Windows paths via `/mnt/c/` work but require explicit volume declarations in docker-compose.

## Example domain mappings

### Legal (Willow)
| Onyx native | Legal domain |
|-------------|--------------|
| user_project | willow_legal_matter |
| chat_session | legal_activities |
| persona | Despacho Legal, Intake Legal, Biblioteca Legal |

### Events (Paola)
| Onyx native | Events domain |
|-------------|---------------|
| user_project | paola_event |
| chat_session | event_operations |
| persona | Ventas Paola, Operaciones Paola, Finanzas Paola |

### Generic pattern
| Onyx native | Your domain |
|-------------|-------------|
| user_project | `<prefix>_project` / `<prefix>_deal` |
| chat_session | `<prefix>_thread` |
| persona | `<prefix>_<role>` (seed with domain system_prompt) |
| user_file | `<prefix>_document` |