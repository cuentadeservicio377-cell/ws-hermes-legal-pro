---
title: Local Server Screenshot Delivery
name: local-server-screenshot-delivery
description: When a locally-running web server/dashboard needs to be shown to a user who cannot access it directly (away from computer, no public URL, deploy failed). Verify server status, capture screenshots of all key views via headless browser, and deliver via Telegram.
trigger: User says "muéstrame el sistema", "quiero ver el dashboard", "toma screenshot", or any request to see a local web app when no public URL is available. Also trigger when Railway/deploy fails and user needs immediate visual confirmation of the local system.
---

# Local Server Screenshot Delivery

## When to Use
- Local web server is running but user has no visual access
- Public deploy (Railway, etc.) failed or is unavailable
- User needs immediate screenshots of dashboard/system views
- User is away from computer or cannot open browser

## Steps

### 1. Verify Server Status
```bash
curl -s http://localhost:<PORT>/api/health 2>/dev/null || echo "No responde"
```
- Check common ports: 8080, 3000, 8000, 5000
- If not running, start the server in background:
```bash
cd <PROJECT_DIR> && python3 <APP_FILE> 2>&1 &
```
- Wait 3-5 seconds, re-check health endpoint

### 2. Discover Available Endpoints
- Check `api/health` for version/routes info
- Common patterns to screenshot:
  - `/` — main dashboard
  - `/api/dashboard` — data overview
  - `/api/eventos` or `/api/items` — list views
  - `/api/evento/<ID>` — detail views (use first real ID)
  - `/api/finanzas` or `/api/stats` — analytics
- If unsure, read the main app file to find routes

### 3. Capture Screenshots (Playwright)
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1920, 'height': 1080})
    
    # Screenshot each endpoint
    for endpoint, name, path in [
        ("http://localhost:8080/", "dashboard", "/tmp/01_dashboard.png"),
        # add more endpoints
    ]:
        page.goto(endpoint)
        page.wait_for_timeout(3000)  # wait for JS rendering
        page.screenshot(path=path, full_page=True)
    
    browser.close()
```
- Install Playwright if missing: `pip install playwright && playwright install chromium`
- Use `full_page=True` to capture entire scrollable content
- Wait at least 3s for JavaScript dashboards to render

### 4. Deliver via Telegram
- Send each screenshot with `MEDIA:/tmp/...` in the message
- Label each image clearly (Dashboard, Eventos, Finanzas, etc.)
- If chat migrated to supergroup, use `telegram:-100<CHAT_ID>`

## Pitfalls
- **Port already in use**: Check with `lsof -i :8080` or `ss -tlnp | grep 8080`
- **Playwright not installed**: Install both Python package AND browser binaries
- **Headless rendering issues**: Some SPAs need extra wait time; increase `wait_for_timeout` to 5s if content blank
- **Telegram supergroup migration**: If send fails with "migrated to supergroup", retry with `-100` prefix on chat_id
- **Large screenshots**: Telegram may compress; for critical detail, capture at 1920x1080 minimum

## Variations
- For API-only endpoints (JSON), screenshot the browser showing formatted JSON
- For auth-required pages, may need to script login flow first
- If Playwright unavailable, fallback to `wkhtmltoimage` or `chromium --screenshot` CLI
