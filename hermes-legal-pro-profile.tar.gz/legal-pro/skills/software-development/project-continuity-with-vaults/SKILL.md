---
name: project-continuity-with-vaults
description: Run long, iterative product projects without losing continuity by anchoring on repo docs + dedicated Obsidian vault + session recall, and avoid over-engineering cron when direct execution is the real bottleneck. Includes recovery protocol for interrupted sessions where user reports context loss or incorrect execution.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [continuity, planning, obsidian, long-running-projects, ws-neo, execution]
---

# Project Continuity with Vaults

Use this when a project is long, iterative, easy to derail by context compression, and the user wants reliable continuity without repeatedly re-explaining the system.

## When to use

Use this skill when:
- the project spans many sessions
- repo code, plans, and product direction are evolving together
- the user explicitly fears memory loss / drift / forgetting prior architecture
- there are multiple sources of truth (repo, vaults, operating contract, session history)
- the temptation exists to solve continuity with scheduled cron summaries instead of real execution

## Core principle

Continuity should live in **artifacts**, not in a single chat session.

The most reliable stack is usually:
1. repo-local plan docs
2. a dedicated Obsidian project vault
3. closeout / checkpoint notes
4. session_search for recall
5. direct implementation turns

Cron jobs are optional. They are useful only if they produce meaningful work or evidence. If they become passive summaries that do not move the project, remove them.

### Alternative anchor: PROJECTS.md

If the project is smaller or the user prefers a lightweight approach, a single `PROJECTS.md` file in `~/.hermes/` can serve as the master project state document:
- **At session start:** Read `PROJECTS.md` for context
- **At session close:** Update `PROJECTS.md` with current status
- **Structure:** Projects activos (P1/P2/P3), qué se hizo, qué NO se hizo, bloqueos

This is a lighter alternative to full vault-based continuity. Use vaults for long, multi-source projects; use PROJECTS.md for simpler tracking.

**Critical hygiene rule for PROJECTS.md:** When a project is cancelled or reverted, do NOT leave it in the "Proyectos Activos" section with a "CANCELADO" badge. Move it to a dedicated **"Proyectos Cancelados / Deprecados"** section at the bottom of the file, or remove it entirely. Leaving cancelled projects mixed with active ones contaminates the system — every session start reads the file and sees dead projects as if they were live, which wastes context tokens and creates confusion.

**Example bad pattern (DO NOT DO THIS):**
```markdown
## 📋 PROYECTOS ACTIVOS
### ⚫ P1: HERMES-MAX — PROYECTO FALLIDO / CANCELADO
```

**Example good pattern:**
```markdown
## 📋 PROYECTOS ACTIVOS
### 🔴 P1: Reparación Sistema Hermes
### 🟢 P2: Paola Meneses

---

## 🗑️ PROYECTOS CANCELADOS
### HERMES-MAX — Cancelado 1 Mayo 2026
- Razón: goal abstracto sin entregables medibles
- Lección: no crear proyectos de "perfección del sistema"
```

## Proven approach

### 1) Re-anchor before acting
Before designing continuity, recover the real architectural anchor from:
- session_search
- key repo plans
- the user’s vault/system notes
- any contract-operativo docs

Do not invent a fresh project narrative if an earlier one already exists.

### 2) Create a dedicated project vault early
Make a dedicated vault/folder for the project with notes such as:
- README / project hub
- master delivery plan
- architecture anchor
- phase tracker
- audit notes
- checkpoints / closeouts
- contract update queue

This vault should answer:
- what this project is
- what architecture anchors it
- what phase it is in
- what changed last
- what remains

### 2a) Create a `CONTINUITY.md` at the repo root
In addition to the external vault, create a **repo-local `CONTINUITY.md`** at the project root. This file is the single source of truth any future agent instance can read to reconstruct state without relying on chat memory.

Required content:
- **Current phase** and what it means
- **Last checkpoint** (date + git hash)
- **Runtime health** (URLs, container names, expected responses)
- **DB schema summary** (key tables and their purpose)
- **Git recovery rules** (commit message pattern, what must be committed before pausing)
- **Recovery script** (ordered validation steps)

Example structure:
```markdown
# Project X — Sistema de Continuidad

## Estado Actual
| Campo | Valor |
|---|---|
| Fase activa | 3B — Package generation |
| Último checkpoint | 2026-04-23 14:00 — git abc1234 |
| API health | localhost:3001/api/health → ok |
| Containers | 7/7 up |
| DB tables | matter, template, package, package_item |

## Fases
| Fase | Estado | Artifact |
|---|---|---|
| 1 | ✅ | docs/phase-1.md |
| 2 | ✅ | docs/phase-2.md |
| 3 | 🔄 | docs/phase-3-spec.md |

## Recovery
1. Leer este archivo
2. `docker ps` + `curl` health
3. `git log --oneline -5`
4. `docker exec ... psql -c "\dt"`
```

Update `CONTINUITY.md` at the end of every session and include it in the final commit. This makes the repo self-describing even if the vault is unreachable.

### 3) Keep the repo plan and the vault in sync
For every major shift, update both:
- repo-local plan docs (`docs/plans/...`)
- vault notes

Common failure mode: the code and vault move forward, but the plan still reflects an abandoned strategy (for example, cron-heavy continuity after the project has switched to direct execution).

### 4) Prefer direct execution over continuity theater
If the user’s real goal is "finish the work," do not let continuity tooling become the work.

Signs of continuity theater:
- too many cron jobs
- passive checkpoint summaries
- lots of planning, little implementation
- the user says "this didn’t execute anything"

When that happens:
- remove or simplify cron jobs
- switch to direct execution by phases
- use the vault and repo docs as memory, not cron as a substitute for progress

### 5) Use short, evidence-based phase blocks
A good project rhythm is:
- define 3–5 phases
- give each an initial small time box
- require visible partial results
- re-estimate based on real throughput, not fake long-hour guesses

The point is not the exact hour count — it is making every phase produce evidence.

### 6) Classify state honestly
When continuity is drifting, explicitly classify each requirement as:
- already implemented
- implemented but poorly exposed
- implemented but poorly bound to runtime/context
- not implemented yet

This avoids the common mistake of re-planning work that already exists.

### 7) Rebuild context from artifacts when needed
If continuity is lost, rebuild from this order:
1. current repo plan
2. latest closeout/checkpoint docs
3. dedicated vault project hub
4. contract/drift notes
5. live repo state (`git status --short`, `git diff --stat`)
6. session_search

Do not trust memory alone on long-running product work.

## What to avoid

- using cron as the primary mechanism for execution when the user wants direct progress
- keeping stale strategy notes after the method changes
- treating the project as if it starts from zero in every session
- overestimating work in abstract hours when small evidence-based blocks are better
- forgetting to preserve the architecture anchor in both repo docs and vault notes
- **leaving cancelled/reverted work in active project lists** — this creates "zombie projects" that consume context and confuse future sessions. Always move cancelled work to a "Cancelled" section or delete it
- **leaving references to deleted skills/tools in documentation** — if a skill was removed (e.g., `ws-system-context-injector`), scrub all references from PROJECTS.md, MEMORY.md, checkpoints, and closeouts. Otherwise future sessions will try to load a non-existent skill
- **keeping rigid "protocols of initiation" with 10-step checklists** — these turn the agent into a mechanical robot. Prefer fluid, context-aware behavior. If the user complains the system feels "like a chatbot" or "too mechanical," the protocol is too rigid and must be simplified or removed

## Additional lesson: dev-flow upgrades need an audit trail

When a long project keeps breaking due to continuity/process drift, the user may want to upgrade the **development flow itself** before continuing the product work.

A reusable pattern is:
1. install the candidate tooling (for example Hermes plugins or external orchestration CLIs)
2. verify what actually installed and whether it is genuinely functional
3. record the result in both the repo plan and the dedicated project vault
4. tag the project with the new flow so future audits use the same assumptions

### Important caution
Do **not** assume every Git repo installs cleanly as a real Hermes plugin.

If `hermes plugins install ...` warns that the repo lacks `plugin.yaml` / `__init__.py`, treat it as:
- an installed reference/fork
- a runtime layer to audit carefully
- **not** a fully trusted Hermes plugin yet

Record that distinction explicitly in project docs so future sessions do not overstate what is active.

### Good pattern for long projects
Use a local-first shared-state tool (for example Maestro) when the project needs:
- mission structure
- handoffs
- persistent local state outside chat memory
- a disciplined workflow for fresh sessions

Then update the project plan/vault with a flow tag such as:
- `flow: camel+maestro-audited`

This makes the execution method itself part of the source of truth.

## Good outcome

A successful continuity setup means:
- the project survives context compression
- the repo and vault tell the same story
- the current phase and next move are obvious
- implementation can resume from artifacts, not memory
- the user does not need to restate the architecture every time

## Phase-completion pattern learned from Willow

For long, phased migrations, close each phase with the same artifact loop:
1. write the new phase spec into the repo plan set
2. mirror the same note into the project vault
3. update the implementation ledger/status table
4. update the active todo/task list
5. verify the mirror exists in both places before moving on

This pattern prevents a common failure mode: a phase being "done" in chat but not reflected in the durable artifacts that future sessions will use.

When a phase has both a repo artifact and a vault mirror, treat that as the source of truth for continuation after compaction.

## Ambiguous "continue" with multiple parallel projects

When the user says "continue" or similar without specifying a topic, and multiple long-running projects may be in flight, do not guess. Use this recovery pattern:

1. **Acknowledge the ambiguity** — tell the user you need to validate state because the session was compressed or context was lost.
2. **Search session history** — run `session_search` with both recent (no query) and keyword queries for each known active project. Look for the most recent sessions and their summaries.
3. **Map memory macros to filesystem** — cross-reference the project names you remember (e.g., "Willow/Onyx", "Workspace", "OpenCode flows") with actual directories in `~/Documents/repos/projects/active/`, `~/Documents/repos/research/`, or the user's known project roots.
4. **Read checkpoint files** — look for vault/checkpoint folders (e.g., `Documents/WS Capital/Willow Vault/02_Checkpoints/`, `docs/` inside repos) and read the latest dated files. These are the ground truth for what was actually accomplished.
5. **Validate service state** — if projects involve running services (Docker containers, APIs, dev servers), do quick health checks (`docker ps`, `curl` health endpoints) to confirm what is actually live vs. what was planned.
6. **Synthesize a status table** — present each project with an honest status:
   - What's LIVE / DONE (with evidence)
   - What's PARTIAL (started but incomplete)
   - What's PENDING (planned but not started)
   - What's STALLED (blocked or deprioritized)
7. **Offer a ranked choice** — let the user pick which project to continue, rather than assuming.

**Lesson from 2026-04-23:** The user said "Continúa" expecting progress on Willow/Onyx, but the agent had only macro-level memory of 4 parallel projects. By searching sessions, reading checkpoint files (`Willow - functional legal surface 2026-04-23.md`, `Willow - nvidia models configured 2026-04-23.md`), and inspecting repos, the agent discovered that Willow/Onyx was actually near-complete (NVIDIA models configured, chat functional, legal API running), while Hermes Workspace was installed but unvalidated, and OpenCode/infra items were stalled. This prevented the agent from restarting work that was already done.

## Session rescue after compaction (checkpoint + vault reconstruction)

When a session is compacted with a system rescue checkpoint (e.g., backend failure), the recovery order is:
1. read the rescue checkpoint summary for the stated next step
2. search the filesystem for the project's dedicated vault folders (common locations: `Documents/WS Capital/`, `Documents/repos/projects/active/`, `~/vaults/`)
3. read the latest checkpoint/backlog files in this priority order:
   - latest checkpoint (e.g., `checkpoint YYYY-MM-DD`)
   - backlog/status file
   - master plan / migration map
   - most recent implementation plan or standalone spec
   - runtime spec or operational contract
4. **audit the repo filesystem for existing code** — this is critical:
   - `git status --short` to find untracked or modified files
   - `git log --oneline -20` to see what was committed before the failure
   - `find <project-dirs> -type f -newer <last-checkpoint-date>` or simply list key source directories
   - look for files that match the project naming convention but are not in `git log`
5. present a reconstructed status table to the user before asking for the next move

**Critical lesson from Willow/Onyx recovery (2026-04-22):**
After an OpenAI backend failure that compacted ~730 messages, the rescue checkpoint said "Phase 1 in progress." A filesystem audit of the Onyx repo revealed that blocks 1-5 of a 7-block frontend plan were **already written as untracked files** (`web/src/app/app/legal/`, `web/src/sections/legal/`, `web/src/refresh-pages/Legal*Page.tsx`) with ~2,500+ lines of real code, mock data, and sidebar integration. None of it had been committed or validated. Without the filesystem audit, the agent would have tried to rebuild work that already existed, wasting the user's time and trust.

Always verify `git status` and key directories before concluding that work "hasn't been started yet."

This avoids restarting from zero and respects the user's prior work.

## Recovery after manual gateway reset (user-provided last state)

When the user says they had to reset the gateway manually and pastes their last message or checkpoint as context, treat that pasted text as a **hypothesis to validate**, not as guaranteed current state.

**Recovery sequence:**

1. **Accept the pasted context** — extract from it: project name, phase, claimed completed work, and intended next step. This is your starting hypothesis.

2. **Run the full multi-source audit anyway** — do not skip session_search, filesystem inspection, or runtime validation just because the user provided a memory fragment. The reset may have happened hours or days ago; disk state may have diverged.

3. **Validate the hypothesis against reality** — check specifically:
   - Does the claimed phase match checkpoint files on disk?
   - Do the claimed endpoints/services respond as expected?
   - Are there commits, files, or DB rows that confirm (or contradict) the user's memory?

4. **Distinguish old repos from active repos** — in long-running projects, abandoned or superseded codebases often linger (e.g., `/root/willow-paperclip-run/` vs `/mnt/c/Users/DELL/Documents/repos/projects/active/willow-hermes-onyx/`). The Docker container mounts and `docker inspect` are the ground truth for which source directory is actually live.

5. **Report honest deltas** — if the user's memory matches reality, confirm it confidently. If it doesn't, show the discrepancy before proposing next steps.

**Lesson from Willow/Onyx recovery (2026-04-23):**
The user reset the gateway manually and pasted: "Fase 2A completada... Sigo con Fase 2B." The agent validated this by:
- Finding the active repo was at `willow-hermes-onyx/runtime/` (not the old `willow-paperclip-run/`)
- Confirming `GET /api/legal/templates` returned 23 active templates
- Reading the vault checkpoint `Willow - checkpoint fase 2A biblioteca viva 2026-04-23.md`
- Discovering that Fase 2B had **not** been started (no compounding tables or endpoints existed yet)
- Presenting a clean status table showing exactly what was done vs. what remained

This prevented the agent from assuming Fase 2B was already in progress and allowed the user to resume from the correct starting line.

## Runtime state validation after compaction (multi-source audit)

When the user says "continue" or references a project after context compression, do not rely on macro-level memory alone. Perform a **multi-source runtime audit** to reconstruct the true state before proposing next steps.

**Audit sequence:**

1. **Session search** — run `session_search` in parallel with:
   - no query (recent sessions) to find the most recent active work
   - keyword queries for each known active project (e.g., `onyx OR willow`, `workspace OR "company OS"`, `opencode OR build`)
   - this recovers what was discussed, decided, and completed in recent sessions

2. **Filesystem mapping** — cross-reference remembered project names with actual disk state:
   - `ls` on `~/Documents/repos/projects/active/` or equivalent
   - `find` for key files (e.g., `package.json`, `night-run-master-plan.md`, `legal_api.py`)
   - `git log --oneline` and `git status` in relevant repos
   - this reveals what exists on disk vs. what was only planned in chat

3. **Checkpoint file reading** — look for dated checkpoint/status files in vaults or repo docs:
   - common locations: `Documents/<Project> Vault/02_Checkpoints/`, `<repo>/docs/`, `<repo>/runtime/`
   - read the latest files (sort by date in filename or mtime)
   - these contain the ground truth of what was accomplished

4. **Service/runtime validation** — if the project involves running services, verify what is actually alive:
   - `docker ps` for container status, uptime, and port mappings
   - `curl` health endpoints to confirm APIs respond
   - `docker exec ... psql` or equivalent to query database state (row counts, configured providers, seeded data)
   - this distinguishes "was configured" from "is currently running"

5. **Source documentation review** — when the user references original specs or source repos, read them:
   - original agent specs (`.md` files in `company/workspace/agents/`)
   - architecture docs (`ARQUITECTURA.md`, `PARA-ABOGADOS.md`)
   - gap audits (`Paperclip vs Onyx gap audit.md`)
   - this recovers intent and scope that may not be in session summaries

6. **Synthesize an honest status table** — present each project with evidence-based status:
   - 🟢 **LIVE / DONE** — with concrete evidence (container running, DB rows, API response, checkpoint file)
   - 🟡 **PARTIAL** — started but incomplete, with specific gaps noted
   - ❌ **PENDING** — planned but not started
   - ⏸️ **STALLED / PAUSED** — blocked, deprioritized, or explicitly on standby

7. **Offer ranked choices** — let the user pick the next project/move rather than assuming.

**Critical lesson from Willow/Onyx recovery (2026-04-23):**
The user said "Continúa" expecting progress on Willow/Onyx. The agent only had macro-level memory of 4 parallel projects. By executing steps 1-6 above, the agent discovered:
- Willow/Onyx was **near-complete**: NVIDIA provider configured, 4 Llama models active, 3 legal agents seeded, 1 real matter in DB, chat sessions functional, Legal API responding, all 7 containers up for 11+ hours
- Hermes Workspace was **installed but unvalidated** (repo present, no runtime evidence)
- OpenCode flows were **repaired but stalled** (smoke test OK, no recent execution)
- Infra items (Whisper, gateway) were **not configured**

This prevented the agent from restarting work that was already done and allowed the user to confidently deprioritize stalled projects and focus on Willow/Onyx.

## Honest scope management after repeated incomplete delivery

When the user has experienced long tasks that "don't complete" or "get unstructured," they may ask for everything at once (e.g., "do all 7 blocks in one session, perfectly divided"). Do not promise this.

Instead:
1. Acknowledge the frustration directly
2. Explain why one giant run fails (context limits, inability to validate without human eyes, hidden blockers)
3. Propose **milestone-based delivery with hard checkpoints**:
   - each milestone has a single deliverable
   - each milestone requires user validation before proceeding
   - each milestone produces a commit + checkpoint note
   - if a milestone fails, it is isolated and does not cascade
4. Let the user choose the next milestone rather than forcing a linear plan

The user is more likely to trust a system that delivers visible, validated chunks than one that promises everything and disappears into a long run that may crash or compress.

## Notes from experience

- A dedicated vault is more valuable than a pile of scheduled summaries.
- Cron jobs are only worth keeping if they create real evidence or real movement.
- When the user says "just finish it," simplify the continuity layer and execute directly.
- Long projects drift most often because the method changes but the documentation does not; always update the plan and vault together.

## Revert and cleanup hygiene

When a project, skill, or system component is cancelled or reverted, the cleanup must be **complete and verified**. Partial cleanup leaves "ghost references" that contaminate future sessions. See `references/revert-cleanup-session-2026-05-01.md` for a real case study of incomplete cleanup and its consequences.

### Complete revert checklist

After cancelling a project or reverting a system change:

1. **Remove from active project lists** — PROJECTS.md, any dashboard, any active todo list
2. **Scrub all documentation** — MEMORY.md, SOUL.md, checkpoints, closeouts, any file that mentions the cancelled item
3. **Delete or archive skills** — if a skill was created for the cancelled project, move it to `.archive/` or delete it entirely
4. **Remove cron jobs** — any scheduled job tied to the cancelled project must be deleted
5. **Verify no references remain** — search the entire `~/.hermes/` directory for the cancelled project name, skill name, or related keywords. References in session logs are OK (historical), but references in active docs are NOT
6. **Update the narrative** — replace "creado/verificado/activo" language with "cancelado/revertido/eliminado" in any document that must reference the item for historical reasons

### Common partial-cleanup failure modes

- **The "cancelled but listed" pattern:** Project marked "CANCELADO" but still appears in "Proyectos Activos" section. This wastes context and creates confusion about what is actually live.
- **The "ghost skill" pattern:** Skill was deleted from `skills/` but is still referenced in PROJECTS.md or MEMORY.md. Future sessions will try to load it and fail.
- **The "rigid protocol" pattern:** A 10-step "Protocolo de Inicio" was created to force continuity, but the user complains the system feels mechanical. The protocol must be simplified or removed — not just updated.
- **The "stale capability" pattern:** MEMORY.md says subagentes use `gpt-5.3-codex` but the actual config was changed to `gpt-5.4-mini`. The doc and reality drift apart.
- **The "checkpoint ghost" pattern:** SESSION_CHECKPOINT files still describe cancelled skills as "creado, instalado, verificado" even after the skill was deleted. If these checkpoints are read at session start, they reinject false state.

### Verification command

After any revert, run this search to confirm cleanliness:
```bash
# Search for references in active docs (not logs/sessions)
grep -r "CANCELLED_PROJECT_NAME" ~/.hermes/*.md ~/.hermes/*.yaml 2>/dev/null || echo "Clean"
```

If results appear in active files, the cleanup is incomplete.

## Runtime debugging patterns (from Willow Legal implementation)

When implementing a FastAPI/SQLAlchemy runtime on PostgreSQL inside Docker, these specific pitfalls were encountered and resolved:

### PostgreSQL array literals with SQLAlchemy `text()`
When binding JSON arrays or Python lists to PostgreSQL `INTEGER[]` columns via SQLAlchemy `text()`, **do not** pass `json.dumps([])`. PostgreSQL expects a native array literal like `{}` or `{1,2}`. SQLAlchemy handles Python lists correctly for array columns when passed directly.

**Wrong:** `{"depends_on": json.dumps([])}`
**Right:** `{"depends_on": []}`

### Missing `updated_at` columns on schema-migration tables
When using `ensure_*_schema()` helpers that run `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`, remember that `UPDATE ... SET updated_at = NOW()` will fail if `updated_at` was never added. Include it in the schema helper alongside functional columns.

### SQLAlchemy text() string concatenation with parameters
Do not mix PostgreSQL `|| :param::text` string concatenation with SQLAlchemy `text()` parameter binding. SQLAlchemy may fail to parse the `::text` cast inside the string literal. Use Python f-strings or compute the value in Python before binding.

**Wrong:** `source_note = 'Updated from proposal ' || :proposal_id::text`
**Right:** `source_note = :source_note` with `"source_note": f"Updated from proposal {proposal_id}"`

### Finding the real source directory via Docker mounts
In long-running projects with multiple repo clones, the Docker container may mount from a directory different from where you are editing. Use `docker inspect <container> --format='{{range .Mounts}}{{.Source}} -> {{.Destination}}{{println}}{{end}}'` to find the **actual live source directory** before editing files that won't be picked up by the container.

**Lesson:** The agent edited `/root/willow-paperclip-run/` for several turns before discovering via `docker inspect` that `willow-legal-api` actually mounted from `/mnt/c/Users/DELL/Documents/repos/projects/active/willow-hermes-onyx/runtime/`. All edits were applied to the wrong directory until this check was performed.

## Git commit conventions for phased projects

When executing a multi-phase master plan, use a strict commit message pattern so that `git log` becomes a readable ledger of progress:

```
WILLOW-PLAN:   Fase X spec + CONTINUITY.md           ← planning/spec phase
WILLOW-PHASE-X: Feature description — YYYY-MM-DD     ← implementation
WILLOW-PHASE-X: Validated + CONTINUITY updated       ← validation gate
WILLOW-FINAL:  All phases completed — YYYY-MM-DD     ← final signoff
```

Rules:
- Never leave changes unstaged before a pause
- Always include `CONTINUITY.md` in the final commit of each session
- If a model interruption occurs, the next instance can read `git log --oneline -10` and know exactly where work stopped

## When Onyx ingestion API is unavailable (DISABLE_VECTOR_DB)

Onyx may have `DISABLE_VECTOR_DB=true`, which causes `/onyx-api/ingestion` to return:
```json
{"detail": "This feature requires a vector database (DISABLE_VECTOR_DB is set)."}
```

When this happens, do not treat it as a blocker. Build a **local knowledge retrieval layer** directly in the project's API:

1. Create a table (e.g., `willow_legal_knowledge`) with `source_path`, `document_set`, `title`, `content`, `metadata`
2. Add a GIN index on `to_tsvector('spanish', coalesce(title,'') || ' ' || coalesce(content,''))` for full-text search
3. Build endpoints:
   - `POST /knowledge/document` — single-document upsert
   - `POST /knowledge/ingest` — batch ingest from filesystem
   - `GET /knowledge/search?q=...` — ranked search with `ts_rank`
   - `GET /knowledge` — list all entries
4. Write an external ingest script (e.g., `scripts/ingest-vault.py`) that walks the Vault directory and POSTs each `.md` file to the API
5. Wire a "Knowledge" tab into the SPA that calls the search endpoint

This bypasses Onyx's vector dependency entirely while giving agents the same semantic: searchable, durable knowledge from the Vault.

**Validation:** After ingest, query with `?q=contract+drafting` and confirm the correct playbook is returned with a non-zero `rank`.
