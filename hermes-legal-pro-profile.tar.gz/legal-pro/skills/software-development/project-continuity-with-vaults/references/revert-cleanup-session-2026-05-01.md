# Revert Cleanup Session — 2026-05-01

## Context

Pablo había pedido revertir "Hermes Max" en una sesión anterior (2026-05-01 ~02:00). En esta sesión posterior (~10:00) descubrió que la limpieza fue **parcial** — quedaron múltiples referencias contaminando el sistema.

## What was supposedly cleaned

- Skill `ws-system-context-injector` — eliminado
- Cron job "Hermes-Max — Mapeo de Skills" — eliminado
- Archivos `HERMES-MAX-DIARIO-2026-05-01.md` y `HERMES-MAX-MONOLOGO.md` — eliminados
- `PROJECTS.md` — marcado como "CANCELADO" pero **NO removido de la sección activa**

## What was NOT cleaned (discovered in this session)

### 1. PROJECTS.md — "zombie project" pattern
- HERMES-MAX seguía listado como `### ⚫ P1: HERMES-MAX` en la sección "PROYECTOS ACTIVOS"
- Aunque decía "CANCELADO", su presencia en la sección activa contaminaba cada lectura
- También mencionaba el skill `ws-system-context-injector` como "creado, instalado, verificado"

### 2. MEMORY.md — rigid protocol still present
- Líneas 189-204: "PROTOCOLO DE INICIO DE SESIÓN (Obligatorio)" con 10 pasos rígidos
- Este protocolo fue exactamente lo que Pablo identificó como el problema que convertía a Hermes en "robot mecánico"
- En la sesión de ~02:00 se había reescrito SOUL.md para eliminar este comportamiento, pero MEMORY.md no fue actualizado

### 3. MEMORY.md — stale subagent model
- Línea 148: decía "Modelo: gpt-5.3-codex" pero la config real era `gpt-5.4-mini`
- Cambiado en sesión de reparación del 30abr pero no reflejado en MEMORY.md

### 4. SESSION_CHECKPOINT_2026-04-30.md — ghost references
- Seguía mencionando `ws-system-context-injector` como "creado, instalado, verificado"
- Checkpoint histórico pero potencialmente leído al inicio de sesión

### 5. Skill archivado — subagent-environment-context
- En `.archive/subagent-environment-context/` — skill que fue reemplazado
- Aunque archivado, podría confundir si alguien lo encuentra

## Cleanup performed in this session

1. Identificado el problema como "contaminación por revert incompleto"
2. Documentado cada referencia huérfana
3. **Aprobado por Pablo** — limpieza ejecutada:
   - HERMES-MAX removido de "PROYECTOS ACTIVOS" en PROJECTS.md, movido a "PROYECTOS CANCELADOS"
   - Referencias a `ws-system-context-injector` eliminadas de PROJECTS.md y SESSION_CHECKPOINT_2026-04-30.md
   - "PROTOCOLO DE INICIO DE SESIÓN (Obligatorio)" con 10 pasos reemplazado por nota fluida en MEMORY.md
   - Modelo de subagentes actualizado de `gpt-5.3-codex` a `gpt-5.4-mini` en MEMORY.md
   - Skill archivado `subagent-environment-context` eliminado de `.archive/`
   - Verificación final confirmó: 0 referencias activas contaminadas
4. Actualizada la skill `project-continuity-with-vaults` con:
   - Sección "Revert and cleanup hygiene"
   - Patrones de falla comunes de cleanup parcial
   - Regla crítica para PROJECTS.md
   - Comando de verificación post-revert

## Lessons for future reverts

- **NUNCA marcar como "CANCELADO" sin remover de la sección activa**
- **SIEMPRE buscar referencias en MEMORY.md y SOUL.md**, no solo en PROJECTS.md
- **SIEMPRE verificar con `grep -r` en `~/.hermes/*.md`** después de cualquier revert
- **Actualizar TODOS los archivos de estado**, no solo el principal
- Los checkpoints históricos (SESSION_CHECKPOINT_*) son menos críticos pero deben ser considerados
