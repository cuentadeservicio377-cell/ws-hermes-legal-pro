---
name: hermes-desktop-assistant
description: "Hermes Desktop Assistant para Windows — Adaptación de Thuki (macOS) con integración completa a Hermes/Onyx. Incluye arquitectura Tauri v2, reemplazo de APIs macOS-only, selector de agentes por departamento, conexión a API Gateway Hermes, y control del escritorio Windows desde WSL vía MCP computer-use."
version: 2.0.0
author: Hermes Agent
license: MIT
category: software-development
metadata:
  hermes:
    tags: [desktop, assistant, tauri, windows, overlay, onyx, thuki, computer-use, wsl, mcp]
---

# Hermes Desktop Assistant — Thuki Windows Adaptation

Adaptar un secretario AI flotante tipo [Thuki](https://github.com/quiet-node/thuki) (macOS Tauri + Rust + React) para Windows con integración completa al ecosistema Hermes/Onyx, incluyendo control del escritorio Windows desde WSL.

## Contexto

Thuki es un proyecto de referencia (440⭐) que implementa:
- Ventana flotante overlay siempre visible
- Hotkey global (doble-tap Control)
- Captura de pantalla silenciosa como contexto visual
- Chat streaming con Ollama local 100% offline
- Historial SQLite local

Pablo quiere adaptarlo a Windows con:
- Acceso rápido desde hotkey global
- Selección de agente/departamento (como Topics de Telegram)
- Integración con API Hermes (no solo Ollama local)
- Contexto visual de pantalla enviado al agente seleccionado
- Control del escritorio Windows desde WSL vía MCP computer-use
- Complemento (no reemplazo) de Telegram

## Arquitectura objetivo

```
┌──────────────────────────────────────────────────────────────┐
│  Hermes Desktop Assistant (Windows)                          │
│  ┌─────────────┐  ┌──────────────────────┐                  │
│  │  Hotkey     │  │  Overlay Window      │                  │
│  │  Win+Shift+H│  │  (always-on-top)     │                  │
│  └──────┬──────┘  └──────────────────────┘                  │
│         │                                                    │
│  ┌──────▼──────────────────────────────┐                      │
│  │  Tauri v2 Backend (Rust)          │                      │
│  │  • Windows hotkey (global-shortcut)│                      │
│  │  • Graphics Capture API (screenshot)│                     │
│  │  • SQLite historial                 │                      │
│  └──────┬──────────────────────────────┘                      │
│         │ HTTP/WebSocket                                         │
│  ┌──────▼──────────────────────────────┐                      │
│  │  Hermes API Gateway                 │                      │
│  │  • Routing por agente/departamento  │                      │
│  │  • Streaming de respuestas          │                      │
│  └──────┬──────────────────────────────┘                      │
│         │                                                    │
│  ┌──────▼────────────┐  ┌────────────────┐                │
│  │  Onyx (docs/KB)   │  │  LLM Providers │                │
│  │  • Willow Legal   │  │  • OpenAI      │                │
│  │  • Paola Eventos  │  │  • NVIDIA      │                │
│  │  • WS Capital     │  │  • Local       │                │
│  └───────────────────┘  └────────────────┘                │
└──────────────────────────────────────────────────────────────┘
```

## Análisis de portabilidad Thuki → Windows

| Componente | Tecnología macOS | Reemplazo Windows | Esfuerzo |
|-----------|------------------|-------------------|----------|
| **Ventana flotante** | NSPanel (`tauri-nspanel`) | Ventana nativa Tauri `set_always_on_top` | Bajo |
| **Hotkey global** | CGEventTap HID-level | `tauri-plugin-global-shortcut` | Bajo |
| **Screenshot** | CoreGraphics `CGWindowListCreateImage` | Windows Graphics Capture API | Medio |
| **Frontend** | React 19 + Tailwind + Framer Motion | **Portable directamente** | Ninguno |
| **Streaming** | Tauri Channel API | **Portable directamente** | Ninguno |
| **Historial** | SQLite local (`rusqlite`) | **Portable directamente** | Ninguno |
| **Settings** | `tauri-plugin-store` | **Portable directamente** | Ninguno |

**Conclusión:** ~70% del código es portable directamente. Solo 3 componentes macOS-only necesitan reemplazo.

## Plan de implementación (7 fases)

### Fase 1: Fork y scaffold Windows (~4-6h)
1. Fork de `quiet-node/thuki` bajo org WS Capital
2. Reemplazar `tauri-nspanel` por ventana nativa always-on-top
3. Adaptar `lib.rs` con `#[cfg(target_os = "windows")]`
4. Validar build en Windows

### Fase 2: Hotkey y activación (~4-6h)
1. Reemplazar CGEventTap por `tauri-plugin-global-shortcut`
2. Configurar shortcut configurable (default: `Win+Shift+H`)
3. Implementar detección de texto seleccionado vía clipboard (Windows no tiene AX API como macOS)

### Fase 3: Screenshot Windows (~3-4h)
1. **Opción A (recomendada):** Windows Graphics Capture API (Windows 10 1903+)
2. **Opción B (fallback):** `PrintWindow` / `BitBlt`
3. Captura fullscreen silenciosa + región interactiva
4. Guardar en `%APPDATA%/HermesAssistant/images/`

### Fase 4: Conector Hermes API (~6-8h)
1. Nuevo módulo Rust: `hermes_client.rs`
2. Auth: API key/token configurable en settings
3. Endpoints:
   - `POST /api/chat` → streaming con selección de agente
   - `POST /api/chat/vision` → chat con imagen (screenshot)
   - `GET /api/agents` → lista de agentes/departamentos
4. Preservar Tauri Channel streaming

### Fase 5: Selector de Agente (~4-6h)
1. Nuevo componente React: `AgentSelector`
2. Departamentos mapeados a Topics de Telegram:

| Departamento | Icono | Agente Hermes | Color |
|-------------|-------|---------------|-------|
| 🏛️ Legal (Willow) | ⚖️ | `willow` | Indigo |
| 📈 Marketing/Growth | 📊 | `growth` | Emerald |
| 💻 Build & Tech | 🛠️ | `builder` | Blue |
| 📁 Admin & Ops | 📋 | `admin` | Amber |
| 💲 Ventas | 🤝 | `ventas` | Rose |
| 🧠 Socio Operativo | 🎯 | `default` | Violet |

3. Cada selección cambia: system prompt, contexto Onyx, theme del overlay

### Fase 6: Integración Onyx + Contexto Visual (~6-8h)
1. `/screen` → captura + envía a endpoint vision
2. `/doc` → consulta documentos Onyx del departamento activo
3. `/search` → búsqueda semántica en KB
4. El agente puede "ver" la pantalla y responder en contexto

### Fase 7: Packaging (~3-4h)
1. Build `.msi` con Tauri bundler
2. System tray icon
3. Shortcut escritorio / Start Menu
4. Auto-start opcional

## APIs Windows específicas

### Windows Graphics Capture API (screenshot)
```rust
// Usar windows crate con feature "Graphics_Capture"
use windows::Graphics::Capture::GraphicsCaptureItem;
use windows::Graphics::DirectX::Direct3D11::IDirect3DDevice;
// Requiere Windows 10 build 18362+ (1903)
```

### Ventana always-on-top
```rust
// En Tauri v2, en el frontend:
import { getCurrentWindow } from '@tauri-apps/api/window';
const window = getCurrentWindow();
await window.setAlwaysOnTop(true);
```

### Hotkey global
```rust
// tauri-plugin-global-shortcut
use tauri_plugin_global_shortcut::{Builder, Shortcut, Code, Modifiers};

Builder::new()
    .with_shortcuts("CommandOrControl+Shift+H")
    .unwrap()
    .build()
```

## Opciones de acceso rápido para Windows

| Opción | Complejidad | UX | Recomendación |
|--------|-------------|-----|---------------|
| Global Hotkey (`Win+Shift+H`) | Baja | ⭐⭐⭐⭐ | **Empezar aquí** |
| System tray doble-click | Baja | ⭐⭐⭐ | Implementar también |
| Tecla física macro (F24) | Media | ⭐⭐⭐⭐⭐ | Evaluar después |
| Taskbar pinned | Muy baja | ⭐⭐⭐ | Default de installer |
| Stream Deck / Loupedeck | Media | ⭐⭐⭐⭐⭐ | Futuro |

## Integración con ecosistema Hermes

**Principio clave:** El Desktop Assistant **complementa** Telegram, no lo reemplaza.

| Canal | Uso ideal |
|-------|-----------|
| **Telegram Topics** | Async, mensajes largos, cuando no estás en PC |
| **Desktop Assistant** | Realtime, contexto visual, cuando estás trabajando |
| **Onyx** | Centro de conocimiento compartido entre ambos |

- Misma sesión: historial y contexto se sincronizan vía Onyx
- Handoff fluido: empezar en Desktop, continuar en Telegram (y viceversa)
- Selección de agente en Desktop = selección de Topic en Telegram

---

# WSL Windows Computer Use

Use this section when Pablo asks to control his Windows computer, take screenshots of Windows apps, or automate UI interactions on Windows from Hermes running in WSL.

## Prerequisites

- `open-computer-use` npm package installed on Windows side (v0.1.36 confirmed working)
- Hermes running in WSL2 on same machine
- MCP stdio bridge works natively through WSL without HTTP bridge

## Exact verified invocation

The working command from WSL is:
```bash
cmd.exe /c "npx -y open-computer-use@latest"
```

Do NOT call `npx` directly from bash — WSL may use its own Node.js instead of Windows'. Always prefix with `cmd.exe /c` to route through Windows.

## Available MCP tools (Windows)

| Tool | Purpose |
|------|---------|
| `list_apps` | List running applications |
| `get_app_state` | Get UI tree + screenshot (PNG base64) of target app |
| `click` | Click by element index or (x,y) coordinates |
| `scroll` | Scroll an element in a direction |
| `drag` | Drag from one point to another |
| `type_text` | Type literal text |
| `press_key` | Press a key or combination |
| `set_value` | Set value of a text field |

## Hermes native MCP registration

To make tools discoverable automatically, the MCP server can be registered in Hermes' native MCP client configuration using stdio transport with command `cmd.exe` and arguments `["/c", "npx", "-y", "open-computer-use@latest"]`. A Hermes restart is required for tool discovery.

## Usage flow

1. User says "control my computer" or "screenshot of Excel"
2. Hermes calls `get_app_state` with target app name (e.g. `"chrome"`, `"excel"`)
3. MCP server returns JSON-RPC with `result.content` array containing:
   - `type: "text"` — UI element tree with numbered indices like `[3] Button "Submit"`
   - `type: "image"` — Base64 PNG screenshot in `source.data`
4. Hermes decodes base64, saves to `/tmp/screenshot.png`, sends to user via `MEDIA:`
5. Hermes performs action (`click`, `type_text`, etc.) using `element_index`
6. Repeat until task complete

## Screenshot extraction pattern

```python
import json, base64
# After getting MCP response:
for item in response["result"]["content"]:
    if item.get("type") == "image":
        img_data = base64.b64decode(item["source"]["data"])
        with open("/tmp/screenshot.png", "wb") as f:
            f.write(img_data)
```

Then send to user: `MEDIA:/tmp/screenshot.png`

## Element interaction

Use numbered indices from the accessibility tree, not coordinates:
```json
{"name": "click", "arguments": {"element_index": "3", "app": "chrome"}}
```

## Important notes

- Screenshots are generated automatically with every `get_app_state` call
- Excel files cannot be written by openpyxl when Excel is open in Windows (`~$` lock file). Close Excel first.
- No HTTP bridge needed — stdio through WSL interop works directly
- The Windows binary uses PowerShell UI Automation under the hood
- Force UTF-8 codepage (65001) if JSON parsing fails due to encoding

## Verification commands

### Check binary availability:
```bash
cmd.exe /c "npx -y open-computer-use@latest --help"
```

### Test MCP tools/list:
Send a JSON-RPC `tools/list` request to the process stdin, read JSON from stdout. Expect tools array.

### Test screenshot capture:
Send `get_app_state` with `"app": "chrome"`. Verify response contains image content with base64 data.

---

# Pitfalls detectados

### Excel lock files en checkpoint
Cuando Excel está abierto en Windows, se crea `~$nombre.xlsx` que bloquea escritura desde WSL/Python. Soluciones:
- Cerrar Excel antes de que Hermes escriba
- Escribir en copia y pedir a Pablo que reemplace
- Usar git para sincronizar cambios

### Windows Graphics Capture requiere Windows 10 1903+
Si la PC de Pablo tiene Windows 10 anterior, usar fallback `BitBlt`/`PrintWindow`.

### Tauri v2 global-shortcut vs system shortcuts
Algunos shortcuts (`Win+L`, `Ctrl+Alt+Del`) están reservados por Windows. Testear que el elegido no interfiera.

### Certificado de código
Para evitar warnings de Windows SmartScreen, se necesita certificado de código (~$70/año). Opcional para MVP interno, recomendado para distribución.

## Pending Decisions (confirm with Pablo)
- Approval to fork Thuki under WS Capital GitHub org
- Final global hotkey choice
- Priority department for MVP Agent Selector
- Whether to start Phase 1 immediately or spec with OpenCode first
- Certificado de código Windows para installer (evitar SmartScreen warnings)

## Referencias

- Thuki original: https://github.com/quiet-node/thuki
- Tauri v2 Windows: https://v2.tauri.app/start/
- Windows Graphics Capture: https://learn.microsoft.com/en-us/windows/uwp/audio-video-camera/screen-capture
- tauri-plugin-global-shortcut: https://github.com/tauri-apps/plugins-workspace/tree/v2/plugins/global-shortcut
- open-computer-use: https://www.npmjs.com/package/open-computer-use

---

*Skill consolidado desde hermes-desktop-assistant, hermes-desktop-assistant-build y wsl-windows-computer-use. Versión 2.0.0*
