---
name: fullstack-project-repair
description: Complete workflow for diagnosing, repairing, and integrating a fullstack project (Python backend + TypeScript frontend). Covers build system fixes, hidden runtime bugs, frontend-backend connectivity, third-party service integration, and end-to-end QA.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [python, typescript, repair, integration, qa, fullstack]
    related_skills: [python-project-setup-repair, systematic-debugging, github-repo-management]
---

# Fullstack Project Repair & Integration

Complete workflow for taking a broken or partially-working project, diagnosing all issues, repairing them systematically, and integrating third-party services.

## When to Use

- A repo clones but doesn't install/run properly
- Frontend and backend exist but don't connect
- Tests fail or pipeline produces wrong results
- Need to integrate an external service/API as a sidecar

## Phase 1: Initial Diagnosis

### 1.1 Clone & Inspect Structure

```bash
gh repo clone owner/repo /tmp/project-name
ls -la /tmp/project-name
find /tmp/project-name -type f | head -80
# Note: private repos need gh auth; check with `gh auth status`
```

### 1.2 Check Build System Files

Look at these files immediately:
- `pyproject.toml` — build-backend must be valid (`setuptools.build_meta`, NOT `setuptools.backends._legacy:_Backend`)
- `package.json` — dependencies, scripts
- `requirements.txt` — may be missing even if README references it
- `config.yaml` — runtime config, URLs, API keys

Common pyproject.toml fixes:
```toml
# WRONG (causes BackendUnavailable)
build-backend = "setuptools.backends._legacy:_Backend"

# CORRECT
build-backend = "setuptools.build_meta"
```

### 1.3 Check Python Version Compatibility

```bash
python3 -c "import sys; print(sys.version)"
# If project requires 3.12+ but system has 3.11, patch pyproject.toml:
# requires-python = ">=3.11"
```

## Phase 2: Install & Fix Dependencies

```bash
cd /tmp/project-name
python3 -m venv .venv && source .venv/bin/activate
pip install --upgrade pip setuptools wheel

# Try editable install
pip install -e . 2>&1 | tail -30

# If optional extras exist:
pip install -e ".[dev]"

# Hidden deps (imported but not declared):
# numpy is commonly missing from pyproject.toml but used by adapters
pip install numpy
```

## Phase 3: Run Tests — Identify Runtime Bugs

```bash
python -m pytest tests/ -x --tb=short
```

If tests pass BUT the app behaves wrong, the bug is likely in **business logic**, not test coverage. Common hidden bug:

### The "File Write Order" Bug

When a pipeline saves results to JSON and also sets completion flags:

```python
# WRONG — flags are set AFTER writing file
results_file.write_text(json.dumps(results))
results["completed"] = True   # Too late!

# CORRECT — set flags first, then persist
results["completed"] = True
results["valid_output"] = True
results_file.write_text(json.dumps(results))
```

This causes dashboards/libraries to show `processing` forever because the saved JSON has `completed: false`.

## Phase 4: Frontend Fixes

### 4.1 Check API Mode

Frontend may default to `stub` (simulated data):

```typescript
// In web/src/lib/api/client.ts
// Change this:
const apiMode = (import.meta.env.VITE_API_MODE as ApiMode | undefined) ?? "stub";
// To:
const apiMode = (import.meta.env.VITE_API_MODE as ApiMode | undefined) ?? "auto";
```

`auto` tries real backend first, falls back to mock on failure.

### 4.2 Verify Vite Proxy

```typescript
// vite.config.ts
server: {
  proxy: {
    "/api": {
      target: "http://127.0.0.1:8765",
      changeOrigin: true,
    },
  },
}
```

### 4.3 Connect Navigation

Dashboard quick-action buttons often lack `onClick` handlers:

```tsx
// Before:
<button className="...">Crear Reel/TikTok</button>

// After:
<button onClick={() => navigate("/social")} className="... cursor-pointer">Crear Reel/TikTok</button>
```

## Phase 5: Backend API Completion

Check that all frontend-called endpoints exist:

```bash
# Frontend calls these:
grep -r "apiClient\." web/src/ | grep -o "apiClient\.[a-zA-Z]*" | sort -u

# Backend should have matching routes:
grep -n "path ==" maquina/web_api.py
```

Add missing endpoints. Ensure CORS headers are set:
```python
handler.send_header("Access-Control-Allow-Origin", "*")
```

## Phase 6: Third-Party Integration (Sidecar Pattern)

### 6.1 Clone & Analyze the External Service

```bash
cd /tmp
gh repo clone jamiepine/voicebox voicebox-source -- --depth 1
cat voicebox-source/backend/routes/*.py | grep "@router."
```

Identify the API contract (endpoints, request/response shapes).

### 6.2 Create Adapter Client

Create `maquina/lib/adapters/<service>.py`:

```python
import httpx

class ServiceClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or "http://127.0.0.1:PORT"
        self.client = httpx.Client(base_url=self.base_url, timeout=120.0)

    def health(self): ...
    def list_resources(self): ...
    def create(self, **kwargs): ...
```

### 6.3 Integrate into Existing Provider Chain

Find where the tool selects providers (e.g., `maquina/tools/audio/tts.py`):

```python
# Add to provider chain
if self._voicebox_available():
    result = self._tts_voicebox(...)
    if result.success:
        return result
```

### 6.4 Add CLI Commands

```python
# In cli.py, add subparser:
voicebox_parser = subparsers.add_parser("voicebox", help="...")
voicebox_subparsers = voicebox_parser.add_subparsers(dest="voicebox_command")
voicebox_subparsers.add_parser("status", help="...")
```

### 6.5 Add Web API Endpoint

```python
if path == "/api/voicebox/status":
    _json_response(self, get_voicebox_status())
    return
```

### 6.6 Add Config Section

```yaml
service:
  enabled: true
  url: "http://127.0.0.1:PORT"
  default_option: "value"
```

## Phase 7: End-to-End QA

### 7.1 Start Backend

```bash
# Use terminal(background=true) for long-lived processes
cd /tmp/project-name && source .venv/bin/activate && python -m maquina.web_api
```

### 7.2 Verify with curl/API calls

```bash
curl -s http://127.0.0.1:8765/api/health
curl -s http://127.0.0.1:8765/api/config | head -c 200
curl -s http://127.0.0.1:8765/api/dashboard
curl -s http://127.0.0.1:8765/api/videos
curl -s http://127.0.0.1:8765/api/voicebox/status
```

### 7.3 Test Upload + Pipeline

```bash
# Upload test file
curl -X POST http://127.0.0.1:8765/api/uploads/videos -F "files=@test.mp4"

# Run pipeline
curl -X POST http://127.0.0.1:8765/api/pipelines/social/run \
  -H "Content-Type: application/json" \
  -d '{"video_paths": ["/path"], "platform": "tiktok"}'

# Poll job
watch -n 2 'curl -s http://127.0.0.1:8765/api/jobs/<id>'
```

### 7.4 Frontend Build Check

```bash
cd web && npm run build
npx eslint .  # should exit 0
```

## Phase 8: Cleanup & Commit

### 8.1 Clean Untracked Files

Remove files that shouldn't be committed:
```bash
git rm --cached web/package-lock.json 2>/dev/null || true
rm -rf test_videos/ web/package-lock.json
```

### 8.2 Commit with Detailed Message

```bash
git add -A
git commit -m "fix: reparación completa del sistema end-to-end

Infraestructura:
- Crear requirements.txt
- Corregir build-backend en pyproject.toml
- Bajar Python requirement 3.12→3.11

Backend:
- Agregar endpoint /api/viral-analysis
- Corregir bug: pipeline_results.json se guardaba antes de setear completed

Frontend:
- Cambiar API mode stub→auto
- Conectar quick actions a navegación"
```

### 8.3 Push (Private Repo)

```bash
# gh auth must be active
token=$(gh auth token)
git remote set-url origin "https://USER:${token}@github.com/OWNER/REPO.git"
git push origin main
git remote set-url origin "https://github.com/OWNER/REPO.git"
```

## Pitfalls

1. **Build-backend typo** — `setuptools.backends._legacy:_Backend` is invalid. Always use `setuptools.build_meta`.
2. **File write order** — Never write JSON results before setting completion flags.
3. **Stub mode default** — Frontend defaults to `stub` = no backend connection. Change to `auto`.
4. **Private repos** — `git clone` over HTTPS fails without auth. Use `gh repo clone` instead.
5. **Missing deps in pyproject.toml** — `numpy` and similar are often imported transitively but not declared.
6. **Indentation in server code** — Python's `http.server` handler uses 8-space indentation for nested `if` blocks. Match exactly.
7. **Background processes** — Use `terminal(background=true)` not shell `&`. Track with `process(action=...)`. Kill old instances before starting new ones.
8. **Voicebox and similar sidecars** — They need to be cloned separately and run independently. Don't try to embed their code; use HTTP adapter pattern.