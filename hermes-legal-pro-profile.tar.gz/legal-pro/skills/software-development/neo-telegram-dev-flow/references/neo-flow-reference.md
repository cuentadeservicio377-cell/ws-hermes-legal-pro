# Neo Flow Reference Notes

## Local docs
- `/mnt/c/Users/DELL/Documents/repos/hermes-ops/README.md`
- `/mnt/c/Users/DELL/Documents/repos/hermes-ops/docs/flow.md`
- `/mnt/c/Users/DELL/Documents/repos/hermes-ops/docs/runbook.md`
- `/mnt/c/Users/DELL/Documents/repos/hermes-ops/docs/evolution-sources.md`

## Research repos
- `/mnt/c/Users/DELL/Documents/repos/research/hermes-agent-orange-book`
- `/mnt/c/Users/DELL/Documents/repos/research/hermes-ecosystem`
- `/mnt/c/Users/DELL/Documents/repos/research/multica`

## Current baseline
- Hermes model: `openai-codex / gpt-5.4`
- Cheap model: `openai-codex / gpt-5.4-mini`
- Profiles: `default`, `research`, `builder`, `writer`
- Coding engine: OpenCode
- Main interface: Telegram
