---
name: neo-telegram-dev-flow
description: "Evolve the Neo + Pablo operating system: Telegram-first Hermes orchestration, OpenCode-first coding, GitHub-shared repos, role-isolated profiles, and local runbooks/sources for continuous improvement."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [workflow, telegram, hermes, opencode, github, profiles, evolution]
---

# Neo Telegram Dev Flow

Use this skill when the user wants to improve, repair, extend, or audit the Neo + Pablo working system.

## Goal

Maintain a Telegram-first operating system where:
- Telegram is the main interface
- Hermes is the orchestrator
- OpenCode is the primary coding engine
- GitHub is the synchronization layer between machines
- Hermes profiles isolate roles
- useful learnings become memory, docs, and skills

## Local source of truth

Always consult these local paths first:

- `C:/Users/DELL/Documents/repos/hermes-ops/README.md`
- `C:/Users/DELL/Documents/repos/hermes-ops/docs/flow.md`
- `C:/Users/DELL/Documents/repos/hermes-ops/docs/contract-operativo-unificado.md`  ← concise authority for bootstrap, pending visibility, proactivity, and backstage/BAC
- `C:/Users/DELL/Documents/repos/hermes-ops/docs/runbook.md`
- `C:/Users/DELL/Documents/repos/hermes-ops/docs/evolution-sources.md`
- `C:/Users/DELL/Documents/repos/research/hermes-agent-orange-book`
- `C:/Users/DELL/Documents/repos/research/hermes-ecosystem`  ← this is the local Hermes Atlas repo/source
- `C:/Users/DELL/Documents/repos/research/multica`

In WSL these are under `/mnt/c/Users/DELL/Documents/repos/...`.

When the task is to redesign the operating model, compare against three layers in this order:
1. live local config/state
2. official Hermes docs / repo-local docs
3. Hermes Atlas / community signals

Do not let community material outrank the local state or official docs.

If managed web search/extract fails because the Nous tool gateway token is expired or unavailable, fall back immediately to:
- local cloned source repos
- direct terminal-based fetch/search for public pages
- repo-local markdown/docs already on disk
instead of blocking the analysis.

## Current architecture

### Main control plane
- Hermes gateway in Telegram
- Hermes dashboard in tmux
- primary model: `openai/gpt-5.4`
- cheap routing / subagent model: `nvidia/z-ai/glm5`
- context compression intentionally disabled unless explicitly needed

### Roles
- `default` = orchestrator
- `research` = source validation and synthesis
- `builder` = implementation and debugging
- `writer` = docs and communication

### Tooling policy
- Prefer OpenCode for coding tasks
- Keep OpenAI API key and Hermes subscription/fallback reserved for Hermes itself
- Use GitHub repos for any serious project that must sync with the user's personal machine

## Health check procedure

When auditing the system, verify in this order:

1. Hermes status
   - `hermes status`
   - `hermes doctor`
   - `hermes profile list`
   - `hermes auth list`

2. Process persistence
   - `tmux ls`
   - confirm `hermes` and `dashboard` sessions when expected
   - note that `hermes status` may still show the gateway service as stopped even while tmux sessions exist; use `hermes doctor` and `tmux ls` together for the real picture

3. OpenCode readiness
   - `opencode --version`
   - `opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'`
   - treat the smoke test as the final verification after any config or binary repair

4. GitHub readiness
   - `gh --version`
   - `gh auth status`
   - if unauthenticated, check SSH key path `/root/.ssh/id_ed25519_github_hermes.pub`

5. Browser readiness
   - `agent-browser --help`
   - if browser tool fails, install/repair Chromium support
   - if `hermes doctor` reports `agent-browser` missing, do not assume local browser automation is ready until that stack is installed

6. Workspace structure
   - `C:/Users/DELL/Documents/repos/projects/active`
   - `C:/Users/DELL/Documents/repos/projects/incubator`
   - `C:/Users/DELL/Documents/repos/projects/archive`
   - `C:/Users/DELL/Documents/repos/projects/templates`

7. Base-flow audit repo
   - `/mnt/c/Users/DELL/Documents/repos/hermes-ops`
   - use this when the task is about the Neo + Pablo operating system rather than an individual product repo

## Improvement loop

When improving the workflow:

1. identify friction
2. reproduce it concretely
3. check whether the fix belongs in:
   - config
   - docs
   - memory
   - a reusable skill
   - a new tool/plugin/install
4. implement the smallest durable fix
5. verify it works
6. update local docs
7. patch this skill if the procedure changed

## Task-state protocol

Treat important work as a process with explicit states:
- `capturada`
- `investigando`
- `planificada`
- `implementando`
- `validando`
- `bloqueada`
- `lista`

When reporting progress, prefer this format:
- current state
- what is running now
- what remains
- blocker
- next step

## Parallelism and mutation policy

- parallelize reading, inspection, research, comparison, and other low-risk analysis
- serialize writes on the same repo/workspace by default
- if multiple coding lines must proceed at once, isolate them with separate branches or worktrees
- principle: parallel analysis, serial mutation per repo
- treat `/background` as a first-class Hermes capability, not a convenience command: it should be the default way to launch long-running, self-contained work without blocking the main conversation
- best `/background` use cases: long research, repo-wide inspection, log review, monitoring/health checks, builds/deploys, and parallel investigations
- mental model: `/background` spawns another isolated Hermes session with inherited config/model/toolsets while the foreground session stays interactive
- use foreground when the work needs close supervision or iterative back-and-forth; use `/background` when the task is clear, independent, and time-consuming enough to deserve its own lane
- every meaningful background/autonomous lane should return a reintegration artifact: result, blocker, evidence, and next step
- if a lane stays in `running` without visible evidence for too long, treat it as **opaco** rather than trustworthy; split it into phases, relaunch it with checkpoints, or bring it back to foreground
- long-running lanes should leave operational checkpoints dense enough to preserve objective, constraints, decisions, evidence, blockers, and next step — not just soft summaries
- for risky multi-step technical jobs, prefer deterministic guardrails: preflight, backup gate, run log, and recorded rollback commands rather than improvising the sequence inline
- use worktree-per-task only when multiple bounded code mutations truly need to run in parallel; keep serial mutation as the default

## Output budgeting policy

Prefer bounded outputs over raw dumps:
- summarize long logs
- report file paths, counts, and key failures
- show only relevant diff chunks
- preserve recent/high-value context before summarizing older material

## Decision rules

Install or integrate only when the new thing:
- reduces real friction
- improves reliability, quality, or speed
- fits Telegram + Hermes + OpenCode + GitHub
- is sustainable to maintain

## Proven operational learnings

- On WSL, prefer the native Linux OpenCode binary if the Windows shim is shadowing PATH.
- If a Windows OpenCode config already exists, copy it into `~/.config/opencode/opencode.json` to keep the environment aligned.
- `opencode run` is the best smoke test for validating the native CLI after installation or repair.
- For GitHub auth on WSL, keep `gh auth login --git-protocol https --web` alive until the device flow completes; if the process exits early, the auth does not persist.
- When `gh auth login` asks to upload an SSH key, the local key path `/root/.ssh/id_ed25519_github_hermes.pub` is the one to use.
- For browser setup, try `agent-browser install` first; if Chrome download fails, fall back to system `chromium` installation.
- Local voice-note transcription is viable using `faster_whisper` with `stt.provider: local`, avoiding API token spend.
- Use `openai/gpt-5.4` for primary reasoning/implementation and `nvidia/z-ai/glm5` for lightweight exploration, summaries, and subagents.
- When a product intentionally has two surfaces (control plane vs operational cockpit), define the boundary first and do not merge their responsibilities by accident.
- For mixed UX systems, normalize navigation through the shared router/wrapper so company prefixes stay consistent and hardcoded absolute links do not leak between surfaces.
- For dual-surface founder products like Willow/Paperclip, audit from the intended end-user surface first, not just repo portability. Ask: what should the operator/lawyer actually feel and do here? Treat the control plane as backstage and the vertical surface as the product. Fix visible leaks early (title, header wording, escape hatches back to the control plane, orphan routes) before moving on to deeper UX work like dashboards or matter-centric views.
- When the current repo is only a portable overlay and fails to install because `workspace:*` dependencies cannot resolve, do not keep fighting the overlay. Find the full monorepo/workspace source of truth (with root `package.json` + `pnpm-workspace.yaml` + local packages), sync the Willow changes there, and only then install/launch. In this environment, `willow-paperclip-portable` was not runnable by itself, while `paola-meneses-portable/app/paperclip` contained the complete workspace needed to boot the UI.
- If the active repo has a partial `app/paperclip` tree (for example `packages/db`, `packages/shared`, `server`, `ui`) but is still missing workspace root files and adapter packages, promote it into a runnable workspace by copying in the missing root metadata (`package.json`, `pnpm-workspace.yaml`, `tsconfig.base.json`), operational dirs (`cli`, `scripts`, `patches`), and required adapter packages from a known-good Paperclip source. Then run `pnpm install` again from the repaired root.
- On WSL, if boot/install on `/mnt/c/...` hits NTFS or native-binary weirdness, create a Linux-local working copy under `/tmp` or `/root` and run the repaired workspace there. This was necessary to get past embedded-postgres and file-permission issues while preserving the original Windows-mounted source as the editable authority.
- For hybrid/forked Paperclip repairs, treat startup failures as layered drift rather than one bug: first fix workspace resolution, then migration numbering collisions, then `packages/shared` exports, then narrow UI helper/export drift (`utils.ts`, approval helpers, etc.). Do not attempt a blind full overwrite of `ui/` or `server/`; patch the smallest contract mismatches that unblock the next boot step.
- Useful verification sequence for this kind of rescue: (1) `pnpm install`, (2) `pnpm dev:once` or `pnpm dev`, (3) if UI still fails, run `pnpm --filter @paperclipai/ui dev --host 127.0.0.1 --port <port>` separately, (4) confirm with `ss -ltnp` and `curl -I http://127.0.0.1:<port>`, and only then attempt browser automation. Terminal-level 200 OK is enough to prove the UI server is live even if the browser tool times out.
- If there is no single clean monorepo already carrying the target product surface, the fallback recovery pattern is: (1) complete the missing workspace skeleton in the portable repo from a compatible Paperclip source (`package.json`, `pnpm-workspace.yaml`, `cli/`, `scripts/`, `patches/`, adapters, server/ui entrypoints, and missing shared/db files), (2) run `pnpm install`, (3) if WSL/NTFS causes native-binary problems, copy the workspace to a pure Linux path such as `/tmp/...` before retrying, and (4) expect the real blocker to move from installation errors to contract drift between `server`, `ui`, `packages/shared`, and `packages/db`.
- Practical Willow/Paperclip rescue lesson: once installation succeeds, verify demo-readiness in this order — migration numbering conflicts, embedded-postgres/root-permission behavior, adapter package names, and shared/db export drift. The install step can succeed while `pnpm dev` still fails due to mixed-version internals; treat that as a monorepo-alignment problem, not an environment/setup problem.
- Use OpenCode as a bounded supervisor during rescue work: ask it for the shortest path to a visible demo after each major blocker shift (install failure -> runtime failure -> contract drift), but keep Hermes as the controller that gathers evidence, edits files, and verifies ports/processes. That split gives fast replanning without losing operational control.
- When reviewing a customized product built on top of a fast-moving upstream repo, inspect the upstream main docs/releases for reusable patterns (for example dynamic document titles, branding hooks, chat-thread/search improvements), but apply them selectively. Use upstream to close leaks and borrow capabilities, not to re-import the full control-plane UX into the operator-facing product.
- Use `openai/gpt-5.4` for primary reasoning/implementation and `nvidia/z-ai/glm5` for lightweight exploration, summaries, and subagents.
- For OpenCode on WSL/Linux, prefer `openai/gpt-5.4` as the main model and `nvidia/z-ai/glm5` as the lightweight model for explore/title/summary/subagents.
- If OpenCode on Windows already has working credentials, sync `~/.local/share/opencode/auth.json` and `mcp-auth.json` into Linux instead of re-running provider setup from scratch.
- OpenCode config must stay schema-valid; if `opencode debug config` rejects a key like `providers`, rebuild the config with only supported keys and re-test with `opencode run`.
- Verify provider availability with `opencode providers list` and model availability with `opencode models <provider>` before changing defaults.
- OpenCode on WSL should be configured with `openai/gpt-5.4` as the primary build/plan model and use OpenCode Go as the default lightweight lane when available: `opencode-go/minimax-m2.5` for `small_model`/title/summary and `opencode-go/qwen3.6-plus` for `explore`. Keep NVIDIA as an auxiliary capacity rather than the default lightweight lane.
- Verify the config with `opencode debug config --pure` and `opencode providers list` before starting a run.
- Use the Windows OpenCode auth cache when available: `~/.local/share/opencode/auth.json` can hold OpenAI OAuth and NVIDIA API credentials.
- When formalizing the Neo+Pablo operating model, explicitly model WS Capital as a shared system between Pablo and Hermes; Hermes is not just a coding assistant but a second operational self inside that shared system.
- After writing a new operating model doc, immediately realign the shorter `docs/flow.md` and `docs/runbook.md` so conceptual authority, workflow guidance, and practical checklists do not drift.
- When evaluating a new specialist operator (for example growth/marketing), do not assume Hermes already ships a dedicated official profile for that role. First verify the live profile/docs state, then treat the role as a profile-design problem: mission, priorities, style, working rules, and handoff contract.
- For new non-coding operators, prefer a phased rollout: (1) define the function and outputs on paper, (2) validate how it should hand off with `default`/`research`/`writer`, and only then (3) create a real Hermes profile if the role proves durable. Avoid spawning disconnected niche agents too early; keep Hermes as the central orchestrator with shared context.
- Growth/marketing integration in this environment should be audited across two authorities at once: the `hermes-ops/docs/*.md` operating contract and the Obsidian Growth Vault. Do not treat vault notes as side notes; compare them against the operating docs and identify what is still only implicit.
- When the founder context came from a long voice note/audio, recover it from durable captures before asking the user to restate it: use `session_search` plus the vault notes (for example thesis, anti-genericity, campaign architecture, and vertical notes). The goal is to preserve the founder signal even when the raw audio is no longer directly available.
- For a Growth audit, explicitly check whether these are already captured as durable notes: thesis mother, anti-genericity rules, campaign architecture (general + vertical), flagship vertical proof (for example Paola/events), audiences, problem map, offer/delivery ladder, and experiment log. Missing items should become a concrete backlog, not vague 'more strategy later'.
- A reliable Growth integration sequence is: (1) audit operating docs for where Growth is implicit vs explicit, (2) audit the vault notes derived from founder audio, (3) write an integration audit doc listing gaps, (4) design the blueprint, and only then (5) update the core operating docs and create Hermes-native artifacts (skills/profile/checklists) if still warranted.
- When integrating Growth, preserve the pre-existing operating contract and add Growth on top of it rather than rewriting the system around Growth. Explicitly document that code/development, Growth, research, documentation, operations, and future native capabilities all remain parallel parts of the same WS Capital system.
- When the user starts depending on Obsidian for more than one lane, do not force everything into a single vault. Split durable memory by system layer when warranted: Growth Vault for commercial/market memory, System Vault for whole-system structure/objective/backlog/methodology, and Build Vault for software/research/writer/builder delivery memory. Add the multi-vault rule to operating docs so future capabilities can earn their own vault without rewriting the whole contract.
- If a doc is meant for the user's direct review and iteration (for example growth checklist, handoffs, templates, or content outputs), mirror a readable copy into the relevant Obsidian vault instead of leaving it only in `hermes-ops/docs`. Keep `hermes-ops/docs` as operational authority, but make reviewable artifacts visible where the user is actually reading.
- Safe technical-fix order learned in this environment: (1) sync Windows OpenCode config to the WSL-approved policy, (2) make Hermes lightweight routing explicit, (3) clean up browser diagnostics, (4) clarify gateway observability in docs, (5) decide whether profile isolation should remain prompt-level or become config-level.
- Current stable model split in this environment is not symmetric: Hermes lightweight lane is `gpt-5.4-mini` via `openai-codex`. OpenCode Go may be configured or available, but it is **not** automatically trustworthy as the default lightweight lane until a live smoke test passes.
- If the live OpenCode Go smoke test fails with `Insufficient balance`, do **not** leave the flow anchored to `opencode-go/*` defaults. Immediately repair the OpenCode flow to an OpenAI-first stable routing:
  - strong/default/build/plan/review/design: `openai/gpt-5.4`
  - lightweight/small_model/explore/qa/title/summary: `openai/gpt-5.4-mini`
  - keep OpenCode Go only as optional extra capacity until balance is healthy again
- When repairing that drift, align all three layers together so future syncs do not re-break the flow:
  - `/root/.config/opencode/*`
  - `/mnt/c/Users/DELL/.config/opencode/*`
  - the reference repo at `/mnt/c/Users/DELL/Documents/repos/research/opencode-flow/*`
- Verify with real commands, not config inspection alone:
  - `opencode debug config --pure`
  - `opencode providers list`
  - `opencode run 'Respond with exactly: OPENCODE_FIXED_OK'`
  - `opencode run 'Respond with exactly: OPENCODE_LIGHT_OK' --model openai/gpt-5.4-mini`
  - optional: `opencode run 'Respond with exactly: GO_OK' --model opencode-go/minimax-m2.5`
- Document the repair in `hermes-ops/docs/` so the overnight/backstage lane has a durable checkpoint and the next sync does not silently restore a broken model split.
- Ollama showing `glm-5.1:cloud` in `ollama list` is not enough to treat it as available capacity; run a real smoke test first. If it returns 403/high-volume/subscription-required, treat it as experimental support only, not a reliable background lane.

Do NOT add complexity just because it exists in Hermes Atlas.
First stabilize the base system, then expand.

## Reusable audit pattern learned from repo-base work
- For large portable product repos, clone with `gh repo clone` after verifying auth, then audit in parallel lanes: runtime/backend, frontend/surface, and docs/portability.
- Prefer the repo-local authority files and canonical install/verify/start scripts over alternate README entrypoints when they disagree.
- In UI audits, specifically check for duplicate surfaces, router-wrapper bypasses, hardcoded absolute links, unregistered profiles, and global style bleed.
- Run `bash -n` on shell entrypoints early to catch portability mistakes before deeper implementation work.
- When a product intentionally has two surfaces (control plane vs operational cockpit), lock the boundary first and migrate each surface separately; avoid sharing ad-hoc field assumptions across them.
- During contract migration, prefer compatibility-first helpers in a shared domain module (for example, read `action`/`accion` through one accessor) so old payloads keep working while the new contract rolls out.
- During contract migration, prefer compatibility-first helpers in a shared domain module (for example, read `action`/`accion` through one accessor) so old payloads keep working while the new contract rolls out.
- After introducing a shared helper, run a repo-wide search for the old field name and decide case-by-case whether each remaining reference is an intentional compatibility fallback, a comment, or a true bug.
- If a shared helper becomes the authority for labels/routes/IDs, update the UI consumers together and validate imports before assuming the migration is complete.
- In the PaolaAlt cockpit, keep navigation inside the `/alt/*` tree when possible; use query-param focus (`?focus=...`) rather than jumping to shared `/approvals/*` or `/issues/*` detail routes from alt-specific cards.
- Dead CTAs in the cockpit should be converted to real navigation/actions (e.g. `/alt/buscar`, `/alt/google`) instead of leaving `console.log` placeholders.
- Centralize Google/Paola IDs in the shared Paola domain helper and reuse them from both the main Paola view and Google subpages to avoid drift.
- Paola audit lesson learned: when resuming a previously discussed audit, recover the backlog from session_search plus the repo-local audit docs, then re-check concrete evidence in the repo before declaring anything blocked or fixed.
- Paola audit lesson learned: distinguish intentional surface separation from missing profile registration. In the Paola portable repo, the alt cockpit lived under `/alt/*` even while `paolaAltProfile` was not registered in the surface registry, so verify both route tree and registry authority separately.
- Paola audit lesson learned: report Google-ID duplication as a concrete drift only when the UI hardcodes values that already exist in a shared config file (for example `config/google/sheets-ids.json`), and cite the matching authority file.
- Paola audit lesson learned: a `null` issue-detail or approval payload panel is not automatically a bug if the renderer already guards `Panel` presence; confirm the render path before adding it to the backlog.
- After finishing Paola UI repairs, verify with `pnpm --filter @paperclipai/ui typecheck`, `pnpm --filter @paperclipai/ui build`, and `git diff --check`; if root `pnpm typecheck` fails in unrelated packages, note the separate blocker rather than conflating it with Paola.
- Paola portable audit lesson learned: read `memory/system-identity.md`, `memory/architecture.md`, `memory/operating-flow.md`, `company/definition/paola-meneses-decoracion/COMPANY.md`, and `manual-usuario.md` before trusting old QA/audit reports; many audit docs are historical snapshots rather than current truth.
- Paola portable audit lesson learned: always separate three UI layers explicitly — the Paperclip board/control plane, the embedded Paola Alt cockpit under `/alt/*`, and the standalone `app/paola-webapp`; asking 'how many dashboards exist?' requires answering across those layers, not inside only one app.
- Paola portable audit lesson learned: in founder/operator products for non-technical LATAM users, a dual-interface model can be correct by design: a technical board/control plane for operators like us, and a simplified cockpit for the entrepreneur who is comfortable with Drive/Sheets/Office but not with programming concepts. Audit the danger as 'multiple simple cockpits competing' rather than treating the board-vs-cockpit split itself as a product mistake.
- For dual-surface vertical products like Willow, do not anchor the audit only on repo portability or standalone runtime. First recover the intended product shape from the founder/user: hidden control plane vs end-user operational surface, target operator, and full lifecycle the product must support. Then audit the user-facing surface against that lifecycle (for Willow: intake → matter creation → analysis → expediente → daily follow-up → deadlines → document generation → template evolution → closeout), explicitly calling out where the control plane leaks into the end-user experience.
- When the correct audit lens is product/usability rather than repo autonomy, produce two artifacts: (1) a deep usability audit in the repo under `docs/audits/`, and (2) a concise mirrored note in the relevant Obsidian vault (for software/product repair, usually Build Vault) so Pablo can review the findings outside the repo.
- For the Willow → Hermes + Onyx pivot, keep the architectural boundary explicit: Hermes is the control plane/orchestrator/backstage layer, Onyx is the document/knowledge/agent application layer, and Willow is the legal vertical wrapper on top. Do not try to collapse Hermes into Onyx or keep treating Willow as just another Paperclip alt-surface.
- For the first local proof-of-concept in this environment, prefer **Onyx Lite before Onyx Standard**. Lite is the right shape-validation lane when WSL memory is below Onyx Standard guidance: it can validate local auth, agents, files, projects, and basic expediente-style workflows without immediately paying the cost/risk of the full indexing stack.
- Be explicit about what Lite does **not** validate: it disables the heavier document-layer pieces (vector DB / indexing / connectors / background sync), so it is good for proving product direction and workspace feel, but not enough to declare Drive replacement solved. Treat the next escalation to Standard as the real document-layer validation step.
- Paola portable audit lesson learned: for a high-quality repo-level audit, create three durable docs and link them from `README.md`: one operator-facing system overview, one UX/UI audit report, and one strategic brain-dump/template note capturing the reusable product thesis.
- Paola portable runtime lesson learned: if visual/browser QA is blocked by environment constraints, still complete the audit by separating confirmed code/docs evidence from runtime assumptions, and record the exact blocker as part of the product assessment rather than silently downgrading scope.
- Paola portable runtime lesson learned: in this WSL environment, `corepack enable pnpm` may be required before `pnpm dev`, and even then `app/paperclip` can fail because embedded Postgres refuses to run as `root`; if that happens, report the runtime blocker clearly and continue the audit from code/docs evidence instead of pretending browser QA is complete.
- Paola portable runtime lesson learned: if `embedded-postgres` still fails after enabling `createPostgresUser`, reproduce the underlying `initdb` command and check locales. In this WSL/Ubuntu setup the real root cause was missing `en_US.UTF-8`, with `initdb: error: invalid locale name "en_US.UTF-8"`; running `locale-gen en_US.UTF-8` fixed startup, and the portable `install.sh` can proactively generate that locale when missing.
- Paola portable runtime lesson learned: `createPostgresUser` alone was not enough in this WSL/root setup because `embedded-postgres` also required a real `en_US.UTF-8` locale; `locale-gen en_US.UTF-8` fixed initdb, and the portable `install.sh` now auto-generates that locale when missing.

## Background work as a native workflow

Use `/background` when a task can be stated clearly in one prompt, may take a while, should not block the current conversation, or can run in parallel with other work. This matters especially in Telegram-first operation because it keeps the operator surface live while another Hermes session works elsewhere.

Good examples:
- long-running research
- repo-wide codebase analysis
- log review and file processing
- service health checks and monitoring
- long builds, deploys, and verification loops
- parallel investigations on different angles of the same problem

Do not treat `/background` as merely 'do this later'. Treat it as session-based parallel execution that normalizes concurrent workstreams.

## Sequential repair-lane pattern

When the user asks to stop meta-work and produce real deliverables, or when parallel lanes become opaque, switch to a **sequential repair lane** instead of adding more background work.

## WS/Neo rebuild pattern (learned here)

When the user wants to **rebuild WS/Neo as a company-system** rather than keep patching the old shape, use this execution order:

1. **Freeze authority first**
   - rewrite `operating-model.md`, `contract-operativo-unificado.md`, `flow.md`, and `runbook.md`
   - make the architecture explicit:
     - Hermes = control plane
     - Onyx = knowledge/document layer
     - OpenCode = build plane
     - Workspace = control-plane surface
     - verticals (for example Willow) are not the whole system
   - add the org/departments explicitly, including any newly introduced area such as `Capacitación`

2. **Convert the architecture into a five-phase plan**
   - Phase 1: contract/authority
   - Phase 2: session + handoff + routing engine
   - Phase 3: Workspace/control-plane surface
   - Phase 4: Onyx/document layer integration
   - Phase 5: verticals + real operation

3. **Close each phase explicitly before advancing**
   - every phase needs:
     - deliverables created
     - evidence visible
     - review/intermediate checkpoint
     - residual backlog
     - explicit pass/fail decision
   - do not say a phase is complete just because docs exist; for implementation phases require code/tests/evidence

4. **Force tests from day one for implementation phases**
   - for Phase 2 specifically, require:
     - contract tests
     - behavior tests
     - integration tests
   - do not allow transition to Phase 3 until the engine exists, tests pass, and a closeout checkpoint is written

5. **Do not let bug lanes stall the architecture lane**
   - if an unrelated bug or BAC lane is still running, keep the architecture/build planning moving in foreground
   - create a periodic cron watcher for the bug lane when useful
   - classify the bug lane as `visible` or `opaco` based on fresh evidence, not optimism

6. **Choose the repo target explicitly before coding**
   - for a session/handoff engine that must feed the control plane, inspect the real target repo for:
     - test runner (`vitest`, etc.)
     - existing session/checkpoint/store patterns
     - insertion point for the module
   - write a repo-target decision note before claiming implementation is ready

7. **Use this completion rule for Phase 2**
   - only declare `Fase 2 terminada` when all three are true:
     1. base module/implementation exists
     2. minimum tests pass
     3. closeout checkpoint with evidence exists

This pattern is useful whenever Pablo wants a serious rebuild of the WS/Neo operating system and expects a phased execution plan rather than more loose architecture commentary.

Use this pattern:
1. **Cancel or pause opaque lanes** that are not producing visible evidence.
2. **Choose one lane at a time** and finish it to a written deliverable before starting the next.
3. **Create a repo-local prompt file** inside the target repo/workspace so OpenCode can read it without cross-directory permission issues.
4. **Route model choice by task cost**:
   - OpenCode Go / lighter models for repo reading, analysis, audit synthesis, and other token-heavy but low-risk work
   - stronger reasoning models only when the lane needs deeper judgment or code-heavy implementation
5. **Mirror the result into the user-facing vault** when the user expects Obsidian/System Vault access, not just repo-local docs.
6. **Verify the artifact exists** with `read_file`, `ls`, or equivalent before closing the lane.

This pattern was useful for getting unstuck on long audit/restart work: it replaced opaque background churn with evidence-backed, finish-one-lane-at-a-time execution.

### Practical example of the repair pattern
- Marketing/Growth first, then legal audit
- Use a repo-local prompt file for each lane
- Use OpenCode Go for analysis-heavy work to reduce token burn
- Write both the repo report and the mirrored vault note
- Only then mark the lane complete

### Implementation-first rule for long rebuilds
When the user says the project is already heavily built and wants you to **finish it**, do not pivot into extra cron/PM scaffolding as the main response. First audit what is already implemented **today** and separate it into four buckets:
1. already built in code
2. built but poorly exposed in the UI
3. built but poorly wired/bound at runtime
4. genuinely missing

Use live evidence before proposing a new meta-layer:
- `git status --short`
- `git diff --stat`
- recent route/component/API files touched in the target repo
- direct API checks for knowledge/memory/profiles/tasks/jobs when relevant
- live route verification where possible

Then choose the execution style based on user intent:
- if the user wants continuity because the project is long-running and unattended, cron/checkpoint structure can help
- if the user says "just finish it" or explicitly de-prioritizes cron, switch back to direct execution and finish the phases serially

Rule: do not mistake missing *representation* for missing *implementation*. In this environment, large parts of WS Neo/Operations/Onyx already existed in code while the user experience still felt incomplete. Audit implementation state before declaring that whole subsystems still need to be built.

### Overnight checkpoint follow-up pattern
When running a second-pass or morning-after checkpoint across multiple lanes, do not just restate prior status from memory.

Use this sequence:
1. re-check the live health primitive first (for example one OpenCode smoke test)
2. inspect the expected artifact locations directly in both places when applicable:
   - repo-local docs/checkpoints
   - mirrored Obsidian/vault notes
3. inspect live repo state (`git status --short --branch`) to distinguish documented progress from actual mutable drift
4. classify each lane as:
   - `visible` = recent artifact exists and says something concrete
   - `opaco` = artifact missing, stale, or too abstract to prove movement
5. if a lane is still opaco, do **one bounded continuation step immediately** and leave a fresh checkpoint rather than ending with only commentary

Preferred bounded continuation step:
- create a new `run-02` / follow-up checkpoint doc in the repo
- mirror a concise note into the user-facing vault when that lane already uses one
- record only concrete fresh evidence such as:
  - file existence
  - resource/preflight readings
  - repo status
  - exact blocker
  - exact next step

Rule: for checkpoint recovery work, visible evidence beats ambition. A small fresh checkpoint with live evidence is better than a vague promise of a later larger restart.

### Long-run project continuity pattern
When a project becomes too long for reliable single-chat continuity, stop estimating in big abstract blocks and switch to a **vault + cron + adaptive-hour** structure.

Use this pattern:
1. create a **dedicated project vault** under the user's Obsidian tree with at least:
   - `00_Project Hub/`
   - `01_Cron Runs/`
   - `02_Checkpoints/`
   - `03_Artifacts/`
   - `04_Runtime Maps/`
   - `05_UI Reviews/`
   - `06_Contract/`
2. create three seed notes immediately:
   - master delivery plan
   - architecture anchor
   - phase tracker
3. define the work as **phases with 1-hour initial budgets**, not fake long estimates
4. for each phase, specify:
   - objective
   - subtask list
   - partial outputs expected by the checkpoint
   - done condition
5. use cron jobs as **measurement checkpoints**, not just reminders. Each cron should report:
   - planned subtasks
   - completed subtasks
   - partial outputs produced
   - blocker
   - revised remaining estimate
6. adjust the estimate from throughput, e.g. if 8/10 subtasks finish in 1 hour, estimate ~15–20 minutes remaining instead of inventing another full hour
7. tag all notes/checkpoints with a stable project label like:
   - `project: <project-name>`
   - `lane: <lane-name>`
8. do not update the operating contract in abstract first; create the vault + cron structure first, then patch the contract once the continuity pattern is real

This pattern is especially useful for Telegram-first Hermes work where context compression, session resets, and long product lanes can otherwise cause drift even when most of the implementation already exists.

### WS/Neo bug-watch audit heuristic
When the task is to audit an active WS/Neo bug lane and classify it `visible` vs `opaco`, do not rely only on yesterday's checkpoint note. Re-check these live primitives first:
1. expected BAC/artifact file exists at the exact target path
2. BAC log exists and has non-zero content
3. the responsible `opencode run` or background process is still alive, finished, or missing
4. the currently relevant service ports answer live (`curl`, `ss -ltnp`), especially frontend dev port vs backend/proxy port
5. if the historical blocker mentioned a specific source file or syntax/build error, read the live file once to see whether that failure signature is still present

Classification rule:
- `visible` = concrete current evidence exists (missing artifact, empty log, live stuck process, refused port, active syntax error, fresh checkpoint with exact blocker)
- `opaco` = only stale narrative exists and current primitives do not prove what is happening now

Artifact rule:
- if fresh live evidence was gathered in the current audit, report it directly and do **not** create another continuation artifact just for ceremony
- create `ws-neo-bug-watch-checkpoint-<timestamp>.md` only when there is no fresh evidence and you need to leave one bounded continuation marker with `state`, `latest evidence`, `blocker`, `next step`, and `confidence`

## Common actions

### Repair OpenCode on WSL when Windows binary is shadowing it
1. Check `which -a opencode` and `opencode --version`
2. If the Windows npm shim is on PATH and fails on Linux, install native OpenCode in WSL:
   - `npm install -g opencode-ai@latest`
3. Link the native binary if needed:
   - `/root/.hermes/node/bin/opencode`
   - `ln -sf /root/.hermes/node/bin/opencode /usr/local/bin/opencode`
- If the user already configured OpenCode on Windows, copy config into WSL:
  - from `/mnt/c/Users/DELL/.config/opencode/opencode.json`
  - to `~/.config/opencode/opencode.json`
5. Verify with:
  - `opencode --version`
  - `opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'`
6. If OpenCode says the config is invalid, inspect the resolved config with `opencode debug config --pure`; in this environment, a top-level `providers` block was rejected, so the working config was rebuilt around `model`, `small_model`, `mcp`, `permission`, `instructions`, and `agent` sections only.
7. If Windows already has OpenCode credentials, sync them to WSL from:
  - `C:/Users/DELL/.local/share/opencode/auth.json`
  - `C:/Users/DELL/.local/share/opencode/mcp-auth.json`
  and place them in:
  - `~/.local/share/opencode/auth.json`
  - `~/.local/share/opencode/mcp-auth.json`
  Then verify with `opencode providers list`.
8. Prefer model IDs that actually exist in the local OpenCode install before launching long work. Useful verified models in this environment:
  - `openai/gpt-5.4` for primary/build/plan work
  - `nvidia/z-ai/glm5` for light/explore tasks
  - do not assume `openrouter/*` or `gpt-5.1-codex-mini` are available just because they were configured elsewhere.

### GitHub auth on WSL
1. Install `gh` if missing
2. Prefer `gh auth login --git-protocol https --web` for the first login when SSH prompts are getting stuck
3. Important: keep the `gh auth login` process alive while the user completes the device flow; if it exits early, the authorization does not persist locally
4. Run it in a PTY/background session, surface the device code, then wait for the user to finish at `https://github.com/login/device`
5. Verify with `gh auth status`
6. Optionally prepare SSH afterward using `/root/.ssh/id_ed25519_github_hermes.pub`

#### GitHub auth on WSL
1. If `gh` is missing, install it in the WSL distro you actually use.
2. Prefer `gh auth login --git-protocol https --web` when SSH prompts are getting stuck.
3. Keep the auth process alive until GitHub prints `Authentication complete`.
4. Verify with `gh auth status` before assuming the session is saved.
5. If a shell wrapper or background launch exits early, the device flow may not persist locally.
6. Use SSH afterward only if needed; HTTPS web login is the more reliable first step in this environment.

## Browser repair on WSL
1. First verify the live state with `agent-browser --help`, `agent-browser doctor`, and `hermes doctor`.
2. If `agent-browser` is actually missing, install it.
3. If `agent-browser install` fails or times out while downloading Chrome, fall back to system Chromium:
   - `apt-get update && apt-get install -y chromium`
4. Re-test the browser tool after Chromium is present.
5. Do not rely on stale memory for tool availability; use the live CLI output as authority.


### Add a new specialist profile
1. `hermes profile create <name> --clone`
2. customize `~/.hermes/profiles/<name>/SOUL.md`
3. keep identity isolated by profile
4. document role and handoff in local operating docs

### Prepare a new project
1. create under `C:/Users/DELL/Documents/repos/projects/incubator` or `active`
2. initialize git
3. connect to GitHub repo
4. add project instructions in the repo using the existing project conventions
5. use OpenCode for implementation
6. use Hermes orchestrator from Telegram for coordination

### Update the operating docs
Always update:
- `docs/flow.md` when the workflow changes
- `docs/runbook.md` when commands or checks change
- `docs/evolution-sources.md` when new source material shapes the system

## Sources that shaped this workflow
These ideas are foundational and should be revisited when evolving the system:
- role-isolated Hermes profiles instead of one overloaded agent
- operator layer / handoff contracts / role boundaries
- project-level instruction files for consistency
- specialized coding engine + orchestration split
- taste, constraints, and verification as quality multipliers
- orchestration platforms are phase 2, not phase 1
- The real system has 4 layers: model, context, harness, infrastructure
- long-running agent loops need observability, cancellation, retries, and bounded outputs
- cheap compaction and protected recent context should be preferred before expensive summarization
- read tools can parallelize more safely than write tools
- When expanding beyond coding into specialist operator lanes (for example growth/marketing), do not create the new profile just because Hermes supports profiles. First run a discovery phase: define the business problem, target audience, outputs, handoff contract, and relation to existing roles (`default`, `research`, `writer`, `builder`). Use the existing role SOUL pattern as the template, but prefer a hybrid path: keep Hermes default as central orchestrator, use current specialist profiles for research/writing support, and only create a new profile once the role boundary is clear enough to deserve its own memory and identity.
- For Growth specifically, treat it as a *native function* of WS Capital before it becomes a new profile: first audit the operating model, then connect the Growth Vault/Obsidian notes, then define the blueprint, runbook, and artifacts, and only after repeated usage decide whether a dedicated profile or skill is warranted. Growth should be integrated into docs and handoffs first, not spun up as a separate marketing island.
- When integrating the marketing head/capability deeper into the system, preserve the existing build/development contract. Add marketing infrastructure as an extra layer rather than replacing OpenCode or reframing the whole system around Growth.
- If the user wants lighter/faster/cheaper backstage work for marketing or auxiliary bug triage, formalize a model/API routing matrix in the operating docs before changing runtime config. In this environment the stable split is: Hermes = orchestration/arbitrage, OpenCode = strong repo-centric build lane, NVIDIA/`nvidia/z-ai/glm5` = lightweight marketing/backstage lane for drafts, triage, summaries, classification, and other low-latency subtasks.
- When a new native capability changes how accounts/providers should be used, update all short authority docs together (`contract-operativo-unificado.md`, `operating-model.md`, `flow.md`, `runbook.md`) and mirror the policy into the relevant Obsidian/System vault so the system contract and human review surface stay aligned.
- When a long founder brain dump changes the system-level understanding, do not keep the impact isolated to Growth docs. Derive a backlog for the whole WS Capital system: objective/mision, Hermes as proactive clone, extraction methodology, offer structure, active verticals, and any new future capacities the contract must leave room for.
- Recovery pattern for long founder audio / voice-note sessions: use `session_search` to recover the prior session, then inspect the Growth Vault notes (`thesis`, `anti-genericity`, `campaign architecture`, `verticals`, `audiences`, `problems`) before asking the user to restate anything. If the raw audio is no longer available, preserve the founder signal via durable notes and derive the missing commercial structure from them.
- When the architecture evolves from one vault into multiple vaults, populate the new vaults from local source-of-truth docs first, not from memory: read the operating docs plus the already-mature vault (in this case Growth) and then create explicit starter trees with README, map, backlog, methodology, and priorities notes.
- For WS Capital multi-vault routing, use this classification rule before writing notes: `System Vault` for objective/architecture/capabilities/methodology/backlog/priorities, `Growth Vault` for market-facing thesis/audiences/campaigns/verticals/experiments, and `Build Vault` for software/research/writer/builder/handoffs/delivery.
- A fourth vault is now justified for backstage experimentation: `Night Ops Vault` for overnight runs, checkpoints, relaunch notes, experiment logs, and comparisons of which tool/capability combinations produced real progress versus opaque churn.
- After creating or reshaping vault structure, immediately realign the short operating docs (`docs/obsidian-vault-architecture.md`, `docs/contract-operativo-unificado.md`, `docs/flow.md`, `docs/runbook.md`) so the routing rules and starter trees are documented in both the vaults and the operating contract.
- Good starter notes for `Night Ops Vault`: run summary, experiments register, active lanes snapshot, and checkpoint master note. This vault should connect to `System`, `Build`, `Growth`, and product-specific vaults without replacing them.
- For Growth specifically, treat it as a *native function* of WS Capital before it becomes a new profile: first audit the operating model, then connect the Growth Vault/Obsidian notes, then define the blueprint, runbook, and artifacts, and only after repeated usage decide whether a dedicated profile or skill is warranted. Growth should be integrated into docs and handoffs first, not spun up as a separate marketing island.
- When redesigning WS/Neo at the system level, do not reduce the output to a light organigram or a simple bullet summary. The user may be asking for a true company-system rebuild. In that mode, treat **Onyx as a central layer**, not an afterthought: `Hermes = control plane`, `Onyx = knowledge/document layer`, `OpenCode = build plane`, `Workspace = center of control`, and verticals like Willow sit on top of that stack.
- Workspace alignment lesson: after landing WS/Neo/Onyx/repair surfaces, do a full product-surface audit before entering verticals. Verify that the whole workspace actually communicates the new company-system model rather than just containing isolated new routes.
- Distinguish three layers explicitly during that audit:
  1. **enterprise/control layer** — `WS / Neo`, `Onyx`, `Repair`, later verticals
  2. **infrastructure layer** — `Profiles`, `Settings`, `Skills`, `Terminal`, `Jobs`, `Files`
  3. **agent observability layer** — `Operations`, `Crew`, agent manifests/monitoring
  Do not confuse technical profiles or agent cards with departments of the company-system.
- Current Hermes Workspace can legitimately contain both the new enterprise model and older legacy/technical surfaces at the same time. Treat that as a surface-alignment problem, not as proof the WS/Neo build was conceptually wrong.
- Before Phase 5, audit live state plus code to detect legacy drift. In this environment, the quick proof was:
  - `GET /api/profiles/list` to see live profile names and active profile
  - inspect `src/routes/profiles.tsx`, `src/screens/profiles/profiles-screen.tsx`
  - inspect `src/routes/operations.tsx`, `src/screens/agents/operations-screen.tsx`, and `src/screens/agents/agent-presets.ts`
  This exposed that `default/writer/builder/research` and operations presets like `sage/scribe/ops/trader` were still technical/legacy surfaces rather than the company departments.
- Interpretation rule: `default / writer / builder / research` are execution profiles for Hermes infrastructure, not the company org chart. Likewise, legacy Operations presets are backstage agents unless explicitly remapped. Keep them as secondary/internal surfaces or rename/reframe them before saying the workspace is fully aligned with the enterprise model.
- Recommended pre-vertical step when this drift appears: run a short “surface alignment” pass to (a) promote WS/Neo as the primary company center, (b) move or relabel Profiles as technical infrastructure, (c) reframe Operations as agent ops/backstage, and (d) unify naming/taxonomy before vertical expansion.
- In that enterprise-system rebuild mode, use this document sequence:
  1. create a master architecture doc for the new system shape
  2. rewrite the core authority docs in place: `docs/operating-model.md`, `docs/contract-operativo-unificado.md`, `docs/flow.md`, `docs/runbook.md`
  3. create implementation-facing docs for the new operating form: department operating contract, session/handoff protocol, execution routing matrix, Workspace control-plane spec, and Onyx integration plan
  4. write an implementation plan under `docs/plans/`
  5. mirror a concise architecture note and backlog note into `System Vault`
- Treat the phrase "rehacer mejor" literally: do not preserve old structure just because it exists. Preserve only what still has structural value; otherwise replace it cleanly and document the new authority so future sessions bootstrap into the new model instead of the old one.
- Once the architecture package exists, force a **build-and-test strategy** before starting implementation. Define from day one: contract tests for sessions/handoffs/routing, integration tests for Hermes↔Workspace / Hermes↔Onyx / Hermes↔OpenCode, UI/flow tests for area navigation, and operational smoke tests for continuous running and checkpoint emission.
- For long WS/Neo rebuild sessions, prefer BAC/background for bounded analysis lanes: create a repo-local prompt, run OpenCode in background to produce a concrete readiness audit/checkpoint artifact, then return to foreground to choose the first implementation lane.
- The preferred first implementation lane in this architecture is the **session/handoff engine**, because it underpins Workspace, routing, observability, and later Onyx/vertical integration.
- When integrating the marketing head/capability deeper into the system, preserve the existing build/development contract. Add marketing infrastructure as an extra layer rather than replacing OpenCode or reframing the whole system around Growth.
- If the user wants lighter/faster/cheaper backstage work for marketing or auxiliary bug triage, formalize a model/API routing matrix in the operating docs before changing runtime config. In this environment the stable split is: Hermes = orchestration/arbitrage, OpenCode = strong repo-centric build lane, NVIDIA/`nvidia/z-ai/glm5` = lightweight marketing/backstage lane for drafts, triage, summaries, classification, and other low-latency subtasks.
- When a new native capability changes how accounts/providers should be used, update all short authority docs together (`contract-operativo-unificado.md`, `operating-model.md`, `flow.md`, `runbook.md`) and mirror the policy into the relevant Obsidian/System vault so the system contract and human review surface stay aligned.
- When a long founder brain dump changes the system-level understanding, do not keep the impact isolated to Growth docs. Derive a backlog for the whole WS Capital system: objective/mision, Hermes as proactive clone, extraction methodology, offer structure, active verticals, and any new future capacities the contract must leave room for.

## Session bootstrap / continuity protocol

When a new session starts, the model/provider/account changes, or Pablo says things like `continúa`, `retoma`, `entra en lo último`, or `revisa memoria`, do not treat it as a cold start.

Use this recovery order before asking broad clarification questions:
1. read local authority docs first:
   - `README.md`
   - `docs/operating-model.md` as conceptual authority
   - `docs/flow.md`
   - `docs/runbook.md`
   - `docs/pm-reminders-operating-loop.md` when the topic is operational continuity / project management
2. recover recent context with `session_search`
3. reload relevant skills
4. reconstruct active lanes in `todo`
5. if continuity, pending visibility, or backstage behavior are central, consult `docs/contract-operativo-unificado.md` as the concise operational synthesis
6. report back with:
   - what was recovered
   - active lanes now
   - what is already decided
   - what is still pending
   - recommended next move

Rule: if the context is recoverable through memory, docs, skills, and `session_search`, recover it first instead of asking Pablo to re-explain the system.

This environment expects Hermes to act as a proactive operating partner / second self inside WS Capital, not as a stateless assistant that needs to be re-trained each session.

## WS/Neo enterprise-system rebuild pattern

When Pablo shifts from analysis into a full rebuild of WS/Neo as an empresa-sistema, do not keep working as if the task were just docs or just coding. Use a phased rebuild with explicit closeout gates.

### Core architecture to preserve
- Hermes = control plane / second operational self
- Onyx = knowledge/document layer
- OpenCode = build plane
- Workspace = control-plane surface / center of control
- Verticals (for example Willow) sit on top of the system; they are not the system itself
- Departments/sessions/handoffs are the organizational runtime

### Required execution order
Run the rebuild in these 5 phases, with a review gate between each:
1. **Contract and authority** — rewrite operating-model/contract/flow/runbook and freeze the new language/authority
2. **Operational nucleus** — build Session + Handoff + SessionCheckpoint engine with tests from day one
3. **Workspace control plane** — make departments, sessions, handoffs, blockers, and visible/opaco state navigable in Workspace
4. **Onyx integration** — connect the knowledge/document layer without collapsing Hermes or OpenCode into Onyx
5. **Verticals and real operation** — wire Willow/legal and other departments onto the new runtime

### Phase gate rule
A phase is not done because the docs exist. Close a phase only when it has:
- concrete deliverables
- visible evidence
- an intermediate review / closeout note
- residual backlog noted
- explicit decision to pass to the next phase

### Phase 2 implementation rule (important)
The first real build lane should usually be the Session & Handoff Engine, because it supports:
- departmental operation
- session separation
- formal handoffs
- checkpointing
- visible/opaco confidence
- future Workspace and Onyx integration

For that lane:
- choose the target repo explicitly (in this environment, Hermes Workspace was the right first target)
- write tests first
- require schemas/models for Session, Handoff, and SessionCheckpoint
- require behavior tests for area changes, handoff creation, checkpoint emission, and visible/opaco confidence
- do not declare Phase 2 done until code exists, tests pass, and a closeout checkpoint doc is written

### Continuous-operation rule learned here
When a bug lane or BAC lane is still running/opaco, do not block the architecture/build lane behind it. Keep bug monitoring running (cron/checkpoints) and continue advancing independent structural work in parallel, especially specs, test strategy, repo-target decisions, and build briefs.

## Session-start and proactivity learnings

When continuity and proactive operation are the actual goal, treat these as part of the core workflow, not optional polish.
Model the system's memory as a spine with layers: Hermes durable memory, session history, skills, vaults, and optional future shared memory backends (for example agentmemory). Do not collapse those layers into one store.

### Session start protocol
At the start of a new session or after context loss:
1. read local authority in this order:
   - `README.md`
   - `docs/operating-model.md`
   - `docs/flow.md`
   - `docs/runbook.md`
   - `docs/session-bootstrap.md`
   - `docs/pm-reminders-operating-loop.md` when PM/continuity matters
2. recover recent context with `session_search`
3. reload relevant skills
4. reconstruct active lanes in `todo`
5. answer with a compact operating picture instead of asking the user to restate everything

## Topic-as-Department Mapping (Telegram Topics → Hermes Profiles)

When Pablo uses a Telegram supergroup with **Topics enabled** as the company operating system, each topic becomes a department channel. Hermes must respond with the correct profile/mode based on which topic the message comes from.

### Discovery protocol
1. Ask Pablo for the list of topics (name + emoji/icon).
2. Propose the profile-to-topic mapping and confirm activation words.
3. To learn thread IDs, ask Pablo to paste the `t.me/c/CHAT_ID/THREAD_ID` link from each topic (right-click → Copy Link).
4. Parse `THREAD_ID` from the link and record the mapping permanently in memory.
5. If thread IDs are unavailable, use **activation-word fallback**: Pablo prefixes messages with `hola <perfil>` (e.g. `hola willow`, `hola build`).

### Important: session isolation per topic
Each Telegram topic creates a **separate Hermes session**. Neo cannot see messages from other topics in the current conversation. This means:
- Cross-topic coordination must happen in **General** or via explicit user-driven context.
- To verify auto-detection, Pablo must write in each topic individually; Neo responds from that isolated session.
- Do not assume you can "poll" other topics from within one topic session.

### Example mapping (Hermes group — Pablo's instance)
| Topic | Thread ID | Activation word | Hermes profile |
|-------|-----------|-----------------|----------------|
| 💬 All | (none — base group) | — | Alert-only |
| #️⃣ General | 1 | — | WS Capital General |
| 💡 Socio Operativo | 2 | `hola socio` | Pablo's Second Brain |
| ✏️ Willow Legal | 5 | `hola willow` | Legal Operator |
| 📈 Growth & Marketing | 8 | `hola growth` | CMO / Growth |
| 💻 Build & Tech | 22 | `hola build` | CTO / Lead Dev |
| 📁 Admin & Ops | 23 | `hola admin` | COO |
| 💲📉 Ventas & Plantillas | 24 | `hola ventas` | Comercial |

> **Note:** The "All" topic is the base group chat; it has no thread ID and uses an invite link (`t.me/+...`). It should be treated as broadcast-only.

### Pinned messages per topic
Hermes cannot pin messages unless the bot has admin rights. If admin is not available, pre-compose the 8 pinned messages (description, links, rules) and give them to Pablo to copy/paste and pin manually.

### Runtime behavior
- At session start, check if the incoming message includes a `thread` ID.
- Look up the thread ID in the recorded mapping; if found, switch to that profile immediately.
- If no mapping exists or thread info is missing, fall back to activation-word detection in the message text.
- If neither works, default to the general orchestrator profile and ask for clarification once.

### Pending-visibility rule
Do not hide active work in prose or chat history.
- `todo` = short-horizon active queue
- cron/reminders = time-based reactivation
- docs = durable backlog/context
- memory = stable facts only

A good startup response should proactively include:
- what was recovered
- active lanes now
- what is already decided
- what is still pending
- blocker
- recommended next move

### Backstage/autonomy rule
If the user's goal is “I give Hermes a task and Hermes works on it behind the scenes until it is ready for review,” then optimize for backstage autonomy, not just better chat answers.

Adopt these rules:
- explicit lane selection for every non-trivial task:
  - foreground
  - `/background`
  - OpenCode
  - delegation
  - hybrid
- default repo mutation to OpenCode
- use `/background` more aggressively for long, independent work
- every meaningful autonomous lane must return a reintegration artifact:
  - result
  - blocker
  - evidence
  - next step
- for risky multi-step jobs, use deterministic guardrails:
  - preflight
  - backup gate
  - run log
  - recorded rollback commands
- use worktree-per-task only when parallel code mutation has clear ROI; keep serial mutation as default

### Gap to watch for
A system can have healthy runtime persistence (gateway/dashboard/keepalive) while still lacking true work-backstage autonomy. Distinguish:
- infra backstage = processes stay alive
- work backstage = tasks keep moving, re-open, and reintegrate without the user re-driving the whole flow

### Current long-term target state in this environment
The target is a Telegram-first shared operating system where Pablo can assign a task, Hermes routes it to the correct lane, OpenCode/subagents do the work, and Hermes returns only when there is a deliverable or precise blocker.

## Long-running project continuity pattern

When a project is too large to trust to one foreground chat session, convert it into a **continuity-backed delivery lane** instead of relying on memory.

### Use this pattern when
- the user says the project is long or keeps losing continuity
- context compression is causing drift
- the same architecture must be revisited across many sessions
- the user wants Hermes to keep working and report back by checkpoints

### Required structure
Create three things together:
1. **repo plan doc** under `docs/plans/`
2. **dedicated Obsidian/vault project space**
3. **cron checkpoint jobs**

### Good vault shape
For a long-running WS/Neo-style project, use a dedicated vault/workspace with folders like:
- `00_Project Hub/`
- `01_Cron Runs/`
- `02_Checkpoints/`
- `03_Artifacts/`
- `04_Runtime Maps/`
- `05_UI Reviews/`
- `06_Contract/`

Seed it immediately with:
- master delivery plan
- architecture anchor
- phase tracker
- cron prompt pack
- contract update queue

### Good cron shape
Install a small fixed set of continuity jobs instead of one giant background lane:
- morning recovery
- midday checkpoint
- night evidence checkpoint
- drift detector
- weekly integration review

These jobs should always be self-contained and include:
- project id / lane tag
- repo path
- vault path
- architecture anchor
- current phase
- what evidence to inspect
- where to write the checkpoint note

### Estimation rule
Do **not** use fake long estimates for this kind of work.
Prefer:
- one initial hour per phase
- explicit subtasks per phase
- partial-result checkpoints
- adaptive re-estimation from actual throughput

If 8 of 10 subtasks finish in one hour, the next estimate should be the residual minutes, not another generic multi-hour block.

### Output rule
Checkpoint notes should always report:
- phase
- subtasks completed / planned
- visible partial outputs
- blocker
- next recommended move
- revised remaining estimate

### Important lesson
For long WS/Neo / company-system work, the implementation may already be largely done while the continuity layer is still weak. Before assuming more coding is needed, audit:
- what is already implemented
- what is only poorly exposed in the UI
- what is poorly bound to runtime/context
- what is truly missing

## Output style for this skill
When asked to improve the flow, answer with:
1. current state
2. friction detected
3. recommended change
4. what to install/configure/edit
5. verification
6. whether memory/docs/skill were updated
