---
name: integrate-external-repo-sidecar
description: Integrate an external open-source repo as a sidecar service into Máquina de Videos. Creates Python adapters, CLI commands, web API endpoints, and React frontend hooks/pages following the established architecture pattern.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [integration, sidecar, adapter, bridge, external-service, video-machine]
    related_skills: [github-repo-management, writing-plans]
---

# Integrate External Repo as Sidecar Service

Integrate an external open-source project (e.g., Voicebox, SmartCut) into Máquina de Videos as a sidecar service. The service runs independently and communicates via HTTP. Creates the full bridge: Python adapter → CLI → Web API → React frontend.

## When to Use

- Integrating a new tool that provides a standalone HTTP API (FastAPI, Next.js, etc.)
- The tool should run as a sidecar (separate process) rather than embedded code
- Need CLI, web API, and React UI access to the tool
- Examples: TTS engines, video editors, transcription services, screen recorders

## Integration Checklist

Use this checklist for every new sidecar integration. Each item maps to a file change.

### 1. Examine the External Repo

```bash
# Clone and inspect
git clone <repo-url> /tmp/<name>-source
cd /tmp/<name>-source

# Identify key endpoints
cat <backend-dir>/routes/*.py        # FastAPI routes
cat <backend-dir>/models.py          # Pydantic models

# Identify port
grep -r "port\|127.0.0.1\|localhost" <backend-dir>/*.py | head -10
```

Key questions:
- What port does it run on?
- What are the main API endpoints?
- What auth/token does it need?
- What config values should be exposed?

### 2. Create Python Adapter

**File:** `maquina/lib/adapters/<name>.py`

Template:

```python
"""<Name> adapter for Máquina de Videos."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import httpx

from maquina.core.config import load_config


DEFAULT_<NAME>_URL = "http://127.0.0.1:<PORT>"


class <Name>Client:
    """HTTP client for the <Name> API."""

    def __init__(self, base_url: str | None = None) -> None:
        config = load_config()
        svc_config = getattr(config, "<name>", None) or {}
        if isinstance(svc_config, dict):
            self.base_url = (base_url or svc_config.get("url") or os.environ.get("<NAME>_URL") or DEFAULT_<NAME>_URL).rstrip("/")
        else:
            self.base_url = (base_url or os.environ.get("<NAME>_URL") or DEFAULT_<NAME>_URL).rstrip("/")
        self.client = httpx.Client(base_url=self.base_url, timeout=120.0)

    def health(self) -> dict[str, Any]:
        try:
            resp = self.client.get("/health")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"available": False, "error": str(e)}

    def close(self) -> None:
        self.client.close()


def <name>_available(base_url: str | None = None) -> bool:
    url = (base_url or os.environ.get("<NAME>_URL", DEFAULT_<NAME>_URL)).rstrip("/")
    try:
        resp = httpx.get(f"{url}/health", timeout=5.0)
        return resp.status_code == 200
    except Exception:
        return False
```

### 3. Create CLI Commands

**File:** `maquina/lib/adapters/<name>_cli.py`

```python
"""<Name> CLI commands."""

from maquina.lib.adapters.<name> import <Name>Client, <name>_available


def <name>_status_command() -> int:
    """Check <Name> connection status."""
    adapter = <Name>Client()
    health = adapter.health()
    print(f"Status: {'✅' if health.get('available') else '❌'}")
    adapter.close()
    return 0 if health.get("available") else 1
```

### 4. Register in Adapters Init

**File:** `maquina/lib/adapters/__init__.py`

```python
from maquina.lib.adapters.<name> import <Name>Client, <name>_available
```

### 5. Add Config Section

**File:** `config.yaml`

```yaml
<name>:
  enabled: true
  url: "http://127.0.0.1:<PORT>"
  # Add tool-specific config here
```

### 6. Add CLI Subcommands

**File:** `maquina/cli.py`

Add argument parser near other subparsers:

```python
<name>_parser = subparsers.add_parser("<name>", help="<Name> integration")
<name>_subparsers = <name>_parser.add_subparsers(dest="<name>_command")
<name>_status_parser = <name>_subparsers.add_parser("status", help="Check status")
```

Add dispatch in `main()`:

```python
elif args.command == "<name>":
    _cmd_<name>(args)
```

Add handler function:

```python
def _cmd_<name>(args: argparse.Namespace) -> None:
    from maquina.lib.adapters.<name>_cli import <name>_status_command
    if args.<name>_command == "status":
        sys.exit(<name>_status_command())
```

### 7. Add Web API Endpoints

**File:** `maquina/web_api.py`

Add import:
```python
from maquina.lib.adapters.<name> import <Name>Client
```

Add status function (before `WebApiHandler` class):
```python
def get_<name>_status() -> dict[str, Any]:
    client = <Name>Client()
    try:
        return client.health()
    finally:
        client.close()
```

Add GET route in `do_GET`:
```python
if path == "/api/<name>/status":
    _json_response(self, get_<name>_status())
    return
```

### 8. Add Frontend Types

**File:** `web/src/lib/api/types.ts`

```typescript
export interface <Name>Status {
  available: boolean;
  url: string;
  message: string;
  // Add tool-specific fields
}
```

### 9. Add API Client Methods

**File:** `web/src/lib/api/client.ts`

```typescript
get<Name>Status(): Promise<<Name>Status> {
  return withFallback(() => fetchJson<<<Name>Status>>("/<name>/status"), { available: false, url: "", message: "Not configured" });
},
```

### 10. Add React Hook

**File:** `web/src/hooks/use<Name>Status.ts`

```typescript
import { useEffect, useState } from "react";
import { apiClient } from "@/lib/api/client";
import type { <Name>Status } from "@/lib/api/types";

export function use<Name>Status() {
  const [status, setStatus] = useState<<<Name>Status> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    apiClient.get<Name>Status().then((response) => {
      if (!active) return;
      setStatus(response);
      setLoading(false);
    });
    return () => { active = false; };
  }, []);

  return { status, loading };
}
```

### 11. Add React Page/Component

Create page or add integration to existing page (e.g., VideoLibrary, SocialWizard).

### 12. Add Route (if new page)

**File:** `web/src/App.tsx`

```typescript
import { <Name>Page } from "./pages/<Name>Page";
// ...
<Route path="<name>" element={<<Name>Page />} />
```

### 13. Add Tests

**File:** `tests/test_adapters/test_<name>_adapter.py`

```python
from unittest.mock import MagicMock, patch
from maquina.lib.adapters.<name> import <Name>Client, <name>_available

class Test<Name>Available:
    def test_available_success(self):
        with patch("maquina.lib.adapters.<name>.httpx.get") as mock_get:
            mock_get.return_value = MagicMock(status_code=200)
            assert <name>_available() is True
```

### 14. Verify Everything

```bash
# Python compilation
cd /tmp/video-machine && python -m py_compile maquina/web_api.py maquina/cli.py maquina/lib/adapters/<name>.py

# Tests
cd /tmp/video-machine && source .venv/bin/activate && python -m pytest tests/ -q

# Frontend build
cd /tmp/video-machine/web && npm run build
```

## Phase 0: Repair the Base Project First

Before integrating any sidecar, verify the base project actually runs. In this session the base project had multiple hidden blockers:

```bash
# 1. Install and run tests
cd /tmp/video-machine
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest tests/ -q

# 2. Build frontend
cd web && npm install && npm run build

# 3. Try running the web API
python -m maquina.web_api
```

Common base-project blockers to fix **before** touching sidecars:

| Symptom | Fix |
|---------|-----|
| `build-backend` error in pyproject.toml | Change to `setuptools.build_meta` |
| `requires-python = ">=3.12"` but system has 3.11 | Lower to `>=3.11` |
| `ModuleNotFoundError: No module named 'numpy'` | Add `numpy` to core deps or install it |
| Missing `requirements.txt` | Create one from `pyproject.toml` dependencies |
| Tests import adapters that fail | Install implicit deps first (numpy, httpx, etc.) |

### Critical Bug Pattern: Save Results *After* Determining State

We found a bug in all 3 pipelines: `pipeline_results.json` was written **before** setting `completed=True` and `valid_output=True`. This caused the Dashboard and Library to show every video as `"processing"` forever.

**Wrong:**
```python
results_file.write_text(json.dumps(results))  # ← saved too early!
if stages_ok:
## Phase 0: Repair the Base Project First

Before integrating any sidecar, verify the base project actually runs. In this session the base project had multiple hidden blockers:

```bash
# 1. Install and run tests
cd /tmp/video-machine
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest tests/ -q

# 2. Build frontend
cd web && npm install && npm run build

# 3. Try running the web API
python -m maquina.web_api
```

Common base-project blockers to fix **before** touching sidecars:

| Symptom | Fix |
|---------|-----|
| `build-backend` error in pyproject.toml | Change to `setuptools.build_meta` |
| `requires-python = ">=3.12"` but system has 3.11 | Lower to `>=3.11` |
| `ModuleNotFoundError: No module named 'numpy'` | Add `numpy` to core deps or install it |
| Missing `requirements.txt` | Create one from `pyproject.toml` dependencies |
| Tests import adapters that fail | Install implicit deps first (numpy, httpx, etc.) |

### Critical Bug Pattern: Save Results *After* Determining State

We found a bug in all 3 pipelines: `pipeline_results.json` was written **before** setting `completed=True` and `valid_output=True`. This caused the Dashboard and Library to show every video as `"processing"` forever.

**Wrong:**
```python
results_file.write_text(json.dumps(results))  # ← saved too early!
if stages_ok:
    results["completed"] = True
```

**Right:**
```python
if stages_ok:
    results["completed"] = True
    results["valid_output"] = True
# ← save ONLY after all mutations
results_file.write_text(json.dumps(results))
```

Apply this fix to `social.py`, `marketing.py`, and `demo.py`.

### Graceful Fallback for Partially-Installed AI Deps

When an AI dep (e.g., `faster-whisper`) is installed but fails on a specific file (invalid audio, wrong format), the tool should fall back to stub mode rather than returning `success=False`:

```python
# Try real provider
if self._faster_whisper_available():
    result = self._transcribe_faster_whisper(...)
    if result.success:
        return result
# Fall through to stub on failure
return self._transcribe_stub(input_path, output_dir)
```

## Phase 2.5: Production Manifest (Convergence Page)

After a pipeline completes, create a **single page** that aggregates ALL artifacts so the user sees everything in one place before editing.

### Backend: Production Manifest Endpoint

Add to `maquina/web_api.py`:

```python
def get_job_production_manifest(job_id: str) -> dict[str, Any]:
    """Return complete production manifest: video, subs, script, storyboard, viral."""
    job = JOBS.get(job_id)
    if not job:
        return {"error": "Job not found"}
    
    result = job.get("result") or {}
    output_dir = Path(result.get("output_dir", "output"))
    
    manifest = {
        "job_id": job_id,
        "status": job.get("status"),
        "video_path": None,
        "subtitles_path": None,
        "script": None,
        "storyboard": None,
        "transcript": None,
        "viral_score": None,
        "recommendations": [],
        "assets": [],
    }
    
    # Find all artifacts in output dir
    if output_dir.exists():
        video_files = list(output_dir.glob("*.mp4")) + list(output_dir.glob("*.mov"))
        if video_files:
            manifest["video_path"] = str(video_files[0])
        srt_files = list(output_dir.glob("*.srt")) + list(output_dir.glob("*.ass"))
        if srt_files:
            manifest["subtitles_path"] = str(srt_files[0])
        for f in output_dir.iterdir():
            if f.is_file():
                manifest["assets"].append({"name": f.name, "path": str(f), "size": f.stat().st_size})
    
    # Extract from pipeline stages
    stages = result.get("stages", {})
    if "script" in stages:
        manifest["script"] = stages["script"].get("data")
    if "storyboard" in stages:
        manifest["storyboard"] = stages["storyboard"].get("data")
    if "viral_score" in stages:
        vs = stages["viral_score"].get("data", {})
        manifest["viral_score"] = vs.get("score") or vs.get("viral_score")
        manifest["recommendations"] = vs.get("recommendations", [])
    
    return manifest
```

Add route in `do_GET`:
```python
if path.startswith("/api/jobs/") and path.endswith("/produccion"):
    job_id = path.split("/api/jobs/", 1)[1].replace("/produccion", "")
    manifest = get_job_production_manifest(job_id)
    if "error" in manifest:
        _json_response(self, manifest, status=HTTPStatus.NOT_FOUND)
    else:
        _json_response(self, manifest)
    return
```

### Frontend: Production Page

Create `web/src/pages/ProduccionFinal.tsx` with tabs for each artifact type:
- **Video**: Show generated video file(s)
- **Subtítulos**: Word-level or segment-level subtitles with timestamps
- **Guion**: Generated script text
- **Storyboard**: Ordered clips with timings
- **Viral**: Score + prioritized recommendations

Side panel:
- Action buttons: "Editar en SmartCut", "Descargar paquete"
- Pipeline checklist: which stages completed successfully
- List of all assets with file sizes

Connect from SocialWizard completion:
```typescript
// When pipeline completes
<Button onClick={() => navigate(`/produccion?job=${job.id}`)}>
  Ver producción final
</Button>
```

### Why This Matters

Without a convergence page, the user must hunt through `output/` directories. The Production Manifest makes the pipeline feel **complete** — the user sees every artifact they paid (in compute/time) to generate.

## Phase 3.5: Windows Desktop Launcher (WSL Projects)

After integration is complete, create a **one-click launcher** on the Windows desktop so the user can start the entire stack without touching the terminal.

### Critical: Use ASCII-only in .bat files

`cmd.exe` cannot parse Unicode box-drawing characters or emojis. Every character like `╔`, `═`, `║`, `╗`, `🎬` will be interpreted as a separate command, producing errors like:
```
"║" no se reconoce como un comando interno o externo
```

**Always use plain ASCII in `.bat` files.** Save emojis for PowerShell scripts or the web UI only.

### 1. Create WSL start script

**File:** `scripts/start-maquina.sh`

```bash
#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
source "$PROJECT_ROOT/.venv/bin/activate"

# Kill previous instances
pkill -f "python -m maquina.web_api" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true
sleep 1

# Start backend
cd "$PROJECT_ROOT"
python3 -m maquina.web_api > /tmp/maquina-backend.log 2>&1 &

# Wait for backend
for i in {1..30}; do
    curl -s http://127.0.0.1:8765/api/health > /dev/null 2>&1 && break
    sleep 1
done

# Start frontend
cd "$PROJECT_ROOT/web"
npm run dev > /tmp/maquina-frontend.log 2>&1 &

# Wait for frontend
for i in {1..30}; do
    curl -s http://127.0.0.1:5173 > /dev/null 2>&1 && break
    sleep 1
done

# Open Windows browser from WSL
cmd.exe /c start http://localhost:5173 2>/dev/null || \
explorer.exe http://localhost:5173 2>/dev/null || \
powershell.exe -Command "Start-Process http://localhost:5173" 2>/dev/null

echo "Máquina de Videos corriendo en http://localhost:5173"
echo "Presiona Ctrl+C para detener..."
trap 'pkill -f vite; pkill -f "python -m maquina.web_api"; exit 0' INT
wait
```

### 2. Create Windows .bat launcher

**File:** `/mnt/c/Users/<Username>/Desktop/Máquina de Videos.bat`

```batch
@echo off
chcp 65001 >nul
title Máquina de Videos
cls
echo.
echo =========================================
echo   MAQUINA DE VIDEOS v0.1.0
echo =========================================
echo.
wsl.exe bash /tmp/video-machine/scripts/start-maquina.sh
pause
```

### 3. Discover Windows username

```bash
ls /mnt/c/Users/ | grep -v Public | grep -v Default | grep -v All
# Or use a generic desktop path:
# /mnt/c/Users/*/Desktop/
```

### 4. Create INSTALL.md

Document the one-time setup and the daily "double-click to run" workflow.

## Common Pitfalls

1. **TypeScript null guard after early return**: After an `if (!manifest) return` guard, TypeScript may still consider `manifest` possibly null. Use `const m = manifest as NonNullable<typeof manifest>;` to create a non-null alias.
2. **TypeScript build errors**: The `withFallback` mock default must match the type exactly (all required fields). Check `types.ts` for missing fields.
3. **Import order in `adapters/__init__.py`**: Some adapters import from each other. Use lazy imports inside functions to avoid circular deps.
4. **Web API endpoint order**: Add new `if path == "/api/<name>/..."` routes BEFORE the catch-all `Not found` block.
5. **Config loading**: `getattr(config, "<name>", None)` returns the raw dict from YAML. Access with `.get("url")` after checking `isinstance(svc_config, dict)`.
6. **Frontend `path` on VideoItem**: The backend `scan_videos()` includes a `path` field. Make sure `VideoItem` type includes `path?: string`.
7. **Job result typing**: `job.result` is `Record<string, unknown> | null`. Cast before accessing nested properties: `const result = job?.result as Record<string, unknown> | null;`
8. **Windows desktop path**: Use `/mnt/c/Users/<Username>/Desktop/`. Discover username with `ls /mnt/c/Users/ | grep -v Public`.
9. **WSL browser launch**: `cmd.exe /c start URL` works from WSL but may fail silently. Chain fallbacks: `cmd.exe` → `explorer.exe` → `powershell.exe`.
10. **Provider chain integration**: When integrating a sidecar into an existing tool's provider fallback chain (e.g., TTS: openai → elevenlabs → **voicebox** → piper → espeak), add it in the correct quality/latency position, not just at the end.
11. **Windows .bat files must be ASCII-only**: `cmd.exe` cannot parse Unicode box-drawing chars or emojis. Characters like `╔`, `═`, `║`, `🎬` are interpreted as separate commands, producing errors. Use plain ASCII in `.bat` files; save decorative characters for PowerShell or web UI only.

## Decision Filter for Sidecar vs Embedded

Use **sidecar** (this pattern) when:
- The tool has its own web UI or complex state
- It runs its own server (FastAPI, Next.js, etc.)
- It needs GPU/ML models that don't fit well in the main process
- It has a large dependency tree (PyTorch, CUDA, etc.)

Use **embedded** (direct Python import) when:
- It's a small pure-Python library
- No separate server needed
- No heavy ML dependencies

## Examples in This Project

| Tool | Port | Integration Files | Notes |
|------|------|-------------------|-------|
| Voicebox | 17493 | `maquina/lib/adapters/voicebox.py`, `voicebox_cli.py`, TTS tool | TTS synthesis, voice cloning |
| SmartCut | 3000 | `maquina/lib/adapters/smartcut.py`, `smartcut_cli.py`, Editor page | Video editor with timeline |
