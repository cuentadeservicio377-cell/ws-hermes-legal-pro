---
name: contrarian-vc-pitch
description: Build contrarian VC pitches for non-standard startup models (company builders, studios, holding companies) targeting YC, EF, or tier-1 accelerators. Focuses on narrative hinges, anti-pattern reframes, and investor psychology.
category: software-development
---

# Contrarian VC Pitch Builder

## When to Use This Skill

Use when the business model **does NOT fit the standard YC template** (single product, technical founders, clear TAM, linear growth). Specifically for:
- Company builders / venture studios
- Holding companies with multiple verticals
- Service-first → product-later models
- AI-native agencies selling clones/playbooks
- Businesses with regulatory moats (legal, gov, health)
- Solo founders seeking cofounders
- Founders with manifesto websites that don't clearly explain the product
- Any pitch where the website and the founder's description seem to describe different companies

**Critical:** This skill requires a Reality Audit (Phase 0) before constructing narrative. Never assume the founder's description matches reality.

## Core Philosophy

**YC's stated criteria:** Make something people want, found by technical teams, in large markets.

**YC's unstated fear:** Distraction, optionality, lack of focus, slow capital efficiency.

**Your job:** Reframe what looks like weakness (multiple businesses, service model, regulated industries) into asymmetric advantage (compounding know-how, captive customers, regulatory moats, portfolio optionality).

## Phase 0: Reality Audit (CRITICAL — Do This First)

**Never build a pitch from memory, assumptions, or the founder's description alone.** Contrarian startups often have a massive gap between what the founder THINKS they are building and what actually exists. Audit reality before constructing narrative.

### Step 1: Scrape the Real Web Presence
```bash
# Check what the world actually sees
curl -sL -A "Mozilla/5.0" "https://[company].com" | grep -o '<title>[^<]*\|<h[1-3][^>]*>[^<]*\|<p[^>]*>[^<]*' | head -40
```

**What to look for:**
- Is the website a **product page** (clear pricing, clear value prop, clear CTA) or a **manifesto** (philosophy, vision, aesthetic)?
- Does it mention revenue, customers, traction? Or only vision?
- How many "verticals" or "products" are listed? Are they real or aspirational?
- Is there a concrete price? A concrete offer? A concrete deliverable?

### Step 2: The Manifesto vs. Operations Test
Many visionary founders build beautiful manifesto websites that confuse VCs. Ask:

| Manifesto Website Says | VC Needs to Hear |
|---|---|
| "We are an AI Lab & Venture Capital Hybrid" | "We sell X to Y for $Z/month" |
| "5 Active Units across multiple sectors" | "Our first product is X with N customers" |
| "80% Agentic, 20% Human operational paradigm" | "Our AI agents save customers 25 hours/week" |
| "Investing in people, building infrastructure" | "$1,500/mo AI Lab, 2 customers, sold out" |
| "Open source tools for democratized intelligence" | "Free tier drives paid conversions at X%" |

**Rule:** If the website doesn't mention pricing, the product may not exist yet. If it mentions 5+ verticals, the founder may be unfocused. Your job is to find the ONE concrete thing that generates revenue and lead with THAT.

### Step 3: Find the Actual Product
Look for:
- Pricing pages
- "Book a call" vs. "Buy now" (services sell calls, products sell directly)
- GitHub repos (are they active? do they have stars?)
- Customer testimonials with names
- Revenue claims (even "sold out" or "waitlist")

### Step 4: YC RFS Alignment Check
Before building narrative, check if the company fits a YC **Request for Startups** category:
```
https://www.ycombinator.com/rfs
```
If there's an explicit RFS match (e.g., "AI-Native Agencies"), that is your strongest hook. Lead with it.

---

## Pre-Phase: Investigate Existing Assets Before Assuming Anything

Before constructing any narrative, investigate the founder's existing web presence, repos, products, and public materials. This prevents building a pitch on false assumptions.

### Commands to Run
```bash
# Scrape the founder's main website
curl -sL -A "Mozilla/5.0" --max-time 15 "https://[company].com" | grep -o '<title>[^<]*\|<h[1-3][^>]*>[^<]*\|<p[^>]*>[^<]*' | head -40

# Check GitHub repos for proof-of-work
curl -sL "https://github.com/[user]" | grep -o 'repo-list[^"]*\|pinned-item[^"]*' | head -10

# Look for open source or linked resources
curl -sL "https://[company].com" | grep -oi 'href="[^"]*"' | sort | uniq
```

### Reality Check Questions
1. What does the website ACTUALLY say the company does?
2. What products/services have real prices?
3. What is the gap between the public narrative and the internal reality?
4. Are there contradictions between what the founder says and what the site shows?

**Never build a pitch on assumptions. Always ground it in reality first.**

---

## Phase 0: Reality Audit (CRITICAL — Do This First)

**Never build a pitch from memory, assumptions, or the founder's description alone.** Contrarian startups often have a massive gap between what the founder THINKS they are building and what actually exists. Audit reality before constructing narrative.

### Step 1: Scrape the Real Web Presence
```bash
# Check what the world actually sees
curl -sL -A "Mozilla/5.0" "https://[company].com" | grep -o '<title>[^<]*\|<h[1-3][^>]*>[^<]*\|<p[^>]*>[^<]*' | head -40
```

**What to look for:**
- Is the website a **product page** (clear pricing, clear value prop, clear CTA) or a **manifesto** (philosophy, vision, aesthetic)?
- Does it mention revenue, customers, traction? Or only vision?
- How many "verticals" or "products" are listed? Are they real or aspirational?
- Is there a concrete price? A concrete offer? A concrete deliverable?

### Step 2: The Manifesto vs. Operations Test
Many visionary founders build beautiful manifesto websites that confuse VCs. Ask:

| Manifesto Website Says | VC Needs to Hear |
|---|---|
| "We are an AI Lab & Venture Capital Hybrid" | "We sell X to Y for $Z/month" |
| "5 Active Units across multiple sectors" | "Our first product is X with N customers" |
| "80% Agentic, 20% Human operational paradigm" | "Our AI agents save customers 25 hours/week" |
| "Investing in people, building infrastructure" | "$1,500/mo AI Lab, 2 customers, sold out" |
| "Open source tools for democratized intelligence" | "Free tier drives paid conversions at X%" |

**Rule:** If the website doesn't mention pricing, the product may not exist yet. If it mentions 5+ verticals, the founder may be unfocused. Your job is to find the ONE concrete thing that generates revenue and lead with THAT.

### Step 3: The Founder Brain Dump
After auditing the website, do a structured voice interview with the founder. Ask:
1. What have you BUILT that is online and working RIGHT NOW? (Links, demos, repos)
2. What is your REVENUE today? (Exact numbers, not aspirational)
3. What FAILED in the past 2 years and what did you learn?
4. What is the ONE product that a customer PAID FOR?
5. Who is on the team? (Names, roles, full-time vs contractor)
6. How old is the company really? (Founders often understate or overstate)

**The gap between the website and the founder's voice is where your real narrative lives.**

### Step 4: Find the Actual Product
Look for:
- Pricing pages
- "Book a call" vs. "Buy now" (services sell calls, products sell directly)
- GitHub repos (are they active? do they have stars?)
- Customer testimonials with names
- Revenue claims (even "sold out" or "waitlist")

### Step 5: YC RFS Alignment Check
Before building narrative, check if the company fits a YC **Request for Startups** category:
```
https://www.ycombinator.com/rfs
```
If there's an explicit RFS match (e.g., "AI-Native Agencies"), that is your strongest hook. Lead with it.

---

Every contrarian pitch needs a **hinge** — a single insight that makes the investor say "Oh, I was thinking about this wrong."

### Find Your Hinge

Ask these questions IN ORDER:

1. **What is the thing investors will immediately dismiss us for?**
   - Example: "We're a company builder, not a focused startup."
   - Example: "We do services first, product later."
   - Example: "We're in legal — boring, regulated, slow."

2. **What is the hidden mechanism that makes that 'weakness' a moat?**
   - "Every 'startup' that tried to sell legal tech failed because they never operated a law firm. We run one. That operating data is our training set."
   - "Services give us paid R&D. Customers fund our product development before we write a line of product code."
   - "Regulation is a wall that keeps out fast followers. Once we're in, we're sticky for decades."

3. **What is the ONE company or precedent that proves this can work at scale?**
   - Example: "Rocket Internet proved you can clone and scale. We do the same, but with AI and for regulated industries."
   - Example: "Palantir started as a consultancy that productized. We're Palantir for professional services."

### The Hinge Statement Template

```
"Most investors think [obvious frame] → but [contrarian insight] → because [hidden mechanism] → which means [reframed strength]."
```

Example for WS Capital:
> "Most investors think company builders are unfocused → but focus is a liability in the AI era when the right strategy is to build vertical operating systems → because AI lets us turn any service business into software margins → which means each business we run makes the NEXT one cheaper and faster to launch."

## Phase 2: The Anti-Pattern Reframe Matrix

Map each "red flag" to its "reframe":

| Investor Red Flag | Standard Weakness | Contrarian Reframe |
|---|---|---|
| Multiple businesses | Unfocused | Portfolio of optionality; each vertical de-risks the others |
| Service model first | Not scalable | Paid customer discovery; revenue-funded R&D |
| Regulated industry | Hard to sell | Regulatory moat; competitors can't copy fast |
| Solo founder | Risky | Proven operator; seeking technical cofounder actively |
| Pre-revenue | Too early | Letters of intent; pilot customers paying for services |
| Non-US market | Small TAM | Beachhead in high-growth emerging market; US expansion ready |
| Selling to SMBs | Low ACV | High volume, low churn, AI-reduced CAC |

## Phase 3: The Metric That Matters

For contrarian pitches, standard metrics (MRR, user count) may be weak. Find the **one metric** that proves the model works:

- **Magic number:** Cost to launch new vertical (decreasing over time)
- **Magic number:** Margin expansion from service → clone (service 20% → SaaS 80%)
- **Magic number:** Time to first paying clone customer (weeks, not months)
- **Magic number:** Revenue per AI-automated employee vs. traditional agency

If you don't have it yet, define it and commit to measuring it.

## Phase 4: The Precedent Stack

Investors think in analogies. Give them the RIGHT analogies:

- **Rocket Internet** → "We clone AND innovate, not just clone."
- **Palantir** → "Services → product flywheel."
- **Stripe** → "Infrastructure for others to build on."
- **OpenAI** → "We don't sell AI; we sell businesses that use AI better than anyone."
- **Lambda School / BloomTech** → "We run the business to prove the model, then sell the model."

NEVER compare yourself to:
- WeWork (unfocused, capital-intensive)
- SoftBank Vision Fund (spray and pray)
- Any failed venture studio (unless explaining why YOU'RE different)

## Phase 5: The Application Strategy

### The Single Wedge Rule (for YC)
Even if the company has a grand vision, 5 verticals, and a manifesto website, the YC application must lead with **ONE concrete product** that has:
- A clear price
- A clear customer
- A clear value proposition
- Some evidence of demand (even a waitlist)

The "machine" or "vision" only appears in "What is your 10-year vision?"

Example:
- ❌ Bad: "We are an AI Lab building infrastructure for LatAm founders across legal, marketing, and admin."
- ✅ Good: "We sell an AI-powered operational lab to SME founders for $1,500/mo. We handle their legal, admin, and back-office via agents so they focus on growth."

### If Applying to YC
### If Applying to YC
- **Lead with ONE vertical** (e.g., Willow) as the wedge
- Mention the "machine" as the vision, not the present
- Emphasize technical founders / AI-native stack
- Show 10-week growth potential (YC loves steep curves)
- **If YC has an RFS category that matches, lead with that match explicitly**

### If Applying to EF
- **Lead with the founder's potential** (you)
- Emphasize willingness to find a technical cofounder
- Frame as "I have the domain; I need the code"
- Singapur = proximity to ASEAN markets, lower burn rate

### If Applying to NS Fellowship (Network School / Balaji)
- **Lead with proof-of-work, not the product**
- Emphasize builder mentality, shipped products, resilience through failure
- Frame as "exit > voice" — building alternatives to broken institutions
- Focus on the founder's story, not just the company metrics
- Balaji values contrarian models, anti-fragility, and global meritocracy
- The ask is $100K, no equity, 1 year, remoto

### If Applying to Both
- YC application = focused, product-first, aggressive
- EF application = talent-first, vision-first, collaborative
- NEVER submit identical narratives

## Phase 6: The Stress Test

Before submitting, answer these brutal questions:

1. **If this works, why hasn't anyone done it before?**
2. **What is the specific thing that would make YC partners say no in the first 30 seconds?**
3. **What is the ONE sentence that reframes that objection?**
4. **If you had to kill all verticals except one, which survives and why?**
5. **What metric would make you look stupid in 6 months if you don't hit it?**
6. **Why are YOU the person who wins this? Not generic. Specific.**
7. **What happens if OpenAI builds this in 12 months?**
8. **If YC says no, what is Plan B and why does it still work?**

## Tools & Commands

### Create a pitch vault
```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
mkdir -p "$VAULT/Pitch/[Company]/01_Hinge" "$VAULT/Pitch/[Company]/02_Reframes" "$VAULT/Pitch/[Company]/03_Metrics" "$VAULT/Pitch/[Company]/04_Precedents" "$VAULT/Pitch/[Company]/05_Application" "$VAULT/Pitch/[Company]/06_Stress_Test"
```

### Generate hinge statement
Use the template above with the company's specific red flags.

### Research YC RFS (Requests for Startups)
Check https://www.ycombinator.com/rfs for relevant categories.

### Research EF batches
Check https://www.joinef.com for current locations and batch dates.

## The Single Wedge Rule (YC Critical)

Even if the company has a grand vision, 5 verticals, and a manifesto website, the YC application must lead with **ONE concrete product** that has:
- A clear price
- A clear customer
- A clear value proposition
- Some evidence of demand (even a waitlist)

The "machine" or "vision" only appears in "What is your 10-year vision?"

**Example:**
- ❌ Bad: "We are an AI Lab building infrastructure for LatAm founders across legal, marketing, and admin."
- ✅ Good: "We sell an AI-powered operational lab to SME founders for $1,500/mo. We handle their legal, admin, and back-office via agents so they focus on growth."

**Why this matters:** YC partners spend 30 seconds on the first read. If they see "5 verticals" they think "unfocused." If they see "1 product with a price" they think "potential."

## Pitfalls

## Pitfalls

- **DO NOT** build the pitch from founder description alone. Audit the real web presence, product, and pricing first. Your assumptions will be wrong.
- **DO NOT** fall into the Manifesto Website Trap. A beautiful visionary website confuses VCs. Translate philosophy into "we sell X to Y for $Z."
- **DO NOT** lead with "we're a company builder." Lead with the FIRST business that generates revenue.
- **DO NOT** say "we have no competition." Say "our competition is fragmented mom-and-pop shops."
- **DO NOT** use AI buzzwords without a specific technical moat.
- **DO NOT** submit the same application to YC and EF.
- **DO NOT** inflate metrics. YC partners have been doing this for 20 years. They smell bullshit instantly.
- **DO NOT** list 5+ verticals in the application. Pick ONE wedge. The others are "future expansion."
- **DO NOT** assume the founder's voice description matches the website. Do the Reality Audit. The gap between the two is your real story.
- **DO NOT** trust voice transcription for critical terms. "Atrasada" can become "sexualizada." Confirm ambiguous terms with the founder.
- **DO NOT** list 5+ verticals in the application. Pick ONE wedge. The others are "future expansion."

## Output Checklist

Before any pitch is "done":
- [ ] Reality Audit completed (website scraped, product identified, pricing verified)
- [ ] Founder brain dump completed (revenue, failures, team, real history)
- [ ] Hinge statement written and tested on a skeptic
- [ ] All red flags mapped to reframes
- [ ] ONE metric that matters is defined and tracked
- [ ] Precedent stack has 3+ companies with specific comparisons
- [ ] Application answers are sub-50 words per field
- [ ] Video script is under 60 seconds and includes the hinge
- [ ] Stress test questions answered honestly
- [ ] Plan B exists and is credible
- [ ] NS Fellowship application drafted (if applicable)
- [ ] YC/EF applications are DIFFERENT (never identical)

---

## Example: WS Capital Application (Partial)

**What is your company doing?**
> "Willow is an AI-powered law firm that operates as a service, then sells its operating system as a SaaS clone to other lawyers. We prove the model first, productize it second."

**Why will you succeed?**
> "We are the only team that runs a real law firm AND builds legal tech. Every other legal tech startup guesses what lawyers need. We know because we are one."

**What is your 10-year vision?**
> "A portfolio of AI-native agencies — legal, marketing, accounting — each proven internally, then cloned globally."

**Why YC?**
> "We need to compress 2 years of learning into 10 weeks. YC's density of operator-founders is the only place we can stress-test this model fast enough."
