---
name: subagent-environment-context
description: "When delegating tasks to subagents via delegate_task, the subagent often lacks awareness of its execution environment (WSL vs VPS, available toolsets, Windows filesystem access, package installation rights). This skill ensures subagents are given explicit context about their environment so they don't get stuck on tasks they could complete."
version: 1.0.0
author: Hermes Agent
tags: [subagent, delegation, environment, wsl, toolsets, context]
---

# Subagent Environment Context

## Purpose

Ensure subagents spawned via `delegate_task` know:
1. What tools they actually have available
2. What operating system they're on
3. That they have full machine access (not a sandboxed VPS)
4. How to access Windows files (if in WSL)

## The Problem (discovered 30 Apr 2026)

When a subagent spawns, it often:
- Doesn't know it has `web_search` or `browser_navigate`
- Doesn't know it's in WSL2 with Windows filesystem at `/mnt/c/`
- Doesn't know it can install packages with `apt/npm/pip`
- Operates as if it's in a restricted sandbox

This causes subagents to **get stuck** on research tasks, file operations, or web tasks — not because they lack capability, but because they don't **know** they have it.

## When to Use

Use this skill EVERY time you call `delegate_task` with a subagent that may need to:
- Search the web
- Navigate websites
- Install packages
- Access Windows files
- Use tools beyond `terminal` and `file`

## The Solution: Explicit Context Injection

### Template for delegate_task context

```
ENVIRONMENT CONTEXT — You have full access to this machine:
- OS: WSL2 Ubuntu 24.04 running on Windows
- Windows filesystem mounted at: /mnt/c/ (e.g., /mnt/c/Users/DELL/Desktop/)
- You can install packages: sudo apt install, npm install, pip install
- You can modify system files and configurations
- Working directory: [current CWD]

TOOLS AVAILABLE — You have these specific tools:
- terminal: Execute shell commands (bash, python, node, git, etc.)
- file: read_file, write_file, search_files (local filesystem)
- web: search_files with target='web' (search the internet)
- browser: browser_navigate, browser_click, browser_extract (browse websites)
- vision: vision_analyze (analyze images from URLs)

IMPORTANT: Do NOT say "I don't have web access" — you DO. Use search_files with target='web'.
Do NOT say "I can't install packages" — you CAN. Use terminal with apt/npm/pip.
Do NOT say "I'm in a sandbox" — you have FULL machine access.
```

### Example: Delegating a research task

```python
delegate_task(
    goal="Research the top 3 competitors of Notion and summarize their pricing",
    context="""
    ENVIRONMENT CONTEXT — You have full access to this machine:
    - OS: WSL2 Ubuntu 24.04 running on Windows
    - Windows filesystem mounted at: /mnt/c/
    - You can install packages if needed
    - Working directory: /root

    TOOLS AVAILABLE:
    - terminal: shell commands
    - file: read/write/search local files
    - web: search_files with target='web' for internet search
    - browser: browser_navigate to visit specific URLs

    TASK: Research Notion competitors. Use web search first, then browser to visit their pricing pages.
    Do NOT say you can't search the web — use search_files with target='web'.
    """,
    toolsets=['terminal', 'file', 'web', 'browser']
)
```

### Example: Delegating a build task

```python
delegate_task(
    goal="Install Node.js 20 and build the Next.js app in /mnt/c/Users/DELL/Documents/my-app",
    context="""
    ENVIRONMENT CONTEXT:
    - OS: WSL2 Ubuntu 24.04 on Windows
    - Windows files at: /mnt/c/Users/DELL/Documents/
    - Full sudo access
    - Can install packages: apt, npm, nvm

    TOOLS AVAILABLE:
    - terminal: all shell commands
    - file: read/write local files

    TASK: The app is at /mnt/c/Users/DELL/Documents/my-app. Install Node 20 if missing, then npm install && npm run build.
    If nvm is not installed, install it first.
    """,
    toolsets=['terminal', 'file']
)
```

## Common Failures and Fixes

| Subagent Says | Root Cause | Fix |
|---------------|-----------|-----|
| "I don't have web access" | Doesn't know `search_files target='web'` exists | Add to context: "Use search_files with target='web' for internet search" |
| "I can't install packages" | Thinks it's sandboxed | Add to context: "You have sudo. Use apt/npm/pip freely." |
| "I'm in a restricted environment" | Doesn't know it's WSL with full access | Add to context: "You have FULL machine access. Not a sandbox." |
| "I can't access Windows files" | Doesn't know about `/mnt/c/` | Add to context: "Windows is at /mnt/c/Users/[username]/" |
| "I don't have browser" | Toolset not propagated or not known | Add `browser` to toolsets AND tell it explicitly |

## Verification: Test Your Subagent's Awareness

Before delegating important work, verify the subagent knows its environment:

```python
delegate_task(
    goal="Report what tools and environment you have. Be specific.",
    context="""
    ENVIRONMENT CONTEXT:
    - OS: WSL2 Ubuntu 24.04 on Windows
    - Full machine access (not sandboxed)
    - Working directory: /root

    TOOLS AVAILABLE:
    - terminal, file, web, browser

    Answer these exactly:
    1. What OS are you on?
    2. Can you run shell commands?
    3. Can you search the web? How?
    4. Can you browse websites?
    5. Can you install packages?
    6. Can you access Windows files?
    """,
    toolsets=['terminal', 'file', 'web', 'browser']
)
```

If the subagent answers incorrectly (e.g., says "NO" to web search), the toolsets are not propagating or the context is insufficient.

## Key Principles

1. **Never assume subagents inherit context** — They start fresh. Tell them everything.
2. **Explicit beats implicit** — Say "You HAVE web search" rather than hoping they figure it out.
3. **Toolsets + Context together** — Passing `toolsets=['web']` is not enough. Also say "You can search the web."
4. **WSL is not a VPS** — Subagents often default to "cloud/VPS" mindset. Explicitly say "You have full local machine access."
5. **Test before trusting** — A 10-second verification delegate_task saves hours of stuck subagents.

## Related Skills

- `subagent-driven-development` — How to structure multi-subagent workflows
- `ws-system-repair` — System-wide repair including subagent verification (Test 2.3c)
- `ws-system-status` — Current verified status of what works and what doesn't
