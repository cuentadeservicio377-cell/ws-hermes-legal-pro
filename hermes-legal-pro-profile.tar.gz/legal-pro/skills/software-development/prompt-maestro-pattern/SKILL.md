---
name: prompt-maestro-pattern
description: Structured prompt pattern for deep ecosystem investigation, feature auditing, and integration planning. Use when the user wants to explore, map, audit, or integrate a large set of features, plugins, skills, tools, or any complex system.
version: 1.0
author: Hermes Neo + Pablo
license: MIT
metadata:
  hermes:
    tags: [prompt-engineering, system-investigation, integration-planning, goals, hermes-features]
    category: software-development
    related_skills: [hermes-system-maintenance, hermes-agent, writing-plans]
---

# Prompt Maestro Pattern

A **Prompt Maestro** is a self-contained, structured prompt designed to be pasted into Telegram as a `/goal` message. It instructs Hermes to perform a deep, systematic investigation of an ecosystem (features, plugins, skills, tools, MCP servers, or any complex system), compare findings against the current system state, and generate an actionable integration plan.

## When to Use This Pattern

- User says "quiero entender todo lo que Hermes puede hacer"
- User says "audit our system against available features"
- User wants to integrate a new plugin library, toolset, or skill category
- User wants a master plan for system expansion
- Any scenario requiring exhaustive discovery + structured analysis + phased planning

## Why This Pattern Works

| Problem with ad-hoc exploration | How Prompt Maestro solves it |
|-------------------------------|------------------------------|
| Agent jumps between features randomly | Systematic investigation with explicit tasks |
| Agent forgets current system state | Current state included as baseline inventory |
| Output is a messy list | Structured document with tables and phases |
| Not reusable for next audit | Same structure works for any ecosystem |
| User has to guide every step | Self-contained — agent executes autonomously |

## Structure of a Prompt Maestro

### 1. Objective Statement
Clear, singular goal. Example:
> "Investigate exhaustively ALL features, plugins, skills, tools, and MCP servers available in Hermes Agent, compare against our current system, identify gaps, and generate a master integration plan."

### 2. Current System Inventory
**Critical technique**: Include exact current state so the agent does NOT waste turns rediscovering what it already knows. Copy from `hermes status`, `hermes skills list`, `hermes tools list`, `hermes config`, etc.

Required inventory sections:
- **Profiles**: Names, purposes, which is active
- **Skills**: Count by source (builtin/local/hub), key categories
- **Cron Jobs**: Names, schedules, purposes
- **Tools**: Enabled vs disabled, with reasons if known
- **MCP Servers**: Active and their purpose
- **Plugins**: Available, enabled vs disabled
- **Platforms Connected**: Which messaging platforms are active
- **Models**: Primary, fallbacks, subagent models
- **Active Projects**: Names, deadlines, status
- **Key Configs**: Non-default settings that matter

### 3. Investigation Tasks
Explicit commands to run. One per line. Examples:
```
- `hermes --help` — all CLI commands
- `hermes skills browse` — official skills
- `hermes skills search <keyword>` — category-specific skills
- `hermes plugins list` — available plugins
- `hermes tools list` — all toolsets
- `hermes mcp list` — MCP servers
- `hermes config` — full configuration
- `hermes status` — system status
- `hermes cron list` — scheduled jobs
```

### 4. Analysis Framework
For each discovered item, evaluate:
- **Relevance**: High / Medium / Low / None (for our context)
- **Effort**: Immediate / Easy / Medium / Complex
- **Dependencies**: What needs to be ready first (API keys, accounts, config)

### 5. Output Format
Structured document with these sections:
```
# PLAN MAESTRO DE INTEGRACIÓN [ECOSYSTEM] ↔ [OUR SYSTEM]

## 1. RESUMEN EJECUTIVO
## 2. INVENTARIO COMPLETO
### 2.1 [Category A]
### 2.2 [Category B]
## 3. GAPS IDENTIFICADOS
## 4. PLAN DE INTEGRACIÓN
### Fase 1: Quick Wins (< 1 hora)
### Fase 2: Esta Semana (1-4 horas)
### Fase 3: Este Mes (proyectos grandes)
### Fase 4: Contínuo
## 5. RECOMENDACIONES ESTRATÉGICAS
## 6. PRÓXIMOS PASOS INMEDIATOS (24h)
```

### 6. Success Criteria
Checklist of deliverables. Example:
- [ ] All native features mapped
- [ ] All plugins evaluated
- [ ] Minimum 20 hub skills identified as relevant
- [ ] Minimum 5 quick wins with exact instructions
- [ ] Phased plan with realistic timelines
- [ ] Document saved and accessible
- [ ] Executive summary delivered to user

### 7. Execution Instructions
Step-by-step workflow for the agent:
1. Run all investigation commands
2. Analyze each finding against current system
3. Document in specified format
4. Save to `~/.hermes/PLAN-MAESTRO-[topic].md`
5. Report executive summary to user

## Delivery Format

Save the Prompt Maestro as a standalone markdown file:
```
~/.hermes/PROMPT-MAESTRO-[topic].md
```

The user then copies the entire content and sends in Telegram as:
```
/goal "[paste complete prompt here]"
```

## Working Example

For a complete, production-ready Prompt Maestro that investigates the entire Hermes Agent ecosystem, see `references/prompt-maestro-hermes-integration.md`. This was used successfully on 2026-05-01 to map 61 features, 3 plugins, 71 skills, and generate an integration plan.

## Key Pitfalls to Avoid

1. **Don't omit current state inventory**: The agent will waste 5+ turns rediscovering what it already knows
2. **Don't make investigation tasks vague**: "Explore features" is bad. "Run `hermes --help` and document every command" is good
3. **Don't skip the analysis framework**: Without relevance/effort scoring, the output is just a list
4. **Don't forget success criteria**: The agent needs to know when it's done
5. **Don't make the prompt too long for Telegram**: If > 4000 chars, split into a reference file + a compact `/goal` trigger

## Variations

| Variation | When to use | Change from base pattern |
|-----------|-------------|--------------------------|
| **Plugin Audit** | New plugin released | Focus on `hermes plugins list` + `hermes plugins install` |
| **Skill Hunt** | Need skills for new department | Focus on `hermes skills search <dept>` across keywords |
| **Toolset Activation** | Want to enable disabled tools | Focus on `hermes tools list` + config requirements |
| **MCP Expansion** | Want more MCP integrations | Focus on `hermes mcp list` + external MCP registry |
| **Config Optimization** | System feels slow/broken | Focus on `hermes config` + `hermes status` + `hermes doctor` |

---

*Created: 2026-05-01 | Version: 1.0*
*Origin: Session where Pablo asked for a prompt to investigate all Hermes features and generate an integration plan*
