# PROMPT MAESTRO: HERMES SYSTEM INTEGRATION GOAL
# Uso: /goal "[pegar este texto completo]"
# Fecha: 2026-05-01
# Versión: 1.0
# Creado por: Hermes Neo + Pablo
# Skill: prompt-maestro-pattern

---

## 🎯 OBJETIVO PRINCIPAL

Eres el Sistema de Integración Maestro de Hermes Neo para WS Capital. Tu misión es investigar exhaustivamente TODO el ecosistema Hermes Agent, compararlo contra nuestro sistema actual, identificar gaps, oportunidades de integración, y generar un plan maestro para convertir Hermes en el socio operativo más completo posible.

---

## 📋 INVENTARIO ACTUAL DE NUESTRO SISTEMA

### Perfiles Activos
- `default` (pablo): Conversaciones directas, build con OpenCode Go, orquestación general
- `ws`: Operaciones de empresa, clientes, Onyx, documentos, seguimientos
- `ws-growth-director`: Thread 8 (Growth & Marketing). Director estratégico flexible.

### Threads/Departamentos Operativos
- Thread 1 (General): Checkpoint de todas las sesiones, coordinación transversal
- Thread 2 (Socio Operativo): Estrategia, build complejo, research, orquestación
- Thread 5 (Build & Tech): RED-GREEN-REFACTOR, tests primero, OpenCode Go
- Thread 8 (Growth & Marketing): Contenido, campañas, video, research, métricas
- Thread 22 (Willow Legal): Firma legal, documentos Kami v3, Onyx, seguimiento
- Thread 23 (Admin & Ops): Excel PM maestro, brain dumps, seguimientos
- Thread 24 (Ventas & Plantillas): Demos, clones, propuestas, onboarding

### Proyectos Activos
1. **Hackathon Hermes** — Video V2 en progreso, deadline 4may2026
2. **Paola Meneses** — :8080, presentación montaje con imágenes reales
3. **Willow Legal Standalone** — :8081, Motor Kami v3, 23 templates, 5 agentes Hermes

### Skills Instaladas (71 activas)
- 46 builtin (oficiales de Nous Research)
- 25 local (creadas por nosotros para WS Capital)
- Categorías: autonomous-ai-agents, creative, devops, email, github, growth-marketing, mcp, media, note-taking, productivity, research, social-media, software-development, web

### Cron Jobs Activos (8 jobs)
- Admin-Ops Brain-Dump Dominical (domingos 9pm)
- Admin-Ops Resumen Lunes Mañana (lunes 8am)
- Admin-Ops Check Viernes Tarde (viernes 6pm)
- Admin-Ops Proactividad PM (miércoles 10am)
- Lunes 10am - Checklist Proyectos WS Capital
- Growth Director - Prueba Continuidad (diario 1pm)
- Growth — Revisión Semanal de Contenido (lunes 10am)
- Growth — Revisión de Experimentos (viernes 6pm)

### Tools Activos
- web, browser, terminal, file, code_execution, vision, image_gen, tts, skills, todo, memory, session_search, clarify, delegation, cronjob, messaging, search
- Desactivados: moa, rl, homeassistant, spotify, yuanbao

### MCP Servers
- railway (todos los tools activos)

### Plugins Disponibles
- disk-cleanup (no activado): Limpieza automática de archivos temporales
- google_meet (no activado): Transcripción y participación en Google Meet
- spotify (no activado): Control nativo de Spotify

### Modelos Configurados
- Principal: kimi-k2.6 (Kimi Coding Plan)
- Fallback 1: gpt-5.4-mini (OpenAI Codex OAuth)
- Fallback 2: kimi-k2.6 (OpenCode Go)
- Subagentes: Codex/Copilot ACP

### Plataformas Conectadas
- Telegram: ✓ (home: -1003910724059)
- Discord, WhatsApp, Signal, Slack, Email, SMS, etc.: ✗ no configurados

### Infraestructura
- WSL2 Ubuntu en Windows
- Gateway corriendo via systemd
- Onyx en puerto 3000 (capa central de conocimiento)
- Willow Legal en puerto 8081
- Paola Meneses en puerto 8080
- Railway MCP para deploys

---

## 🔍 TAREAS DE INVESTIGACIÓN

### 1. MAPEAR TODAS LAS FEATURES NATIVAS DE HERMES
Investiga y documenta:
- Todos los slash commands disponibles (`/help`, `/goal`, `/background`, `/model`, `/branch`, `/snapshot`, `/steer`, `/insights`, `/usage`, `/cron`, `/kanban`, `/queue`, `/skills`, `/curator`, `/yolo`, `/undo`, `/retry`, `/compress`, etc.)
- Qué hace cada uno, cómo se usa, y si requiere configuración especial
- Cuáles son persistidos vs temporales
- Cuáles funcionan en gateway (Telegram) vs solo en CLI

### 2. MAPEAR TODOS LOS PLUGINS DISPONIBLES
- Lista completa de plugins en `hermes plugins list`
- Qué hace cada plugin
- Qué se necesita para activarlo
- Cuáles son relevantes para WS Capital

### 3. MAPEAR TODAS LAS SKILLS DEL HUB
- `hermes skills browse` — todas las skills oficiales
- `hermes skills search <keyword>` — buscar por categoría relevante
- Identificar skills que podrían mejorar nuestros departamentos:
  - Ventas & CRM
  - Legal & documentos
  - Marketing & contenido
  - DevOps & deploy
  - Research & inteligencia
  - Productividad & ops

### 4. MAPEAR TODOS LOS TOOLSETS
- `hermes tools list` — builtins
- Cuáles están desactivados y por qué
- Qué toolsets adicionales podrían activarse
- Toolsets que requieren configuración extra (homeassistant, spotify, yuanbao, etc.)

### 5. MAPEAR MCP SERVERS POSIBLES
- `hermes mcp list` — actuales
- Qué otros MCP servers existen en el ecosistema
- Cómo integraríamos más MCP servers para WS Capital

### 6. REVISAR CONFIGURACIÓN ACTUAL
- `hermes config` — revisar cada sección
- `hermes status` — ver estado completo
- Identificar configuraciones subóptimas
- Identificar features no configuradas (Discord, Slack, Email, etc.)

---

## 🧠 ANÁLISIS DE INTEGRACIÓN

Para cada feature/plugin/skill/tool encontrado, evalúa:

### Relevancia para WS Capital
- **Alta**: Impacto directo en operaciones actuales
- **Media**: Útil pero requiere trabajo de integración
- **Baja**: Nice-to-have, no prioridad
- **No aplica**: No relevante para nuestro contexto

### Esfuerzo de Integración
- **Inmediato**: Ya funciona, solo activar/configurar
- **Fácil**: < 1 hora de trabajo
- **Medio**: 1-4 horas, requiere configuración
- **Complejo**: > 4 horas o requiere desarrollo

### Dependencias
- ¿Qué se necesita antes? (API keys, cuentas, configuración)
- ¿Bloquea otras integraciones?

---

## 📊 FORMATO DE ENTREGA

Genera un documento maestro con esta estructura:

```
# PLAN MAESTRO DE INTEGRACIÓN HERMES ↔ WS CAPITAL

## 1. RESUMEN EJECUTIVO
- Features totales mapeadas: X
- Plugins disponibles: Y
- Skills del hub relevantes: Z
- Oportunidades inmediatas: N

## 2. INVENTARIO COMPLETO
### 2.1 Features Nativas
[Tabla con: nombre, descripción, estado actual, relevancia, esfuerzo]

### 2.2 Plugins
[Tabla con: nombre, descripción, estado, relevancia, esfuerzo, dependencias]

### 2.3 Skills del Hub Relevantes
[Tabla con: nombre, categoría, descripción, relevancia, esfuerzo]

### 2.4 Toolsets Adicionales
[Tabla con: nombre, estado actual, qué habilitaría, esfuerzo]

### 2.5 MCP Servers Posibles
[Tabla con: nombre, propósito, estado, esfuerzo]

## 3. GAPS IDENTIFICADOS
[Qué falta en nuestro sistema que Hermes podría cubrir]

## 4. PLAN DE INTEGRACIÓN
### Fase 1: Quick Wins (< 1 hora cada)
[Lista de integraciones inmediatas]

### Fase 2: Esta Semana (1-4 horas cada una)
[Integraciones de esfuerzo medio]

### Fase 3: Este Mes (proyectos más grandes)
[Integraciones complejas]

### Fase 4: Contínuo
[Mejoras iterativas y mantenimiento]

## 5. RECOMENDACIONES ESTRATÉGICAS
[Decisiones de alto nivel sobre qué integrar primero y por qué]

## 6. PRÓXIMOS PASOS INMEDIATOS
[Acciones concretas para las próximas 24 horas]
```

---

## ⚙️ INSTRUCCIONES DE EJECUCIÓN

1. **Investiga** usando todas las herramientas disponibles:
   - `hermes --help` para comandos
   - `hermes skills browse/search` para skills
   - `hermes plugins list` para plugins
   - `hermes tools list` para toolsets
   - `hermes mcp list` para MCP servers
   - `hermes config` para configuración
   - `hermes status` para estado actual
   - Revisar documentación en https://hermes-agent.nousresearch.com/docs/

2. **Analiza** cada descubrimiento contra nuestro sistema actual

3. **Documenta** todo en el formato especificado

4. **Genera** el plan maestro de integración

5. **Guarda** el resultado en `~/.hermes/PLAN-MAESTRO-INTEGRACION.md`

6. **Reporta** un resumen ejecutivo a Pablo con las 5 acciones más importantes para hacer HOY

---

## 🎯 CRITERIOS DE ÉXITO

- [ ] Todas las features nativas mapeadas y documentadas
- [ ] Todos los plugins evaluados para relevancia WS Capital
- [ ] Mínimo 20 skills del hub identificadas como relevantes
- [ ] Mínimo 5 quick wins identificados con instrucciones exactas
- [ ] Plan de fases con timelines realistas
- [ ] Documento guardado y accesible
- [ ] Resumen ejecutivo entregado a Pablo

---

## 📝 NOTAS IMPORTANTES

- **NO asumir**: Verificar cada feature con `hermes <comando> --help` o probándola
- **NO omitir**: Si algo parece irrelevante, documentarlo como "no aplica" con razón
- **SÉ EXHAUSTIVO**: Mejor documentar de más que de menos
- **PIENSA ESTRATÉGICAMENTE**: No solo listar features, sino analizar CÓMO integrarlas
- **CONSIDERA COSTOS**: Algunas features requieren API keys pagadas o cuotas
- **DOCUMENTA DEPENDENCIAS**: Si algo requiere configuración previa, indicarlo claramente

---

*Prompt generado por: Hermes Neo + Pablo*
*Fecha: 2026-05-01*
*Versión: 1.0*
*Uso: Copiar y pegar en Telegram como mensaje de `/goal`*
