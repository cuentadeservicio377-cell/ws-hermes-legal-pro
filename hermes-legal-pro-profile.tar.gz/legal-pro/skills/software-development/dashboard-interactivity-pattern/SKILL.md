---
name: dashboard-interactivity-pattern
title: Dashboard Interactivity Pattern
description: Transform a read-only data dashboard (FastAPI backend + vanilla JS SPA) into an interactive operations dashboard with agent personas, actionable buttons, batch commands, and execution history — all wired to real backend POST endpoints.
triggers:
  - Dashboard exists but only shows data (GET endpoints only)
  - User needs to "do things" from the UI, not just view
  - Multiple "agents" or personas need distinct action panels
  - Batch operations across multiple items are needed
  - Execution feedback/history is required
  - Backend already has POST endpoints but frontend doesn't expose them
  - Need to replace a passive "Alerts" tab with an active "Agents & Actions" panel
  - User explicitly says the dashboard "looks like a demo" or "buttons don't do anything real"
  - Need to transform a passive data viewer into an active operations command center
  - Documents are generated with generic/template data instead of real event data
  - Timeline exists but tasks don't persist or connect to real backend actions
---

# Dashboard Interactivity Pattern

## When to use this

You have a working dashboard that:
- Displays data from `GET /api/*` endpoints
- Has no buttons, forms, or actions
- Users can only view, not interact
- Backend already has `POST /api/*` endpoints that are unused by the frontend

**OR** the user explicitly says:
- "This looks like a demo"
- "Buttons don't do anything real"
- "I need a real operations center, not a visual prototype"
- "Documents are generic, not real data"

You need to add:
- **Agent cards** — persona-based action panels
- **Action buttons** — each wired to a real POST endpoint
- **Batch commands** — execute across multiple items at once
- **Execution history** — timestamped log of what happened
- **Event selection** — dropdown to pick which item to act on
- **Operational views** — pipeline (kanban), alerts with actions, financial tracking

## The "Demo to Real" Transformation Methodology

When the user says the dashboard is "just a demo," follow this systematic audit-and-transform process:

### Phase 0: Honest Audit (CRITICAL — do not skip)

Before writing any new code, audit what exists:

```bash
# 1. Check if backend endpoints are real or simulated
grep -n "@app\.\(post\|put\|delete\|patch\)" dashboard/app.py
# Look for endpoints that return hardcoded JSON vs. ones that execute real code

# 2. Check if document generators use real data
grep -n "completo\.json\|resumen\.json" dashboard/*.py
# If generators read "resumen" or "summary" files → they're using generic data

# 3. Check if file operations are real
grep -n "subprocess\|os\.system\|open(" dashboard/*.py
# If no subprocess/os calls → backend is just simulating

# 4. Check frontend functions
curl -s http://localhost:8080/ | grep -o "function.*(" | sort | uniq -c
# Count functions. If < 10 JS functions → frontend is mostly static
```

**Audit checklist:**
- [ ] Backend endpoints execute real code (not just return JSON)
- [ ] Document generators read real event data (not templates)
- [ ] File system operations actually create/open files
- [ ] Frontend buttons call real API endpoints (not just show toasts)
- [ ] Task completion persists to backend (not just localStorage)
- [ ] Progress reflects real state (not hardcoded percentages)

### Phase 1: Connect Real Data Sources

**The most common demo flaw:** Generators use summarized/generic JSON instead of complete event data.

**Fix:** Create a new executor module that reads the complete data:

```python
# ejecutor_v4.py — reads PAO-XXX-completo.json (full PPT slides data)
def generar_documentos_evento_especifico(pao_id, tipos):
    json_path = DATOS_DIR / f"{pao_id}-completo.json"
    with open(json_path) as f:
        datos_reales = json.load(f)
    
    # Extract real data: services, quantities, prices, venue, WP info
    servicios = datos_reales.get('servicios', [])
    venue = datos_reales.get('venue', '')
    invitados = datos_reales.get('invitados', 0)
    
    for tipo in tipos:
        if tipo == 'requisicion':
            generar_requisicion_con_datos_reales(pao_id, servicios, venue, invitados)
        elif tipo == 'pedido_flor':
            generar_pedido_flor_con_datos_reales(pao_id, servicios, venue)
```

**Key rule:** Every document must include real data:
- Client name (from JSON, not hardcoded)
- Event date (from JSON)
- Venue (from JSON)
- Services with quantities (from PPT slides)
- Prices (from PPT, not estimates)
- WP/aliado info (from JSON)

**Critical data source pattern:** The system may have TWO versions of event data:
- `PAO-XXX.json` — **Summary/resume** (generic, small, often hardcoded placeholders)
- `PAO-XXX-completo.json` — **Complete** (real data extracted from PPT slides, full services, quantities, prices)

**Detection:** Check which file the executor reads:
```bash
grep -n "\.json" dashboard/ejecutor*.py
# If it reads "{pao_id}.json" → likely using summary (generic)
# If it reads "{pao_id}-completo.json" → using real data
```

**Fix:** Create `ejecutor_v4.py` that reads the complete JSON:
```python
# ejecutor_v4.py — reads PAO-XXX-completo.json (full PPT slides data)
def cargar_json_completo(pao_id):
    json_path = DATOS_DIR / f"{pao_id}-completo.json"
    with open(json_path, encoding='utf-8') as f:
        return json.load(f)

def extraer_datos_reales(data):
    """Extract real business data from complete JSON"""
    return {
        'nombre': data.get('nombre', ''),
        'fecha': data.get('fecha', ''),
        'venue': data.get('venue', ''),
        'invitados': data.get('invitados', 0),
        'servicios': data.get('servicios', []),  # Real services from PPT
        'wp_aliado': data.get('wp_aliado', {}),   # Real WP info
        'total': data.get('total', 0),
    }
```

Then update `app.py` to import from `ejecutor_v4` instead of the old executor:
```python
# app.py
from ejecutor_v4 import (
    generar_documentos_evento_especifico as generar_documentos_evento,
    abrir_carpeta_evento
)
```

### Phase 2: Make Every Button Execute Something Real

**The second most common demo flaw:** Buttons show toasts but don't call APIs.

**Fix pattern for each button type:**

| Button Type | Fake (demo) | Real (ops) |
|-------------|-------------|------------|
| "Generate document" | `showToast('Document generated')` | `apiPost('/api/cliente/{pao_id}/generar-documento', {tipo})` |
| "Complete task" | `localStorage.setItem('task', 'done')` | `apiPost('/api/tareas/{id}/completar', {})` |
| "Open folder" | `showToast('Folder opened')` | `apiPost('/api/cliente/{pao_id}/abrir-carpeta', {})` |
| "View document" | `showToast('Document: filename')` | Actually open the file or show its contents |

### Phase 3: Add Operational Views

A real operations center needs these views (not just "Dashboard"):

1. **Pipeline (Kanban)** — Events as cards moving through stages:
   ```
   [Cotizado] → [Contratado] → [En Planning] → [Listo] → [Ejecutado] → [Cerrado]
   ```

2. **Detail Panel** — Slide-in panel with operational sections:
   - Resumen ejecutivo (risk, next action, margin)
   - Timeline with real tasks (D-60 to D+7)
   - Documents (real files with view/regenerate/open)
   - Finances (quoted, paid, pending, margin)
   - Suppliers/aliados (florist, WP, venue, warehouse)
   - Action history (who did what, when, result)

3. **Actionable Alerts** — Each alert has a direct resolution button:
   ```
   "Missing flower order for XV Ximena" → [Generate flower order]
   "Event contracted without checklist" → [Generate checklist]
   "Pending payment" → [Record payment]
   ```

4. **Agent Status Panel** — Real execution state:
   ```
   Motor de Documentos: ● Ready | Last run: 2 min ago
   Operaciones: ● Ready | Last run: 1 hour ago
   Almacén: ● Ready | Last run: 5 min ago
   ```

### Phase 4: End-to-End Verification

After transformation, verify with a real event:

```bash
# 1. Open event
curl -s http://localhost:8080/api/evento/PAO-002 | python3 -m json.tool

# 2. Generate a document with REAL data
curl -s -X POST http://localhost:8080/api/cliente/PAO-002/generar-documento \
  -H "Content-Type: application/json" -d '{"tipo":"requisicion"}'

# 3. Verify document was created AND contains real data
curl -s http://localhost:8080/api/cliente/PAO-002/documentos | \
  python3 -c "import sys,json; d=json.load(sys.stdin); \
  print('Documents:', [k for k,v in d['documentos'].items() if v['existe']])"

# 4. Verify filename includes pao_id (not empty string)
# Should be: Pedido_Flor_PAO-002.pdf (NOT Pedido_Flor_.pdf)
curl -s http://localhost:8080/api/cliente/PAO-002/documentos | \
  python3 -c "import sys,json; d=json.load(sys.stdin); \
  [print(k, v['nombre']) for k,v in d['documentos'].items()]"

# 5. Complete a task
curl -s -X POST http://localhost:8080/api/tareas/PAO-002-T4/completar -d '{}'

# 6. Verify progress updated (check BOTH fields)
curl -s http://localhost:8080/api/evento/PAO-002 | \
  python3 -c "import sys,json; d=json.load(sys.stdin); \
  print('progreso:', d.get('progreso'), 'detalles.progreso_pct:', d.get('detalles',{}).get('progreso_pct'))"

# 7. Open folder (WSL/Windows)
curl -s -X POST http://localhost:8080/api/cliente/PAO-002/abrir-carpeta -d '{}'

# 8. Generate ALL document types to verify complete coverage
curl -s -X POST http://localhost:8080/api/cliente/PAO-002/generar-documento \
  -H "Content-Type: application/json" -d '{"tipo":"checklist"}'
curl -s -X POST http://localhost:8080/api/cliente/PAO-002/generar-documento \
  -H "Content-Type: application/json" -d '{"tipo":"nomina"}'
```

**Verification criteria:**
- [ ] Event data is real (not placeholder)
- [ ] Generated documents contain real event data (services, quantities, venue from PPT)
- [ ] Filenames include pao_id (e.g., `Pedido_Flor_PAO-002.pdf`, NOT `Pedido_Flor_.pdf`)
- [ ] Task completion persists and updates progress
- [ ] Progress reflects real state (from `detalles.progreso_pct`, not `evento.progreso`)
- [ ] Folder opens in Windows from WSL
- [ ] Alerts appear if documents are missing for upcoming events
- [ ] Financial data reflects real quotes and payments
- [ ] ALL document types generate successfully (requisicion, pedido_flor, checklist, nomina, cotizacion, bookdate)

## Architecture

**Backend:** FastAPI (already exists)
**Frontend:** Single `index.html` with embedded CSS/JS (vanilla, no bundler)
**Pattern:** Add a new tab/section that exposes all POST capabilities

## Implementation Steps

### Step 0: Audit (if transforming from demo)

Follow Phase 0-4 of the "Demo to Real" methodology above. Identify:
- Which endpoints are simulated vs. real
- Which data sources are generic vs. real
- Which frontend functions are decorative vs. functional

### Step 1: Audit existing POST endpoints

```bash
# Find all POST endpoints in the backend
grep -n "@app\.\(post\|put\|delete\|patch\)" dashboard/app.py
```

Document what exists but isn't exposed:
- `POST /api/tareas/{id}/completar` — mark task done
- `POST /api/cliente/{pao_id}/abrir-carpeta` — open folder
- `POST /api/agentes/{id}/accion` — execute agent action
- `POST /api/pendientes` — create todo

### Step 2: Add operational views to the SPA

Replace passive tabs with active operational views:

```html
<!-- Navigation -->
<div class="nav-item" data-tab="pipeline" onclick="switchTab('pipeline')">🔄 Pipeline</div>
<div class="nav-item" data-tab="eventos" onclick="switchTab('eventos')">📅 Eventos</div>
<div class="nav-item" data-tab="agentes" onclick="switchTab('agentes')">🤖 Agentes</div>

<!-- Pipeline (Kanban) -->
<div id="tab-pipeline" class="tab-content hidden">
    <div class="pipeline">
        <div class="pipeline-col">
            <h3>Cotizado (3)</h3>
            <!-- Event cards that can be dragged or clicked -->
        </div>
        <div class="pipeline-col">
            <h3>Contratado (4)</h3>
        </div>
        <div class="pipeline-col">
            <h3>En Planning (2)</h3>
        </div>
        <!-- ... more columns -->
    </div>
</div>

<!-- Detail Panel (slide-in) -->
<div class="detail-overlay" id="detail-overlay" onclick="closeDetail()"></div>
<div class="detail-panel" id="detail-panel">
    <div class="detail-header">
        <h2 id="detail-title">Evento</h2>
        <div class="actions">
            <button onclick="generarDocumento(pao_id, 'todos')">📄 Generar Docs</button>
            <button onclick="abrirCarpeta(pao_id)">📁 Abrir Carpeta</button>
        </div>
    </div>
    <div class="detail-body">
        <!-- Resumen, Timeline, Documentos, Finanzas, Proveedores, Historial -->
    </div>
</div>
```

### Step 3: Add document generation modal

```javascript
function showGenerarDocsModal(pao_id) {
    const docs = [
        { key: 'cotizacion', name: 'Cotización PPT', icon: '📊' },
        { key: 'bookdate', name: 'Bookdate', icon: '📅' },
        { key: 'pedido_flor', name: 'Pedido de Flor', icon: '🌸' },
        { key: 'requisicion', name: 'Requisición Bodega', icon: '📦' },
        { key: 'checklist', name: 'Checklist Montaje', icon: '✓' },
        { key: 'nomina', name: 'Nómina', icon: '👥' },
    ];
    // Render modal with real POST calls
}
```

### Step 4: Add timeline with real task completion

```javascript
async function toggleTimelineTask(pao_id, taskKey, checked) {
    const tareaId = pao_id + '-' + taskKey;
    // Persist to backend
    try {
        await apiPost('/api/tareas/' + tareaId + '/completar', {});
    } catch (e) {
        console.log('Backend tareas not persisted');
    }
    // Update UI
    renderDetail();
}
```

### Step 5: Add actionable alerts

```javascript
async function renderAlertas() {
    const data = await apiGet('/api/alertas');
    const alertas = data.alertas || [];
    return alertas.map(a => `
        <div class="alerta-card ${a.urgente ? 'urgente' : ''}">
            <h4>${a.titulo}</h4>
            <p>${a.mensaje}</p>
            <div class="actions">
                ${a.accion ? `<button onclick="${a.accion}">${a.accion_label || 'Resolver'}</button>` : ''}
                <button onclick="dismissAlerta('${a.id}')">Descartar</button>
            </div>
        </div>
    `).join('');
}
```

### Step 6: Add agent status panel

```javascript
const agentes = [
    { id: 'motor', nombre: 'Motor de Documentos', estado: 'listo', ultima: 'Hace 2 min', icon: '📄', color: '#8b5cf6' },
    { id: 'ops', nombre: 'Operaciones', estado: 'listo', ultima: 'Hace 1 hora', icon: '🚚', color: '#f97316' },
    { id: 'almacen', nombre: 'Almacén', estado: 'listo', ultima: 'Hace 5 min', icon: '📦', color: '#eab308' },
];
```

### Step 7: Define agent configuration in JS

```javascript
const AGENTES_CONFIG = {
    admin: {
        icono: '📊',
        nombre: 'Administración de Proyectos',
        descripcion: 'Gestión de eventos, timeline y coordinación',
        color: '#5B8FA8',
        acciones: [
            { id: 'ver_eventos', icono: '📋', label: 'Ver todos los eventos', tipo: 'nav', tab: 'eventos' },
            { id: 'actualizar_status', icono: '🔄', label: 'Cambiar status', tipo: 'form', form: 'status' },
            { id: 'editar_fecha', icono: '📅', label: 'Editar fecha/venue', tipo: 'form', form: 'fecha' },
        ]
    },
    ops: {
        icono: '🚚',
        nombre: 'Operaciones y Logística',
        descripcion: 'Logística, montaje, desmontaje y venue',
        color: '#C49420',
        acciones: [
            { id: 'generar_checklist', icono: '✅', label: 'Generar checklist', tipo: 'accion', endpoint: 'checklist' },
            { id: 'generar_nominas', icono: '👥', label: 'Generar nóminas', tipo: 'accion', endpoint: 'nominas' },
            { id: 'abrir_carpeta', icono: '📁', label: 'Abrir carpeta', tipo: 'accion', endpoint: 'abrir_carpeta' },
        ]
    },
    // ... more agents
};

**Action types:**
- `nav` — switch to another tab
- `accion` — POST to backend endpoint
- `batch` — POST to multiple items sequentially
- `form` — show inline form (future enhancement)
```

### Step 4: Add batch commands

```javascript
const COMANDOS_RAPIDOS = [
    { id: 'batch_requisiciones', icono: '📦', titulo: 'Requisiciones de Bodega', desc: 'Generar para todos los eventos activos', agente: 'almacen', color: '#4A7C59' },
    { id: 'batch_checklists', icono: '✅', titulo: 'Checklists de Montaje', desc: 'Generar para eventos próximos', agente: 'ops', color: '#C49420' },
    // ... more commands
];
```

### Step 5: Implement execution handler

```javascript
async function ejecutarAccion(agenteId, accionId, pao_id, accionConfig) {
    const btn = document.getElementById(`btn-${agenteId}-${accionId}`);
    
    // Validate event selection
    if (!pao_id && accionConfig.tipo !== 'nav') {
        alert('⚠️ Primero selecciona un evento');
        return;
    }
    
    // Visual feedback: normal → executing → done/error
    btn.classList.add('ejecutando');
    btn.innerHTML = `<span>⏳</span><span>Ejecutando...</span>`;
    
    try {
        let resultado;
        switch (config.tipo) {
            case 'nav':
                switchTab(config.tab);
                resultado = { success: true };
                break;
            case 'accion':
                resultado = await apiPost(`/api/agentes/${agenteId}/accion`, {
                    tipo: `generar_${config.endpoint}`,
                    pao_id: pao_id
                });
                break;
            case 'batch':
                const items = data.items.filter(e => e.status !== 'Cerrado');
                let exitos = 0;
                for (const item of items) {
                    const r = await apiPost(`/api/agentes/${agenteId}/accion`, {
                        tipo: `generar_${config.endpoint}`,
                        pao_id: item.id
                    });
                    if (r.success) exitos++;
                }
                resultado = { success: true, mensaje: `${exitos}/${items.length} procesados` };
                break;
        }
        
        // Success state
        btn.classList.remove('ejecutando');
        btn.classList.add('completado');
        btn.innerHTML = `<span>✅</span><span>¡Listo!</span>`;
        agregarHistorial('success', `${config.label}: ${resultado.mensaje}`);
        
        // Revert after 3 seconds
        setTimeout(() => {
            btn.classList.remove('completado');
            btn.innerHTML = `<span>${config.icono}</span><span>${config.label}</span>`;
        }, 3000);
        
    } catch (e) {
        // Error state
        btn.classList.remove('ejecutando');
        btn.classList.add('error');
        btn.innerHTML = `<span>❌</span><span>Error</span>`;
        agregarHistorial('error', `${config.label}: ${e.message}`);
        
        setTimeout(() => {
            btn.classList.remove('error');
            btn.innerHTML = `<span>${config.icono}</span><span>${config.label}</span>`;
        }, 3000);
    }
}
```

### Step 6: Add execution history

```javascript
let historialAcciones = [];

function agregarHistorial(tipo, mensaje) {
    const hora = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    historialAcciones.unshift({ tipo, mensaje, hora });
    if (historialAcciones.length > 50) historialAcciones.pop();
    renderHistorial();
}

function renderHistorial() {
    const html = historialAcciones.map(h => `
        <div class="historial-item ${h.tipo}">
            <span class="historial-time">${h.hora}</span>
            <span class="historial-msg">${h.mensaje}</span>
        </div>
    `).join('');
    document.getElementById('historial-ejecuciones').innerHTML = html;
}
```

### Step 7: Add CSS for interactive states

```css
/* Agent cards */
.agente-card {
    background: var(--card);
    border-radius: var(--radius);
    padding: 20px;
    border: 1px solid var(--border);
    margin-bottom: 16px;
}
.agente-card:hover { box-shadow: var(--shadow); border-color: var(--primary-light); }

/* Action buttons */
.btn-accion {
    padding: 10px 14px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--bg);
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
}
.btn-accion:hover { background: var(--primary); color: white; }
.btn-accion.ejecutando { opacity: 0.6; pointer-events: none; }
.btn-accion.completado { background: #E8F5E9; color: var(--success); }
.btn-accion.error { background: #FFEBEE; color: var(--danger); }

/* Mini action buttons on cards */
.acciones-rapidas {
    display: flex;
    gap: 6px;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--border);
    justify-content: flex-end;
}
.btn-mini {
    width: 32px; height: 32px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--bg);
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}
.btn-mini:hover { background: var(--primary); color: white; transform: scale(1.1); }
.btn-mini:active { transform: scale(0.95); }

/* Toast notifications */
.toast-container {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.toast {
    padding: 14px 20px;
    border-radius: 10px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    animation: toastIn 0.3s ease;
    display: flex;
    align-items: center;
    gap: 10px;
    max-width: 400px;
}
.toast.success { background: var(--success); }
.toast.error { background: var(--danger); }
.toast.info { background: var(--info); }
.toast.warning { background: var(--warning); }
@keyframes toastIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}
@keyframes toastOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}
.toast.hiding { animation: toastOut 0.3s ease forwards; }

/* Interactive timeline checkboxes */
.timeline-check {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px;
    border-left: 3px solid var(--warning);
    margin-bottom: 8px;
    padding-left: 12px;
    transition: all 0.2s;
}
.timeline-check.completado {
    border-left-color: var(--success);
    opacity: 0.7;
}
.timeline-check input[type="checkbox"] {
    width: 18px; height: 18px;
    cursor: pointer;
    accent-color: var(--success);
}
.timeline-check label { cursor: pointer; flex: 1; }
.timeline-check.completado label {
    text-decoration: line-through;
    color: var(--text-muted);
}

/* Search & filters */
.search-bar {
    display: flex;
    gap: 12px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}
.search-input {
    flex: 1;
    min-width: 200px;
    padding: 10px 16px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--card);
    font-size: 14px;
    outline: none;
}
.search-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(139, 115, 85, 0.1);
}
.filter-btn {
    padding: 10px 16px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--card);
    cursor: pointer;
    font-size: 13px;
    transition: all 0.2s;
}
.filter-btn:hover { background: var(--bg); }
.filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }

/* Batch command cards */
.comando-card {
    background: linear-gradient(135deg, var(--primary-dark), var(--primary));
    color: white;
    border-radius: var(--radius);
    padding: 16px;
    cursor: pointer;
    transition: all 0.2s;
}
.comando-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

/* History items */
.historial-item { display: flex; gap: 12px; padding: 10px; border-radius: 8px; margin-bottom: 6px; font-size: 13px; }
.historial-item.success { background: #E8F5E9; }
.historial-item.error { background: #FFEBEE; }
.historial-item.info { background: #E3F2FD; }

/* Responsive */
@media (max-width: 768px) {
    .header { flex-direction: column; gap: 12px; padding: 12px; }
    .nav { width: 100%; justify-content: center; }
    .container { padding: 12px; }
    .kpi-grid { grid-template-columns: repeat(2, 1fr); }
    .event-grid { grid-template-columns: 1fr; }
    .detail-panel { width: 100%; }
    .acciones-grid { grid-template-columns: 1fr; }
    .comandos-grid { grid-template-columns: 1fr; }
    .search-bar { flex-direction: column; }
    .search-input { width: 100%; }
}
@media (max-width: 480px) {
    .kpi-grid { grid-template-columns: 1fr; }
    .nav-item { padding: 6px 10px; font-size: 12px; }
    .logo-text h1 { font-size: 16px; }
}
```

### Step 8: Wire the API helper

```javascript
async function apiPost(endpoint, data) {
    const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${res.status}`);
    }
    return res.json();
}
```

### Step 9: Add mini action buttons to item cards

Add quick-action buttons directly on each item card in the grid:

```html
<div class="event-card" data-pao-id="${e.pao_id}">
    <!-- ... card content ... -->
    <div class="acciones-rapidas">
        <button class="btn-mini" onclick="event.stopPropagation(); accionRapida('${e.pao_id}', 'abrir_carpeta')" title="Abrir carpeta">📁</button>
        <button class="btn-mini" onclick="event.stopPropagation(); accionRapida('${e.pao_id}', 'generar_docs')" title="Generar documentos">📄</button>
        <button class="btn-mini" onclick="event.stopPropagation(); accionRapida('${e.pao_id}', 'abrir_detalle')" title="Ver detalle">👁️</button>
    </div>
</div>
```

```javascript
async function accionRapida(pao_id, accion) {
    if (accion === 'abrir_detalle') {
        openEvent(pao_id);
        return;
    }
    showToast(`Ejecutando: ${accion.replace('_', ' ')}...`, 'info', 2000);
    try {
        let resultado;
        switch (accion) {
            case 'abrir_carpeta':
                resultado = await apiPost(`/api/cliente/${pao_id}/abrir-carpeta`, {});
                showToast(resultado.success ? `📁 Carpeta abierta: ${pao_id}` : `⚠️ ${resultado.mensaje}`, resultado.success ? 'success' : 'warning');
                break;
            case 'generar_docs':
                resultado = await apiPost(`/api/cliente/${pao_id}/generar-documento`, { tipo: 'todos' });
                showToast(`📄 Documentos generados para ${pao_id}`, 'success');
                break;
        }
    } catch (e) {
        showToast(`❌ Error: ${e.message}`, 'error');
    }
}
```

### Step 10: Add toast notification system

```javascript
function showToast(mensaje, tipo = 'info', duracion = 3000) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    const iconos = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    toast.innerHTML = `<span>${iconos[tipo] || 'ℹ️'}</span><span>${mensaje}</span>`;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('hiding');
        setTimeout(() => toast.remove(), 300);
    }, duracion);
}
```

Add the container to HTML:
```html
<div id="toast-container" class="toast-container"></div>
```

### Step 11: Add interactive timeline checkboxes

Replace static timeline with checkable items:

```javascript
const timelineHtml = timelineEntries.map(([key, t], idx) => `
    <div class="timeline-check ${t.verificado ? 'completado' : ''}" id="timeline-${pao_id}-${idx}">
        <input type="checkbox" 
               ${t.verificado ? 'checked' : ''} 
               onchange="toggleTimelineTask('${pao_id}', '${key}', ${idx}, this.checked)"
               id="chk-${pao_id}-${idx}">
        <label for="chk-${pao_id}-${idx}">
            <strong>${key}</strong> — ${t.tarea}
            <span style="font-size: 11px; color: var(--text-muted); display: block;">${t.notas}</span>
        </label>
    </div>
`).join('');

async function toggleTimelineTask(pao_id, taskKey, idx, checked) {
    const el = document.getElementById(`timeline-${pao_id}-${idx}`);
    if (checked) {
        el.classList.add('completado');
        showToast(`✅ Tarea completada: ${taskKey}`, 'success', 2000);
    } else {
        el.classList.remove('completado');
        showToast(`↩️ Tarea reactivada: ${taskKey}`, 'info', 2000);
    }
    // Persist to backend: await apiPost(`/api/tareas/...`, { status: checked ? 'completada' : 'pendiente' });
}
```

### Step 12: Add search & filter bar

```javascript
let filtroActual = 'todos';
let busquedaActual = '';

function renderEventosConFiltro() {
    let eventos = eventosData.eventos;
    
    // Apply search
    if (busquedaActual) {
        const q = busquedaActual.toLowerCase();
        eventos = eventos.filter(e => 
            e.nombre.toLowerCase().includes(q) ||
            e.pao_id.toLowerCase().includes(q) ||
            (e.venue && e.venue.toLowerCase().includes(q))
        );
    }
    
    // Apply status filter
    if (filtroActual !== 'todos') {
        eventos = eventos.filter(e => e.status.toLowerCase() === filtroActual);
    }
    
    const html = `
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="🔍 Buscar..." 
                   value="${busquedaActual}" oninput="onBusqueda(this.value)">
            <button class="filter-btn ${filtroActual === 'todos' ? 'active' : ''}" onclick="setFiltro('todos')">Todos</button>
            <button class="filter-btn ${filtroActual === 'cotizado' ? 'active' : ''}" onclick="setFiltro('cotizado')">Cotizados</button>
            <button class="filter-btn ${filtroActual === 'contratado' ? 'active' : ''}" onclick="setFiltro('contratado')">Contratados</button>
        </div>
        <div class="event-grid">
            ${eventos.map(e => `...card HTML...`).join('')}
        </div>
        ${eventos.length === 0 ? '<p style="text-align: center; padding: 40px;">No se encontraron eventos</p>' : ''}
    `;
    document.getElementById('todos-eventos').innerHTML = html;
}

function onBusqueda(valor) {
    busquedaActual = valor;
    renderEventosConFiltro();
}

function setFiltro(filtro) {
    filtroActual = filtro;
    renderEventosConFiltro();
}
```

## Key UX Patterns

1. **Event selection dropdown** — required before any item-specific action
2. **Visual button states** — normal → ⏳ executing → ✅ done → ❌ error → normal
3. **Auto-revert** — buttons return to normal after 3 seconds
4. **History timestamp** — every action logged with HH:MM:SS
5. **Batch progress** — show "X/Y processed" for bulk operations
6. **Color-coded agents** — each agent has a distinct color gradient
7. **Mini action buttons on cards** — quick actions (📁 open folder, 📄 generate docs, 👁️ view) directly on each item card without opening detail
8. **Toast notifications** — replace `alert()` with elegant, animated, auto-dismissing notifications (success/error/info/warning)
9. **Interactive checkboxes** — mark timeline tasks complete with strikethrough and color change
10. **Search & filter bar** — real-time search by name/ID/venue with status filter buttons
11. **Responsive layout** — `@media` queries for tablet (2-col KPIs, full-width panel) and mobile (1-col, compact nav)
12. **Action buttons in detail panel** — primary actions (open folder, generate docs, view docs) inside the slide-in detail header

## Verification Checklist

- [ ] New tab appears in navigation
- [ ] Event selector dropdown populated with real data
- [ ] Agent cards render with correct icon, name, description
- [ ] Action buttons exist for each agent
- [ ] Clicking action without selected event shows alert
- [ ] Clicking action with event shows "executing" state
- [ ] Backend POST endpoint is called
- [ ] Success shows "✅ ¡Listo!" for 3 seconds
- [ ] Error shows "❌ Error" for 3 seconds
- [ ] History panel shows timestamped entries
- [ ] Batch commands execute across multiple items
- [ ] All existing GET functionality still works
- [ ] Mini action buttons appear on every item card
- [ ] Clicking mini button executes action without opening detail
- [ ] Toast notifications appear instead of alert()
- [ ] Toast auto-dismisses after 3 seconds with animation
- [ ] Timeline checkboxes toggle completado state visually
- [ ] Search bar filters items in real-time
- [ ] Filter buttons highlight active filter
- [ ] Empty state shows "No se encontraron eventos" when filtered to zero
- [ ] Detail panel has action buttons in header
- [ ] Responsive layout works at 768px and 480px widths

## Pitfalls

1. **Button ID collisions** — use `btn-{agenteId}-{accionId}` pattern
2. **JSON serialization in onclick** — use `JSON.stringify().replace(/"/g, '&quot;')` for inline handlers
3. **Event validation** — always check `pao_id` before POST, not after
4. **History memory leak** — cap at 50 entries, not unbounded
5. **CORS** — if frontend and backend are on different ports, ensure `CORSMiddleware`
6. **Button state timing** — `setTimeout` must match visual feedback duration
7. **Batch failures** — catch individual item failures, don't fail entire batch
8. **Toast container z-index** — must be `z-index: 9999` and `position: fixed` to overlay all content
9. **Checkbox label association** — always use `for="id"` + `id` attribute, not just wrapping, for accessibility and click target
10. **Search debouncing** — for large datasets, debounce `oninput` at 200-300ms; for small datasets (<100 items), direct filtering is fine
11. **Responsive panel width** — detail panel should be `width: 100%` below 768px, not remain at 500px
12. **stopPropagation on card buttons** — mini buttons inside clickable cards must call `event.stopPropagation()` to prevent card click
13. **WSL localhost access** — Windows browsers cannot access WSL `localhost` directly. The server must bind to `0.0.0.0` (not `127.0.0.1`). Use the WSL IP (`172.x.x.x`) from Windows, or set up `netsh interface portproxy` for `localhost:8080` forwarding. Verify with `ss -tlnp | grep 8080` that it shows `0.0.0.0:8080`, not `127.0.0.1:8080`.
14. **Port zombie processes** — if `address already in use` error occurs, find and kill the old process with `lsof -i :8080` or `ss -tlnp | grep 8080`, then `kill -9 <PID>`. The old process may be binding to `127.0.0.1` even though the code says `0.0.0.0`.
15. **Process monitoring** — use `process: poll` or `curl` health checks to verify the server is actually running after restart, not just that the command was issued.
16. **Connecting actions to real scripts** — the frontend POST endpoints must call backend code that actually executes scripts, not just returns JSON. Create a separate `ejecutor_real.py` module that uses `subprocess.run()` to call the real Python scripts. Map action types to script names in a dictionary. The backend endpoint should import and call functions from this module, capturing stdout/stderr and returncode. Example:
    ```python
    # ejecutor_real.py
    def ejecutar_script(script_name, args=None, cwd=None):
        script_path = BASE_DIR / script_name
        cmd = [sys.executable, str(script_path)] + (args or [])
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return {"success": result.returncode == 0, "stdout": result.stdout, "stderr": result.stderr}
    
    # app.py endpoint
    from ejecutor_real import generar_documentos_evento
    
    @app.post("/api/agentes/{agente_id}/accion")
    async def ejecutar_accion_agente(agente_id: str, request: Request):
        data = await request.json()
        tipo = data.get("tipo", "")
        pao_id = data.get("pao_id", "")
        
        doc_tipos_map = {
            "generar_requisicion": ["requisicion"],
            "generar_checklist": ["checklist"],
            "generar_docs": ["requisicion", "checklist", "nomina"],
        }
        
        if tipo in doc_tipos_map:
            resultado = generar_documentos_evento(pao_id, doc_tipos_map[tipo])
            return {"success": resultado["success"], "detalle": resultado}
    ```
17. **WSL-to-Windows folder opening** — `xdg-open` does not work in WSL for Windows paths. Use `cmd.exe /c start` with the Windows path converted from WSL format (`/mnt/c/...` → `C:\...`). Example:
    ```python
    def abrir_carpeta_evento(pao_id):
        carpeta = find_event_folder(pao_id)
        win_path = str(carpeta).replace("/mnt/c/", "C:\\").replace("/", "\\")
        subprocess.run(["cmd.exe", "/c", "start", "", win_path], capture_output=True, timeout=10)
        return {"success": True, "mensaje": "Carpeta abierta en Windows"}
    ```
18. **Script execution feedback** — when executing real scripts, always capture and return stdout/stderr so the frontend can show meaningful feedback. Scripts that generate files should report which files were created. The frontend should display this in the execution history panel.
19. **Batch command execution** — batch commands (e.g., "generate docs for all events") should iterate over the filtered item list and call the single-item function for each. Track success/failure counts and report "X/Y processed" in the toast notification.
20. **Endpoint audit before wiring** — before connecting frontend buttons to backend, run `grep -n "@app\.\(post\|put\|delete\|patch\)" app.py` to see what endpoints exist. Many POST endpoints may only simulate (return JSON without executing). Replace these with real execution code before exposing them to the frontend.
21. **Missing `switchTab` function** — when adding new tabs via multiple `patch` operations, the `switchTab()` function can be accidentally deleted if a patch replaces the entire `<script>` block or overwrites the section containing it. Always verify `switchTab` still exists after each patch by running `grep -c "function switchTab" index.html`. If it disappears, restore it at the end of the `<script>` before `DOMContentLoaded`. The function must handle: (a) updating `currentTab`, (b) toggling `.active` on nav items, (c) toggling `.hidden` on tab-content divs, (d) calling `renderCatalogo()` when `tab === 'catalogo'`, (e) calling `renderAgentes()` when `tab === 'agentes'`.
22. **Duplicate function definitions** — when patching JS, multiple `patch` operations can define the same function twice (e.g., `renderEventos()` in the original code + a replacement patch). JavaScript uses the last definition, silently overriding earlier ones. This causes subtle bugs where the intended logic is replaced by an older/incomplete version. Always check for duplicate definitions with `grep -c "function renderEventos(" index.html` and consolidate into a single definition.
23. **Function-not-defined runtime errors** — if clicking a tab or button throws `switchTab is not defined` or `renderAgentes is not defined`, the function was either deleted by a patch, defined after its first call site, or inside a scope where it's not accessible. Verify: (a) the function exists in the HTML output (`curl | grep`), (b) it's defined in the global scope (not inside another function), (c) it's defined before `DOMContentLoaded` fires.
24. **Browser cannot access WSL localhost** — Windows browsers cannot access `http://localhost:8080` served from WSL. The server must bind to `0.0.0.0`. Access from Windows using the WSL IP (`http://172.x.x.x:8080`). Verify binding with `ss -tlnp | grep 8080` showing `0.0.0.0:8080`. If it shows `127.0.0.1:8080`, the server is not accessible from Windows — kill the process and restart with explicit `host='0.0.0.0'`.
25. **Process zombie after restart** — when restarting a server, the old process may not release the port immediately. If `address already in use` occurs, find the PID with `lsof -i :8080` or `ss -tlnp | grep 8080`, then `kill -9 <PID>`. The old process may be binding to `127.0.0.1` even if the new code says `0.0.0.0`, blocking both the old and new binding.
26. **Verify server actually running** — after `process: start`, always verify with `process: poll` or `curl http://localhost:8080/api/health`. The command may have been issued but the server may have crashed immediately. Check `uptime_seconds` in the poll response.
27. **Optional argument defaulting to empty string in file paths** — When a backend function like `verificar_documentos(carpeta, safe_nombre, pao_id="")` has an optional `pao_id` that defaults to empty string, and the caller omits it, the function silently builds paths like `Pedido_Flor_.pdf` instead of `Pedido_Flor_PAO-002.pdf`. The symptom is "document not found" even though it was generated. The fix is one line at the call site: pass `pao_id` as the third argument. Always verify call sites match function signatures after adding optional parameters.
  ```python
  # ❌ WRONG — pao_id defaults to "", builds "Pedido_Flor_.pdf"
  documentos = verificar_documentos(carpeta, safe_nombre)
  
  # ✅ CORRECT — passes pao_id, builds "Pedido_Flor_PAO-002.pdf"
  documentos = verificar_documentos(carpeta, safe_nombre, pao_id)
  ```
  **Detection:** Check API response for filenames ending in `_.pdf` or `_.xlsx` — that's the telltale sign of a missing pao_id in path construction.
28. **Frontend reads wrong progress field** — The backend calculates `progreso_pct` inside `detalles.progreso_pct` (based on real document existence), but the frontend may render `evento.progreso` (which is undefined or stale). The fix: update the frontend template to use `(e.detalles?.progreso_pct || e.progreso || 0)` instead of `e.progreso || 0`. Verify by checking the API response structure with `curl /api/evento/PAO-002 | python3 -c "import sys,json; d=json.load(sys.stdin); print('progreso:', d.get('progreso'), 'detalles.progreso_pct:', d.get('detalles',{}).get('progreso_pct'))"`.

## Related Skills

- `backend-spa-fallback` — when you need to create the SPA from scratch
- `fullstack-project-repair` — when the whole stack needs diagnosis and repair
- `paola-meneses-eventos` — domain-specific wedding/event planning operations