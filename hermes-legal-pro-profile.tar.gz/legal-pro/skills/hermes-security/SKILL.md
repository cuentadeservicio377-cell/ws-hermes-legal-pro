---
name: hermes-security
description: Capa de seguridad nativa de Hermes — auditoría, OSINT, defensa y operaciones ofensivas éticas. Feature incluido en todos los clones de Hermes.
version: 1.0.0
author: Hermes Agent
metadata:
  hermes:
    tags: [security, audit, osint, defense, pentesting, hermes-clone-feature]
    category: security
    required: true  # Feature obligatorio en clones
---

# 🛡️ Hermes Security Layer

## Visión

> "La mayoría de los asistentes AI no incluyen capacidades de seguridad. Hermes sí."

Capa de seguridad nativa que permite a cualquier clone de Hermes:
- **Auditar** su propia infraestructura automáticamente
- **Detectar** rootkits, malware y configuraciones inseguras
- **Monitorear** fugas de datos y credenciales expuestas
- **Investigar** su exposición pública (OSINT defensivo)
- **Generar** reportes profesionales de seguridad

## Comandos disponibles

### `/security audit`
Auditoría completa del sistema:
- **Lynis** — Índice de hardening, warnings, sugerencias
- **chkrootkit + rkhunter** — Detección de rootkits
- **SSH/Firewall audit** — Configuraciones críticas

**Uso:**
```bash
python -m security audit
# o via Hermes:
hermes-security.execute("audit")
```

### `/security osint <domain>`
OSINT defensivo sobre un dominio propio:
- **theHarvester** — Emails, hosts, subdomains expuestos
- **amass** — Enumeración completa de subdominios

**Uso:**
```bash
python -m security osint wscapital.mx
# o via Hermes:
hermes-security.execute("osint", "wscapital.mx")
```

### `/security leak-check`
Verificación de fugas de datos:
- **HaveIBeenPwned** — Breaches de emails y dominios
- **TruffleHog + Gitleaks** — Secretos expuestos en repos

**Uso:**
```bash
python -m security leak-check
python -m security leak-check --emails user@domain.com --domains wscapital.mx
```

### `/security report`
Genera reporte consolidado con todos los análisis recientes.

**Uso:**
```bash
python -m security report
```

## Estructura de reportes

```
~/hermes-core/security/reports/
├── lynis_audit_YYYYMMDD_HHMMSS.txt
├── chkrootkit_YYYYMMDD_HHMMSS.txt
├── rkhunter_YYYYMMDD_HHMMSS.txt
├── config_audit_YYYYMMDD_HHMMSS.json
├── theharvester_<domain>_YYYYMMDD_HHMMSS.xml
├── amass_<domain>_YYYYMMDD_HHMMSS.txt
├── gitleaks_<repo>_YYYYMMDD_HHMMSS.json
├── breach_check_YYYYMMDD_HHMMSS.json
├── full_audit_YYYYMMDD_HHMMSS.json
└── security_summary_YYYYMMDD_HHMMSS.json
```

## Reglas de oro

1. **Autorización:** NUNCA escanear/auditar sistemas sin autorización explícita documentada
2. **Logging:** Todo se loguea automáticamente en `~/hermes-core/security/logs/`
3. **Reportes:** Todo genera reporte timestamped
4. **Límites:** Herramientas ofensivas (phishing, RAT, DDOS) NO se integran
5. **Ética:** Solo defensa propia y auditorías autorizadas

## Instalación de dependencias

```bash
# Phase 1: Defensa (sistema)
sudo apt-get install -y lynis chkrootkit rkhunter fail2ban

# Phase 2: OSINT/Recon
pip install theHarvester
# amass: descargar desde https://github.com/owasp-amass/amass/releases
# gitleaks: descargar desde https://github.com/gitleaks/gitleaks/releases
# truffleHog: docker pull trufflesecurity/trufflehog:latest

# Phase 3: Configuración
export HIBP_API_KEY="your-key-here"  # Opcional, gratuito con rate limits
```

## Automatización

### Auditoría semanal (cron)
```bash
# Instalar cron job
echo "0 3 * * 0 /root/hermes-core/security/cron/weekly_audit.sh" | crontab -
```

### Hardening inicial
```bash
# Ejecutar en nuevos clones de Hermes
sudo /root/hermes-core/security/scripts/hardening.sh
```

## WSL vs Linux nativo

| Feature | Linux nativo | WSL |
|:---|:---:|:---:|
| Lynis | ✅ Full | ✅ Full |
| chkrootkit | ✅ Full | ✅ Full |
| rkhunter | ✅ Full | ⚠️ Necesita ajuste WEB_CMD |
| fail2ban | ✅ Full | ✅ Service (firewall limitado) |
| auditd | ✅ Full | ❌ No funciona (kernel) |
| UFW | ✅ Full | ⚠️ Solo tráfico WSL↔WSL |

## Diferenciador competitivo

- **Proactivo:** Detecta problemas antes de que sean explotados
- **Autónomo:** Corre auditorías automáticas sin intervención
- **Integrado:** No es una tool aparte — es parte del core de Hermes
- **Ético:** Solo defensa y auditoría autorizada
- **Profesional:** Reportes timestamped y consolidados

## Changelog

- **v1.0.0** (2026-04-24) — Release inicial con 4 fases completas
