---
name: ws-event-montage-guide-builder
category: productivity
description: >
  Build integrated event montage guides by merging operational documents
  (requisitions, flower orders, purchase lists, timelines, checklists) into a
  single visual PowerPoint presentation. Transforms administrative paperwork
  into an actionable day-of-event bible for crew members who don't use computers.
version: 1.1.0
author: Hermes Neo / WS Capital
triggers:
  - "integrar documentos operativos en presentación"
  - "guía de montaje completa"
  - "fusionar requisición pedido compras checklist"
  - "presentación día D"
  - "biblia del montaje"
  - "convertir cotización en guía operativa"
  - "el montaje debe ser parte del sistema"
  - "integrar montaje al ejecutor"
  - "documento de montaje con datos reales"
  - "la presentación original con instrucciones de montaje"
  - "datos operativos del Excel en la guía de montaje"
---

# WS Event Montage Guide Builder

## Purpose
Transform scattered operational documents into a single visual PowerPoint that serves as the day-of-event bible for crew members (bodega staff, florists, assistants) who don't use computers.

## When to Use
- When the user has generated separate operational docs (requisition, flower order, purchase list, checklist) and wants them unified
- When the user says the crew needs "one document" for the day of the event
- When the user wants to transform the client quotation PPT into an operational guide
- When the user mentions "communication problems" between planning and execution
- When the user wants "the administrative work to flow into physical action"

## Input Requirements
1. **Original quotation PPT** — client presentation with service images and specs
2. **Event master data** — from Excel/JSON: venue, times, contacts, notes
3. **Operational documents** (already generated or to be generated):
   - Requisition de bodega (materials, furniture, tools)
   - Pedido de flor (flower order with quantities)
   - Lista de compras (purchase list for consumables)
   - Cronograma (minute-by-minute timeline)
   - Checklist final (pre-departure verification)

## Output Structure

The integrated guide is a 15+ slide PowerPoint:

```
Slides 1-9:   Original client quotation (preserved with montage instructions added)
Slide 10:     DATOS OPERATIVOS — Venue, contacts, schedules, critical notes
Slide 11:     REQUISICIÓN DE BODEGA — Structures, furniture, tools, decoration
Slide 12:     PEDIDO DE FLOR — Bouquets, centerpieces, structural decor
Slide 13:     LISTA DE COMPRAS — Candles, crystals, consumables, logistics
Slide 14:     CRONOGRAMA DÍA D — Minute-by-minute from load to teardown
Slide 15:     CHECKLIST FINAL — Tick-boxes before leaving warehouse
```

## Color Coding by Section
- 🔵 Blue — Event data / venue info
- 🟣 Purple — Warehouse requisition
- 🟢 Green — Flower order
- 🔴 Red — Purchase list
- 🟠 Orange — Day-of timeline
- 🟢 Bright green — Final checklist

## Technical Implementation

### System Integration (CRITICAL — v1.1 addition)

The montage guide is NOT a standalone script. It must integrate into the existing document generation pipeline:

**1. Register as a document type in the executor:**
```python
# In ejecutor_v4.py, add 'montaje' to the type map
tipos_map = {
    "todos": ["requisicion", "pedido_flor", "checklist", "montaje"],
    "requisicion": ["requisicion"],
    "pedido_flor": ["pedido_flor"],
    "checklist": ["checklist"],
    "nomina": ["nomina"],
    "montaje": ["montaje"],
}
```

**2. Add generation logic in the executor:**
```python
elif tipo == 'montaje':
    from sistema_documentos_reales import generar_guia_montaje_integrada
    output_path = docs_dir / "Montaje" / f"Guia_Montaje_{pao_id}_INTEGRADA.pptx"
    output_path.parent.mkdir(exist_ok=True)
    resultado = generar_guia_montaje_integrada(pao_id, output_path)
    # Returns: {success, archivo, servicios}
```

**3. Backend endpoint already supports it:**
```bash
POST /api/cliente/{pao_id}/generar-documento
{"tipo": "montaje"}
```

### Real Data Pipeline (v1.2 — IMPLEMENTED)

**All operational documents must use real event data, never generic templates.**

The pipeline has three layers. This was built and verified in session 30abr2026.

**Layer 1: Extract real data from sources**
```python
# Source A: PPT JSON (service specifications)
# File: datos_extraidos/PAO-XXX-completo.json
# Contains: slide text with exact specs, quantities, prices

# Source B: Excel Master (operational data)
# File: sistema-completo/control-maestro/Paola_Meneses_Control_Maestro_V3_DATOS_REALES.xlsx
# Contains: venue, times, contacts, WP info, notes

def cargar_datos_reales(pao_id):
    ppt_json = cargar_json_completo(pao_id)      # Service specs
    excel_data = extraer_datos_operativos_excel(pao_id)  # Times, contacts
    return {"ppt": ppt_json, "excel": excel_data}
```

**Layer 2: Generate documents from real data**

Implemented in `sistema_documentos_reales.py`:

```python
def generar_requisicion_bodega_real_v2(pao_id, output_path):
    datos = cargar_datos_reales(pao_id)
    servicios = extraer_servicios_reales(datos['ppt'])
    # Extract materials from actual service specs
    # Example: "75 cilindros con velas flotantes" from PPT → Cilindros: 75
    # Example: "6 mesas redondas" from PPT → Mesas redondas: 6

def generar_pedido_flor_real_v2(pao_id, output_path):
    datos = cargar_datos_reales(pao_id)
    servicios = extraer_servicios_reales(datos['ppt'])
    # Generate flower order from actual services in PPT
    # If PPT has "Cielo de flores" + "6 candelabros" → include both
    # If PPT has "Ramos y Accesorios" → include ramos

def generar_checklist_montaje_real_v2(pao_id, output_path):
    datos = cargar_datos_reales(pao_id)
    servicios = extraer_servicios_reales(datos['ppt'])
    # Generate checklist items from actual service specs
    # NOT generic template — specific to services contracted

def generar_guia_montaje_integrada(pao_id, output_path):
    # FINAL OUTPUT: consumes all sources
    # 1. Original PPT (images, branding, service visuals)
    # 2. Requisicion_Bodega_REAL.pdf (materials list)
    # 3. Pedido_Flor_REAL.pdf (flower order)
    # 4. Checklist_Montaje_REAL.pdf (verification items)
    # 5. Excel data (times, contacts, notes)
    # → Produces: unified PPTX guide with 15+ slides
```

**Layer 3: System integration via ejecutor_v4**

```python
# In ejecutor_v4.py, register 'montaje' as a document type:
tipos_map = {
    "todos": ["requisicion", "pedido_flor", "checklist", "montaje"],
    "montaje": ["montaje"],
}

# The executor imports from sistema_documentos_reales:
from sistema_documentos_reales import (
    generar_requisicion_bodega_real_v2,
    generar_pedido_flor_real_v2,
    generar_checklist_montaje_real_v2,
    generar_guia_montaje_integrada
)

# Backend endpoint (already supports it):
POST /api/cliente/{pao_id}/generar-documento
{"tipo": "montaje"}
# Returns: {success, archivo, servicios, total_slides}
```

**Output file structure:**
```
04_Documentos_Operativos/
├── Requisicion_Bodega/Requisicion_Bodega_PAO-XXX_REAL.pdf
├── Pedido_Flor/Pedido_Flor_PAO-XXX_REAL.pdf
├── Checklist_Montaje/Checklist_Montaje_PAO-XXX_REAL.pdf
└── Montaje/Guia_Montaje_PAO-XXX_INTEGRADA.pptx
```

### Data Extraction from PPT JSON

```python
def extraer_servicios_reales(data):
    """Extract services with real specifications from PPT JSON"""
    slides = data.get('slides', [])
    servicios = []
    
    for slide in slides:
        textos = slide.get('textos', [])
        texto_completo = ' '.join(textos)
        
        # Detect service slides by keywords
        es_servicio = any(kw in texto_completo.lower() for kw in [
            'especificaciones técnicas', 'costo total', 'costo por mesa',
            'dimensión', 'decoración', 'diseño'
        ])
        
        if es_servicio:
            nombre = textos[0].strip()  # First text = service name
            especs = [t.strip() for t in textos[1:] 
                      if 'especificaciones' not in t.lower() 
                      and 'costo' not in t.lower()]
            
            # Extract cost
            costo = 0
            for t in textos:
                if 'costo' in t.lower():
                    nums = re.findall(r'[\d,]+\.?\d*', t)
                    if nums:
                        costo = float(nums[0].replace(',', ''))
            
            servicios.append({
                'nombre': nombre,
                'especificaciones': especs,
                'costo': costo,
                'slide_num': slide.get('slide_num', 0)
            })
    
    return servicios
```

### Data Extraction from Excel Master

```python
def extraer_datos_operativos_excel(pao_id):
    """Extract operational data from Excel master"""
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    sheet = wb["Eventos"]
    
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if row[0] and pao_id in str(row[0]):
            return {
                'hora_entrada': row[20] if len(row) > 20 and row[20] else "09:00",
                'hora_montaje_listo': row[21] if len(row) > 21 and row[21] else "17:00",
                'hora_evento_inicio': row[22] if len(row) > 22 and row[22] else "18:30",
                'hora_evento_fin': row[23] if len(row) > 23 and row[23] else "02:30",
                'hora_desmontaje': row[24] if len(row) > 24 and row[24] else "06:30",
                'venue_url': row[25] if len(row) > 25 and row[25] else "",
                'contacto_venue': row[26] if len(row) > 26 and row[26] else "",
                'notas_proveedores': row[27] if len(row) > 27 and row[27] else "",
                'wp_nombre': row[28] if len(row) > 28 and row[28] else "",
                'wp_contacto': row[29] if len(row) > 29 and row[29] else "",
            }
    return {}
```

### Python with python-pptx — Use ORIGINAL PPT as Base

**CRITICAL:** Do NOT create a new generic PPT. Use the client's original quotation PPT as the base, then append operational slides.

```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
from pathlib import Path

def generar_documento_montaje(pao_id, output_path=None):
    # 1. Find original quotation PPT
    eventos_dir = Path("/mnt/c/Users/.../BB_En_Proceso")
    carpetas = list(eventos_dir.glob(f"{pao_id}*"))
    carpeta = carpetas[0]
    ppt_dir = carpeta / "01_Cotizaciones"
    ppt_files = list(ppt_dir.glob("*.pptx"))
    
    # 2. Load original PPT (preserves images, layout, branding)
    prs = Presentation(str(ppt_files[0]))
    
    # 3. Load real data sources
    datos_ppt = cargar_json_completo(pao_id)  # Extracted slide text
    datos_excel = cargar_datos_excel(pao_id)   # Venue, times, contacts
    
    # 4. Add montage instructions to existing service slides
    for servicio in extraer_servicios(datos_ppt):
        instrucciones = MAPEO_INSTRUCCIONES.get(servicio['nombre'])
        if instrucciones:
            slide = encontrar_slide_por_nombre(prs, servicio['nombre'])
            agregar_caja_instrucciones(slide, instrucciones)
    
    # 5. Append operational slides
    agregar_slide_datos_operativos(prs, datos_excel)
    agregar_slide_requisicion_bodega(prs, servicios)
    agregar_slide_pedido_flor(prs, servicios)
    agregar_slide_lista_compras(prs, servicios)
    agregar_slide_cronograma(prs, datos_excel)
    agregar_slide_checklist_final(prs, servicios)
    
    # 6. Save to standard location
    if output_path is None:
        docs_dir = carpeta / "04_Documentos_Operativos" / "Montaje"
        docs_dir.mkdir(parents=True, exist_ok=True)
        output_path = docs_dir / f"Guia_Montaje_{pao_id}.pptx"
    
    prs.save(str(output_path))
    return {"success": True, "archivo": str(output_path), "total_slides": len(prs.slides)}
```

### Data Sources — MUST use real data, never generic templates

**CRITICAL RULE:** All numbers, contacts, and times come from the master Excel (operational data) and the PPT JSON (service specs). Never use generic templates or estimated quantities.

**From Excel master (operational data):**
```python
wb = openpyxl.load_workbook(excel_path, data_only=True)
sheet = wb["Eventos"]
for row in sheet.iter_rows(min_row=2, values_only=True):
    if row[0] and pao_id in str(row[0]):
        return {
            "venue": row[6],                    # Venue name
            "invitados": row[7],                # Guest count
            "wp_nombre": row[8] or row[28],     # Wedding planner
            "wp_contacto": row[29],             # WP phone
            "hora_entrada": row[20] or "09:00", # Entry time
            "hora_montaje_listo": row[21] or "17:00",  # Setup deadline
            "hora_evento_inicio": row[22] or "18:30",
            "hora_evento_fin": row[23] or "02:30",
            "hora_desmontaje": row[24] or "06:30",
            "venue_url": row[25],               # Google Maps link
            "contacto_venue": row[26],          # Venue contact
            "notas_proveedores": row[27],       # Critical notes
            "coordinador": row[9],              # Paola's coordinator
        }
```

**From quotation PPT JSON (service specs):**
```python
with open(f'{pao_id}-completo.json', 'r') as f:
    data = json.load(f)

for slide in data['slides']:
    textos = slide.get('textos', [])
    # Extract: service name, specifications, quantities, prices
    # Example: "Tunel de Ingreso", "3.40m alto x 8m largo", "75 cilindros"
```

**Anti-pattern to avoid:**
```python
# ❌ WRONG: Generic calculation
mesas = max(8, invitados // 10)  # Generic estimate

# ✅ CORRECT: Real data from PPT
for texto in slide['textos']:
    if 'mesas redondas' in texto.lower():
        nums = re.findall(r'\d+', texto)
        if nums:
            mesas = int(nums[0])  # "6 Mesas redondas" → 6
```

### Conversion to PDF and Images

```bash
# Convert to PDF (for printing)
libreoffice --headless --convert-to pdf guia_montaje.pptx

# Convert PDF to images (for WhatsApp/mobile sharing)
pdftoppm -png -r 300 guia_montaje.pdf slide

# Result: slide-01.png through slide-NN.png
```

## Key Principles

1. **System integration, not standalone** — The montage guide must be a document type within the existing generation pipeline (`ejecutor_v4.py`), not a separate script. It uses the same backend endpoint: `POST /api/cliente/{pao_id}/generar-documento {"tipo": "montaje"}`
2. **Original PPT as base** — Use the client's actual quotation PPT (with real images and branding), never create a generic template. The guide extends the original, it doesn't replace it.
3. **Real data only** — All numbers, contacts, and times come from the master Excel (operational data) and the PPT JSON (service specs). Never use generic templates or estimated quantities.
4. **Visual first** — Crew members don't read long documents; they need scannable slides with color-coded sections.
5. **Tick-box culture** — The checklist slide has physical checkboxes that get ticked with pen/marker before leaving the warehouse.
6. **Mobile-friendly** — Export slides as PNG images for WhatsApp sharing with crew members who don't use computers.
7. **One source of truth** — The original quotation PPT becomes the operational bible. Administrative work flows into physical action through this single document.

## Integration with Existing System

This skill extends the `paola-meneses-eventos` workflow:
- After generating `requisicion_bodega.pdf`, `pedido_flor.pdf`, etc.
- Instead of delivering separate PDFs, merge them into the unified guide
- The guide becomes the final deliverable for the day-of-event crew

## Files and Locations

- Workspace: `/root/ws-paola-meneses/`
- Real-data pipeline: `/root/ws-paola-meneses/sistema_documentos_reales.py`
- Event folders: `/mnt/c/Users/DELL/Documents/WS Capital/Paola Meneses Decoracion/03_Eventos_Confirmados/BB_En_Proceso/PAO-XXX/`
- PPT source: `01_Cotizaciones/Cotizacion_XXX_v1.pptx` (original quotation)
- PPT JSON data: `/root/ws-paola-meneses/datos_extraidos/PAO-XXX-completo.json`
- Excel master: `/root/ws-paola-meneses/sistema-completo/control-maestro/Paola_Meneses_Control_Maestro_V3_DATOS_REALES.xlsx`
- Output: `04_Documentos_Operativos/Montaje/Guia_Montaje_PAO-XXX_INTEGRADA.pptx`
- PDF conversion: `/tmp/paoXXX_guia_completa/`

## Verification Steps

After generating, verify integration works end-to-end:

```bash
# 1. Backend health
curl -s http://localhost:8080/api/health

# 2. Generate montage guide via API
curl -s -X POST http://localhost:8080/api/cliente/PAO-001/generar-documento \
  -H "Content-Type: application/json" \
  -d '{"tipo": "montaje"}'

# 3. Verify files exist
ls /mnt/c/Users/.../BB_En_Proceso/PAO-001/04_Documentos_Operativos/Montaje/

# 4. Convert to PDF for printing
libreoffice --headless --convert-to pdf Guia_Montaje_PAO-001_INTEGRADA.pptx

# 5. Convert to images for WhatsApp
pdftoppm -png -r 300 Guia_Montaje_PAO-001_INTEGRADA.pdf slide
```
