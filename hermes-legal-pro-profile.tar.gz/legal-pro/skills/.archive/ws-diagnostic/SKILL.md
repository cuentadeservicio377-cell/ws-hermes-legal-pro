---
name: ws-diagnostic
description: Diagnose and document the current LLM provider configuration AND session continuity state for Hermes (WS Capital). Covers providers, subagent runtime, project state persistence, and the "system works but session doesn't remember" pattern.
author: pablo
tags: [diagnostic, model-config, session-continuity, project-state, hermes, ws-capital]
version: 2.0
---

# Hermes Diagnostic — Providers + Session Continuity

## Overview
This skill diagnoses TWO distinct layers:
1. **Infrastructure layer** — providers, auth, subagents, config
2. **Session continuity layer** — does the current session know about active projects?

The most common user complaint: "It was working before, now it acts like before" usually means infrastructure is FINE but session continuity is BROKEN.

## Class of Problem: "System Works But Session Forgets"

### Trigger
User says any of:
- "Se supone que ya estaba configurado"
- "Ya podía usar todo y ahora no"
- "Actúa como la gente de antes"
- "No revisa los logs / no encuentra el proyecto"
- "Estaba corriendo de la perfección y ahora no"

### Root Cause
Each chat session starts FRESH. The system infrastructure (config, auth, skills) persists across sessions. But:
- Active projects are NOT automatically loaded
- Cron job results are NOT automatically reported
- Session context is NOT automatically recovered
- The agent must explicitly be told "we are working on X"

### Diagnostic Flow
```
1. Verify infrastructure FIRST (providers, auth, subagents)
   → If broken, use ws-system-repair
   → If working, continue to step 2

2. Check session continuity:
   → Ask user: "¿En qué proyecto estás trabajando?"
   → Search for project files in known locations
   → Check Obsidian Vault / repos / Documents for active projects
   → Look for checkpoint files, cron logs, pending work

3. If infrastructure OK + project exists but session unaware:
   → This is SESSION CONTINUITY GAP, not system failure
   → Load project context explicitly
   → Report: "Sistema operativo. Proyecto encontrado en [ruta]."
```

## Current Configuration (as of 2026-04-28)

### Primary Providers
| Provider | Model | Role | Status |
|----------|-------|------|--------|
| **kimi-coding** | kimi-k2.6 | Principal | ✅ Active |
| **openai-codex** | gpt-5.3-codex | Subagentes | ✅ Active (Copilot ACP) |
| **openai-codex** | gpt-5.4-mini | Fallback 1 | ✅ Active |
| **opencode-go** | kimi-k2.6 | Fallback 2 | ⚠️ Backup (Cloudflare 403 in WSL) |
| **openai-codex** | gpt-5.4 | Vision | ✅ Active |

### Deprecated/Removed Providers
| Provider | Status | Notes |
|----------|--------|-------|
| DeepSeek | ❌ Removed | Never configured |
| Xiaomi MIMO | ❌ Removed | Removed 2026-04-22 |
| OpenRouter | ❌ Removed | Not in current config |
| Nous Research | ❌ Removed | Replaced by OpenAI Codex |

### Infrastructure Verification Commands
```bash
# 1. Providers configured?
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); print('Providers:', list(c.get('providers',{}).keys()))"

# 2. Copilot CLI installed?
which copilot && copilot --version

# 3. Gateway running?
ps aux | grep hermes | grep -v grep

# 4. Subagent test (REAL runtime test)
# → Use delegate_task with acp_command="copilot" to verify

# 5. Active projects search
find /mnt/c/Users/DELL/Documents -maxdepth 4 -type d -name "*2026*" -o -name "*active*" -o -name "*campaign*" 2>/dev/null
find /mnt/c/Users/DELL/Documents/repos -maxdepth 2 -type d 2>/dev/null
find "/mnt/c/Users/DELL/Documents/Obsidian Vault" -maxdepth 3 -type d 2>/dev/null
```

## Session Continuity Audit

### Checklist
- [ ] Infrastructure verified (providers, auth, subagents)
- [ ] Ask user what project they're referring to
- [ ] Search for project in known locations:
  - `/mnt/c/Users/DELL/Documents/Obsidian Vault/WS-Campaigns/01-Active/`
  - `/mnt/c/Users/DELL/Documents/repos/`
  - `/mnt/c/Users/DELL/Documents/WS Capital/`
  - `/mnt/c/Users/DELL/Desktop/`
- [ ] Check for checkpoint files (`checkpoint-*.md`, `CIERRE-REAL-*.md`)
- [ ] Check for cron job logs or pending async work
- [ ] If project found but session unaware → load context, NOT repair infrastructure
- [ ] If project NOT found anywhere → investigate if it was deleted/moved

### Common Project Locations (WS Capital)
| Project Type | Typical Location |
|-------------|------------------|
| Campaigns/Hackathons | `Obsidian Vault/WS-Campaigns/01-Active/` |
| Client systems | `Documents/repos/` or `Documents/[client-name]/` |
| Product clones | `Documents/WS Capital/[product]/` |
| Deliverables | `Desktop/[project]-Entrega-[date]/` |

### Distinguishing Infrastructure vs Continuity Problems

| Symptom | Infrastructure? | Continuity? |
|---------|----------------|-------------|
| "No tiene acceso a nada" | ✅ Check providers/auth | ✅ Check if project context loaded |
| "Actúa como antes" | ✅ Check if config corrupted | ✅ Check if session lost project state |
| "No revisa logs" | ✅ Check if tools available | ✅ Check if logs location known |
| "Estaba perfecto y ahora no" | ✅ Check gateway/copilot | ✅ Check if project still exists |

## Recommendations

1. **Always verify infrastructure first** — use ws-system-repair if broken
2. **Always ask "what project?"** — don't assume the session knows
3. **Search before repairing** — the project may exist, the session just doesn't know
4. **Report honestly** — "Sistema OK, proyecto encontrado en [ruta]" vs "Sistema roto, reparando"
5. **Update ws-system-repair** if infrastructure IS broken — don't duplicate repair logic here

---