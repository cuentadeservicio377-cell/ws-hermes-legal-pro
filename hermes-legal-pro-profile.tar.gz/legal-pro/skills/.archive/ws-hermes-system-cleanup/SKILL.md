---
name: ws-hermes-system-cleanup
description: Sesión completa de limpieza y reparación del sistema Hermes para WS Capital. Incluye limpieza de memoria, skills, vaults, configuración, y organización de Telegram como centro de control.
trigger: Cuando el sistema Hermes se siente "sucio", hay drift de configuración, o se necesita reorganizar después de importar skills de otra máquina.
---

# WS Capital — Limpieza y Reparación del Sistema Hermes

## 1. Diagnóstico inicial

- Verificar `hermes memory` (debe estar < 80%)
- Verificar `hermes profile` (detectar drift modelo/provider)
- Listar skills: `ls ~/.hermes/skills/` — contar y categorizar
- Revisar vaults en `~/Documents/WS Capital/` — detectar duplicación
- Revisar procesos: `hermes ps` y `hermes cron list`
- Verificar `~/.hermes/config.yaml` por duplicados o valores obsoletos
- Revisar `~/.hermes/AGENTS.md` — NO debe existir en HERMES_HOME

## 2. Limpieza de memoria persistente

### Memory (environment facts)
- Consolidar entradas redundantes (usar `memory replace`)
- Eliminar información temporal/session-specific (commits, puertos, fechas de reparación)
- Corregir contradicciones modelo/provider
- Compactar usando formato § (section sign)
- Target: < 50% utilización

### User profile (preferences)
- Consolidar preferencias duplicadas
- Eliminar datos de proyectos ya cerrados
- Target: < 50% utilización

## 3. Limpieza de skills

### Script reutilizable
```python
# ~/.hermes/scripts/skill-cleanup.py
# Elimina skills bundled no deseadas de un perfil
# Uso: python skill-cleanup.py --profile ws --keep-list skills-a-mantener.txt
```

### Skills a mantener (lista mínima WS Capital)
- `neo-telegram-dev-flow`
- `opencode`, `codex`, `claude-code`, `hermes-agent`
- `github-*` (auth, pr-workflow, issues, code-review, repo-management)
- `plan`, `writing-plans`, `tdd`, `systematic-debugging`, `requesting-code-review`
- `subagent-driven-development`, `project-continuity-with-vaults`
- `aws-capital-operating-model`, `ws-brain-dump`, `ws-growth-operational-batch`
- `obsidian`, `onyx-lite-extension-pattern`, `onyx-integration-technical-reference`
- `onyx-standalone-legal-frontend`, `willow-legal-surface-repair`
- `kami-legal-document-generation`, `kami-blocks-legal-document-engine`
- `ws-department-activation`, `ws-interconnected-ops`
- `paola-meneses-eventos`

### Categorías a eliminar si no se usan
- Apple, Creative, Data Science, Gaming, MLOps, Red-teaming, SmartHome
- Skills de proyectos ya cerrados (Willow migration phases, Paperclip, etc.)

## 4. Consolidación de vaults

### Estructura final (3 fuentes de verdad)
```
WS Capital/
├── Build Vault/          ← Proyectos activos + Willow dev/integration
├── Growth Vault/         ← Estrategia, marketing, contenido
└── System Vault/         ← Contrato operativo + Archive + Operations
```

### Pasos
1. Crear `System Vault/Archive/` y `System Vault/Operations/`
2. Mover `WS Neo Delivery Vault/` → `System Vault/Archive/WS-Neo-Delivery/`
3. Mover `Night Ops Vault/` → `System Vault/Operations/Night-Ops/`
4. Mover `Willow Vault/` → `Build Vault/Projects/Willow/Development/`
5. Mover `Willow Firm Integration Vault/` → `Build Vault/Projects/Willow/Integration/`
6. Eliminar carpetas vacías originales

## 5. Reparación de configuración

### Eliminar AGENTS.md de HERMES_HOME
```bash
rm ~/.hermes/AGENTS.md
```
AGENTS.md va en el directorio de cada proyecto (CWD + subdirectorios progresivos).

### Actualizar SOUL.md global
- Reflejar modelo dual: socio operativo personal + operador de empresas
- Confirmar modelo actual (Kimi K2.6 vía nous)
- Confirmar OpenCode como herramienta externa de build

### Crear perfil ws (si no existe)
```bash
hermes profile create ws --clone
# Limpiar skills bundled no deseadas
# Actualizar SOUL.md del perfil ws con identidad operador WS Capital
```

## 6. Limpieza de procesos y cron

- `hermes ps` — matar procesos zombie si los hay
- `hermes cron list` — eliminar cron jobs de proyectos cerrados
- Verificar que no haya duplicados

## 7. Organización de Telegram como centro de control

### Topics recomendados en grupo Hermes
1. `🧠 Socio Operativo` — planificación, limpiezas, decisiones
2. `⚖️ Willow Legal` — operar firma legal, matters, Onyx
3. `📈 Growth & Marketing` — estrategia, contenio, campañas
4. `🏗️ Build & Tech` — código, repos, OpenCode, deploys
5. `📋 Admin & Ops` — cotizaciones, facturas, finanzas
6. `🚀 Ventas & Plantillas` — vender clones, demos, onboarding

### Configurar channel_prompts en config.yaml
```yaml
telegram:
  allowed_chats:
    - -5181506599
  channel_prompts:
    -5181506599: |
      [DETECTA CONTEXTO DESDE EL MENSAJE O EL TOPIC]
      ... (ver configuración completa en sesión 24/04/2026)
```

### Nota técnica
Hermes `channel_prompts` funciona por `chat_id`, NO por `topic_id`. Para aislamiento total por empresa, usar grupos separados con distintos `chat_id`.

## 8. Verificación final

- [ ] Memoria < 50%
- [ ] User profile < 50%
- [ ] Skills < 60 esenciales
- [ ] 3 vaults consolidados
- [ ] AGENTS.md eliminado de HERMES_HOME
- [ ] SOUL.md actualizado
- [ ] Perfil ws creado y limpio
- [ ] 0 cron jobs obsoletos
- [ ] Gateway de Telegram configurado con prompt inteligente
- [ ] Topics creados en grupo Hermes

## Referencias
- Plan maestro Company OS: `hermes-workspace/.hermes/plans/2026-04-23_ws-capital-company-os-master-plan.md`
- Documentación Hermes: https://hermes-agent.nousresearch.com/docs/
- Onyx: puerto 3000, centro de control de conocimiento legal
