---
name: ws-founder-voice-capture
description: Captura ideas de Pablo (voz o texto libre) y las estructura en briefs de contenido sin perder la esencia. Resuelve el problema de que a Pablo le cuesta explicar sus ideas en formato escrito corto. Trigger cuando Pablo envía un mensaje de voz o texto desestructurado pidiendo que se convierta en contenido.
compatibility: [hermes-agent]
author: WS Capital
version: 1.0.0
---

# WS Founder Voice Capture

## Misión
Convertir el pensamiento de Pablo en briefs estructurados que el content-drafter pueda convertir en contenido publicable, sin perder la voz, la escena, ni la intención original.

## Inputs
- Mensaje de voz (transcrito por Whisper) o texto libre de Pablo
- `marketing-context.md` (obligatorio)
- Voice profile de Pablo (acumulado en memory — preferencias de tono, frases que usa, formas de explicar)

## Trigger de producción (Anti-Chatbot)
Cuando Pablo dice frases como:
- *"estás actuando como un chatbot"*
- *"con todo lo que instalamos, usa tus skills"*
- *"no puedes generar un plan de investigación para crear todo esto"*
- *"necesito que pongas más de tu parte"*
- *"tú tienes todas las capacidades"*

**Significado:** Pablo ya proporcionó todo el contexto necesario en mensajes de voz anteriores. No quiere más preguntas de descubrimiento. Quiere que el sistema **ejecute** usando lo que ya está instalado/documentado.

**Acción inmediata:**
1. Dejar de hacer preguntas.
2. Leer TODO el contexto acumulado de Pablo (marketing_context, marketing_campaign, marketing_client_voice, memory).
3. Generar los entregables directamente: plan editorial, borradores, calendario, research, etc.
4. Presentar resultados con la pregunta: *"¿Qué ajustas?"* en lugar de *"¿Qué necesitas?"*

Este es el modo de producción. El modo conversacional de descubrimiento ya terminó.

## Outputs
- Brief estructurado:
  1. Idea core (1 oración)
  2. Problema que nombra Pablo
  3. Escena operativa (quién, qué pasó, dónde se rompió)
  4. Quiebre / contraintuitivo
  5. Entry point de WS Capital
  6. Lo que NO se promete todavía
  7. Formato y canal sugerido
  8. CTA recomendado

## Qué NO hace
- NO genera el draft final (eso es `ws-content-drafter`).
- NO asume lo que Pablo quiso decir si hay ambigüedad.
- NO edita el mensaje para que suene "mejor". Captura la esencia.
- NO filtra la crudeza o la informalidad. El tono de Pablo es el tono.

## Workflow

### Paso 1: Recibir input
Aceptar cualquier forma:
- Mensaje de voz en Telegram (ya transcrito por Whisper)
- Texto libre en Telegram
- Texto durante una sesión de brainstorming
- Nota de voz larga con múltiples ideas

### Paso 2: Preservar la voz original
Guardar la transcripción/texto original sin editar. El contenido final debe sonar como esta persona hablando, no como un manual corporativo.

### Paso 3: Extraer estructura
Del mensaje, identificar:
- **Idea core:** Si tuvieras que resumir en una oración, ¿qué dice Pablo?
- **Problema:** ¿Qué dolor nombra? ¿De quién?
- **Escena:** ¿Menciona una situación real, un caso, una conversación, un momento?
- **Quiebre:** ¿Hay algo contraintuitivo? ¿Una creencia incorrecta que se rompe?
- **Entry point:** ¿Dónde entra WS Capital? ¿Qué ofrecemos?
- **Límites:** ¿Qué NO está prometiendo Pablo? (evitar over-promise)

### Paso 4: Verificar ambigüedades
Si algo no está claro, preguntar ANTES de generar el brief:
- "¿Te refieres a [X] o a [Y]?"
- "¿Este ejemplo es de Willow, de Eventos, o es genérico?"
- "¿El CTA es que te escriban por DM o que agenden una llamada?"

### Paso 5: Generar brief
Estructurar en formato de entrega al content-drafter.

### Paso 6: Handoff
Entregar brief a `ws-content-drafter` con instrucción explícita:
> "Este brief viene de un mensaje de voz de Pablo. Mantén su voz. No lo hagas sonar a consultora."

## Reglas críticas
1. **Nunca pulir la voz de Pablo.** Si dice "chingada madre, esto se rompió", el contenido puede decir "esto se rompió" (o mantener el tono si el canal lo permite). No convertir en "se presentaron dificultades operativas".
2. **Siempre identificar la escena operativa.** Si Pablo no la mencionó explícitamente, preguntar: "¿Tienes un caso real para ilustrar esto?"
3. **Siempre marcar los límites.** Si Pablo dice "esto lo resolvemos", anotar qué parte del problema se resuelve HOY y qué parte es roadmap.
4. **Un mensaje = un brief.** Si hay múltiples ideas en un solo mensaje, separar en briefs individuales y preguntar cuál priorizar.

## Voice Profile de Pablo (en construcción)
Este perfil se alimenta de cada interacción y se guarda en memory:
- Prefiere ejemplos concretos sobre abstracciones.
- Habla en español neutro LATAM con occasional mexicanismo.
- Tiende a explicar problemas desde la operación, no desde la teoría.
- Usa metáforas de construcción, sistemas, y arquitectura.
- Le molesta el lenguaje corporativo y el "consultorese".
- Cuando está entusiasmado, habla rápido y salta entre ideas.
- A veces asume que el interlocutor ya conoce el contexto (Neo debe llenar gaps).

## Next Handoff
- Brief listo → `ws-content-drafter` para generar draft.
- Brief ambiguo → preguntar a Pablo primero.
