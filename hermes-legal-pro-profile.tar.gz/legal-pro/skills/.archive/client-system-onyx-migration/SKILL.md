---
name: client-system-onyx-migration
description: Audit a client's existing system (PaperClip, custom app, etc.) and design a migration into Onyx Lite using the extension pattern. Covers domain mapping, schema design, bridge API planning, and phased implementation.
trigger: When a client has an existing system/app and wants to migrate its functionality into a new Onyx instance.
---

# Client System → Onyx Migration

Use this when WS Capital needs to onboard a new client by migrating their existing system into a fresh Onyx instance, using Willow Legal as the proven pattern.

## Prerequisites
- Access to client's existing repo (GitHub) or running instance
- Onyx Lite source cloned locally (`/mnt/c/Users/DELL/Documents/repos/research/onyx` or similar)
- Understanding of the client's business domain (events, legal, sales, etc.)

## Deployment Mode Decision

Before auditing, decide which pattern the client needs:

| Pattern | Use When | DB | Network |
|---------|----------|-----|---------|
| **Extension** (shared Onyx) | Add domain to existing Onyx | Shared PostgreSQL, prefixed tables | Same Docker network |
| **Separate Instance** (new Onyx) | Client needs completely isolated system | Separate PostgreSQL container/volume | Separate Docker network via `name:` |

**Paola Rule:** If the client is a different company, use a **separate Onyx instance** with its own project name, ports, and network. This makes it portable and avoids cross-tenant contamination.

### Multi-instance Onyx on same host (critical ops lesson)

When running multiple Onyx instances on the same Docker host, port conflicts are guaranteed unless you override the nginx bindings:

```bash
# Onyx nginx binds to these env vars in docker-compose.yml:
#   ports:
#     - "${HOST_PORT_80:-80}:80"
#     - "${HOST_PORT:-3000}:80"
#
# Set these in .env BEFORE first compose up:
HOST_PORT_80=82      # avoids conflict with existing :80
HOST_PORT=3002       # avoids conflict with existing :3000
```

**Discovery path:** If you see `Bind for 0.0.0.0:80 failed: port is already allocated`, the fix is always to set `HOST_PORT_80` and `HOST_PORT` in `.env`, then destroy and recreate.

**Verify port state:**
```bash
ss -ltnp | grep -E ':(80|3000|3002|5432|5433|8080|8082)'
```

The compose project `name:` field (e.g., `name: paola` vs `name: onyx`) automatically isolates networks and volumes, but **port bindings are host-level** and must be explicitly separated.

## Phase 1: Audit the Existing System

### 1.1 Clone and inspect the repo
```bash
cd /tmp
gh repo clone <owner>/<repo> <client-name> -- --depth 1
find <client-name> -type f -not -path '*/.git/*' | sort | head -100
```

### 1.2 Read the authoritative docs first
Look for and read in this order:
1. `README.md` or system overview file — high-level purpose
2. `memory/architecture.md` or `docs/ARCHITECTURE.md` — technical stack
3. `memory/operating-flow.md` or `docs/OPERATIONS.md` — business processes
4. Any backend audit docs (`specs/*-backend-audit.md`)
5. Any frontend/webapp audit docs (`specs/*-webapp-audit.md`)
6. `SISTEMA-OPERATIVO.md` or similar — current operational state

### 1.3 Identify the tech stack
Record:
| Layer | Technology |
|-------|-----------|
| Backend runtime | Node/Express, Python/FastAPI, etc. |
| Frontend | React/Vite, Next.js, vanilla, etc. |
| Database | PostgreSQL, SQLite, etc. |
| Auth | Session, JWT, API keys |
| Real-time | WebSocket, polling |
| External integrations | Google Workspace, Stripe, etc. |
| Ports | Backend port, frontend port |

### 1.4 Map existing functionality
List all modules/features:
- Dashboard / main view
- Entities (projects, matters, events, deals, etc.)
- Workflows / pipelines (D-15/D-7, intake→close, etc.)
- Approval gates
- Documents / files
- Tasks / issues
- AI personas / agents
- Search
- Calendar / scheduling
- External links (Drive, Sheets, etc.)
### 1.6 Extract schema from agent definitions (PaperClip pattern)

When the source system is PaperClip, business logic lives in agent definition files under the company definition directory. These files describe the full operational model — read them systematically to derive the database schema.

For each agent definition file, extract:

**Data entities the agent manages** → Database tables
- Sheets or tabs referenced (e.g., event index, inventory stock) → Dedicated tables
- Documents generated (e.g., presentations, requisitions) → Document link tables

**Approval workflows** → Approval table with JSON payload
- Each distinct approval type the agent can create → Enum column + flexible payload

**Pipeline stages** → Stage tracking
- Named phases with entry/exit criteria → Current stage field + history table

**Personnel and assignments** → Staff tables
- Team directory → Staff master table
- Per-event role assignments → Junction table

**Catalogs and kits** → Reference data tables
- Product catalogs with seasonal pricing → Catalog tables
- Assembly kits with component lists → Kit + item tables

**Business rules to encode as columns or constraints:**
- Margin targets per service tier → Integer percent columns
- Seasonal price variations → Multiple price columns
- Minimum stock thresholds → Minimum quantity columns

### 1.7 Determine data migration scope

Note counts of entities, active items, and tenant IDs. Then ask the client:
**Is all existing data real production data, or was it generated for demo/testing?**

If the data is entirely demo (common for pre-launch clients), skip migration scripts entirely. Instead, build seed scripts that populate the new schema with realistic demo data derived from the business rules discovered in the agent definitions. This is faster and avoids dirty data.

## Phase 2: Audit the Onyx Base (Willow Pattern)

### 2.1 Inspect running Onyx containers
```bash
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Ports}}"
```

### 2.2 Inspect existing extension tables
```bash
docker exec onyx-relational_db-1 psql -U postgres -d postgres -c "\dt willow_*"
```

### 2.3 Inspect the bridge API
```bash
docker exec <willow-api-container> ls -la /app
docker exec <willow-api-container> grep -n "@app\." /app/legal_api.py
docker exec <willow-api-container> grep -n "def " /app/legal_api.py
```

### 2.4 Inspect schema details
```bash
docker exec onyx-relational_db-1 psql -U postgres -d postgres -c "\d willow_legal_matter"
docker exec onyx-relational_db-1 psql -U postgres -d postgres -c "\d willow_legal_deadline"
```

### 2.5 Note the integration points
Record how Willow connects to Onyx native tables:
| Concept | Onyx Native | Extension Table |
|---------|-------------|-----------------|
| Matter | `user_project` | `willow_legal_matter` |
| Document | `user_file` | none (native) |
| Chat | `chat_session` | none (native) |
| Agent | `persona` | seed data |

## Phase 3: Domain Mapping (The Critical Step)

Create a table mapping client's concepts → Onyx native → extension tables:

```
| Client Concept | Onyx Native | Extension Table | Notes |
|----------------|-------------|-----------------|-------|
| Projects/Eventos | user_project | paola_event | Add event-specific fields |
| Issues/Tasks | chat_session | paola_task | Or use native chat only |
| Approvals | — | paola_approval | New workflow table |
| Documents | user_file | paola_doc_link | For external Drive links |
| Agents | persona | seed | Create domain personas |
| Pipeline Stages | — | paola_stage | Track D-15, D-7, etc. |
```

### Schema design rules
- **Always prefix** extension tables with client/domain shortname: `paola_`, `willow_legal_`
- **Foreign key** to Onyx native tables where possible (`user_project.id`, `chat_session.id`)
- **Never modify** Onyx native tables directly
- Use `jsonb` for flexible payload fields (approvals, stage metadata)
- Include `created_at`, `updated_at` on every table

### Separate instance vs shared instance

| Aspect | Shared Instance | Separate Instance |
|--------|-----------------|-------------------|
| Docker project name | Same `name:` | Different `name:` per client |
| PostgreSQL | Shared DB, prefixed tables | Separate container + volume |
| Web port | Same :3000 | Different port per client |
| API port | Same :8080 | Different port per client |
| Bridge port | Unique per extension | Unique per client |
| Use case | One company, multiple departments | Multiple companies |

For a separate instance, create a docker-compose overlay file that:
- Sets a unique Docker compose `name:`
- Overrides web server, API server, and DB ports
- Includes the bridge API as an additional service
- References the Onyx source repository for the base images

## Phase 4: Design the Bridge API

### Port assignment rule
Pick a unique port per client extension to avoid conflicts:
| Client | Port |
|--------|------|
| Willow Legal | 3001 |
| Paola Events | 3002 |
| Next client | 3003 |

### Endpoint structure
Mirror the Willow pattern:
```
GET/POST    /api/<domain>/entities          # list, create
GET/PATCH   /api/<domain>/entities/{id}     # detail, update
POST        /api/<domain>/entities/{id}/chat-sessions
GET/POST    /api/<domain>/entities/{id}/files
GET/POST    /api/<domain>/workflows         # approvals, stages
GET         /api/<domain>/dashboard
GET         /api/<domain>/calendar
GET/POST    /api/<domain>/agents
```

### File organization
Base the new API on `legal_api.py`:
```bash
cp /path/to/legal_api.py /path/to/<client>_api.py
# Then adapt endpoints, table names, and business logic
```

## Phase 5: Frontend Decision

### Option A: SPA Vanilla JS (Recommended for speed)
- Serve from FastAPI static files mount
- Copy and adapt `legal_spa/index.html` pattern
- Independent of Next.js/Opal build
- Pros: Builds in minutes, no Docker rebuild needed
- Cons: Less integrated visually with Onyx

### Option B: Native Onyx Routes (`/app/<domain>`)
- Requires Next.js build inside Onyx container
- Reuses Opal design system
- Pros: Fully integrated, native look
- Cons: Build is slow, Opal TS constraints are strict

**Rule:** Start with SPA. Migrate to native routes only after the client validates the product.

## Phase 6: Implementation Plan

Structure phases as:
| Phase | Focus | Deliverable |
|-------|-------|-------------|
| 0 | Schema + container | DB tables, Docker container running |
| 1 | Backend core | CRUD entities, chat, files |
| 2 | Business logic | Workflows, approvals, pipeline |
| 3 | Dashboard + agents | Summary endpoints, persona seed |
| 4 | Frontend SPA | All screens wired to real API |
| 5 | Integration | E2E test, demo, data migration |

## Phase 7: Data Migration (if needed)

If the client has live data to preserve:
1. Export from existing DB: `pg_dump` or API crawl
2. Transform to Onyx schema + extension tables
3. Insert via script, preserving IDs or generating new ones
4. Map old entity IDs to new Onyx `user_project.id`

## Key Learnings from Real Audits

### PaperClip → Onyx mapping nuances
- PaperClip's `companies` table doesn't map cleanly; Onyx uses `user` + `user_project` for tenancy
- PaperClip's `issues` with single-assignee semantics map better to `chat_session` + custom `task` table than to native Onyx task tracking
- PaperClip's `approvals` are richer than Willow's; they need their own table with `payload jsonb`
- Google Workspace links are static metadata, not file content; store as `url TEXT` fields, not `user_file`
- Pipeline stages (D-15, D-7) need both a `current_stage` field and a history table

### Reuse checklist
- [ ] Copy `legal_api.py` structure as base
- [ ] Copy `legal_spa/index.html` pattern for frontend
- [ ] Copy `legal_agents_phase1.json` pattern for agent seeding
- [ ] Use same PostgreSQL connection pattern (`host.docker.internal:5432` or Docker network)
- [ ] Use same CORS middleware config
- [ ] Use same `SessionLocal` pattern for DB access

## Validation

Before declaring the migration plan complete:
- [ ] All client features mapped to Onyx native or extension tables
- [ ] Schema SQL written for all extension tables
- [ ] Bridge API endpoints listed with HTTP methods
- [ ] Frontend approach decided (SPA vs native)
- [ ] Implementation phases estimated with hours
- [ ] Risks and client decisions documented
