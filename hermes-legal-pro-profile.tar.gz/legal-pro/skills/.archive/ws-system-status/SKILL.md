---
name: ws-system-status
version: 1.0.0
author: WS Capital
description: Estado real y verificado del sistema Hermes Neo. Referencia única de verdad para qué funciona y qué no.
---

# WS System Status — Estado Real del Sistema

## ⚠️ INSTRUCCIÓN CRÍTICA

**ANTES de usar cualquier skill de video, imagen, o generación de media:**
1. Leer este documento
2. Verificar que las herramientas mencionadas siguen en el estado indicado
3. Si hay duda, usar `terminal` para probar el endpoint/API antes de confiar en él

---

## ✅ QUÉ SÍ FUNCIONA (Verificado 29abr2026)

### LLMs / Chat
- **Kimi (kimi-k2.6)** @ kimi-coding — Principal, activo, confiable
- **OpenAI Codex (gpt-5.3-codex)** @ openai-codex — Subagentes, fallbacks, visión
- **OpenAI Codex (gpt-5.4-mini)** @ openai-codex — Auxiliares, compresión
- **NVIDIA API** — Chat de texto únicamente (llama-3.2-90b-vision-instruct OK para texto)

### Subagentes / Delegación
- **Copilot ACP** — GitHub Copilot CLI 1.0.39 en `/usr/local/bin/copilot`
- **delegate_task** con `acp_command="copilot"` — ✅ Funcionando
- Máximo 3 concurrentes, depth 2
- ⚠️ **Toolsets limitados**: Subagentes NO heredan automáticamente web/browser. Deben declararse explícitamente en `toolsets=[...]` Y en el mensaje de contexto. Ver skill `subagent-environment-context`.

### Voz / Audio
- **text_to_speech** nativo de Hermes — ✅ Disponible
- **Edge TTS** — Gratis, activo

### Video / Ensamblaje
- **ffmpeg** — Instalado, SIEMPRE disponible
- **SmartCut** — Instalado en `/root/SmartCut`
- **PIL/OpenCV** — Disponibles para efectos programáticos

### Productividad / Gestión
- **Onyx** — Puertos 3000/3001, operativo
- **Paola Meneses** — Dashboard :8080, operativo (verificar si responde)
- **Willow Legal** — Sistema completo, 80% automatizado
- **Excel PM** — `/mnt/c/Users/DELL/Downloads/Telegram Desktop/ws-admin-ops-master-v2.xlsx`

### Research / Contenido
- **Deep Research System** — 4 agentes en paralelo, funcionando
- **ws-content-drafter** — Genera drafts de contenido
- **ws-campaign-planner** — Planifica campañas integradas

---

## ❌ QUÉ NO FUNCIONA (Verificado 29abr2026)

### Generación de Imagen / Video
- **Fal.ai** — ❌ SIN BALANCE. Error: "User is locked. Reason: Exhausted balance"
- **NVIDIA API (images/generations)** — ❌ 404 page not found. NO genera imágenes aquí
- **NVIDIA API (vision con imágenes)** — ❌ Internal Server Error. NO analiza imágenes aquí
- **OpenCode Go** — ❌ Cloudflare 403 en WSL. NO confiable como opción principal
- **image_generate nativo** — ❌ Depende de Fal.ai, bloqueado por sin balance

### Video Machine Automático
- **Generación automática de video** — ❌ BLOQUEADA. No hay proveedor de imagen activo
- **Cron jobs nocturnos** — ❌ Fallaron sin notificación en hackathon

---

## ⚠️ LÍMITES IMPORTANTES

### NVIDIA API
- ✅ Chat de texto: FUNCIONA
- ❌ Generación de imagen: NO FUNCIONA (404)
- ❌ Análisis de imagen: NO FUNCIONA (500)
- **NO usar NVIDIA como fallback para imagen/video**

### Subagentes / Delegación (ACP)
- ✅ Subagentes spawnean y responden
- ⚠️ **Toolsets NO se propagan automáticamente**: Si el agente principal tiene `web` y `browser`, el subagente NO los hereda por defecto
- ⚠️ **Solución**: Pasar `toolsets=['terminal','file','web','browser']` explícitamente + contexto en mensaje
- ⚠️ **Verificar siempre**: Antes de delegar tareas de research/web, hacer un delegate_task de prueba preguntando "¿qué herramientas tienes?"
- 📖 Ver skill: `subagent-environment-context`
- ✅ Chat de texto: Funciona ocasionalmente (desde WSL es 403)
- ❌ Generación de imagen: BLOQUEADO (Cloudflare 403)
- ❌ Video: No soportado
- **Solo backup teórico, NO opción principal**

### Fal.ai
- ❌ Sin balance — necesita recarga en fal.ai/dashboard/billing
- **Verificar balance ANTES de intentar usar**

---

## 🔄 FLUJO RECOMENDADO PARA PRODUCCIÓN DE VIDEO

Cuando necesites producir video AHORA:

1. **Guion:** Usar Kimi o Codex (✅ funciona)
2. **Assets visuales:**
   - Opción A: Fotos reales del usuario + FFmpeg effects (✅ siempre funciona)
   - Opción B: Esperar a que Fal.ai tenga balance o configurar DALL-E/Replicate
3. **Voiceover:** text_to_speech nativo o Edge TTS (✅ funciona)
4. **Ensamblaje:** ffmpeg + PIL/OpenCV (✅ funciona)
5. **Edición:** SmartCut manual si es necesario

**NO intentar:**
- Generar imágenes con NVIDIA API (no funciona)
- Usar OpenCode Go como principal (bloqueado)
- Depender de Fal.ai sin verificar balance

---

## 📋 CHECKLIST DE VERIFICACIÓN PRE-VUELO

Antes de cualquier tarea de generación de media:

- [ ] ¿Necesito generar imagen? → Verificar Fal.ai balance primero
- [ ] ¿Necesito video automático? → Confirmar que hay proveedor de imagen activo
- [ ] ¿Necesito análisis visual? → Usar vision_analyze nativo de Hermes (si funciona)
- [ ] ¿Todo lo demás falla? → Usar fotos reales + ffmpeg (siempre funciona)

---

## 📝 HISTORIAL DE CAMBIOS

- **29abr2026:** Limpieza masiva. Removidas referencias a NVIDIA imagen, OpenCode Go como principal. Documentado estado real post-verificación.
- **28abr2026:** Auditoría inicial. Descubierto que NVIDIA no genera imágenes, Fal.ai sin balance.

---

*Este documento es la única fuente de verdad. Si algo cambia, actualizar inmediatamente.*
*Última verificación: 29 Abril 2026*
