# VIDEO MACHINE — ORQUESTACIÓN DE PRODUCCIÓN VIDEO
## WS Capital | 28 Abril 2026
## Skill de orquestación para producción de video

---

## 🎯 PROPÓSITO

Orquestar la producción completa de video para marketing: desde script hasta publicación. No es solo generar video — es producción profesional con múltiples etapas, assets, y distribución.

---

## 🤖 AGENTES DEL SISTEMA

**Motor de subagentes:** OpenAI Codex (gpt-5.3-codex) vía Copilot ACP
**Máximo concurrente:** 3 agentes
**Comando ACP:** `copilot`
**Flujo:** Secuencial (4 etapas)

### Agente 1: Guionista (Script Writer)
**Función:** Escribir script basado en brief
**Tools:** file, skills
**Skills:** ws-content-drafter, ws-founder-voice-capture
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Recibir brief de contenido
- Escribir script con estructura:
  - Hook (primeros 3 segundos)
  - Problema/Contexto
  - Solución/Valor
  - Llamada a la acción
- Adaptar tono a voz de Pablo/WS Capital
- Generar 3 variantes si es necesario

### Agente 2: Director Visual (Visual Director)
**Función:** Diseñar visuals, seleccionar estilo, generar assets
**Tools:** image_gen, vision, web
**Skills:** ws-video-machine
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Leer script
- Diseñar storyboard (escena por escena)
- Seleccionar estilo visual:
  - Realista / Animado / Motion Graphics
  - Paleta de colores WS Capital
  - Tipografía consistente
- **Generar imágenes:**
  - **Opción 1 (nativa):** `image_generate` tool de Hermes (GPT Image 2.0 cuando disponible)
  - **Opción 2 (NVIDIA):** API de NVIDIA para generación de imagen (gratuita, fallback)
  - **Opción 3 (OpenCode Go):** `nvidia/black-forest-labs/flux.1-dev` si funciona desde WSL
  - **Opción 4 (Fal.ai):** Solo si tiene balance confirmado — verificar primero
- **NO usar OpenCode Go como opción principal** para imagen/video — está bloqueado por Cloudflare 403 en WSL
- Seleccionar música/sonido (si aplica)

### Agente 3: Productor Técnico (Technical Producer)
**Función:** Generar video, editar, renderizar
**Tools:** terminal, file
**Skills:** ws-video-studio-system
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Recibir script + storyboard
- **Seleccionar herramienta de generación (en orden de prioridad):**
  1. **Hermes nativo:** `image_generate` + `text_to_speech` + ffmpeg para ensamblar
  2. **NVIDIA API:** Para generación de imagen/video si disponible (gratuita)
  3. **Fal.ai:** Solo si tiene balance confirmado — verificar primero
  4. **OpenCode Go:** NO usar como opción principal — Cloudflare 403 en WSL
- **Para ensamblaje de video:**
  - ffmpeg (local) — SIEMPRE disponible
  - Python + PIL/OpenCV para efectos
  - Ken Burns, zoom/pan, transiciones
- **Para voiceover:**
  - `text_to_speech` nativo de Hermes
  - Edge TTS (gratis, activo)
- Editar (cortes, transiciones, texto)
- Renderizar en formato correcto:
  - Vertical (9:16) para Reels/TikTok/Shorts
  - Horizontal (16:9) para YouTube/LinkedIn
  - Cuadrado (1:1) para Instagram/Facebook

### Agente 4: Distribuidor (Distributor)
**Función:** Publicar, programar, medir
**Tools:** web, browser, messaging
**Skills:** ws-video-social, xitter, youtube-content
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Recibir video renderizado
- Preparar para cada plataforma:
  - Título optimizado
  - Descripción con hashtags
  - Thumbnail
  - Tags/Keywords
- Publicar o programar
- Configurar tracking de métricas
- Reportar resultados
---

## 📋 FLUJO DE TRABAJO

```
Entrada: "Crea un video sobre [tema] para [plataforma]"
    ↓
Orquestador recibe brief
    ↓
Etapa 1: Guionista
    ├─ Escribe script con hook, problema, solución, CTA
    ├─ Adapta a voz de Pablo/WS Capital
    └─ Entrega: Script + notas de dirección
    ↓
Etapa 2: Director Visual (paralelo si es posible)
    ├─ Diseña storyboard
    ├─ Selecciona estilo visual
    ├─ Genera assets de imagen
    └─ Entrega: Storyboard + assets
    ↓
Etapa 3: Productor Técnico
    ├─ Genera video con herramienta seleccionada
    ├─ Edita (cortes, texto, transiciones)
    ├─ Añade música/VO
    ├─ Renderiza en formato correcto
    └─ Entrega: Video final + variantes
    ↓
Etapa 4: Distribuidor
    ├─ Prepara para cada plataforma
    ├─ Publica o programa
    ├─ Configura tracking
    └─ Entrega: Links + métricas iniciales
    ↓
Salida: Video publicado + reporte de distribución
```

---

## 📝 FORMATOS DE VIDEO

### Reels / TikTok / Shorts (Vertical)
- **Resolución:** 1080x1920 (9:16)
- **Duración:** 15-60 segundos
- **Hook:** Primeros 3 segundos CRÍTICOS
- **Texto:** Grande, legible, mínimo
- **Música:** Trending o brand-appropriate

### YouTube / LinkedIn (Horizontal)
- **Resolución:** 1920x1080 (16:9)
- **Duración:** 2-10 minutos
- **Estructura:** Hook → Contexto → Contenido → CTA
- **Thumbnail:** Personalizado, alto contraste
- **SEO:** Título optimizado, descripción, tags

### Instagram / Facebook (Cuadrado)
- **Resolución:** 1080x1080 (1:1)
- **Duración:** 30-90 segundos
- **Estilo:** Visual-first, mínimo texto
- **Hashtags:** 5-10 relevantes

---

## 🎨 PALETA VISUAL WS CAPITAL

### Colores:
- **Primario:** #1a1a2e (Azul oscuro)
- **Secundario:** #16213e (Azul medio)
- **Acento:** #e94560 (Rojo coral)
- **Texto:** #f5f5f5 (Blanco hueso)
- **Fondo:** #0f3460 (Azul profundo)

### Tipografía:
- **Títulos:** Montserrat Bold
- **Cuerpo:** Inter Regular
- **CTA:** Montserrat Black

### Estilo:
- Moderno, tech-forward
- Limpio, minimalista
- Profesional pero accesible
- Motion graphics sutiles

---

## ⚙️ CONFIGURACIÓN TÉCNICA

### Herramientas de Generación (ACTUALIZADO 29abr2026):

1. **Imágenes (para storyboard/assets):**
   - **Opción 1 (nativa):** `image_generate` tool de Hermes (GPT Image 2.0 cuando disponible)
   - **Opción 2 (Fal.ai):** Solo si tiene balance confirmado — verificar primero
   - **Opción 3 (OpenCode Go):** Backup teórico — Cloudflare 403 en WSL, NO confiable
   - **Opción 4 (NVIDIA):** Chat de texto únicamente — NO genera imágenes en este entorno
   - Prompt: "[descripción], professional, high quality, [estilo WS Capital]"

2. **Video (generación):**
   - **ffmpeg (local)** — SIEMPRE disponible, ensamblaje de frames + audio
   - **Hermes nativo:** `image_generate` para frames + `text_to_speech` para VO
   - **Fal.ai:** Solo si tiene balance confirmado
   - **NO usar OpenCode Go** como opción principal — bloqueado por Cloudflare 403 en WSL
   - **NO usar NVIDIA API** para generación de imagen/video — no disponible en este entorno

3. **Edición (post-producción):**
   - ffmpeg (local) — SIEMPRE disponible
   - Python + PIL/OpenCV para efectos (Ken Burns, zoom/pan, transiciones)
   - CapCut (manual si es necesario)
   - DaVinci Resolve (manual si es necesario)

### Para usar este sistema:

1. **Cargar skill:** `skill_view("video-machine")`
2. **Delegar:** `delegate_task` con los 4 agentes en secuencia
3. **Tiempo estimado:** 15-30 minutos por video
4. **Costo:** Depende de herramienta de generación

---

## 🎯 EJEMPLOS DE USO

### Ejemplo 1: "Crea un Reel sobre Willow Legal"
- Guionista: Script de 30 segundos (hook: "¿Qué harías con 5 tuyos?")
- Director: Storyboard con abogado tech, motion graphics
- Productor: Genera video vertical 9:16
- Distribuidor: Publica en Instagram Reels + LinkedIn

### Ejemplo 2: "Crea un video educativo sobre WS Capital"
- Guionista: Script de 3 minutos (modelo de negocio, productos)
- Director: Storyboard con diagramas, animaciones
- Productor: Genera video horizontal 16:9
- Distribuidor: Publica en YouTube + LinkedIn

### Ejemplo 3: "Crea un TikTok sobre Paola Meneses"
- Guionista: Script de 15 segundos (hook: "Esta boda costó $X...")
- Director: Storyboard con fotos de eventos, texto animado
- Productor: Genera video vertical 9:16
- Distribuidor: Publica en TikTok + Instagram Reels

---

## 🔧 INTEGRACIÓN CON WS CAPITAL

### Conexiones:
- **Growth Marketing:** Alimenta calendario de contenido
- **Content Drafter:** Genera scripts basados en briefs
- **Campaign Planner:** Integra videos en campañas
- **Performance Reviewer:** Mide resultados de videos

### Automatización:
- **Cron:** Generar video semanal (martes 10AM)
- **Trigger:** Cuando Pablo mencione "video", "reel", "tiktok"
- **Output:** Video + reporte de métricas

---

## 📁 ARCHIVOS

- **Skill:** `~/.hermes/skills/media/video-machine/SKILL.md`
- **Templates:** `~/.hermes/skills/media/video-machine/templates/`
  - `script-template.md`
  - `storyboard-template.md`
  - `distribution-checklist.md`
- **Scripts:** `~/.hermes/skills/media/video-machine/scripts/`
  - `generate_video.py`
  - `edit_video.py`
  - `publish_video.py`

---

## 📝 CHECKLIST DE PRODUCCIÓN

### Pre-producción:
- [ ] Brief recibido y validado
- [ ] Script aprobado
- [ ] Storyboard aprobado
- [ ] Assets generados

### Producción:
- [ ] Video generado
- [ ] Edición completa
- [ ] Música/VO añadido
- [ ] Renderizado en formato correcto

### Post-producción:
- [ ] Thumbnail creado
- [ ] Título optimizado
- [ ] Descripción escrita
- [ ] Hashtags seleccionados
- [ ] Publicado/programado
- [ ] Tracking configurado

---

*Video Machine — Sistema completo de producción video para WS Capital*
*Desde script hasta publicación, end-to-end.*
