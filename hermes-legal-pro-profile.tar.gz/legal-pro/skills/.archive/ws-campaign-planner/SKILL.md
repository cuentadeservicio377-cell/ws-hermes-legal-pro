---
name: ws-campaign-planner
description: Diseña campañas integradas de growth para WS Capital. Conecta objetivo, audiencia, mensaje, canales, métricas y timeline en un brief ejecutable.
compatibility: [hermes-agent]
author: WS Capital
version: 1.0.0
---

# WS Campaign Planner

## Misión
Convertir objetivos de negocio en campañas de marketing concretas, con channel mix, calendar, y KPIs claros.

## Inputs
- Objetivo de campaña (ej: "10 leads legales este mes")
- Vertical (legal, eventos, agencia)
- Presupuesto (tiempo, dinero, tokens)
- `marketing-context.md` (obligatorio)
- Research previo (opcional)

## Outputs
- Campaign brief con:
  1. Objetivo SMART
  2. Audiencia objetivo (segmento del ICP)
  3. Mensaje core (1 oración)
  4. Channel mix con justificación
  5. Content calendar (2 semanas mínimo)
  6. KPIs y milestones
  7. Experimentos embebidos
  8. Risks y mitigaciones

## Qué NO hace
- NO produce los assets finales → delega a `ws-content-drafter`
- NO ejecuta la campaña → eso es orchestrator + channel connectors
- NO asume presupuesto sin confirmar

## Workflow

### Paso 1: Cargar contexto
Leer `marketing-context.md`.
Confirmar vertical y objetivo.

### Paso 2: Definir objetivo SMART
Convertir "necesitamos leads" en:
- Específico: ¿de qué vertical?
- Medible: ¿cuántos? ¿qué cuenta como lead?
- Alcanzable: ¿con qué recursos?
- Relevante: ¿alineado con objetivo mayor?
- Time-bound: ¿para cuándo?

### Paso 3: Seleccionar audiencia
Del ICP, elegir el segmento más probable para este objetivo.
Si no hay ICP, delegar a `ws-market-researcher` primero.

### Paso 4: Diseñar mensaje core
Una oración que conecte:
- Problema operativo específico
- Consecuencia de no resolverlo
- Entry point de WS Capital (sin prometer todo)

### Paso 5: Channel mix
Justificar cada canal:
- ¿Dónde vive esta audiencia?
- ¿Qué formato funciona allí?
- ¿Tenemos presencia o empezamos desde cero?

Canales posibles:
- LinkedIn (organic, personal brand de Pablo)
- Reddit (community engagement, no spam)
- Email (outbound o newsletter)
- Blog/SEO (long-term)
- Telegram (hub interno, no canal de adquisición primario)
- Paid (Meta, Google) — solo si hay presupuesto confirmado

### Paso 6: Content calendar
2 semanas mínimo. Cada entry:
- Día
- Canal
- Formato
- Tema / angle
- KPI esperado

### Paso 7: Experimentos embebidos
Identificar 1-2 experimentos dentro de la campaña:
- Hypothesis
- Variable
- Métrica
- Duración

### Paso 8: Output
Guardar brief en:
- `~/.hermes/hermes-ops/docs/campaigns/[YYYY-MM-DD]_[nombre-campana].md`
- Entregar a `ws-growth-orchestrator` para producción.

## Quality Rules
1. Nunca más de 3 canales activos en una campaña inicial. Focus > spread.
2. Cada pieza de contenido en el calendar debe nombrar un problema operativo.
3. Si no hay research previo, incluir una tarea de research en la campaña.
4. Presupuesto de tokens: estimar cuántos jobs de content requiere y avisar si excede lo razonable.

## Hackathon Campaign Mode

When the campaign is for a hackathon or competition (e.g., Nous Research Hermes Agent Creative Hackathon):

### Additional Research Required
1. **Competition rules and criteria** — What do judges evaluate?
2. **Previous winners** — What projects won and why?
3. **Meta-narrative** — The campaign itself must DEMONSTRATE the tool (Hermes) in action

### Creative Concept Framework
- **Thesis:** Technology should liberate human creativity, not replace it
- **Narrative arc:** Oppression → Breakthrough → Liberation → Manifesto (inspired by Apple 1984)
- **Visual metaphor:** Monochrome/digital noise → Color/human moments → Hermes operating → Freedom
- **Philosophical anchors:** Greek mythology (Hermes, Nous, Prometeo, Daimon, Eros, Poiesis)
- **CTA:** "Open Source must win so humanity can win"

### Production with Subagents
Use parallel subagent workflow:
1. **Script Agent** — Refine narrative, create variants (60s/30s/15s)
2. **Visual Director** — Select photos, create frame-by-frame storyboard
3. **Technical Producer** — Write Python/PIL effects + ffmpeg assembly scripts
4. **Audio Composer** — Generate synthwave music + SFX
5. **Distributor** — Thumbnails, copy, hashtags, submission package

### Fallback Strategy
When AI image generation is blocked (Fal.ai no balance, NVIDIA 404, OpenCode 403):
- Use real founder photos + PIL/Python effects (glitch, CRT, color grading)
- Use ffmpeg for Ken Burns, transitions, assembly
- Use TTS native for voiceover
- Frame this as a FEATURE: "Authenticity > AI perfection"

### Submission Package
- Main video (60s)
- Short variants (30s, 15s)
- Thumbnails
- Social copy for LinkedIn/Twitter/Instagram
- Project description emphasizing Hermes usage
- Documentation of the creative process

## Next Handoff
- Producción de assets → `ws-content-drafter`
- Publicación → `ws-channel-connector` (vía orchestrator)
- Métricas → `ws-performance-reviewer` post-campaña
- Hackathon submission → `ws-video-marketing` or `video-machine`
