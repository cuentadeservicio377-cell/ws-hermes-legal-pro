#!/usr/bin/env python3
"""
Verificación de topología de providers en Hermes Neo / WS Capital.
Ejecutar después de cualquier migración de provider secundario.
"""
import yaml, json, sys

def verify():
    with open('/root/.hermes/config.yaml', 'r') as f:
        config = yaml.safe_load(f)

    providers = config.get('providers', {})
    delegation = config.get('delegation', {})
    fallbacks = config.get('fallback_providers', [])
    aux = config.get('auxiliary', {})
    display = config.get('display', {})

    all_pass = True

    # 1. Providers principales
    for req in ['kimi-coding', 'opencode-go', 'openai-codex']:
        if req not in providers:
            print(f"FAIL: Provider '{req}' no está en config.yaml")
            all_pass = False

    # 2. Modelo principal
    if providers.get('kimi-coding', {}).get('default_model') != 'kimi-k2.6':
        print("FAIL: Modelo principal no es kimi-k2.6")
        all_pass = False

    # 3. Delegación
    if delegation.get('provider') != 'opencode-go':
        print(f"FAIL: Delegation provider es '{delegation.get('provider')}' (debe ser opencode-go)")
        all_pass = False
    if delegation.get('model') != 'kimi-k2.6':
        print(f"FAIL: Delegation model es '{delegation.get('model')}' (debe ser kimi-k2.6)")
        all_pass = False

    # 4. Fallbacks
    if len(fallbacks) < 1 or fallbacks[0].get('provider') != 'opencode-go':
        print("FAIL: Fallback 1 no es opencode-go")
        all_pass = False

    # 5. Auxiliares
    for task, cfg in aux.items():
        if cfg.get('provider') != 'opencode-go' or cfg.get('model') != 'kimi-k2.6':
            print(f"FAIL: Auxiliary '{task}' es {cfg.get('provider')}/{cfg.get('model')}")
            all_pass = False

    # 6. Display flags
    if display.get('show_reasoning') != True:
        print("FAIL: show_reasoning no es True")
        all_pass = False
    if display.get('streaming') != True:
        print("FAIL: streaming no es True")
        all_pass = False

    if all_pass:
        print("PASS: Topología de providers correcta — OpenCode Go es motor secundario universal")
        return 0
    else:
        print("FAIL: Hay problemas en la topología de providers")
        return 1

if __name__ == '__main__':
    sys.exit(verify())
