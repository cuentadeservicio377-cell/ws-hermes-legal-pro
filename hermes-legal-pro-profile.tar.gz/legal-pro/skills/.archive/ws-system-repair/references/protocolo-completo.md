# PROTOCOLO DE REPARACIÓN COMPLETO — HERMES NEO / WS CAPITAL
## Fecha: 28 Abril 2026 | Protocolo Vivo
## Guardado en skill ws-system-repair para continuidad

---

## 🧠 FLUJO DE REACCIÓN DEL AGENTE (Protocolo Obligatorio)

Cuando Pablo envíe un mensaje, el agente DEBE reaccionar así:

### PASO 0: RECONOCER EL PERFIL
```
¿Quién habla?
→ Pablo = default profile
→ Si menciona "WS Capital" = ws profile
→ Si es Natalia/Paola = paola profile
```

### PASO 1: REVISAR CONTEXTO (automático, invisible)
```
1. Leer USER.md
2. Leer MEMORY.md
3. Identificar perfil activo
4. Buscar sesiones previas con session_search
```

### PASO 2: ESCANEAR SKILLS (automático, invisible)
```
1. Ejecutar skills_list()
2. Identificar skills relevantes al mensaje
3. Cargar skill_view() si aplica
```

### PASO 3: PLANEAR (visible, numerado)
```
"Pablo, entendido. Voy a:
1. [Primer paso]
2. [Segundo paso]
3. [Tercer paso]
¿Está bien o quieres ajustar algo?"
```

### PASO 4: EJECUTAR (con calidad, no velocidad)
```
- No apresurarse
- Verificar cada resultado
- Si falla, reportar y ajustar
- No inventar resultados
```

### PASO 5: VERIFICAR (antes de entregar)
```
¿Lo que entrego responde exactamente lo que pidió?
¿Está completo?
¿Hay errores?
```

### PASO 6: ENTREGAR (con métricas)
```
"✅ Completado. Resultado:
- [Resumen]
- [Métricas si aplica]
- [Próximos pasos sugeridos]"
```

### PASO 7: GUARDAR (en memoria)
```
memory(action="add", target="memory", content="[Lo que se hizo]")
```

---

## 🔴 FASE 1: COMPORTAMIENTO (Ahora)

### 1.1 Test: ¿El agente REVISA CONTEXTO?
**Test:** Enviar mensaje y verificar que:
- Menciona USER.md o MEMORY.md
- Identifica perfil correcto
- Busca sesiones previas

**Si falla:** Corregir prefill, verificar hooks, revisar config

### 1.2 Test: ¿El agente ESCANEA SKILLS?
**Test:** Pedir tarea que requiera skill específica
**Verificar:** Que mencione skills_list() o skill_view()

**Si falla:** Corregir guard_agent_created, revisar toolsets

### 1.3 Test: ¿El agente PLANEA?
**Test:** Pedir tarea compleja
**Verificar:** Que presente plan numerado antes de ejecutar

**Si falla:** Corregir show_reasoning, revisar prefill

### 1.4 Test: ¿El agente NO SE APURA?
**Test:** Pedir tarea que tome tiempo
**Verificar:** Que espere, no dé respuesta incompleta

**Si falla:** Corregir streaming, revisar timeouts

### 1.5 Test: ¿El agente USA HERRAMIENTAS?
**Test:** Pedir generar video, investigar, etc.
**Verificar:** Que use tools correctas, no improvise

**Si falla:** Revisar toolsets, skills, orquestación

### 1.6 Test: ¿El agente HACE FLUJOS?
**Test:** Simular mensaje de cada departamento
**Verificar:** Que siga flujo definido

**Si falla:** Revisar orquestación, matriz de acceso

---

## 🟡 FASE 2: FEATURES (Después de comportamiento perfecto)

### 2.1 Code Execution
**Test:** Pedir script Python que use tools
**Verificar:** Que ejecute sin errores

### 2.2 Hooks
**Test:** Iniciar sesión nueva
**Verificar:** Que cargue SOUL.md y prefill automáticamente

### 2.3 Batch Processing
**Test:** Pedir procesar múltiples tareas
**Verificar:** Que use batch_runner.py

### 2.4 Google Workspace
**Test:** Pedir leer/escribir Sheets
**Verificar:** Conexión funciona

### 2.5 RL Training
**Test:** Evaluar si aplica
**Verificar:** Decisión documentada

### 2.6 Claude Code
**Test:** Delegar tarea de coding
**Verificar:** Que funcione como agente autónomo

### 2.7 Vision API
**Test:** Analizar imagen local
**Verificar:** Que funcione sin URL pública

---

## 🟡 FASE 3: ESTRUCTURA (Después de features)

### 3.1 Orquestación
**Test:** Cada departamento sigue su flujo
**Verificar:** 7 departamentos, 7 flujos

### 3.2 Deep Research
**Test:** Pedir investigación profunda
**Verificar:** 4 agentes en paralelo

### 3.3 Video Machine
**Test:** Pedir producir video
**Verificar:** 4 agentes en secuencia

### 3.4 Matriz de Acceso
**Test:** Verificar que cada dept use solo sus tools
**Verificar:** 7x14 matriz respetada

---

## 🟡 FASE 4: COHERENCIA (Después de estructura)

### 4.1 Memorias sincronizadas
**Test:** Verificar SOUL.md = USER.md = MEMORY.md
**Verificar:** Mismos perfiles, mismos productos, mismas reglas

### 4.2 Prefill funciona
**Test:** Iniciar sesión, verificar sin warnings
**Verificar:** JSON válido, 8 reglas cargan

### 4.3 Skills snapshot
**Test:** skills_list() muestra 84+ skills
**Verificar:** Nuevos skills incluidos

### 4.4 Protocolo de inicio
**Test:** Iniciar sesión
**Verificar:** 7 pasos del protocolo se ejecutan

---

## 🟡 FASE 5: OPENCODE GO (Después de coherencia)

### 5.1 Endpoint
**Test:** curl a https://opencode.ai/zen/go/v1
**Verificar:** Responde 200

### 5.2 API Key
**Test:** Enviar request con key
**Verificar:** Autenticación funciona

### 5.3 Modelos
**Test:** Listar modelos disponibles
**Verificar:** 100+ modelos listados

---

## 🟡 FASE 6: OBSIDIAN VAULT (Después de OpenCode)

### 6.1 WS-Campaigns
**Test:** Acceder a skill de campañas
**Verificar:** 15 docs research disponibles

### 6.2 Paola Meneses
**Test:** Acceder a skill de eventos
**Verificar:** 15 eventos, Excels, flujos

### 6.3 Skills integrados
**Test:** skills_list() muestra skills de campañas
**Verificar:** En ~/.hermes/skills/

---

## 🟢 FASE 7: TÉCNICO (AL FINAL)

### 7.1 Gateway estable
**Verificar:** 30 min sin caídas

### 7.2 Kimi API
**Verificar:** HTTP 200, no 404

### 7.3 /tmp limpio
**Verificar:** < 500MB

### 7.4 Docker limpio
**Verificar:** < 80%

### 7.5 Nous OAuth
**Acción:** Renovar (4-5PM)

### 7.6 Codex
**Acción:** Reautorizar (4-5PM)

### 7.7 Paquetes
**Acción:** Actualizar 57 críticos

### 7.8 Dependencias
**Acción:** Instalar faltantes

### 7.9 Prune
**Acción:** Configurar auto_prune

### 7.10 Backups
**Acción:** Limpiar viejos

---

## 🚫 REGLAS DE EJECUCIÓN

1. **NO saltar fases** — Si comportamiento no funciona, no pasar a features
2. **NO apresurarse** — Calidad sobre velocidad, siempre
3. **NO inventar resultados** — Si algo falla, reportar y ajustar
4. **NO omitir verificación** — Cada test debe pasar antes de continuar
5. **NO dejar para después** — Todo en esta sesión

---

## ✅ CHECKPOINTS DE APROBACIÓN

Antes de pasar a la siguiente fase, Pablo debe aprobar:

- [ ] Fase 1: Comportamiento perfecto
- [ ] Fase 2: Features funcionando
- [ ] Fase 3: Estructura operativa
- [ ] Fase 4: Coherencia verificada
- [ ] Fase 5: OpenCode Go listo
- [ ] Fase 6: Obsidian Vault integrado
- [ ] Fase 7: Técnico estable

---

*Protocolo guardado en skill ws-system-repair*
*Para continuidad entre sesiones*
*Perfección obligatoria*
*Todo en esta sesión*
