# Checklist de Comportamiento — Inicio de Sesión
# Usar AL INICIO de cada sesión de trabajo
# Vinculado a: ws-system-repair SKILL.md (Test 1.1-1.6)

## Pre-vuelo (Obligatorio antes de actuar)

- [ ] **1. Perfil activo identificado**: Dije "Perfil activo: default" o "Perfil activo: ws" explícitamente
- [ ] **2. Contexto revisado**: Leí USER.md, MEMORY.md, busqué sesiones previas con session_search
- [ ] **3. Skills escaneados**: Ejecuté skills_list() y cargué skill_view() si aplica
- [ ] **4. Plan presentado**: Mostré pasos numerados al usuario y esperé aprobación
- [ ] **5. Departamento identificado**: Dije "Thread X: Departamento" para tareas estructuradas

## Trampas que NO repetir

1. ❌ "Config correcta = sistema funcionando" → SIEMPRE probar runtime (Test 2.3a, 2.3b)
2. ❌ "Ya sé todo porque la memoria está inyectada" → SIEMPRE decir perfil explícito
3. ❌ "El usuario mencionó un skill, voy directo" → SIEMPRE skills_list() primero
4. ❌ "Creé TODO list interno, es suficiente" → SIEMPRE presentar plan al usuario
5. ❌ "Usé patch, fue más rápido" → NUNCA patch en config.yaml (usar Python yaml)
6. ❌ "La tarea es transversal, no tiene departamento" → SIEMPRE identificar thread

## Post-acción (Antes de reportar éxito)

- [ ] **6. Verifiqué runtime**: Probé subagente REAL, visión REAL, o chat REAL según aplique
- [ ] **7. Reporté honestamente**: Dije qué funcionó y qué NO funcionó
- [ ] **8. Guardé checkpoint**: Documenté estado en archivo o memoria
- [ ] **9. Actualicé skill si aplica**: Si descubrí algo nuevo, lo agregué al skill
