# Runtime Verification Scripts — Hermes Multi-Provider Repair
## Extracted from ws-system-repair session 28abr2026

Use these scripts when config.yaml "looks correct" but subagents, vision, or providers fail at runtime.

---

## 1. Verify OpenAI Codex Token (List Models + Chat)

```python
import urllib.request, json

with open('/root/.hermes/auth.json', 'r') as f:
    auth = json.load(f)

cred = auth['credential_pool']['openai-codex']
if isinstance(cred, list):
    cred = cred[0]
access_token = cred['access_token']

# Test 1: List models (GET)
try:
    req = urllib.request.Request(
        'https://chatgpt.com/backend-api/codex/models?client_version=1.2026.0428',
        headers={'Authorization': f'Bearer {access_token}'}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        print(f"✅ List models: {len(data.get('models',[]))} models")
except urllib.error.HTTPError as e:
    print(f"❌ List models failed: {e.code}")

# Test 2: Chat completion (POST) — CRITICAL: this is what subagents need
try:
    req = urllib.request.Request(
        'https://chatgpt.com/backend-api/conversation',
        method='POST',
        data=json.dumps({
            'action': 'next',
            'messages': [{'id': 'test', 'author': {'role': 'user'}, 
                         'content': {'content_type': 'text', 'parts': ['hi']}}],
            'model': 'gpt-5.4-mini',
            'conversation_mode': {'kind': 'primary_assistant'},
            'client_version': '1.2026.0428'
        }).encode(),
        headers={'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        print("✅ Chat works — subagents will work")
except urllib.error.HTTPError as e:
    if e.code == 403:
        print("❌ TOKEN VALID FOR LISTING BUT NOT FOR CHAT")
        print("   Subagents WILL fail. Cause: missing chat scope, arkose_token, or proof_token")
    elif e.code == 401:
        print("❌ Token revoked")
```

---

## 2. Verify OpenCode Go API Key (Models + Chat)

```python
import urllib.request, json

# Read API key from .env (auth.json may have empty api_key)
api_key = None
with open('/root/.hermes/.env', 'r') as f:
    for line in f:
        if 'OPENCODE_GO_API_KEY' in line:
            api_key = line.split('=', 1)[1].strip().strip('"\'')
            break

if not api_key:
    print("❌ No OPENCODE_GO_API_KEY in .env")
    exit()

# Test 1: List models
try:
    req = urllib.request.Request(
        'https://opencode.ai/zen/go/v1/models',
        headers={'Authorization': f'Bearer {api_key}'}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        models = data if isinstance(data, list) else data.get('data', [])
        print(f"✅ Models: {len(models)}")
except urllib.error.HTTPError as e:
    if e.code == 403:
        print(f"❌ 403 Forbidden — API key invalid or Cloudflare blocked")
    else:
        print(f"❌ {e.code}: {e.reason}")

# Test 2: Chat completion
try:
    req = urllib.request.Request(
        'https://opencode.ai/zen/go/v1/chat/completions',
        method='POST',
        data=json.dumps({
            'model': 'kimi-k2.6',
            'messages': [{'role': 'user', 'content': 'Say "test ok"'}],
            'max_tokens': 10
        }).encode(),
        headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
        content = data['choices'][0]['message']['content']
        print(f"✅ Chat works: '{content}'")
except urllib.error.HTTPError as e:
    print(f"❌ Chat failed: {e.code} — provider not usable for subagents")
```

---

## 3. Check auth.json vs .env Desynchronization

```python
import json

with open('/root/.hermes/auth.json', 'r') as f:
    auth = json.load(f)

with open('/root/.hermes/.env', 'r') as f:
    env_lines = f.readlines()

env_vars = {}
for line in env_lines:
    line = line.strip()
    if line and not line.startswith('#') and '=' in line:
        k, v = line.split('=', 1)
        env_vars[k] = v.strip().strip('"\'')

for name, cred in auth.get('credential_pool', {}).items():
    if isinstance(cred, list):
        cred = cred[0] if cred else {}
    api_key = cred.get('api_key', '')
    
    # Check if api_key is empty but .env has a value
    if len(api_key) == 0:
        env_key = name.upper().replace('-', '_') + '_API_KEY'
        if env_key in env_vars and len(env_vars[env_key]) > 10:
            print(f"⚠️  {name}: auth.json has EMPTY api_key but .env has {env_key}")
            print(f"   Fix: Update auth.json credential_pool or use .env key in config.yaml")
```

---

## 4. Count Errors in Logs by Type

```bash
# Count specific error types in errors.log
grep -c "APITimeoutError" ~/.hermes/logs/errors.log
grep -c "subagent" ~/.hermes/logs/errors.log
grep -c "vision" ~/.hermes/logs/errors.log
grep -c "token_revoked\|401" ~/.hermes/logs/errors.log
grep -c "Copilot ACP" ~/.hermes/logs/errors.log
grep -c "Could not start Copilot ACP command" ~/.hermes/logs/errors.log

# Gateway restarts
grep -c "Starting Hermes Gateway" ~/.hermes/logs/keepalive.log

# Recent subagent failures
grep "subagent.*API call failed" ~/.hermes/logs/errors.log | tail -n 10
```

---

## 5. Install GitHub Copilot CLI for ACP (when subagents fail)

```bash
# Install Copilot CLI
npm install -g @github/copilot

# Verify installation
copilot --version

# Symlink to system PATH
ln -sf $(which copilot) /usr/local/bin/copilot

# Configure Hermes
export HERMES_COPILOT_ACP_COMMAND=/usr/local/bin/copilot
# Add to ~/.hermes/.env: HERMES_COPILOT_ACP_COMMAND=/usr/local/bin/copilot

# Test subagent
delegate_task(acp_command="copilot", goal="Say 'funciona'", context="Test")
```

---

## 6. Behavior Audit Checklist (Agent Self-Verification)

Use at the START of any repair session to verify the agent's own behavior:

```markdown
## Pre-flight Behavior Checklist

- [ ] **1. Profile identified**: Said "Perfil activo: default" or "Perfil activo: ws" explicitly
- [ ] **2. Context reviewed**: Read USER.md, MEMORY.md injected
- [ ] **3. Skills scanned**: Ran skills_list() and loaded relevant skills
- [ ] **4. Previous sessions checked**: Used session_search if applicable
- [ ] **5. Plan presented**: Showed numbered steps to user
- [ ] **6. Approval obtained**: User said "ok", "proceed", "go ahead"

## During Execution

- [ ] **7. Not rushing**: Waited for complete results from each tool
- [ ] **8. Not inventing**: Said "I don't know" or "need to verify" when unsure
- [ ] **9. Honest reporting**: Reported what failed, didn't hide errors
- [ ] **10. Runtime verified**: Tested with real data/calls, not just config
- [ ] **11. Correct tools**: Used read_file (not cat), search_files (not grep)
- [ ] **12. No patch on config.yaml**: Always Python yaml.safe_load/dump

## Common Behavior Traps (DO NOT REPEAT)

1. ❌ "Config correct = system working" → ALWAYS test runtime
2. ❌ "I know everything because memory is injected" → ALWAYS state profile explicitly
3. ❌ "User mentioned a skill, I'll go direct" → ALWAYS skills_list() first
4. ❌ "I created internal TODO list, that's enough" → ALWAYS present plan to user
5. ❌ "I used patch, it was faster" → NEVER patch on config.yaml
6. ❌ "This is cross-cutting, no department" → ALWAYS identify thread/department
```

---

## Key Insight: "Config Correct ≠ System Working"

Always run these verification scripts AFTER checking config.yaml. The most common traps:

1. **Token lists models but can't chat** → subagents fail despite "valid" token
2. **auth.json has empty api_key but .env has the real key** → 403 Forbidden
3. **Cloudflare 1010 on OpenCode Go** → blocked from WSL, use different provider
4. **Missing Copilot CLI** → "Could not start Copilot ACP command 'claude'"
