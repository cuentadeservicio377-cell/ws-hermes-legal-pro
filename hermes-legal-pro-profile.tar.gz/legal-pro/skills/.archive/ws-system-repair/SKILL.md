---
name: ws-system-repair
description: Protocolo de reparación completo del sistema Hermes Neo / WS Capital. Incluye auditoría, comportamiento, features, estructura, coherencia, OpenCode Go, Obsidian Vault, y técnico.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [repair, system, hermes, ws-capital, protocol, audit]
---

# WS System Repair Protocol

## Propósito

Sistema end-to-end para auditar, reparar y verificar el funcionamiento completo de Hermes Neo / WS Capital.

## Trigger

Usar este skill cuando:
- El sistema no funciona como debería
- Se detectan problemas de comportamiento del agente
- Features de Hermes no están configuradas
- Hay inconsistencias en memorias/personalidad
- Se necesita integrar nuevos componentes
- La configuración "parece correcta" pero el sistema no opera (usar sección Log Forensics)
- Subagentes fallan al spawnear a pesar de config correcta
- Hay errores intermitentes que requieren análisis de logs reales

## Protocolo de Reparación

### FASE 1: COMPORTAMIENTO (Prioridad 1)

#### Test 1.1: ¿Revisa contexto?
```
1. Leer USER.md
2. Leer MEMORY.md
3. Identificar perfil activo
4. Buscar sesiones previas
```

**Trampa común**: La memoria se inyecta automáticamente, pero eso NO cuenta como "revisar contexto". El agente debe:
- Identificar EXPLÍCITAMENTE el perfil activo (default vs ws)
- Buscar sesiones previas relacionadas con session_search
- No asumir que ya "sabe" todo porque la memoria está ahí

**Verificación**: Si el agente no dice "Perfil activo: ws" o "Perfil activo: default" en los primeros 3 mensajes, FALLA este test.

#### Test 1.2: ¿Escanea skills?
```
1. Ejecutar skills_list()
2. Identificar skills relevantes
3. Cargar skill_view() si aplica
```

**Trampa común**: El usuario menciona un skill (ej: "el skill de plan de reparación") y el agente va DIRECTO a skill_view() sin hacer skills_list() primero. Esto es PARCIAL — el protocolo requiere escanear TODOS los skills disponibles, no solo el que el usuario mencionó.

**Verificación**: Si el agente no ejecuta skills_list() en los primeros 5 mensajes de una sesión nueva, FALLA este test.

#### Test 1.3: ¿Planea?
```
1. Presentar pasos numerados
2. Esperar aprobación
3. Ejecutar con calidad
```

**Trampa común**: El agente crea un TODO list interno pero NUNCA presenta el plan al usuario antes de actuar. El usuario debe poder ver y aprobar/rechazar el plan.

**Verificación**: Si el agente ejecuta tools (patch, write_file, terminal) antes de que el usuario diga "ok", "procede", "adelante", o similar, FALLA este test.

#### Test 1.4: ¿No se apura?
```
1. Esperar resultados completos
2. No inventar respuestas
3. Reportar fallos honestamente
```

**Trampa común**: El agente dice "todo está funcionando" cuando en realidad NO verificó runtime. O dice "reparado" cuando solo cambió config sin probar.

**Verificación**: Si el agente reporta éxito sin haber ejecutado una prueba real (subagente, visión, chat), FALLA este test.

#### Test 1.5: ¿Usa herramientas?
```
1. Usar tools correctas
2. No improvisar
3. Verificar resultados
```

**Trampa común**: Usar `patch` para modificar config.yaml cuando el skill dice explícitamente "NUNCA usar patch para config.yaml". O usar terminal para leer archivos en vez de read_file.

**Verificación**: Si el agente usa patch en config.yaml, o cat/head/tail en vez de read_file, o grep en vez de search_files, FALLA este test.

#### Test 1.6: ¿Hace flujos?
```
1. Seguir flujo de departamento
2. Respetar matriz de acceso
3. Guardar checkpoint
```

**Trampa común**: El agente trata una tarea transversal (ej: reparación) como si no tuviera departamento, cuando en realidad debería identificar que está en Thread 1 (General) y seguir el flujo correspondiente.

**Verificación**: Si el agente no identifica el thread/departamento activo al inicio de una sesión de trabajo estructurado, FALLA este test.

### FASE 2: FEATURES (Prioridad 2)

- Code Execution
- Hooks
- Batch Processing
- Google Workspace
- RL Training
- Claude Code
- Vision API

#### Test 2.1: ¿Providers de modelos configurados?
```
1. Verificar que 'providers:' en config.yaml NO esté vacío {}
2. Comparar config.yaml actual contra backup más reciente (*.bak-*)
3. Si providers está vacío, restaurar desde backup válido
4. Verificar que cada provider tenga: base_url, api_key, default_model
```

#### Test 2.1a: ¿Audit completo de credential_pool vs providers vs .env?
```
1. Leer ~/.hermes/auth.json — revisar credential_pool (tiene credenciales con API keys/OAuth)
2. Leer ~/.hermes/auth.json — revisar providers (qué providers están ACTIVOS para Hermes)
3. CRUZAR: ¿cada provider en credential_pool tiene entrada correspondiente en config.yaml providers:?
4. Si credential_pool tiene openai-codex pero providers: {} está vacío → provider NO está disponible
5. Si providers solo tiene 'nous' pero config.yaml tiene providers: {} → desincronización auth vs config
6. CRUZAR con .env: ¿cada provider con api_key en config.yaml tiene su variable en .env?
7. ESPECIAL: verificar que auth.json credential_pool tenga api_key NO vacía para providers que la usan
   - opencode-go en auth.json con api_key vacío + .env con key válida = DESINCRONIZACIÓN
   - Esto causa 403 Forbidden aunque la config "parezca correcta"
```

#### Test 2.2: ¿API keys en .env sincronizadas?
```
1. Leer ~/.hermes/.env
2. Verificar que existan: KIMI_API_KEY, OPENAI_API_KEY, NVIDIA_API_KEY, OPENCODE_GO_API_KEY
3. Cruzar con providers en config.yaml: cada provider debe tener su key en .env
4. Si falta alguna, reportar al usuario ANTES de continuar
5. ESPECIAL: OpenAI Codex usa OAuth (no API key en .env) — verificar en credential_pool
```

#### Test 2.3: ¿Modelos de fallback y delegación correctos?
```
1. Verificar fallback_providers: debe tener al menos 1 fallback válido
2. Verificar delegation.model y delegation.provider: NO deben estar vacíos
3. Confirmar con usuario: ¿qué modelo para subagentes? ¿qué modelo para fallback principal?
4. NO usar APIs gratuitas (NVIDIA free, Nous free, OpenRouter free) para subagentes ni fallbacks principales
5. Política de modelos WS Capital (actualizada 28abr2026 — OpenAI Codex es motor secundario):
   - Principal: kimi-k2.6 (Kimi)
   - Subagentes: openai-codex / gpt-5.3-codex (OpenAI Codex, max 3 concurrentes, depth 2)
   - Fallback principal: openai-codex / gpt-5.4-mini (OpenAI Codex)
   - Fallback secundario: opencode-go / kimi-k2.6 (OpenCode Go)
   - Auxiliares: openai-codex / gpt-5.4-mini (vision, web_extract, compression, session_search, etc.)
   - Vision: openai-codex / gpt-5.4 (análisis de imágenes)
   - OpenCode Go es backup secundario, NO motor principal
   - NO usar APIs gratuitas (NVIDIA free, Nous free) para subagentes ni fallbacks
```

#### Test 2.3a: ¿Delegación de subagentes funciona en runtime?
```
CRÍTICO: No basta con que config.yaml tenga delegation configurado.
Hay que probar que un subagente REAL spawnea y responde.

1. Ejecutar delegate_task con un objetivo trivial (ej: "responde 'ok'")
2. Si falla con "Copilot ACP process exited early" → falta CLI de Copilot/Claude
3. Si falla con "Could not start Copilot ACP command 'claude'" → instalar gh copilot CLI
4. Si falla con 401/403 → token OAuth revocado o sin permisos de chat
5. Si funciona → subagentes operativos confirmados

Trampa común: OpenAI Codex token puede listar modelos (GET /models) pero
fallar en conversación (POST /conversation) por falta de scope o arkose_token.
Esto hace que la config "parezca correcta" pero los subagentes nunca funcionan.
```

#### Test 2.3b: ¿Vision API funciona en runtime?
```
CRÍTICO: La config puede tener vision.provider = 'openai-codex' y vision.model = 'gpt-5.4',
pero si el modelo no soporta image_input o el endpoint devuelve 404, la visión falla.

1. Verificar que el modelo de visión SOPORTE image_input (no todos los modelos multimodales lo hacen)
2. Probar vision_analyze con una URL pública de imagen
3. Si devuelve 404 "No endpoints found that support image input" → modelo/configuración incorrecta
4. Si devuelve 401/403 → token sin permisos para visión
5. Si funciona → visión operativa confirmada

Trampa común: gpt-5.4 puede ser chat-only sin visión. Verificar en la lista de modelos
de la API que el modelo tenga 'supports_vision' o equivalente.
```

#### Test 2.3c: ¿Subagentes tienen toolsets completos? (NUEVO — crítico)
```
CRÍTICO: Un subagente puede spawnear correctamente pero NO tener las herramientas que necesita.
Esto causa que "se traben" en tareas que requieren web, browser, o búsqueda.

1. Spawnear subagente con delegate_task que incluya toolsets: ["terminal", "file", "web", "browser"]
2. Dentro del subagente, intentar: web_search, browser_navigate, search_files
3. Si el subagente reporta "NO tengo acceso a web" → toolsets NO se propagan correctamente
4. Si el subagente puede ejecutar web_search → toolsets SÍ se propagan
5. Documentar qué toolsets tiene el subagente vs. qué toolsets tiene el agente principal

Trampa común: El agente principal tiene web/browser pero el subagente ACP solo hereda
un subset. Esto hace que tareas de research fallen silenciosamente.
```

#### Test 2.3d: ¿Contexto del sistema se inyecta en subagentes? (NUEVO — crítico)
```
CRÍTICO: Subagentes no saben en qué entorno operan ni qué sistemas tienen disponibles.
Esto causa que "razonen como chatbot genérico en VPS" en lugar de "operador WS Capital en WSL".

1. Spawnear subagente y preguntarle: "¿En qué sistema operativo estás? ¿Tienes GitHub? ¿Qué APIs?"
2. Si responde "No lo sé" o "Soy un asistente AI" → contexto NO inyectado
3. Si responde "WSL2 Ubuntu, GitHub cuentadeservicio377-cell, APIs Kimi/Codex/NVIDIA" → OK
4. La solución: subagente debe leer MEMORY.md al inicio (o el padre debe pasar contexto)

Trampa común: Subagentes ACP arrancan con contexto vacío. NO asumen que "heredan"
la memoria del agente principal. Deben leer archivos o recibir contexto explícito.
```
```
1. show_reasoning: debe ser true
2. streaming: debe ser true
3. personality: debe coincidir con perfil activo (professional para ws)
4. Si alguno es false, corregir inmediatamente
```

### FASE 3: ESTRUCTURA (Prioridad 3)

- Orquestación por departamento
- Deep Research System
- Video Machine
- Matriz de acceso

#### Test 3.1: ¿Todos los departamentos tienen skills críticos?
```
1. Verificar que cada thread/departamento tiene skills asignados
2. Verificar que las skills existen físicamente (SKILL.md presente)
3. Verificar que cada departamento tiene al menos 2-3 skills críticas

Departamentos esperados (WS Capital):
- Thread 1: General (Dirección / Orquestación)
- Thread 2: Socio Operativo (Segundo Yo de Pablo)
- Thread 5: Build & Tech (Fábrica de Software)
- Thread 8: Growth & Marketing (Growth)
- Thread 22: Willow Legal (Jurídico / Willow)
- Thread 23: Admin & Ops (COO / PM)
- Thread 24: Ventas & Plantillas (Comercial)

Skills mínimas por departamento:
- General: ws-system-repair, session-close-checkpoint, ws-diagnostic
- Socio Operativo: ws-founder-voice-capture, deep-research-system, plan
- Build: opencode-go-integration, test-driven-development, github-pr-workflow
- Growth: ws-campaign-planner, ws-video-machine, ws-market-researcher
- Willow: willow-legal-complete, client-system-onyx-migration, ocr-and-documents
- Admin & Ops: admin-ops-brain-dump, ws-excel-pm-design, ws-interconnected-ops
- Ventas: ws-demo-mode, powerpoint, paola-meneses-eventos
```

#### Test 3.2: ¿Agentes especializados operativos?
```
1. Deep Research System: Verificar que delegate_task funciona (4 agentes paralelo)
2. Video Machine: Verificar ffmpeg/ffprobe instalados, skills presentes
3. Content Engine: Verificar calendario/templates configurados

CRÍTICO: No basta con que los skills existan. Hay que verificar runtime:
- Deep Research: delegate_task trivial debe funcionar
- Video Machine: ffmpeg -version debe responder
- Content Engine: ws-content-drafter debe cargar sin errores
```

#### Test 3.3: ¿Conexión con PM (Excel Maestro)?
```
1. Verificar que Excel PM Maestro existe y es accesible
2. Verificar que cada departamento puede escribir/leer del Excel
3. Verificar cron jobs de Admin & Ops (sync Onyx, chrome killer, gateway restart)
4. Verificar que handoffs entre departamentos se registran en Excel

Handoffs esperados:
- Growth → Build: landing pages
- Growth → Admin: presupuestos
- Build → Admin: features listas para QA
- Willow → Build: automatización documentos
- Ventas → Willow: contratos
- Ventas → Growth: casos de éxito
- Socio Op → Cualquiera: ideas, prioridades
- General → Todos: reuniones, decisiones
```

#### Test 3.4: ¿Servicios y procesos activos?
```
1. Verificar gateway está corriendo (tmux session o proceso)
2. Verificar Onyx en puerto 3000 responde
3. Verificar Copilot CLI instalado y en PATH
4. Verificar cron jobs activos
5. Verificar logs recientes (gateway.log, agent.log, errors.log)

Comandos:
ps aux | grep hermes
ss -tlnp | grep 3000
which copilot
crontab -l
ls -la ~/.hermes/logs/
```

### FASE 4: COHERENCIA (Prioridad 4)

- SOUL.md
- USER.md
- MEMORY.md
- Prefill JSON
- Skills snapshot

### FASE 5: OPENCODE GO (Prioridad 5)

- Endpoint
- API Key
- 100+ modelos

### FASE 6: OBSIDIAN VAULT (Prioridad 6)

- WS-Campaigns
- Paola Meneses
- Skills integrados

### FASE 7: TÉCNICO (Prioridad 7 - AL FINAL)

- Gateway
- Kimi API
- /tmp
- Docker
- Nous OAuth
- Codex
- Paquetes
- Dependencias
- Prune
- Backups

#### Test 7.1: ¿Configuración de modelos estable?
```
1. Re-ejecutar Tests 2.1-2.4 para confirmar que no se corrompió durante reparación técnica
2. Verificar que gateway reinicia sin errores de provider
3. Hacer smoke test con cada provider activo (Kimi, OpenAI, OpenCode Go)
4. Confirmar que subagentes pueden spawnear con modelo de delegación configurado
5. Verificar que NO hay desincronización auth vs config (ver patrón arriba)
```

#### Test 7.2: ¿Configuración objetivo WS Capital verificada?
```
- [ ] Modelo principal: kimi-k2.6 (Kimi)
- [ ] Provider Kimi: base_url, api_key, default_model configurado
- [ ] Provider OpenAI Codex: base_url, auth_type oauth, default_model configurado (motor secundario)
- [ ] Provider OpenCode Go: base_url, api_key, default_model configurado (backup)
- [ ] Fallback principal: openai-codex / gpt-5.4-mini
- [ ] Fallback secundario: opencode-go / kimi-k2.6
- [ ] Delegación subagentes: openai-codex / gpt-5.3-codex, max_concurrent_children=3, max_spawn_depth=2
- [ ] Auxiliares: openai-codex / gpt-5.4-mini (session_search, compression, vision, web_extract, etc.)
- [ ] Vision: openai-codex / gpt-5.4
- [ ] NO usar APIs gratuitas (NVIDIA, Nous, OpenRouter free) para subagentes/fallbacks
- [ ] show_reasoning: true
- [ ] streaming: true
- [ ] personality: professional (para ws)
```

## Reglas de Ejecución

1. NO saltar fases
2. NO apresurarse
3. NO inventar resultados
4. NO omitir verificación
5. NO dejar para después
6. **NUNCA usar el tool `patch` para modificar config.yaml** — siempre usar Python con yaml.safe_load/dump para evitar corrupción
7. **DURANTE la reparación, verificar config.yaml cada 2-3 pasos** — cambios en modelos pueden corromper providers, display flags, o delegation settings
8. **Siempre comparar config actual vs backup más reciente** antes de declarar una fase "completa"
9. **Nunca asumir que .env tiene todas las keys** — verificar explícitamente cada API key necesaria

## Patrón de desincronización auth vs config (descubierto 28abr2026)

Situación: auth.json tiene credenciales en credential_pool pero config.yaml tiene providers: {}

### Síntomas:
- `hermes auth list` muestra credenciales activas
- PERO `providers: {}` está vacío en config.yaml
- Fallback apunta a provider que no está declarado
- Subagentes fallan porque delegation no tiene provider válido
- display flags (show_reasoning, streaming) pueden estar en false

### Causa raíz:
- auth.json y config.yaml son archivos separados
- auth.json guarda credenciales (credential_pool)
- config.yaml declara qué providers están disponibles para uso
- Si config.yaml se corrompe/resetea, providers: {} queda vacío aunque auth.json tenga todo
- Los patches manuales con tool `patch` pueden desbordarse y corromper el YAML (duplicar keys, perder secciones)

### Flujo de diagnóstico:
```bash
# 1. Verificar auth.json tiene credenciales
python3 -c "import json; auth=json.load(open('/root/.hermes/auth.json')); print('credential_pool:', list(auth.get('credential_pool',{}).keys()))"

# 2. Verificar config.yaml tiene providers declarados
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); print('providers:', list(c.get('providers',{}).keys()))"

# 3. Verificar display flags
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); print('show_reasoning:', c.get('display',{}).get('show_reasoning')); print('streaming:', c.get('display',{}).get('streaming'))"

# 4. Verificar delegation
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); d=c.get('delegation',{}); print('delegation provider:', d.get('provider')); print('delegation model:', d.get('model'))"
```

### Reconstrucción SEGURA de providers (usar Python, NO patch manual):

**NUNCA usar el tool `patch` para modificar config.yaml** — los patches manuales pueden desbordarse, duplicar keys, o eliminar secciones enteras (como `display:`). Siempre usar Python con `yaml.safe_load`/`yaml.dump`:

```python
import yaml

with open('/root/.hermes/config.yaml', 'r') as f:
    config = yaml.safe_load(f)

# Reconstruir providers desde credential_pool + .env
config['providers'] = {
    'kimi-coding': {
        'base_url': 'https://api.kimi.com/coding',
        'api_key': '${KIMI_API_KEY}',
        'default_model': 'kimi-k2.6',
        'timeout': 180,
        'extra_headers': {
            'HTTP-Referer': 'https://wscapital.ai',
            'X-Title': 'WS Capital Hermes'
        }
    },
    'openai-codex': {
        'base_url': 'https://chatgpt.com/backend-api/codex',
        'auth_type': 'oauth',
        'default_model': 'gpt-5.4-mini',
        'timeout': 180,
        'extra_headers': {
            'HTTP-Referer': 'https://wscapital.ai',
            'X-Title': 'WS Capital Hermes'
        }
    },
    'opencode-go': {
        'base_url': 'https://opencode.ai/zen/go/v1',
        'api_key': '${OPENCODE_GO_API_KEY}',
        'default_model': 'kimi-k2.6',
        'timeout': 180,
        'extra_headers': {
            'HTTP-Referer': 'https://wscapital.ai',
            'X-Title': 'WS Capital Hermes'
        }
    }
}

# Configurar fallbacks (OpenCode Go primero, OpenAI solo emergencia)
config['fallback_providers'] = [
    {'provider': 'opencode-go', 'model': 'kimi-k2.6'},
    {'provider': 'openai-codex', 'model': 'gpt-5.4-mini'}
]

# Configurar delegation para subagentes (OpenAI Codex con ACP)
config['delegation'] = {
    'model': 'gpt-5.3-codex',
    'provider': 'openai-codex',
    'base_url': '',
    'api_key': '',
    'max_iterations': 50,
    'reasoning_effort': 'high',
    'max_concurrent_children': 3,
    'max_spawn_depth': 2,
    'orchestrator_enabled': True,
    'child_timeout_seconds': 600,
    'subagent_auto_approve': False
}

# IMPORTANTE: Instalar GitHub Copilot CLI para ACP
# npm install -g @github/copilot
# ln -sf $(which copilot) /usr/local/bin/copilot
# Configurar HERMES_COPILOT_ACP_COMMAND=/usr/local/bin/copilot
# Ver scripts de verificación en: references/runtime-verification-scripts.md

# Configurar display flags
if 'display' not in config:
    config['display'] = {}
config['display']['show_reasoning'] = True
config['display']['streaming'] = True
config['display']['personality'] = 'professional'
config['display']['compact'] = True

# Configurar auxiliary tasks (OpenAI Codex, motor secundario)
config['auxiliary'] = {
    'vision': {'provider': 'openai-codex', 'model': 'gpt-5.4', 'base_url': '', 'api_key': '', 'timeout': 120, 'extra_body': {}, 'download_timeout': 30},
    'web_extract': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 360, 'extra_body': {}},
    'compression': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 120, 'extra_body': {}},
    'session_search': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}, 'max_concurrency': 3},
    'skills_hub': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}},
    'approval': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}},
    'mcp': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}},
    'title_generation': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}},
    'flush_memories': {'provider': 'openai-codex', 'model': 'gpt-5.4-mini', 'base_url': '', 'api_key': '', 'timeout': 30, 'extra_body': {}}
}

# Guardar
with open('/root/.hermes/config.yaml', 'w') as f:
    yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
```

## FASE 8: SESSION CONTINUITY & PROJECT STATE (NUEVO — Prioridad crítica post-reparación)

### Cuándo usar esta fase
- Usuario dice "ya estaba funcionando" o "actúa como antes"
- Infraestructura verificada OK pero proyecto no aparece en sesión
- Cron jobs programados pero usuario no encuentra resultados
- Múltiples proyectos existen pero sesión actual no tiene contexto

### La trampa: "Sistema reparado ≠ Proyecto recuperado"

Después de una reparación exitosa (Fases 1-7), el sistema infraestructura está perfecto:
- ✅ Providers configurados
- ✅ Subagentes funcionando
- ✅ Skills instaladas
- ✅ Gateway corriendo

PERO la sesión actual NO sabe:
- ❌ Qué proyectos están activos
- ❌ Dónde están los archivos del proyecto
- ❌ Qué trabajo async quedó pendiente
- ❌ Qué cron jobs fallaron o produjeron

**Esto NO es una falla del sistema — es una falla de continuidad de sesión.**

### Flujo de verificación de continuidad

```
1. Infraestructura OK? (Fases 1-7)
   → Si NO → reparar primero
   → Si SÍ → continuar

2. Preguntar al usuario: "¿En qué proyecto estás trabajando?"
   → Si el usuario menciona nombre → buscar en ubicaciones conocidas
   → Si el usuario no sabe → listar proyectos activos encontrados

3. Buscar proyectos en ubicaciones estándar WS Capital:
   a. Obsidian Vault: /mnt/c/Users/DELL/Documents/Obsidian Vault/WS-Campaigns/01-Active/
   b. Repos: /mnt/c/Users/DELL/Documents/repos/
   c. WS Capital: /mnt/c/Users/DELL/Documents/WS Capital/
   d. Desktop: /mnt/c/Users/DELL/Desktop/
   e. Checkpoints: ~/.hermes/checkpoints/

4. Verificar estado del proyecto:
   a. ¿Tiene archivos recientes? (ls -lt | head)
   b. ¿Tiene checkpoints? (find . -name "checkpoint*" -o -name "CIERRE-REAL*")
   c. ¿Tiene cron jobs pendientes? (revisar crontab, logs)
   d. ¿Tiene trabajo async no verificado? (revisar logs de sesiones previas)

5. Reportar hallazgo:
   → "Sistema operativo. Proyecto '[nombre]' encontrado en [ruta]. Estado: [resumen]"
   → "Sistema operativo. No encontré proyectos activos en ubicaciones estándar."
   → "Sistema operativo. Proyecto encontrado pero con trabajo pendiente: [lista]"
```

### Ubicaciones de proyectos WS Capital (referencia rápida)

| Tipo | Ubicación típica | Patrón de búsqueda |
|------|-----------------|-------------------|
| Campañas/Hackathons | Obsidian Vault/WS-Campaigns/01-Active/ | find ... -type d -name "*Hackathon*" -o -name "*Campaign*" |
| Sistemas cliente | Documents/repos/ o Documents/[client]/ | find ... -maxdepth 2 -type d |
| Productos WS | Documents/WS Capital/[product]/ | ls -la ... |
| Entregas | Desktop/[project]-Entrega-[fecha]/ | ls -lt ~/Desktop |
| Checkpoints sistema | ~/.hermes/checkpoints/ | ls -la ~/.hermes/checkpoints/ |

### Verificación de trabajo async (cron jobs, nocturno)

```bash
# 1. ¿Hay cron jobs activos?
crontab -l

# 2. ¿Hay logs de cron?
ls -la ~/.hermes/logs/ | grep cron

# 3. ¿Hay sesiones de cron recientes?
ls -lt ~/.hermes/sessions/ | grep cron | head -5

# 4. ¿Hay archivos de checkpoint de cierre?
find ~/.hermes/ -name "checkpoint*" -type f -mtime -7
find /mnt/c/Users/DELL/Documents -name "CIERRE-REAL*" -type f -mtime -7
find /mnt/c/Users/DELL/Documents -name "checkpoint*" -type f -mtime -7

# 5. ¿Hay trabajo programado que no se verificó?
grep -r "cron\|nocturno\|async" ~/.hermes/checkpoints/ 2>/dev/null
```

### Diferenciando "sistema roto" vs "sesión perdida"

| Síntoma del usuario | Diagnóstico probable | Acción |
|--------------------|---------------------|--------|
| "No tiene acceso a nada" | Infraestructura rota | Fases 1-7 |
| "Actúa como la gente de antes" | Sesión sin contexto | Fase 8 + cargar proyecto |
| "No revisa logs" | No sabe dónde están los logs | Fase 8 + ubicar proyecto |
| "Estaba perfecto y ahora no" | Cron job falló o no se verificó | Fase 8 + auditar async |
| "Ya podía usar flujos y ahora no" | Infraestructura rota | Fases 1-7 |

### Lección clave (descubierta 28abr2026)

**"Config correcta = sistema funcionando" es la trampa #1.**
**"Sistema funcionando = proyecto operativo" es la trampa #2.**

El sistema puede estar 100% operativo y aun así el usuario percibe que "no funciona" porque:
1. La sesión actual no cargó el contexto del proyecto
2. El trabajo async (cron, nocturno) falló sin notificación
3. El agente reportó "hecho" cuando en realidad solo planeó (guiones ≠ videos)

**Siempre verificar ambas capas: infraestructura + continuidad.**

## Log Forensics & Runtime Verification (Análisis Profundo con Logs)

**Ver scripts ejecutables en:** `references/runtime-verification-scripts.md`

### Cuándo usar esta sección
- La verificación superficial dice "todo correcto" pero el sistema no funciona
- Se necesita distinguir entre "configuración correcta" y "sistema operativo"
- Hay sospecha de que providers, tokens, o features fallan en runtime
- Se detectan errores intermitentes o subagentes que no spawnean

### La trampa: "Config correcta ≠ Sistema funcionando"

**Síntoma clásico:** El check de config.yaml pasa todos los tests, pero:
- Subagentes fallan al spawnear
- Vision API devuelve 404
- OAuth tokens están revocados
- Gateway se reinicia constantemente

**Regla de oro:** Siempre verificar el runtime DESPUÉS de verificar la configuración.

### Flujo de análisis de logs

```
1. Localizar directorio de logs: ~/.hermes/logs/
2. Analizar errors.log — contar errores por tipo:
   - APITimeoutError (timeouts)
   - ProviderError / model errors
   - Subagent spawn failures
   - Vision / tool errors
3. Analizar gateway.log — buscar:
   - Reinicios del gateway
   - Desconexiones de plataformas
   - Warnings de configuración
4. Analizar agent.log — verificar:
   - Qué modelos se usan realmente
   - Cuántos subagentes spawnean
   - Errores de tools
5. Analizar keepalive.log — verificar:
   - Cuántos reinicios ha hecho
   - Estado actual del gateway
```

### Comandos de diagnóstico con logs

```bash
# Errores por tipo en errors.log
grep -c "APITimeoutError" ~/.hermes/logs/errors.log
grep -c "subagent" ~/.hermes/logs/errors.log
grep -c "vision" ~/.hermes/logs/errors.log
grep -c "token_revoked\|401" ~/.hermes/logs/errors.log

# Reinicios del gateway
grep -c "Starting Hermes Gateway" ~/.hermes/logs/gateway.log
grep -c "Exiting with code" ~/.hermes/logs/gateway.log

# Subagentes que fallaron
grep "subagent.*API call failed" ~/.hermes/logs/errors.log | tail -n 20

# Warnings de config
grep "unknown config keys" ~/.hermes/logs/gateway.log
```

### Verificación runtime de providers

**NO confiar en que el token existe — probar que funciona:**

```python
# Verificar OpenAI Codex token (prueba REAL de chat, no solo listar modelos)
import urllib.request
try:
    req = urllib.request.Request(
        'https://chatgpt.com/backend-api/codex/models?client_version=1.2026.0428',
        headers={'Authorization': f'Bearer {token}'}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        print(f"✅ Token válido — {len(data.get('models',[]))} modelos")
except urllib.error.HTTPError as e:
    if e.code == 401:
        print("❌ TOKEN REVOCADO — necesita re-autenticación")
    elif e.code == 400:
        print("🟡 Falta client_version — token puede ser válido")

# Verificar que el token permite CHAT (no solo listar)
# Si POST /conversation da 403, el token NO sirve para subagentes
# aunque GET /models funcione perfectamente

try:
    req = urllib.request.Request(
        'https://chatgpt.com/backend-api/conversation',
        method='POST',
        data=json.dumps({
            'action': 'next',
            'messages': [{'id': 'test', 'author': {'role': 'user'}, 'content': {'content_type': 'text', 'parts': ['hi']}}],
            'model': 'gpt-5.4-mini',
            'conversation_mode': {'kind': 'primary_assistant'},
            'client_version': '1.2026.0428'
        }).encode(),
        headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        print("✅ Chat funciona — subagentes operativos")
except urllib.error.HTTPError as e:
    if e.code == 403:
        print("❌ TOKEN VÁLIDO PARA LISTAR PERO NO PARA CHAT — subagentes FALLARÁN")
        print("   Causa: falta scope de chat, arkose_token, o proof_token")
    elif e.code == 401:
        print("❌ TOKEN REVOCADO")

# Verificar OpenCode Go modelos + chat
import urllib.request
req = urllib.request.Request(
    'https://opencode.ai/zen/go/v1/models',
    headers={'Authorization': f'Bearer {api_key}'}
)
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        models = json.loads(resp.read())
        print(f"✅ {len(models)} modelos disponibles")
except urllib.error.HTTPError as e:
    print(f"❌ Error {e.code}: {e.reason}")
    if e.code == 403:
        print("   API key revocada o inválida — revisar en https://opencode.ai")

# Verificar que OpenCode Go chat completion funciona
try:
    req = urllib.request.Request(
        'https://opencode.ai/zen/go/v1/chat/completions',
        method='POST',
        data=json.dumps({
            'model': 'kimi-k2.6',
            'messages': [{'role': 'user', 'content': 'Say "test ok"'}],
            'max_tokens': 10
        }).encode(),
        headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
        content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
        print(f"✅ Chat funciona: '{content}'")
except urllib.error.HTTPError as e:
    print(f"❌ Chat falla: {e.code} — provider no sirve para subagentes")
```

### Verificación de auth.json vs .env desincronización

```python
import json

with open('/root/.hermes/auth.json', 'r') as f:
    auth = json.load(f)

# Verificar que credential_pool tenga api_key NO vacía
for name, cred in auth.get('credential_pool', {}).items():
    if isinstance(cred, list):
        cred = cred[0] if cred else {}
    api_key = cred.get('api_key', '')
    if len(api_key) == 0 and name in ['opencode-go', 'openrouter', 'nvidia']:
        print(f"❌ {name}: api_key VACÍO en auth.json — revisar .env")
        # Leer .env para ver si hay key válida
        try:
            with open('/root/.hermes/.env', 'r') as ef:
                for line in ef:
                    if name.upper().replace('-', '_') in line.upper():
                        print(f"   .env tiene: {line.strip()[:30]}...")
        except:
            pass
```

### Problemas comunes descubiertos en logs

| Error en Log | Significado | Severidad |
|-------------|-------------|-----------|
| `token_revoked` (401) | OAuth expirado/revocado | CRÍTICA |
| `Copilot ACP process exited early` | Codex CLI roto en WSL | CRÍTICA |
| `Could not start Copilot ACP command 'claude'` | Falta instalar GitHub Copilot CLI | CRÍTICA |
| `No endpoints found that support image input` (404) | Vision no soportada por modelo | MEDIA |
| `Model not available on Free Tier` (404) | NVIDIA/Nous free no funciona | MEDIA |
| `unknown config keys ignored` | Config tiene keys no reconocidas | BAJA |
| `Gateway reiniciado N veces` | Inestabilidad del gateway | MEDIA |
| `api_key vacío en credential_pool` | auth.json desincronizado con .env | CRÍTICA |
| `403 Forbidden` en chat completion | Token válido para GET pero no para POST | CRÍTICA |

### Checklist de verificación profunda

- [ ] Config superficial pasa ✅
- [ ] errors.log analizado — contar errores por tipo
- [ ] gateway.log analizado — verificar reinicios
- [ ] agent.log analizado — verificar subagentes reales
- [ ] Tokens probados en runtime (no solo existen)
- [ ] Modelos listados desde API (no solo configurados)
- [ ] Vision API probada si se necesita
- [ ] Diferencia entre "config correcta" y "runtime funcional" documentada
- [ ] **Subagente REAL spawneado y respondido** (delegate_task trivial)
- [ ] **auth.json credential_pool vs .env cruzado** (api_key no vacío)
- [ ] **Vision API probada con imagen real** (no solo config)
- [ ] **Chat completion probado** (GET /models ≠ POST /chat/completions)
- [ ] **Limpieza post-reparación ejecutada** (skills, memoria, docs, vaults)
- [ ] **ws-system-status creado/actualizado** con estado real post-verificación
- [ ] **PROJECTS.md actualizado** con estado real de proyectos activos
- [ ] **grep final** confirmando cero referencias obsoletas en skills/docs

## Migración de Topología de Providers (Provider Topology Migration)

### Cuándo usar esta sección
- Un provider secundario pierde crédito, rate limits, o se vuelve no disponible
- Se necesita cambiar el motor secundario de TODO el sistema (subagentes, fallbacks, auxiliares)
- La documentación (skills, memoria) tiene la topología vieja y podría corromper el sistema en futuras reparaciones
- **Después de una reparación exitosa, se descubre que skills/memoria/docs aún referencian providers/herramientas que NO funcionan en el entorno actual**

### Superficies que deben actualizarse
1. **config.yaml** — providers, delegation, fallback_providers, auxiliary
2. **Skill de reparación** (`ws-system-repair`) — política de modelos, código de reconstrucción, checklist
3. **Memoria del sistema** — entry de configuración de modelos
4. **Otros skills** — buscar referencias al provider/herramienta viejo y actualizar
5. **Documentos de proyectos** (Obsidian vault, checkpoints) — quitar referencias obsoletas
6. **PROJECTS.md** — reflejar estado real post-limpieza

### Procedimiento de migración
```
1. Confirmar con usuario: ¿provider viejo definitivamente fuera? ¿cuál es el nuevo?
2. Actualizar config.yaml (Python yaml.safe_load/dump, NUNCA patch manual)
3. Verificar auth.json vs config.yaml sincronizados
4. Ejecutar verificación final (12 checks)
5. Actualizar skill ws-system-repair: política, código, checklist
6. Actualizar memoria del sistema
7. Buscar en otros skills referencias al provider viejo
8. Verificación post-migración: todo en nuevo provider, provider viejo solo emergencia
```

### FASE CRÍTICA POST-MIGRACIÓN: Limpieza de referencias obsoletas

**Cuándo:** Inmediatamente después de cambiar la topología en config.yaml y actualizar el skill de reparación.

**Por qué:** Skills, memoria, documentos de proyectos, y checkpoints contienen referencias a providers/herramientas que ya no funcionan. Si no se limpian, futuras sesiones intentarán usar herramientas rotas.

**Procedimiento de limpieza:**
```
1. AUDITAR skills:
   grep -r "provider_viejo\|herramienta_rota" ~/.hermes/skills/ --include="*.md" -l
   # Ejemplos: "NVIDIA.*imagen", "OpenCode Go.*principal", "Fal.ai.*sin verificar"

2. REVERTIR skills modificadas incorrectamente:
   # Si una skill fue modificada durante la reparación con info falsa,
   # revertirla desde backup o reescribir la sección afectada
   cp ~/.hermes/skills/[skill]/SKILL.md.backup-antes-limpieza-YYYYMMDD \
      ~/.hermes/skills/[skill]/SKILL.md

3. ACTUALIZAR skills con estado real:
   # Para cada skill afectada, reemplazar:
   # "Provider X (fallback principal)" → "Provider X: NO disponible en este entorno"
   # "OpenCode Go (opción principal)" → "OpenCode Go: backup teórico, Cloudflare 403"
   # "NVIDIA API (generación imagen)" → "NVIDIA API: chat texto únicamente"

4. LIMPIAR memoria:
   memory(action="replace") para quitar afirmaciones incorrectas
   # Ejemplo: "NVIDIA API activa" → "NVIDIA API: chat texto, NO imagen/video"

5. LIMPIAR documentos de proyectos:
   # Revisar checkpoints, CIERRE-REAL, PLAN-* en Obsidian vault
   # Actualizar "próximos pasos" para reflejar herramientas reales disponibles

6. CREAR skill ws-system-status:
   # Documentar estado REAL post-verificación como referencia única de verdad
   # Incluir: qué SÍ funciona, qué NO, límites importantes, flujo recomendado

7. VERIFICAR:
   # Volver a grep para confirmar que no quedan referencias obsoletas
   grep -r "provider_viejo\|herramienta_rota" ~/.hermes/skills/ ~/.hermes/memories/ \
      /mnt/c/Users/DELL/Documents/Obsidian\ Vault/ --include="*.md" -l
```

**Ejemplo real (29abr2026):**
- Descubierto: 16 skills referenciaban OpenCode Go como opción principal (bloqueado 403)
- Descubierto: 4 skills decían "NVIDIA API (generación imagen gratuita)" (404 en este entorno)
- Descubierto: Memoria decía "NVIDIA API activa" sin especificar limitaciones
- Descubierto: PROJECTS.md y checkpoints del hackathon tenían próximos pasos imposibles
- Acción: Revertir 5 skills modificadas incorrectamente, actualizar 11 más, limpiar memoria, marcar documentos obsoletos como DEPRECATED, crear ws-system-status

### Trampa común: skill stale
El peligro más grande es que el skill de reparación tenga la topología vieja. Si en una futura reparación se ejecuta el código de reconstrucción del skill, corromperá el sistema restaurando el provider viejo. **Siempre actualizar el skill INMEDIATAMENTE después de cambiar la topología en config.yaml.**

**Trampa #2 (descubierta 29abr2026):** Después de actualizar el skill de reparación, skills de VIDEO/MEDIA aún tienen referencias al provider viejo. Esto causa que futuras sesiones de producción de video intenten usar herramientas rotas. **La limpieza post-migración debe incluir TODAS las skills, no solo la skill de reparación.**

### Política de modelos WS Capital (post-reparación 28abr2026):

| Rol | Provider | Modelo | Notas |
|-----|----------|--------|-------|
| Principal | kimi-coding | kimi-k2.6 | Conversaciones principales |
| Subagentes | openai-codex | gpt-5.3-codex | Uno por subagente, max 3 concurrentes, depth 2 |
| Fallback 1 | openai-codex | gpt-5.4-mini | Backup principal cuando Kimi falle |
| Fallback 2 | opencode-go | kimi-k2.6 | Backup secundario |
| Auxiliary | openai-codex | gpt-5.4-mini | vision, web_extract, compression, session_search, etc. |
| Vision | openai-codex | gpt-5.4 | Análisis de imágenes (modelo multimodal) |

**REGLA CRÍTICA:** OpenAI Codex es el motor secundario principal (subagentes, fallbacks, auxiliares). OpenCode Go es backup secundario. NO usar APIs gratuitas (NVIDIA free, Nous free) para subagentes ni fallbacks principales.

## Lecciones Aprendidas (Sesión 28abr2026)

### Errores que NO deben repetirse

1. **NUNCA asumir que "config correcta = sistema funcionando"**
   - En esta sesión, config.yaml se veía perfecto pero subagentes fallaban
   - Causa: faltaba GitHub Copilot CLI para ACP
   - Solución: siempre probar `delegate_task` trivial como parte de Test 2.3a

2. **NUNCA omitir Test 2.3a (subagente REAL) y Test 2.3b (visión REAL)**
   - Son los tests más importantes y los más omitidos
   - Un subagente que no spawnea invalida TODO el sistema de orquestación

3. **NUNCA confiar en que auth.json tiene api_key válida**
   - opencode-go tenía api_key VACÍO en auth.json pero .env tenía key
   - Esto causó 403 Forbidden que parecía "API key inválida"
   - Siempre cruzar auth.json credential_pool con .env

4. **NUNCA dejar skill de reparación stale después de cambiar providers**
   - Si el skill tiene código de reconstrucción con topología vieja,
     una futura reparación corromperá el sistema automáticamente
   - Siempre actualizar skill INMEDIATAMENTE después de cambiar config.yaml

5. **NUNCA asumir que "sistema funcionando = proyecto operativo" (NUEVO)**
   - Trampa #2 descubierta: infraestructura 100% OK pero sesión no sabe del proyecto
   - Usuario dice "estaba perfecto y ahora no" → puede ser continuidad, no infraestructura
   - Solución: Fase 8 — verificar continuidad de sesión después de verificar infraestructura
   - Siempre preguntar "¿en qué proyecto?" y buscar en ubicaciones estándar antes de reparar

6. **NUNCA reportar "hecho" cuando solo se planeó**
   - Guiones ≠ videos. Prompts ≠ imágenes. Planificación ≠ producción.
   - "Hecho" = archivo tangible (.mp4, .png, .xlsx, código ejecutable)
   - Si no hay producto tangible → reportar "planificado, pendiente de producción"

## Checklist de Comportamiento

Para usar al inicio de cada sesión: `references/checklist-comportamiento.md`

## Patrones descubiertos en esta sesión

| Patrón | Síntoma | Causa | Solución |
|--------|---------|-------|----------|
| "Copilot ACP process exited early" | Subagente falla instantáneamente | Falta `copilot` CLI | `npm install -g @github/copilot` + symlink |
| "Could not start Copilot ACP command 'claude'" | Subagente no encuentra ejecutable | `claude` no instalado | Usar `copilot` como ACP command |
| Cloudflare 1010 | 403 Forbidden en API | Bloqueo anti-bot WSL | Documentar como no compatible con WSL |
| Token lista modelos pero no chatea | GET /models ✅, POST /conversation ❌ | Falta scope/chat permission | Usar Copilot ACP en vez de llamadas directas |
| auth.json api_key vacío | 403 Forbidden aunque .env tiene key | Desincronización auth vs config | Cruzar credential_pool con .env |
| "No endpoints found that support image input" | Vision API 404 | Modelo no soporta visión | Verificar supports_vision en lista de modelos |
| "Sistema funcionando = proyecto operativo" | Usuario dice "estaba perfecto y ahora no" | Sesión no carga contexto de proyecto | Fase 8: verificar continuidad + ubicaciones estándar |
| **Skills stale post-reparación** | Skills usan providers/herramientas obsoletas | Skill no actualizado después de cambiar topología | Actualizar skill INMEDIATAMENTE después de cambiar config.yaml |
| **OpenCode Go como opción principal** | Skill dice "usar OpenCode Go" pero no funciona | Cloudflare 403 en WSL | Reemplazar con: Hermes nativo → NVIDIA → Fal.ai (con balance) |
| **Fal.ai sin balance** | "Exhausted balance" / "User is locked" | Crédito agotado | Recargar Fal.ai o usar fotos reales + ffmpeg |
| **image_generate nativo bloqueado** | Fal.ai es el backend de image_generate | Fal.ai sin balance = image_generate falla | Usar fotos reales + ffmpeg |
| **NVIDIA como generador de imagen** | Skill dice "NVIDIA API para imagen" | NVIDIA no tiene endpoint images/generations en este entorno | Remover NVIDIA de opciones de imagen/video. Solo chat texto. |
| **OpenCode Go como opción principal** | Skill dice "usar OpenCode Go" pero no funciona | Cloudflare 403 en WSL | Reemplazar con: Hermes nativo → Fal.ai (con balance) → fotos reales + ffmpeg |
| **Video Machine usa herramientas obsoletas** | Skills de video mencionan OpenCode Go/Runway/Pika/NVIDIA imagen | No se actualizaron después de reparación | Actualizar skills: nativo → Fal.ai (con balance) → fotos reales + ffmpeg |
| **Sistema visual no implementado** | vision_analyze solo URLs públicas, no archivos locales | Limitación de la tool | Implementar Ollama local + Google Vision + servidor HTTP local como router |
| **Skills stale post-reparación** | Skills usan providers/herramientas obsoletas | Skill no actualizado después de cambiar topología | Actualizar skill INMEDIATAMENTE después de cambiar config.yaml |
| **OpenCode Go como opción principal** | Skill dice "usar OpenCode Go" pero no funciona | Cloudflare 403 en WSL | Reemplazar con: Hermes nativo → Fal.ai (con balance) → fotos reales + ffmpeg |
| **NVIDIA como generador de imagen** | Skill dice "NVIDIA API para imagen" | NVIDIA no tiene endpoint images/generations en este entorno | Remover NVIDIA de opciones de imagen/video. Solo chat texto. |
| **Fal.ai sin balance** | "Exhausted balance" / "User is locked" | Crédito agotado | Usar NVIDIA API (gratuita) o fotos reales + ffmpeg |
| **image_generate nativo bloqueado** | Fal.ai es el backend de image_generate | Fal.ai sin balance = image_generate falla | Usar NVIDIA API directa o fotos reales + ffmpeg |
| **Video Machine usa herramientas obsoletas** | Skills de video mencionan OpenCode Go/Runway/Pika/NVIDIA imagen | No se actualizaron después de reparación | Actualizar skills: nativo → Fal.ai (con balance) → fotos reales + ffmpeg |
| **Sistema visual no implementado** | vision_analyze solo URLs públicas, no archivos locales | Limitación de la tool | Implementar Ollama local + Google Vision + servidor HTTP local como router |
| **Limpieza incompleta post-reparación** | Skills/docs aún referencian providers rotos después de "reparar" | Solo se actualizó config.yaml, no se auditó skills/memoria/docs | Ejecutar FASE CRÍTICA POST-MIGRACIÓN: grep en skills, revertir, actualizar, crear ws-system-status |
| **PROJECTS.md desactualizado** | Proyectos activos parecen tener assets que no existen | No se actualizó después de limpieza/borrado | Actualizar PROJECTS.md con estado REAL post-limpieza (vacío/bloqueado/operativo) |
| **Documentos de proyecto obsoletos** | Checkpoints/PLAN-* tienen "próximos pasos" imposibles | Documentos no se limpiaron después de cambiar topología | Marcar como DEPRECATED o reescribir próximos pasos con herramientas reales |
- [ ] Fase 2: Features funcionando (incluyendo Test 2.3a y 2.3b)
- [ ] Fase 3: Estructura operativa
- [ ] Fase 4: Coherencia verificada
- [ ] Fase 5: OpenCode Go documentado (incluyendo limitaciones WSL)
- [ ] Fase 6: Obsidian Vault integrado
- [ ] Fase 7: Técnico estable + re-verificación post-reparación
