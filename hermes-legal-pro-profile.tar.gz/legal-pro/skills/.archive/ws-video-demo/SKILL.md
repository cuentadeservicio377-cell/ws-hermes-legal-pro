---
name: ws-video-demo
description: "Skill para crear demos de software y tutoriales educativos. Screen recording con zoom automático, cursor highlight, narración paso a paso, y captions. Para mostrar features de productos de forma clara y profesional."
version: 1.0.0
author: WS Capital
license: MIT
metadata:
  hermes:
    tags: [video, demo, tutorial, software, screen-recording, educativo]
---

# WS Video Demo — Demos de Software / Tutoriales

## Propósito
Crear videos tutoriales y demos de software con grabación de pantalla, zoom automático en elementos importantes, cursor destacado, narración clara, y captions.

## Trigger Words (cómo invocar este skill)
- "graba un demo de [feature]"
- "tutorial de cómo funciona [producto]"
- "screen recording de [software]"
- "walkthrough de [feature]"
- "video explicativo de [proceso]"
- "demo de 2 minutos de [funcionalidad]"

## Estructura de Carpetas

```
C:\Users\DELL\Documents\WS-Capital\Video-Studio\
├── 00-Assets\              ← Depósito
│   ├── Video-Raw\         ← Recordings previos
│   ├── Audio\             ← Narraciones grabadas
│   └── Branding\          ← Logos para watermark
│
└── 03-Demos\
    ├── 01-Briefs\         ← brief.md + storyboard
    ├── 02-Assets-Generados\ ← screenshots, scripts, voz
    ├── 03-Edicion-SmartCut\ ← proyecto con recordings
    ├── 04-Renders-Finales\  ← MP4 multi-formato
    └── 05-Entregas\         ← Paquete completo
```

## Flujo Completo

### Paso 1: THINK (planificar el demo)
**Input:** Feature o funcionalidad a demostrar
**Output:** `01-Briefs/YYYY-MM-DD_[feature]/brief.md`

Responder:
- ¿Qué problema resuelve esta feature?
- ¿Cuál es el "wow moment"?
- ¿Qué NO mostrar? (evitar distracciones)
- ¿Quién es el usuario objetivo? (novato vs avanzado)
- ¿Duración ideal? (2-5 minutos recomendado)

### Paso 2: STORYBOARD
**Output:** `01-Briefs/YYYY-MM-DD_[feature]/storyboard.md`

Estructura shot-by-shot:
```
Escena 1 (0-10s): Intro — pantalla inicial, contexto
Escena 2 (10-30s): Paso 1 — navegar a la feature
Escena 3 (30-60s): Paso 2 — usar la feature principal
Escena 4 (60-90s): Paso 3 — resultado/valor obtenido
Escena 5 (90-120s): Outro — CTA o siguiente paso
```

Marcar:
- Dónde hacer zoom
- Dónde resaltar cursor
- Dónde hacer pause para énfasis

### Paso 3: SCREEN RECORDING
**Opciones:**

**A. Web (si es web app):**
- `browser_navigate` → navegar a URL
- `browser_vision` → capturar screenshots por escena
- Grabar como secuencia de screenshots + animaciones

**B. Desktop (si es app nativa):**
- Usar Recordly/Coherence Studio
- O manual: tú grabas, Hermes edita

**Output:** `02-Assets-Generados/recording-raw.mp4` o screenshots

### Paso 4: SCREENSHOTS ANOTADOS
**Tool:** `browser_vision` + anotaciones
**Output:** Screenshots con marcas de zoom y clicks

Para cada escena:
1. Screenshot de la pantalla
2. Marcar: dónde hacer click, qué elemento destacar
3. Notas de timing

### Paso 5: SCRIPT DE NARRACIÓN
**Output:** `02-Assets-Generados/script-narracion.md`

Estilo: instructivo, claro, paso a paso
```
"Primero, haz clic en el botón 'Nuevo Contrato' ubicado en la esquina superior derecha."
[Pausa 2s]
"Ahora verás el formulario de creación. Aquí puedes seleccionar el tipo de contrato..."
```

Timing marks:
- [0:05] "..."
- [0:12] "..."
- [0:25] "..."

### Paso 6: NARRACIÓN DE VOZ
**Tool:** `text_to_speech`
**Output:** `02-Assets-Generados/narracion.mp3`

Tono: claro, pausado, instructivo
Velocidad: 0.9x (más lento para tutoriales)

### Paso 7: EDICIÓN EN SMARTCUT
**Input:** Recording/screenshots + narración + script
**Output:** `03-Edicion-SmartCut/proyecto.json`

Edición:
1. Importar video/screenshots a timeline
2. Sincronizar con narración (ajustar timing)
3. Añadir zoom automático en elementos clave
4. Resaltar cursor (halo/glow effect)
5. Añadir captions karaoke-style (opcional pero recomendado)
6. Transiciones: cut directo (más limpio para tutoriales)
7. Añadir intro/outro con branding

**Efectos especiales:**
- **Zoom:** En botones importantes, resultados
- **Cursor highlight:** Glow amarillo alrededor del cursor
- **Click indicators:** Círculo que aparece en cada click
- **Text overlays:** Labels para botones o secciones

### Paso 8: CAPTIONS/SUBTÍTULOS
**Tool:** `transcribe` ( Whisper ) o generar desde script
**Output:** `02-Assets-Generados/captions.srt`

Estilo: karaoke — palabra resaltada conforme se dice
Beneficio: accesibilidad + retención en mute

### Paso 9: QUALITY GATES
Revisar:
- [ ] Audio claro, sin ruido de fondo
- [ ] Zoom no es brusco (suave in/out)
- [ ] Cursor siempre visible
- [ ] Texto legible en pantallas pequeñas
- [ ] Duración < 5 minutos (ideal: 2-3 min)

### Paso 10: RENDER MULTI-FORMATO
**Tool:** `maquina demo`
**Output:** `04-Renders-Finales/`

Versiones:
1. `demo-landscape.mp4` — 1920x1080 (tutorial YouTube)
2. `demo-portrait.mp4` — 1080x1920 (Stories, TikTok)
3. `demo-square.mp4` — 1080x1080 (feed social)

### Paso 11: ENTREGA
**Carpeta:** `05-Entregas/YYYY-MM-DD_[feature]/`

Contenido:
- `demo-[formato].mp4` (3 archivos)
- `thumbnail.png` — screenshot del momento clave + texto
- `captions.srt` — subtítulos descargables
- `script-narracion.md` — guion completo
- `chapters.txt` — timestamps para YouTube
- `embed-code.html` — código para insertar en landing

### Paso 12: ARCHIVAR
- Copiar a `99-Repositorio/YYYY-MM/Demos/`
- Actualizar dashboard
- Indexar en Onyx para búsqueda ("busca el demo de contratos")

## Comandos Rápidos

```bash
# Crear brief de demo
maquina demo --brief "[feature]" --duration 3min

# Generar storyboard
maquina demo --storyboard --feature "[descripción]"

# Editar recording existente
maquina demo --edit ./02-Assets-Generados/recording.mp4 --script ./script.md

# Añadir captions
maquina demo --captions ./04-Renders-Finales/demo.mp4

# Renderizar desde SmartCut
maquina demo --render ./03-Edicion-SmartCut/proyecto.json
```

## Diferencias con Social/Marketing
| Aspecto | Social | Marketing | Demo |
|---------|--------|-----------|------|
| Input principal | Tema/descripción | Producto + assets | Feature/software |
| Grabación | Imágenes generadas | Imágenes/video | Screen recording |
| Estilo | Rápido, trendy | Profesional, pulido | Claro, instructivo |
| Duración | 15-30s | 15-60s | 2-5 min |
| Zoom | No | No | Sí (automático) |
| Cursor | No | No | Sí (highlight) |
| Captions | Opcional | Opcional | Recomendado |
| Score viral | Sí | Opcional | No aplica |

## Tips para Demos Efectivas

1. **Una feature por demo** — No intentes mostrar todo
2. **Empieza con el resultado** — "Así se ve un contrato terminado..."
3. **Voz clara, pausada** — La gente pausa y rebobina
4. **Zoom en lo importante** — No dejes que el usuario busque
5. **Captions siempre** — Muchos ven sin sonido
6. **CTA claro al final** — "Prueba gratis", "Agenda demo", etc.

## Dependencias
- video-machine con pipeline demo
- SmartCut para edición
- Opcional: Recordly/Coherence para grabación desktop
- Opcional: OpenAI para guiones técnicos
