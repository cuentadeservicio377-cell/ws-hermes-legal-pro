---
name: ws-video-marketing
description: "Skill para crear videos promocionales de producto/servicio. Videos horizontales (16:9), cuadrados (1:1), y verticales (9:16) para landing pages, ads, y presentaciones. Toma assets del depósito, genera concepto creativo, ensambla en SmartCut, renderiza múltiples formatos, y entrega paquete completo."
version: 1.0.0
author: WS Capital
license: MIT
metadata:
  hermes:
    tags: [video, marketing, promocional, landing, ads, producto]
---

# WS Video Marketing — Videos Promocionales

## Propósito
Crear videos profesionales de marketing para productos o servicios. Multi-formato (16:9, 1:1, 9:16) para usar en landing pages, ads, y presentaciones.

## Trigger Words (cómo invocar este skill)
- "video promocional de [producto]"
- "video para la landing de [marca]"
- "spot publicitario de [servicio]"
- "video de marketing para [tema]"
- "crea un ad para [producto]"

## Estructura de Carpetas

```
C:\Users\DELL\Documents\WS-Capital\Video-Studio\
├── 00-Assets\              ← Depósito de ingredientes
│   ├── Imagenes\          ← Fotos de producto, lifestyle
│   ├── Audio\             ← Voiceovers grabados
│   ├── Music\             ← Tracks corporativos
│   └── Branding\          ← Guías de marca, logos, paletas
│
└── 02-Marketing\
    ├── 01-Briefs\         ← brief.md con concepto creativo
    ├── 02-Assets-Generados\ ← imágenes, voz, concept art
    ├── 03-Edicion-SmartCut\ ← proyecto del editor
    ├── 04-Renders-Finales\  ← MP4 en 3 formatos
    └── 05-Entregas\         ← Paquete completo
```

## Flujo Completo

### Paso 1: BRIEF CREATIVO
**Input:** Producto + descripción + objetivo de marketing
**Output:** `01-Briefs/YYYY-MM-DD_[producto]/brief.md`

Secciones del brief:
- Producto/Servicio
- Target Audience (demográfico + psicográfico)
- Diferenciador clave (USP)
- Objetivo del video (awareness, conversion, educación)
- Plataformas destino (landing, YouTube ads, Facebook, etc.)
- Duración (15s, 30s, 60s)
- Tono (corporativo, moderno, emocional, minimalista)

### Paso 2: CONCEPTO CREATIVO
**Output:** `01-Briefs/YYYY-MM-DD_[producto]/concepto.md`

Desarrollar:
- Big Idea (concepto central)
- Moodboard (referencias visuales)
- Color palette (basado en branding o generado)
- Typography (fonts de 00-Assets/Branding/ o defaults)
- Shot list (4-8 escenas)

### Paso 3: REVISAR ASSETS
**Input:** `00-Assets/Branding/[marca]/` y `00-Assets/Imagenes/`
**Output:** Lista de assets disponibles

Buscar:
- Logos en formatos vectoriales
- Fotos de producto de alta calidad
- Videos de producto existentes
- Música corporativa aprobada
- Fonts de marca

### Paso 4: GENERAR ASSETS VISUALES
**Tool:** `image_generate` nativo de Hermes (cuando disponible) o generación local
**Output:** `02-Assets-Generados/`

Generar:
- Hero image (escena principal)
- Product shots (si no hay fotos reales)
- Lifestyle scenes (contexto de uso)
- Backgrounds/abstractos para transiciones

**Prompts optimizados para marketing:**
- Estilo consistente con branding
- Iluminación profesional
- Composición centrada o rule of thirds
- Espacio para texto (safe zones)

**Para generación de assets cuando `image_generate` no está disponible:**
- Usar fotos reales del usuario + FFmpeg effects
- O generar con PIL/Python para tipografía y gráficos simples

---

### Paso 4b: FALLBACK — CUANDO FAL.AI / IMAGE_GENERATE ESTÁ AGOTADO

**Trigger:** `image_generate` devuelve `FalClientHTTPError` o "Exhausted balance"

**Estrategia "Human-First":**
Cuando la generación de imágenes por IA no está disponible, pivotar inmediatamente a usar **fotos reales del usuario/fundador**. Esto alinea con el mensaje de marca de WS Capital: *"La creatividad es para los humanos"*.

**Pasos del fallback:**

1. **Revisar assets reales disponibles**
   - Buscar en `00-Assets/Imagenes/` o carpeta de fotos del usuario
   - Identificar fotos de: familia, viajes, oficina, producto, lifestyle
   - Preferir fotos con alto valor emocional sobre stock perfectas

2. **Analizar fotos para asignación a escenas**
   - Usar `terminal` + `execute_code` (PIL) para listar dimensiones y formatos
   - Si `vision_analyze` está disponible con URLs públicas, usarlo para clasificar
   - Si no, usar nombres de archivo + dimensiones + contexto del guion

3. **Crear assets generados con PIL/Python cuando sea necesario**
   - Tipografía griega/brutalista: generar con PIL + fuentes system
   - Textos animados: crear frames con PIL, renderizar con FFmpeg
   - Efectos visuales: glitch, CRT scanlines, estática — todo con FFmpeg filters

4. **Efectos FFmpeg para estilizar fotos reales**
   ```bash
   # Glitch effect
   ffmpeg -i foto.jpg -vf "geq='random(1)*255':128:128" -frames:v 1 glitch.png
   
   # CRT scanlines
   ffmpeg -i foto.jpg -vf "drawgrid=w=iw:h=2:t=1:c=black@0.5" crt.png
   
   # Color grading estilo 80s
   ffmpeg -i foto.jpg -vf "colorbalance=rs=.3:gs=-.1:bs=.3:rm=.1:gm=-.05:bm=.1" retro.jpg
   ```

5. **Documentar la decisión en el brief**
   - Notar: "Assets generados por IA no disponibles → usando fotos reales del fundador"
   - Esto es una **feature, no un bug**: autenticidad > perfección generada

**Ventajas del enfoque Human-First:**
- Más auténtico y creíble
- Alineado con value prop de WS Capital (liberar al fundador para vivir)
- No depende de servicios externos con balance limitado
- Más rápido (no hay que esperar generación)
- Cada video es único (no hay dos fundadores iguales)

**Limitaciones:**
- Requiere que el usuario tenga fotos de calidad aceptable
- No funciona para productos físicos que aún no existen
- Menos control sobre estética exacta

### Paso 5: GUION NARRATIVO
**Estructura:**
```
Hook (0-5s): Problema o promesa
Contexto (5-15s): El producto como solución
Beneficios (15-40s): 3 beneficios clave con pruebas
CTA (40-60s): Llamado a la acción clara
```

### Paso 6: NARRACIÓN DE VOZ
**Tool:** `text_to_speech`
**Output:** `02-Assets-Generados/narracion.mp3`

Tono según marca:
- Profesional y confiable (B2B)
- Cálido y cercano (B2C lifestyle)
- Energético y moderno (tech/startups)

### Paso 7: COMPOSICIÓN EN SMARTCUT
**Input:** Assets + guion + concepto
**Output:** `03-Edicion-SmartCut/proyecto.json`

Montaje:
- Secuencia de escenas según shot list
- Timing sincronizado con narración
- Música de fondo (corporativa, no distrae)
- Lower thirds para datos clave
- Logo reveal al inicio/final
- Transiciones suaves (dissolve, slide)

### Paso 8: QUALITY GATES
Revisar antes de render:
- [ ] Slideshow risk < 0.7 (no es solo imágenes estáticas)
- [ ] Audio levels: -30dB a -3dB
- [ ] Brand consistency: colores, fonts, logo
- [ ] Resolution correcta por formato

### Paso 9: RENDER MULTI-FORMATO
**Tool:** `maquina marketing`
**Output:** `04-Renders-Finales/`

Generar 3 versiones:
1. `video-landscape.mp4` — 1920x1080 (16:9) para YouTube, landing
2. `video-square.mp4` — 1080x1080 (1:1) para Instagram, Facebook
3. `video-portrait.mp4` — 1080x1920 (9:16) para Stories, Reels ads

### Paso 10: THUMBNAIL Y SEO
**Tool:** `image_generate` nativo de Hermes (cuando disponible) para thumbnail
**Output:** `05-Entregas/`

Crear:
- Thumbnail optimizado (1280x720, contraste alto)
- Título SEO-friendly
- Descripción para YouTube
- Tags/keywords
- Script de anuncio para paid media

### Paso 11: ENTREGA FINAL
**Carpeta:** `05-Entregas/YYYY-MM-DD_[producto]/`

Contenido:
- `video-landscape.mp4`
- `video-square.mp4`
- `video-portrait.mp4`
- `thumbnail.png`
- `titulo-youtube.txt`
- `descripcion-youtube.txt`
- `tags.txt`
- `script-ads.txt` — para Facebook/Google Ads
- `brief-completo.md` — todo el concepto para futuras referencias

### Paso 12: ARCHIVAR Y REPORTAR
- Copiar a `99-Repositorio/YYYY-MM/Marketing/`
- Actualizar dashboard
- Guardar métricas si es para campaña pagada

## Comandos Rápidos

```bash
# Crear brief de marketing
maquina marketing --brief "[producto]" --duration 30 --style modern

# Generar concepto creativo
maquina marketing --concept-only --brief "[descripción]"

# Renderizar multi-formato
maquina marketing --render --formats landscape,square,portrait

# Solo thumbnail
maquina marketing --thumbnail ./04-Renders-Finales/video.mp4
```

## Creative Direction from Founder Voice (NEW — April 2026)

When the founder (Pablo) describes a video concept verbally — aesthetic, mood, messaging, personal photos — translate that voice direction into a structured production brief.

### Trigger
Pablo sends a voice message describing:
- Aesthetic ("cyberpunk", "electrónico", "visual", "rebeldía")
- Specific messaging ("la creatividad es para los humanos", "open source must win")
- Personal assets to use ("mis fotos de viajes", "screenshots del sistema")
- Emotional arc ("primero opresión, después liberación, al final aspiracional")

### Workflow: Voice → Script → Asset Map

**Step 1: Capture verbatim (do NOT interpret)**
- Save exact transcription to `pablo-voice-vault/`
- Extract key phrases Pablo uses for aesthetic, message, assets
- Do NOT translate to marketing-speak

**Step 2: Audit assets Pablo mentions**
- Search filesystem for photos, screenshots, videos he references
- Use `vision_analyze` (if available) or `terminal` + `execute_code` to catalog
- Classify each asset: person/place/object/abstract, quality level, usable for which scene

**Step 3: Map voice direction to visual parameters**

| Pablo's Words | Visual Translation |
|---------------|-------------------|
| "cyberpunk" | Glitch effects, neon text, Matrix-style code, dark backgrounds |
| "electrónico" | Synthwave music, pulsing beats, digital transitions |
| "rebeldía" | Apple 1984 homage, monochrome→color transition, bold text |
| "mis fotos de viajes" | Personal photos with overlays, glow effects, Ken Burns motion |
| "screenshots del sistema" | Dashboard interfaces, agent cards, real operational data |
| "opresión → liberación" | Cold blue monochrome → warm golden color grading |

**Step 4: Create scene-by-scene script from voice**

Template:
```
SCENE [N] — [Pablo's description]
- Time: 0:00-0:10
- Visual: [Translated from Pablo's words]
- Text/Voice: [Exact quote or paraphrase in Pablo's voice]
- Assets needed: [Specific files or generated content]
- Effects: [FFmpeg filters or PIL operations]
```

**Step 5: Identify gaps — real vs. generated assets**

| Asset Type | Source | Fallback if missing |
|------------|--------|-------------------|
| Founder photos | User's photo library | Ask user to provide |
| System screenshots | Desktop captures | Take new screenshots |
| Cyberpunk backgrounds | Generate with `image_generate` | Use PIL + code patterns |
| Music | Generate programmatically | Use royalty-free library |
| Voiceover | Founder records | Use `text_to_speech` |

**Step 6: Present to Pablo for validation**
- Show scene breakdown
- Show which assets found vs. missing
- Ask: "¿Así va la dirección? ¿Qué ajustas?"
- Do NOT produce video until Pablo validates direction

### Anti-patterns to avoid
- ❌ "Entendido, haré un video cyberpunk" → Produce without validation
- ❌ Using generic stock cyberpunk images → Use founder's real photos
- ❌ Translating Pablo's words to marketing language → Keep his exact phrases
- ❌ Skipping asset audit → Always verify what exists before promising

## Hackathon Video Production

When producing video for a hackathon (e.g., Nous Research Hermes Agent Creative Hackathon):

### Key Differences from Regular Marketing Video
1. **Meta-narrative:** The video must SHOW how Hermes was used to create it
2. **Philosophical depth:** Connect Greek mythology (Hermes, Nous, Prometeo, Daimon, Eros, Poiesis) to the message
3. **Rebellion aesthetic:** Inspired by Apple 1984 — monochrome oppression → color liberation
4. **Human-first:** When AI generation is blocked, use real founder photos as a feature, not a bug

### Structure (Apple 1984 Inspired)
- **Act I — Oppression (0-15s):** Digital noise, notifications, tasks. Monochrome cold.
- **Act II — Breakthrough (15-30s):** Founder photos enter. Color warmth. Human moments.
- **Act III — Liberation (30-50s):** Hermes operating business (show real dashboard/data). Freedom.
- **Act IV — Manifesto (50-60s):** "Creativity for humans." CTA: "Open Source must win."

### Production with Subagents
Use `delegate_task` with `acp_command="copilot"` for parallel work:
1. **Script Agent:** Narrative + philosophical copy
2. **Visual Agent:** Photo selection + storyboard
3. **Technical Agent:** PIL effects + ffmpeg assembly
4. **Audio Agent:** Synthwave music + voiceover
5. **Package Agent:** Thumbnails + social copy

### When AI Image Generation is Blocked — Proven Fallback Workflow

**Trigger:** `image_generate` fails, FAL AI returns "Exhausted balance", NVIDIA returns 404, or OpenCode Go returns 403.

**Immediate pivot:** Use real founder photos + Python/PIL effects + ffmpeg. This is a **feature, not a bug** — aligns with "Creativity is for humans."

#### Proven Production Pipeline (tested 29 Apr 2026):

**Step 1: Parallel Subagent Delegation**
Launch 3+ subagents simultaneously via `delegate_task` with `acp_command="copilot"`:
- **Director Visual:** Selects best photos from user's library, creates storyboard with scene timing
- **Technical Producer:** Writes PIL-based effects script (cold→warm transition, glow, vignette)
- **Audio Composer:** Generates synthwave music programmatically with Python (numpy + wave)

**Step 2: Apply Programmatic Effects**
Use PIL/Pillow (not OpenCV — better compatibility) for:
- `cold_monochrome()` — blue-tinted grayscale for "oppression" scenes
- `warm_golden_grade()` — golden color grading for "liberation" scenes
- `digital_liberation_frame(t)` — blend from cold to warm based on progress parameter `t` (0.0→1.0)
- `subtle_glow()` — cinematic glow with Gaussian blur + screen blend
- `cinematic_vignette()` — edge darkening with radial gradient masks

**Step 3: Extend Frames to Target Duration**
Each photo produces only 12 effect frames. To reach 60s at 30fps (1800 frames):
- Duplicate each frame N times: `12 frames × 25 repeats = 300 frames per photo = 10s per photo`
- 6 photos × 10s = 60s total
- Use `shutil.copy2()` in Python to duplicate frames with sequential naming

**Step 4: Generate Music Programmatically**
If no royalty-free music available, generate synthwave with Python:
- `numpy` for waveform synthesis (sine + square waves)
- `wave` module for WAV output
- Structure: intro (10s) → build up (20s) → climax (20s) → outro (10s)
- 44100 Hz, 16-bit, mono — compatible with ffmpeg AAC encoding

**Step 5: Assemble with ffmpeg**
```bash
# Video from frames
ffmpeg -y -framerate 30 -i frame_%05d.jpg -c:v libx264 -pix_fmt yuv420p -crf 23 video_no_audio.mp4

# Add audio
ffmpeg -y -i video_no_audio.mp4 -i music.wav -c:v copy -c:a aac -b:a 192k -shortest final.mp4
```

**Step 6: Deliver for Review**
- Export SIN VOZ first (as Pablo requested: "hazlo sin la voz, quiero verlo en video")
- Let user review visual flow, then add narration in V2

### Key Technical Parameters
- Resolution: 1080x1080 (1:1) or 1920x1080 (16:9)
- Frame rate: 30fps
- Video codec: H.264 (libx264)
- Audio codec: AAC 192kbps
- CRF: 23 (quality vs size balance)
- Output: ~5MB for 60s at 1080x1080

### Critical Lesson: Static Photos Are Not Enough
**What we learned (29 Apr 2026):** A video with only static photos + music, even with color effects, is perceived as "just a slideshow." For hackathon-level impact, you need:
1. **Motion on every frame** — Ken Burns zoom/pan, not just color transitions
2. **Scene transitions** — crossfade, glitch, or wipe between photos
3. **Text overlays** — animated text appearing/disappearing
4. **Narration or voice** — human voice > music-only
5. **Real proof points** — screenshots, data, not just aesthetic photos

**The fallback pipeline works, but needs these enhancements for next version.**

### Proof Points to Include
- Real business metrics (e.g., Paola Meneses: 152 files managed, dashboard active)
- Screenshots of Hermes operating the business
- Subagent usage in production (show `delegate_task` calls)
- Open Source philosophy alignment
- Founder photos as creative assets (not AI-generated)

### Submission Checklist
- [ ] Main video 60s (1920x1080 or 1080x1080 H.264)
- [ ] Short variants 30s, 15s
- [ ] Thumbnail 1280x720
- [ ] LinkedIn copy
- [ ] Twitter thread
- [ ] Instagram caption
- [ ] Project description (how Hermes was used)
- [ ] Demo/code links
- [ ] Documentation of fallback workflow (proves resilience)

## Diferencias con Social
| Aspecto | Social | Marketing | Hackathon |
|---------|--------|-----------|-----------|
| Formato | Solo 9:16 | 16:9 + 1:1 + 9:16 | 16:9 principal |
| Duración | 15-30s | 15-60s | 60s exacto |
| Tono | Rápido, hook-first | Profesional, narrativo | Filosófico, rebelde |
| Música | Trendy, upbeat | Corporativa, subtle | Synthwave, épica |
| Meta | Engagement | Conversion | Demostrar herramienta |
| Entrega | Copy + hashtags | SEO + ads scripts | Filosofía + proof points |

## Dependencias
- video-machine instalado
- SmartCut corriendo
- Branding assets en 00-Assets/Branding/
- Opcional: OpenAI para guiones creativos
