---
name: project-continuity
description: Sistema de continuidad de proyectos para WS Capital. Mantiene estado de proyectos activos entre sesiones de Hermes Neo.
version: 1.0.0
author: Hermes Neo
---

# Skill: Project Continuity

## Propósito
Mantener contexto y estado de proyectos activos de WS Capital entre sesiones de trabajo. Evita que cada sesión arranque "desde cero" sin saber qué proyectos están en curso, qué se hizo, y qué falta.

## Cuándo usar
- AL INICIO de cada sesión: leer PROJECTS.md para contexto
- AL CERRAR cada sesión: actualizar PROJECTS.md con estado actual
- Cuando Pablo mencione un proyecto: cargar contexto completo automáticamente
- Cuando se detecte un nuevo proyecto: agregarlo a PROJECTS.md
- Cuando el sistema parezca "olvidar" proyectos activos entre sesiones
- Cuando Pablo diga "continúa" sin especificar qué proyecto

## Archivos clave

| Archivo | Ubicación | Propósito |
|---------|-----------|-----------|
| PROJECTS.md | ~/.hermes/PROJECTS.md | Estado maestro de proyectos |
| MEMORY.md | ~/.hermes/memories/MEMORY.md | Hechos duraderos (incluye referencia a PROJECTS.md) |
| SOUL.md | ~/.hermes/SOUL.md | Identidad y capacidades |

## Protocolo de inicio de sesión

### Paso 1: Leer PROJECTS.md
```
read_file(path="~/.hermes/PROJECTS.md")
```

### Paso 2: Identificar proyectos activos
- Buscar sección "PROYECTOS ACTIVOS"
- Identificar prioridad (P1, P2, P3)
- Revisar "Qué se hizo" vs "Qué NO se hizo"

### Paso 3: Presentar contexto a Pablo
```
"Proyectos activos detectados:
- [P1] Eleutheria (hackathon) — Research completo, producción bloqueada por Fal.ai sin balance
- [P2] Paola Meneses — Dashboard :8080, operativo, pendiente verificar
- [P3] Willow Legal — Operativo en Onyx :3000

¿Continuamos con alguno o iniciamos nuevo?"
```

## Protocolo de cierre de sesión

### Paso 1: Actualizar PROJECTS.md
Para cada proyecto trabajado en la sesión:
- Agregar fecha de última sesión
- Actualizar "Qué se hizo"
- Actualizar "Qué NO se hizo / Bloqueadores"
- Actualizar "Próximos pasos"

### Paso 2: Guardar checkpoint en Obsidian
```
/mnt/c/Users/DELL/Documents/Obsidian Vault/WS Capital/Checkpoints/<fecha>.md
```

### Paso 3: Actualizar Excel PM si aplica

## Formato de entrada de proyecto

```markdown
### [Prioridad] [Nombre del Proyecto]
**Estado:** [emoji] [Estado descriptivo]
**Deadline:** [fecha]
**Departamento:** [Thread X - Nombre]
**Skill:** [skill-name]

#### Qué se hizo (sesiones previas)
- [ ] [Tarea completada]

#### Qué NO se hizo / Bloqueadores
- [ ] [Tarea pendiente] — [razón]

#### Próximos pasos
1. [Paso concreto]

#### Assets ubicados
```
[ruta a archivos]
```
```

## Reglas

1. **NUNCA borrar información** — solo actualizar estado
2. **SIEMPRE incluir rutas** — para encontrar assets rápido
3. **SIEMPRE documentar bloqueadores** — con razón específica
4. **SIEMPRE incluir deadline** — si aplica
5. **ACTUALIZAR al cerrar** — no dejar para "después"

## Proyectos activos actuales (2026-04-28)

| Proyecto | Prioridad | Estado | Deadline |
|----------|-----------|--------|----------|
| Eleutheria Hackathon | P1 | 🟡 Research OK, producción bloqueada | ~2-3 May |
| Paola Meneses | P2 | 🟢 Operativo, verificar :8080 | N/A |
| Willow Legal | P3 | 🟢 Operativo en Onyx | N/A |
| Reparación Sistema | — | ✅ Completada 28abr | N/A |

## Relación con otras skills

Esta skill se complementa con:
- **session-close-checkpoint** (software-development): Guarda el estado de la sesión al cerrar
- **project-continuity-with-vaults** (software-development): Enfoque repo-centric con CONTINUITY.md
- **ws-interconnected-ops** (productivity): Operación transversal entre departamentos

**Nota sobre overlap**: `project-continuity` (esta skill) es el **sistema maestro de estado de proyectos** para WS Capital. `project-continuity-with-vaults` es un enfoque más general de continuidad para proyectos largos con repos. Ambas coexisten: esta skill maneja el estado macro de WS Capital, la otra maneja continuidad granular de proyectos individuales.

## Lección aprendida: Por qué se creó esta skill

**Problema original (2026-04-28):**
El sistema Hermes Neo estaba completamente reparado (config, auth, subagentes, skills) pero cada sesión nueva "olvidaba" los proyectos activos. Pablo mencionaba el hackathon Eleutheria y Paola Meneses, pero el sistema actuaba como si no supiera de qué hablaba.

**Causa raíz:**
1. SOUL.md tenía versiones inconsistentes entre sesiones (cacheado vs. actual)
2. MEMORY.md no incluía estado de proyectos activos
3. No existía mecanismo para mantener continuidad entre sesiones de trabajo

**Solución implementada:**
1. Crear `~/.hermes/PROJECTS.md` como estado maestro
2. Actualizar `MEMORY.md` con referencia a PROJECTS.md
3. Crear esta skill con protocolo de inicio/cierre

**Resultado:**
Ahora el sistema puede reconstruir contexto de proyectos al inicio de cada sesión sin depender de que la memoria inyectada "recuerde" todo.

## Troubleshooting

**Problema**: PROJECTS.md no se lee automáticamente
**Solución**: Verificar que MEMORY.md incluya referencia a PROJECTS.md

**Problema**: Proyecto no aparece en lista
**Solución**: Agregar manualmente con formato estándar

**Problema**: Estado desactualizado
**Solución**: Forzar actualización al cerrar sesión con session-close-checkpoint
