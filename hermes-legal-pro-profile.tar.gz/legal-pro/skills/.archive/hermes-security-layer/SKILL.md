---
name: hermes-security-layer
title: Hermes Security Layer v1.0.0
description: Capa de seguridad nativa de Hermes — auditoría, OSINT, detección de leaks, hardening. Incluida en todos los clones.
category: security
version: 1.0.0
created: 2026-04-25
author: Hermes Neo
---

# Hermes Security Layer

## Overview

Capa de seguridad nativa integrada en Hermes. No es producto para vender — es feature de todos los clones de Hermes.

> "La mayoría de los asistentes AI no incluyen capacidades de seguridad. Hermes sí."

## Estructura

```
~/hermes-core/security/
├── __init__.py
├── __main__.py          # CLI: python -m security [comando]
├── config.py            # Configuración central
├── utils.py             # Helpers comunes
├── system_auditor.py    # Phase 1: Defensa (Lynis, rootkits)
├── osint_scanner.py     # Phase 2: OSINT (theHarvester, amass)
├── secret_scanner.py    # Phase 3: Secret leaks (TruffleHog, Gitleaks)
├── breach_checker.py    # Phase 3: Breaches (HaveIBeenPwned)
├── report_generator.py  # Phase 4: Reportes automáticos
├── hardening.py         # Phase 4: Hardening para nuevos clones
├── cron_setup.py        # Phase 5: Automatización
└── README.md
```

## Comandos CLI

```bash
python -m security report        # Reporte completo
python -m security audit         # Auditar sistema
python -m security osint <domain> # OSINT sobre dominio
python -m security leak-check    # Verificar fugas de datos
python -m security harden        # Hardening del sistema
python -m security cron          # Instalar cron semanal
```

## Herramientas incluidas (52 de 180 auditadas)

### GREEN (incluidas)
- **Defensa:** lynis, chkrootkit, rkhunter, fail2ban, ufw, auditd
- **OSINT:** theHarvester, amass, sublist3r, dnsrecon, whatweb
- **Secretos:** truffleHog, gitleaks, gitLeaks
- **Red:** nmap, masscan
- **Web:** nikto, wpscan, sqlmap (modo defensivo)
- **Forense:** autopsy, sleuthkit
- **Móvil:** apktool, jadx
- **Wireless:** aircrack-ng, wifite, reaver
- **Exploit:** searchsploit (solo búsqueda, no ejecución)

### RED (excluidas permanentemente)
- Phishing: PyPhisher, AdvPhishing, Setoolkit, Zphisher, HiddenEye, SocialFish, ShellPhish, BlackPhish
- RATs: Storm-Breaker, SayCheese, Grabcam
- DDOS: Slowloris, Hulk, DDOS-Attack
- Keyloggers: Keylogger, BeeLogger
- Anonimato ofensivo: AnonSMS

### YELLOW (evaluar caso por caso)
- SQLMap (solo modo defensivo/auditoría propia)
- XSS tools (solo testing propio)
- Striker, XSSStrike (bajo supervisión)

## WSL Limitaciones

| Tool | Estado | Nota |
|---|---|---|
| Lynis | ✅ Full | Funciona perfecto |
| chkrootkit | ✅ Full | Funciona perfecto |
| rkhunter | ⚠️ Parcial | Necesita `WEB_CMD=""` en config |
| fail2ban | ✅ Full | Funciona perfecto |
| ufw | ⚠️ Parcial | Solo tráfico WSL↔WSL |
| auditd | ❌ No | No soportado en WSL |

**Recomendación producción:** Migrar a Linux nativo o VM para full hardening.

## Integración con Proviq Management

- Security Layer = proyecto completado en Excel v2
- Status: PRODUCTION
- Próxima fase: Cloud Security (Prowler, ScoutSuite)

## Repositorio

- **Git:** `~/hermes-core/` (rama main)
- **Skill:** `~/.hermes/skills/hermes-security/SKILL.md`
- **Docs:** `~/ws-capital/security/`

## Historial

- 2026-04-25: v1.0.0 — Implementación completa 5 fases
- 2026-04-25: Clasificación 180 tools de hackingtool
- 2026-04-25: Integración con Proviq Management
