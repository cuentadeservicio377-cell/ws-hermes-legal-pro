---
name: ws-excel-pm-design
description: "Diseño profesional de Excel para Project Management de WS Capital. Dashboard visual, semáforos, navegación tipo app, formato condicional, colores corporativos."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [excel, design, pm, dashboard, ws, visual]
---

# WS Excel PM Design

Diseño visual profesional para Excel de Project Management de WS Capital.

## Paleta Corporativa WS Capital

| Color | Hex | Uso |
|-------|-----|-----|
| Ink Blue | #1B365D | Headers principales, títulos |
| Corporate Blue | #2F5496 | Headers secundarios |
| Success Green | #548235 | Completado, activo, ok |
| Warning Yellow | #FFC000 | En progreso, pendiente |
| Alert Red | #C00000 | Bloqueado, vencido, crítico |
| Light Gray | #F2F2F2 | Fondos alternos |
| White | #FFFFFF | Fondo principal |
| Dark Text | #333333 | Texto principal |
| Light Blue | #D9E2F3 | Fondos de KPIs |

## Estructura Visual

### Dashboard tipo App
```
┌─────────────────────────────────────────────┐
│  WS CAPITAL PM          [fecha]   [status]  │
├─────────────────────────────────────────────┤
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐           │
│  │KPI 1│ │KPI 2│ │KPI 3│ │KPI 4│   Cards   │
│  │ 42  │ │  7  │ │  3  │ │  1  │           │
│  └─────┘ └─────┘ └─────┘ └─────┘           │
├─────────────────────────────────────────────┤
│  ESTADO POR ÁREA                            │
│  🟢 Dirección    🟡 Build    🔴 Growth      │
│  🟢 Jurídico     🟡 Admin    🟢 Ventas      │
├─────────────────────────────────────────────┤
│  NAVEGACIÓN RÁPIDA                          │
│  [Proyectos] [Tareas] [Clientes] [Ideas]    │
└─────────────────────────────────────────────┘
```

### Tablas con Semáforos

Estados visuales:
- 🟢 Hecho / Activo / Completado → Verde
- 🟡 En progreso / Pendiente / Backlog → Amarillo
- 🔴 Bloqueado / Vencido / Cancelado → Rojo

Formato condicional automático en columnas de estado.

### Navegación entre Hojas

Hyperlinks en dashboard para saltar a:
- Proyectos
- Tareas
- Clientes
- Ideas
- Handoffs
- Actividades

### Hojas de Datos

Cada hoja de datos tiene:
- Header con color corporativo
- Filtros automáticos (AutoFilter)
- Bordes limpios
- Altura de fila consistente
- Ancho de columna optimizado
- Formato condicional en estado

## Implementación openpyxl

### Estilos base
```python
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# Fills
FILL_HEADER = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
FILL_SUCCESS = PatternFill(start_color="548235", end_color="548235", fill_type="solid")
FILL_WARNING = PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid")
FILL_ALERT = PatternFill(start_color="C00000", end_color="C00000", fill_type="solid")
FILL_LIGHT = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
FILL_KPI = PatternFill(start_color="D9E2F3", end_color="D9E2F3", fill_type="solid")

# Fonts
FONT_TITLE = Font(name="Calibri", size=16, bold=True, color="1B365D")
FONT_HEADER = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
FONT_KPI_BIG = Font(name="Calibri", size=24, bold=True, color="1B365D")
FONT_NORMAL = Font(name="Calibri", size=10, color="333333")

# Alignment
ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
ALIGN_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)

# Border
BORDER_THIN = Border(
    left=Side(style='thin', color='CCCCCC'),
    right=Side(style='thin', color='CCCCCC'),
    top=Side(style='thin', color='CCCCCC'),
    bottom=Side(style='thin', color='CCCCCC')
)
```

### Formato condicional para estados
```python
from openpyxl.formatting.rule import CellIsRule

# Verde para "Hecho", "Completado", "Activo"
ws.conditional_formatting.add('E2:E100',
    CellIsRule(operator='equal', formula=['"Hecho"'], fill=FILL_SUCCESS))

# Amarillo para "En progreso", "Pendiente"
ws.conditional_formatting.add('E2:E100',
    CellIsRule(operator='equal', formula=['"En progreso"'], fill=FILL_WARNING))

# Rojo para "Bloqueado", "Vencido"
ws.conditional_formatting.add('E2:E100',
    CellIsRule(operator='equal', formula=['"Bloqueado"'], fill=FILL_ALERT))
```

### Hyperlinks de navegación
```python
ws['A10'] = "Ir a Proyectos"
ws['A10'].hyperlink = "#'Proyectos'!A1"
ws['A10'].font = Font(color="2F5496", underline="single")
```

## Reglas de diseño

1. **Dashboard primero.** Siempre la hoja 1 es Dashboard.
2. **KPIs visibles.** Números grandes, colores claros.
3. **Semáforos consistentes.** Mismo significado en todas las hojas.
4. **Navegación clara.** Siempre poder volver al dashboard.
5. **Filtros activos.** En todas las tablas de datos.
6. **Colores corporativos.** Solo la paleta definida.
7. **Espacio en blanco.** No saturar. Aire entre secciones.
8. **Fechas visibles.** Última actualización siempre visible.

## Pitfall: Emoji en nombres de hoja

Si usas emojis en los nombres de hoja (ej: `📁 Proyectos`, `✅ Tareas`), **todos los scripts que lean el Excel deben usar el nombre exacto con emoji**:

```python
# ❌ ERROR — KeyError
ws = wb["Proyectos"]

# ✅ CORRECTO
ws = wb["📁 Proyectos"]
```

Alternativa: mantener nombres sin emoji en scripts que necesiten compatibilidad robusta, o centralizar los nombres de hoja en constantes:

```python
SHEETS = {
    "proyectos": "📁 Proyectos",
    "tareas": "✅ Tareas",
    "clientes": "👥 Clientes",
    "ideas": "💡 Ideas",
    "handoffs": "🔄 Handoffs",
    "actividades": "📅 Actividades",
}
ws = wb[SHEETS["proyectos"]]
```

## Estructura completa de hojas (v2 real — WS Capital general)

| Orden | Hoja | Emoji | Función |
|-------|------|-------|---------|
| 1 | Instrucciones | 📖 | Guía de uso para el usuario |
| 2 | Dashboard | 📊 | KPI cards + estado por área + navegación |
| 3 | Resumen_Areas | 🏢 | Visibilidad transversal de departamentos |
| 4 | Clientes | 👥 | CRM |
| 5 | Proyectos | 📁 | Proyectos con progreso y deadlines |
| 6 | Tareas | ✅ | Tareas con formato condicional |
| 7 | Ideas | 💡 | Brain-dumps capturados |
| 8 | Actividades | 📅 | Actividades recurrentes por área |
| 9 | Seguimiento_Semanal | 📈 | Reporte semanal de cumplimiento |
| 10 | Handoffs | 🔄 | Transferencias entre departamentos |

## Estructura para Firma Legal / Willow (v3)

Para despachos jurídicos, usar esta estructura de 12 hojas que integra control de documentos legales, agentes Onyx, y seguimiento de Motor Kami:

| Orden | Hoja | Qué controla | Campos clave |
|-------|------|-------------|--------------|
| 1 | 🏠 Inicio | Navegación + reglas del sistema | Índice, reglas importantes |
| 2 | 📊 Dashboard | KPIs ejecutivos | Matters activos, clientes, docs, plazos, cobranza, aprobaciones, agentes, docs Kami |
| 3 | ⚖️ Matters | Todos los asuntos/casos | MAT-ID, CLI-ID, área, estado, fase, honorarios, saldo, plazos, engagement, faltantes, próximo paso |
| 4 | 👥 Clientes | Directorio + conflictos de interés | CLI-ID, RFC, industria, contactos, matters totales, honorarios, saldo, conflictos |
| 5 | 📄 Documentos | Tracking de todos los docs generados | DOC-ID, tipo, estado, versiones, fechas (creación, envío, firma), motor usado, ruta |
| 6 | ⏰ Plazos | Deadlines judiciales y contractuales | PLZ-ID, tipo, fecha límite, días restantes, prioridad, es judicial, juzgado, alertas (7/3/1 días) |
| 7 | 💰 Cobranza | Pagos y facturación | COB-ID, concepto, monto, factura, fechas, estado, método, intereses moratorios, días retraso |
| 8 | 🤖 Agentes | Actividad de agentes Onyx | AGT-ID, rol, matter asignado, tarea actual, issues, aprobaciones, docs generados, eficiencia % |
| 9 | ✅ Aprobaciones | Estados de approval | APR-ID, tipo (10 tipos), solicitado por, revisor, estado, payload JSON, impacto |
| 10 | 📚 Biblioteca | Plantillas y lecciones | BIB-ID, key, área, materia, versión, lecciones, usos, estado, ruta |
| 11 | 🎨 Contratos Kami | Registro de docs generados por Motor Kami | KAM-ID, plantilla usada, validación sustancia, elementos válidos, palabras, errores, ruta PDF/HTML |
| 12 | ⚙️ Configuración | Parámetros del sistema | Máximo palabras, metáforas prohibidas, intereses moratorios, alertas plazos, rutas físicas |

### Generación automática (Python)

```python
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation

wb = Workbook()

# Kami color palette
INK_BLUE = "1B365D"
PARCHMENT = "F5F4ED"
NEAR_BLACK = "1A1A18"
STONE = "87867F"
header_fill = PatternFill(start_color=INK_BLUE, end_color=INK_BLUE, fill_type="solid")
header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
alt_fill = PatternFill(start_color=PARCHMENT, end_color=PARCHMENT, fill_type="solid")
thin_border = Border(
    left=Side(style='thin', color="E8E6DC"),
    right=Side(style='thin', color="E8E6DC"),
    top=Side(style='thin', color="E8E6DC"),
    bottom=Side(style='thin', color="E8E6DC")
)

def create_sheet(wb, title, headers, validations=None):
    ws = wb.create_sheet(title)
    # Header row
    for i, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=i, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = thin_border
    # Auto-filter + freeze
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}1"
    ws.freeze_panes = "A2"
    # Validations
    if validations:
        for col_letter, options in validations.items():
            dv = DataValidation(type="list", formula1=f'"{options}"', allow_blank=True)
            ws.add_data_validation(dv)
            dv.add(f"{col_letter}2:{col_letter}1000")
    return ws

# Create each sheet with headers and validations
matters_ws = create_sheet(wb, "⚖️ Matters", [
    "MAT-ID", "CLI-ID", "Cliente", "Área", "Estado", "Fase operativa",
    "Tipo de asunto", "Descripción", "Honorarios pactados", ...
], {
    "E": "prospecto,activo,en_proceso,cerrado,cancelado,archivado",
    "D": "mercantil,laboral,civil,corporativo,fiscal,privacidad,litigios",
    "F": "consolidacion,intake,documental,procesal,cobranza,admin,cierre",
})

# Add data rows, set column widths, add formulas for Dashboard KPIs
# ... (see full script in WillowLegal/02_Administracion/build script)

wb.save("Centro_Operativo_Maestro.xlsx")
```

### Integration with Kami Document Engine

The "🎨 Contratos Kami" sheet must track every document generated by the Motor Kami:

| KAM-ID | MAT-ID | Validación sustancia | Elementos válidos | Palabras | Errores | Ruta PDF |
|--------|--------|---------------------|-------------------|----------|---------|----------|
| KAM-001 | MAT-001 | NO (v1) | — | — | Metáforas, estructura incompleta | .../v1.pdf |
| KAM-002 | MAT-001 | SÍ (v2) | 13/13 | ~2000 | Ninguno | .../v2.pdf |

This creates an audit trail showing the evolution of each document and why earlier versions were rejected.
## Dashboard: layout real usado

### Barra superior
- Título grande: "WS CAPITAL — Project Management Dashboard"
- Subtítulo: fecha de última actualización + estado de conexión

### KPI Cards (2 filas x 4 columnas mergeadas)
- Cada KPI = label + número grande + color
- Fórmulas Excel: `=COUNTA(...)`, `=COUNTIF(...)`
- Colores: azul corporativo para clientes, verde para activos, amarillo para pendientes, rojo para bloqueos

### Estado por Área (2 columnas de 3 áreas cada una)
- Emoji de semáforo + nombre de área + nota corta
- Colores alternados para legibilidad

### Navegación Rápida (botones con hyperlink)
- Botones tipo pill: `[🏢 Resumen Áreas]` `[👥 Clientes]` `[📁 Proyectos]` ...
- Cada botón = celda mergeada con hyperlink a otra hoja
- Estilo: fondo gris claro, texto azul subrayado, borde sutil

### Bloqueos Destacados
- Sección roja al final del dashboard
- Tabla con: Área | Proyecto | Bloqueo | Desde | Acción
- Header rojo para llamar atención

## Formato condicional completo (v2)

```python
from openpyxl.formatting.rule import CellIsRule

def apply_conditional_formatting(ws, col_range):
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Hecho"'], fill=FILL_SUCCESS))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Completado"'], fill=FILL_SUCCESS))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Activo"'], fill=FILL_SUCCESS))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"En progreso"'], fill=FILL_WARNING))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Pendiente"'], fill=FILL_WARNING))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Backlog"'], fill=FILL_WARNING))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Bloqueado"'], fill=FILL_ALERT))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Vencido"'], fill=FILL_ALERT))
    ws.conditional_formatting.add(col_range,
        CellIsRule(operator='equal', formula=['"Cancelado"'], fill=FILL_ALERT))
```

## Botones de navegación con merge

```python
def add_nav_link(ws, cell, text, sheet_name):
    ws[cell] = text
    ws[cell].hyperlink = f"#'{sheet_name}'!A1"
    ws[cell].font = Font(name="Calibri", size=11, bold=True, 
                          color="2F5496", underline="single")
    ws[cell].alignment = Alignment(horizontal="center", vertical="center")
    ws[cell].border = Border(
        left=Side(style='thin', color='CCCCCC'),
        right=Side(style='thin', color='CCCCCC'),
        top=Side(style='thin', color='CCCCCC'),
        bottom=Side(style='thin', color='CCCCCC')
    )
    ws[cell].fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

# Uso: botón de 2 columnas de ancho
add_nav_link(ws, 'A16', '📁 Proyectos', '📁 Proyectos')
ws.merge_cells('A16:B16')
```

## User preference: local Excel over SaaS

En WS Capital, el usuario prefiere **Excel local** sobre herramientas SaaS como Linear, Notion, Monday, etc. Razones:
- Cero cuentas externas
- Control total de los datos
- Edición directa por el usuario
- Hermes lee/escribe vía scripts Python (openpyxl)
- Exportable y portable

Cuando el usuario pida "PM tooling", proponer Excel local primero.

## Actualización

Cuando se actualiza el Excel:
1. Preservar formato visual
2. Actualizar datos manteniendo estilos
3. Recalcular KPIs
4. Actualizar timestamp
5. Verificar que los nombres de hoja con emoji siguen funcionando en scripts
