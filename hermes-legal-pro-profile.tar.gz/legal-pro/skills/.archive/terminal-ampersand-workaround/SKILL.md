---
name: terminal-ampersand-workaround
description: "Workaround for terminal tool parsing ampersands (&) inside Python strings as background operators."
version: 1.0.0
author: Hermes Neo
---

# Terminal Ampersand Workaround

## Problem

The `terminal` tool's parser interprets `&` characters inside Python code (even within strings or f-strings) as shell background operators (`&`). This causes the tool to reject the command with:

```
Foreground command uses '&' backgrounding. Use terminal(background=true) for long-lived processes.
```

This happens even when `&` is inside a quoted string, f-string, or list comprehension.

## Affected Patterns

```python
# ❌ FAILS — & inside f-string
python3 -c "print(f'Hello {name}')"

# ❌ FAILS — & inside list comprehension condition
python3 -c "for cmd in COMMAND_REGISTRY if any(x in desc for x in ['session', 'history']):"

# ❌ FAILS — & in regex or string operations
python3 -c "import re; re.search(r'a&b', text)"
```

## Workaround: Write to File First

Instead of inline `python3 -c "..."`, write the script to a temporary file and execute it:

```bash
# 1. Write script to /tmp
cat > /tmp/script.py << 'EOF'
from hermes_cli.commands import COMMAND_REGISTRY
for cmd in COMMAND_REGISTRY:
    print(f"/{cmd.name} - {cmd.description}")
EOF

# 2. Execute
python3 /tmp/script.py
```

Or use the `write_file` tool, then `terminal` to run it:

```python
# Step 1: write_file
tmp_script = """
from hermes_cli.commands import COMMAND_REGISTRY
for cmd in COMMAND_REGISTRY:
    print(f'/{cmd.name} - {cmd.description}')
"""
# write_file(path="/tmp/list_cmds.py", content=tmp_script)

# Step 2: terminal
# terminal(command="python3 /tmp/list_cmds.py")
```

## Alternative: Use Single Quotes + Escape

If the script is very short, use single quotes for the outer shell and double quotes inside:

```bash
python3 -c 'print("Hello & World")'   # ✅ Works
```

But this breaks quickly with complex Python (nested quotes, f-strings with variables).

## Best Practice

**For any Python script longer than 2 lines or containing `&`, `|`, `$`, or backticks: always write to a file first.**

This is more reliable, readable, and avoids parser edge cases entirely.

## Related

- `hermes-agent` skill — for Hermes-specific commands and features
