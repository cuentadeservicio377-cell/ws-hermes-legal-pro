# WS Brain Dump Template

## Source
- Date:
- Source type: voice / text / mixed
- Topic:

## What I understood

## Key points
- 
- 
- 

## Business structure
- Company / brand:
- Customer type:
- Current offering:
- Repeated operational patterns:
- Internal vs client version:

## Reusable assets
- Templates:
- Automations:
- Agents:
- Reusable modules:

## Gaps / questions
- 
- 
- 

## Next step
- 

## Memory candidates
- 
- 
- 
