---
name: ws-brain-dump
description: "Capture, structure, and evolve WS / WS Capital brain dumps into business models, project inventories, reusable templates, and concrete next steps."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [brain-dump, business, ws, aws-capital, strategy, templates, planning]
---

# WS Brain Dump

Use this skill when the user sends messy, repeated, partial, or voice-transcribed ideas about WS / WS Capital and wants them turned into structured business thinking.

## Goal

Convert raw thoughts into durable structure:
- what WS is
- what the business is trying to do
- which projects exist
- what can be reused as templates
- what should become agents/automation
- what should be built next
- what should be documented or remembered
- what should be turned into a reusable business model or portfolio map

## Typical inputs

- voice notes
- rambling text
- repeated ideas with more detail each time
- half-formed product ideas
- lists of clients, projects, services, or systems
- business strategy mixed with execution details

## Working method

When a WS brain dump arrives:

1. **Extract the core intent**
   - What is the user trying to achieve?
   - What business line, client, or project is being discussed?

2. **Separate signal from noise**
   - Identify repeated ideas
   - Identify new facts
   - Identify assumptions
   - Identify missing information

3. **Classify the content**
   - business model
   - product/service
   - internal tool
   - client need
   - operational workflow
   - template candidate
   - agent/automation candidate
   - open question

4. **Structure it**
   - portfolio map
   - project inventory
   - reusable template map
   - internal vs client version
   - next-step list

5. **Evolve it**
   - detect patterns that repeat across dumps
   - propose what should become a skill, doc, memory, or project

## Intake protocol

Treat the dump as one of these forms:
- raw voice note
- messy thought stream
- repeated clarification
- business idea
- project inventory
- client need
- execution problem

If the same idea repeats, interpret repetition as refinement, not duplication.
If multiple topics are mixed together, split them into separate buckets.

## Output format

Prefer this structure:

### 1. What I understood
Short summary in plain language.

### 2. Key points
Bullets with the most important facts.

### 3. Business structure
- company / lab / brand
- customer type
- current offerings
- repeated operational patterns
- internal vs client distinction
- if relevant, separate the general thesis from each vertical thesis

### 4. Reusable assets
- templates
- automations
- agents
- reusable modules
- workflows that should become standard
- if the topic is growth/marketing, identify campaign templates, audience notes, problem notes, and anti-genericity rules as reusable assets

### 5. Gaps / questions
What is still unclear or missing.

### 6. Next step
The single most useful next action.

### 7. Capture note
If the user is building a long-term business system, suggest whether this should become:
- memory
- a local note
- a project doc
- a new skill

### 8. Vault handling and routing
When the dump creates durable system memory, route it explicitly instead of letting everything fall into one vault.

#### Growth Vault handling (when relevant)
If the dump contains founder strategy, market positioning, campaign ideas, or repeated voice-note insights:
- store the durable parts in Obsidian
- create/refresh a thesis note
- create audience/problem notes before writing final campaigns
- use anti-genericity rules to block buzzword-driven outputs
- keep the Growth Vault as the commercial memory layer

#### System Vault handling (when relevant)
If the dump changes how WS Capital / Hermes should be understood as a system:
- update/create notes for objective, system map, principles, capabilities, methodology, backlog, and priorities
- keep explicit backlog notes for unresolved structural work (for example: project/system notes, formalizing extraction methodology, session logging/linking)
- if future capture conventions are still immature, keep that backlog in System first instead of scattering it
- if the dump introduces new observability/checkpoint rules or shared-memory ideas, capture them as system-layer changes first before patching individual lanes

#### Build Vault handling (when relevant)
If the dump points toward software, research, writer, builder, delivery, or implementation memory:
- capture it in Build Vault instead of mixing it into Growth or generic system notes
- prefer a starter tree that includes software, research, writer, builder, delivery, handoffs, and build backlog/build notes
- keep Build as the durable memory layer for construction and delivery, not just repo state

## Note-taking rule

If the input looks like a durable business idea, prepare it as if it could later be stored in Obsidian or a project note:
- concise title
- clear bullets
- links to related concepts
- explicit next step

## Rules

- Do not over-explain when the user wants structure.
- Keep the business meaning intact.
- Prefer clarity over elegance.
- If the user repeats ideas, treat repetition as refinement, not noise.
- Store durable patterns as skills, docs, or notes when they clearly recur.
- When the problem is a multi-step business/system design, outline it in bite-sized steps before proposing changes.
- Treat WS as a living system: the model should improve with each dump.
- If a brain dump changes the operating picture beyond the immediate topic, derive a system-wide backlog instead of leaving the insight trapped in the current lane. A founder dump can affect Growth, contract docs, methodology, offer design, and future capabilities at the same time.
- When the dump is about WS / Neo system architecture, do **not** collapse it into a lightweight org chart or generic bullets too early.
- Preserve dense structural distinctions when they matter, especially:
  - Hermes as control plane / orchestrator
  - Onyx as document / knowledge / retrieval layer
  - vertical surfaces (for example Willow) as distinct from the control plane
  - departments/areas as operational units with boundaries, handoffs, and sessions
- If Onyx is part of the user's architecture, keep it explicit in the model instead of treating it as an optional afterthought.
- For architecture dumps, prefer a serious system-design document over a simplified summary. The output should capture layers, authority, interfaces, handoffs, memory routing, and what is intentionally deferred.

## Best use

Use this skill to build a shared operating picture for:
- WS Capital strategy
- project organization
- reusable product templates
- internal vs client systems
- agentic workflows and automation roadmaps
- knowledge capture from repeated voice notes

## Growth-specific capture pattern
When the brain dump is about growth, positioning, or marketing:
1. recover the founder signal from the audio/session first
2. write or update durable notes in the Growth Vault
3. separate thesis / audiences / problems / campaigns / verticals / experiments
4. apply anti-genericity rules before drafting any final copy
5. keep campaign architecture as general + vertical, not one blob
6. if Paola or another vertical is a proof case, treat it as a thesis example rather than the whole company
