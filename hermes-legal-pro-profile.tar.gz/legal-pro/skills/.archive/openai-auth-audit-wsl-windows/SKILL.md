---
name: openai-auth-audit-wsl-windows
description: Audit and separate OpenAI/Codex auth across Hermes, OpenCode, and Windows Codex on a WSL+Windows machine. Use when multiple ChatGPT/Codex accounts may be mixed or duplicated and you need to map which account is active where before rotating or reauthing.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [openai, codex, opencode, hermes, auth, wsl, windows, account-audit]
---

# OpenAI Auth Audit on WSL + Windows

Use this skill when:
- Hermes and OpenCode seem to be consuming the same OpenAI/Codex account unexpectedly
- the user says there are multiple OpenAI accounts on the computer
- you need to identify which account is active in Hermes vs OpenCode vs Windows Codex
- you want to assign one account to Hermes, one to OpenCode, and another as fallback

## Goal

Map actual account usage before changing auth.
Do not assume that multiple credentials mean multiple accounts.
A duplicated OAuth credential may still point to the same ChatGPT account.

## High-value lesson

On this environment, Hermes can show multiple `openai-codex` credentials in `~/.hermes/auth.json` that are actually the **same account**. The reliable discriminator is the decoded JWT payload (`chatgpt_account_id` / profile email), not the credential label.

Also, Windows Codex keeps its own auth state under `C:\Users\<USER>\.codex\auth.json` and backup auth files. Those may reveal additional accounts that are not currently wired into Hermes or OpenCode.

## Audit order

### 1. Hermes auth pool

Check live Hermes auth:

```bash
hermes auth list
hermes config show
```

Then inspect `~/.hermes/auth.json` safely without printing tokens:

```bash
python3 - <<'PY'
import json
from pathlib import Path
obj=json.loads(Path('/root/.hermes/auth.json').read_text())
for provider, creds in obj.get('credential_pool', {}).items():
    print(f'PROVIDER {provider} count={len(creds)}')
    for i,c in enumerate(creds,1):
        print(i, {k:c.get(k) for k in ['label','source','priority','last_refresh','id']})
PY
```

### 2. Decode Hermes OpenAI Codex JWTs

Do this to determine whether the credentials are truly different accounts:

```bash
python3 - <<'PY'
import json, base64
from pathlib import Path
obj=json.loads(Path('/root/.hermes/auth.json').read_text())
creds=obj.get('credential_pool',{}).get('openai-codex',[])
for i,c in enumerate(creds,1):
    tok=c['access_token']
    part=tok.split('.')[1]
    part += '='*((4-len(part)%4)%4)
    payload=json.loads(base64.urlsafe_b64decode(part))
    auth=payload.get('https://api.openai.com/auth',{})
    prof=payload.get('https://api.openai.com/profile',{})
    print({
      'index': i,
      'label': c.get('label'),
      'account_id': auth.get('chatgpt_account_id'),
      'plan': auth.get('chatgpt_plan_type'),
      'email': prof.get('email'),
    })
PY
```

If `account_id` and email match, they are the same account even if labels differ.

### 3. OpenCode auth store

Inspect OpenCode auth in WSL:

```bash
python3 - <<'PY'
import json
from pathlib import Path
obj=json.loads(Path('/root/.local/share/opencode/auth.json').read_text())
print(obj.get('openai'))
print(obj.get('nvidia'))
PY
```

Key fact: `accountId` in OpenCode can be compared against the decoded Hermes `chatgpt_account_id`.

Also verify OpenCode health:

```bash
opencode --version
opencode providers list
opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'
```

### 4. Windows Codex auth store

Search Windows-side Codex files from WSL:

```bash
find /mnt/c/Users/<USER>/.codex -maxdepth 2 -type f | sed -n '1,120p'
```

Important files:
- `/mnt/c/Users/<USER>/.codex/auth.json`
- `/mnt/c/Users/<USER>/.codex/auth.before-new-login.*.json`
- backup auth files inside `.codex/.../auth.json`

Read them carefully and decode the JWT payload the same way to get:
- `account_id`
- email
- plan

Example:

```bash
python3 - <<'PY'
import json, base64
from pathlib import Path
files=[
 '/mnt/c/Users/DELL/.codex/auth.json',
 '/mnt/c/Users/DELL/.codex/auth.before-new-login.20260418_151252.json',
]
for path in files:
    obj=json.loads(Path(path).read_text())
    tok=obj['tokens']['access_token']
    part=tok.split('.')[1]
    part += '='*((4-len(part)%4)%4)
    payload=json.loads(base64.urlsafe_b64decode(part))
    auth=payload.get('https://api.openai.com/auth',{})
    prof=payload.get('https://api.openai.com/profile',{})
    print(path)
    print(' account_id=', obj['tokens'].get('account_id'))
    print(' email=', prof.get('email'))
    print(' plan=', auth.get('chatgpt_plan_type'))
PY
```

## What was learned in this environment

Actual findings from this machine:
- Hermes initially had multiple `openai-codex` credentials, but two of them decoded to the same account (`tpzb99@gmail.com`, plan `plus`)
- One Hermes credential was mislabelled as `regina939ph@gmail.com` while its JWT still decoded to `tpzb99@gmail.com`; labels are not trustworthy unless validated against decoded payloads
- OpenCode also used the same TPZB account via `accountId`, so Hermes and OpenCode were unintentionally sharing one OpenAI account
- Windows Codex `.codex/auth.json` revealed the active account `tpzb99@gmail.com`
- Windows Codex backup auth files revealed another account: `juanjosenarvaezcarrillo@gmail.com`
- After reauth, Hermes successfully obtained a real Regina credential (`regina939ph@gmail.com`) with a distinct `chatgpt_account_id`
- The final working split on this machine became:
  - Hermes primary = `regina939ph@gmail.com`
  - Hermes fallback = `juanjosenarvaezcarrillo@gmail.com`
  - OpenCode = `tpzb99@gmail.com`
- When cleaning Hermes auth manually, you must update both layers in `~/.hermes/auth.json`:
  - `credential_pool.openai-codex`
  - `providers.openai-codex.tokens`
  Otherwise the pool can look correct while provider-level active tokens still point to the wrong account
- To make Hermes actively use a fallback credential that is already present in the pool (without reauth), the reliable method in this environment was:
  1. back up `/root/.hermes/auth.json`
  2. move the desired credential to index `#1` in `credential_pool.openai-codex`
  3. rewrite `priority` fields to match the new order
  4. copy that first credential into `providers.openai-codex.tokens`
  5. verify with `hermes auth list openai-codex`
  6. verify again by decoding the active provider token or running a tiny `hermes chat` smoke test
- Simply having the fallback listed as credential `#2` is not enough to make it active; Hermes follows the provider-level active token plus the pool ordering.
- If you import a fallback credential from Windows Codex backup into Hermes, preserve the original Windows auth file and mark the imported source clearly (for example `imported:windows-codex-backup`)
- After manual JSON cleanup, fields like `request_count` are not reliable for attributing which account was used most recently; prefer explicit verification and smoke tests

## Decision rule

Before reauthing anything, produce a map like:
- Hermes active account
- Hermes duplicate credentials (same or different?)
- OpenCode active account
- Windows Codex active account
- Windows Codex backup/prior accounts
- accounts expected by user but not currently authenticated

Only after that should you propose reassignment, for example:
- OpenCode = account A
- Hermes primary = account B
- Hermes fallback = account C

## Safe cleanup / next actions

### Remove an unwanted Hermes credential

Use exact label or index after confirming identity:

```bash
hermes auth remove openai-codex 2
# or
hermes auth remove openai-codex device_code
```

### Add a new Hermes OpenAI Codex account

```bash
hermes auth add openai-codex --type oauth --no-browser
```

Run it in PTY/background if interactive handling is needed.

### Re-point OpenCode

OpenCode manages provider auth separately:

```bash
opencode providers list
opencode providers login
opencode providers logout
```

After changing auth, re-run:

```bash
opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'
```

## Pitfalls

- Do not assume two Hermes credentials = two different OpenAI accounts
- Do not rotate blindly between labels without decoding account IDs
- Do not treat `Regina` or another persona/project identity as proof of an active OpenAI auth; verify with actual auth files
- Windows `.codex` backups can contain valuable prior account state even if Hermes/OpenCode do not
- Compare `accountId` / `chatgpt_account_id` across tools; that is the cleanest cross-tool join key

## Output format

Report back with:
1. account map by tool
2. which entries are duplicates vs distinct
3. which accounts are active vs only recoverable from backup
4. recommended assignment plan
5. exact next auth action to take
