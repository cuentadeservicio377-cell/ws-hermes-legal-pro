# Proceso de Descubrimiento de Features Ocultas

## Contexto
**Fecha:** 2026-05-01
**Situación:** Pablo preguntó si Hermes estaba actualizado. Al investigar, descubrimos que Hermes tiene 61 features slash commands y ninguna se usaba.

## Método de Descubrimiento

### Paso 1: Verificar versión instalada
```bash
hermes --version
pip show hermes-agent
```

### Paso 2: Listar comandos disponibles
```python
from hermes_cli.commands import COMMAND_REGISTRY
print(f'Total comandos: {len(COMMAND_REGISTRY)}')
for cmd in COMMAND_REGISTRY:
    print(f'/{cmd.name} - {cmd.description}')
```

### Paso 3: Agrupar por utilidad
- **Alta utilidad:** /goal, /background, /model, /branch, /snapshot, /steer, /insights, /cron, /kanban, /queue, /curator
- **Media utilidad:** /save, /title, /personality, /reasoning, /fast, /voice, /browser, /tools, /plugins, /config, /status, /agents, /stop, /busy, /verbose, /commands, /help, /new, /clear, /redraw
- **Sistema/Infra:** /update, /debug, /gquota, /platforms, /profile, /sethome, /footer, /restart, /skin, /indicator, /statusbar, /copy, /paste, /image, /history, /approve, /deny, /quit
- **No aplica:** /snapshot restore, /reload .env, /paste clipboard, /image local file

### Paso 4: Verificar funcionamiento en gateway
Revisar `gateway/run.py` para confirmar que comandos como `/goal` y `/background` son procesados por el gateway de Telegram.

### Paso 5: Documentar y crear skill
- Mapeo completo en archivo markdown
- Skill de referencia rápida
- Diario de construcción

## Lecciones Aprendidas

1. **"Config correcta ≠ Sistema funcionando"** — Hermes estaba en última versión pero features no se usaban
2. **Features de usuario vs tools de agente** — /goal, /background, /model son comandos DE USUARIO (Pablo los escribe en Telegram), no tools que Hermes ejecuta
3. **Activación requiere acción del usuario** — Hermes puede documentar y guiar, pero Pablo debe enviar los comandos
4. **Documentar el proceso de descubrimiento** — El método de auditoría es reusable para futuras versiones

## Aplicabilidad

Este método se puede usar para:
- Descubrir features nuevas en cada release de Hermes
- Auditar skills existentes (como se hizo con las 116 skills)
- Verificar estado de cron jobs
- Documentar capacidades del sistema para demos
