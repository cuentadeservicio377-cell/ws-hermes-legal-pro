---
name: hermes-61-features
description: Mapeo completo de las 61 features de Hermes Agent con instrucciones de uso para WS Capital
author: Pablo + Hermes Neo
date: 2026-05-01
version: 1.0
---

# Hermes 61 Features — Skill de Referencia Rápida

## 🚀 ACTIVACIÓN RÁPIDA — Técnica "Copiar y Pegar Todos"

**Descubierto por Pablo (2026-05-01):** Puedes enviar TODOS los comandos en un solo mensaje de Telegram. El gateway los procesa uno por uno.

**Formato:**
```
/goal [texto del goal]

/background [tarea en paralelo]

/model [modelo]

/snapshot [nombre]

/steer ["mensaje"]

/insights

/kanban list

/queue ["prompt"]

/branch [nombre-experimento]
```

**Reglas:**
- Un comando por línea
- Dejar línea en blanco entre comandos (opcional, ayuda a legibilidad)
- El gateway los ejecuta secuencialmente
- Algunos requieren confirmación, otros son inmediatos

**Advertencia:** `/yolo` al final activa modo sin confirmaciones. Usar con cuidado.

---

## 🎯 COMANDOS CLAVE PARA WS CAPITAL

### Goal Persistentes
```
/goal Hacer el mejor Hermes posible — ganar hackathon Eleutheria
```
- Objetivos que persisten entre turns
- Hermes recuerda qué está haciendo
- Sub-goals: hackathon, skills, model-switching

### Background Jobs
```
/background Mapear skills existentes y crear reporte
```
- Trabajo en paralelo sin bloquear conversación
- Ideal para: research, scraping, generación de contenido
- Ver estado: `/goal status` o mensajes de notificación

### Model Switching
```
/model gpt-5.4-mini     # Para coding complejo
/model kimi-k2.6        # Para estrategia y análisis
/model codex            # Para subagentes paralelos
```
- Cambiar modelo en medio de sesión
- `--provider openai` para cambiar provider
- `--global` para hacerlo permanente

### Branching de Sesiones
```
/branch nombre-experimento
```
- Bifurcar conversación sin perder hilo original
- Probar ideas locas con seguridad
- Volver con `/resume nombre-original`

### Snapshots y Rollback
```
/snapshot crear antes-cambio-grande
/rollback list          # Ver checkpoints
/rollback restaurar X   # Volver a versión X
```
- Backup completo del estado
- Restaurar archivos si algo sale mal

### Steer (Inyección Silenciosa)
```
/steer "Recuerda: prioridad es el hackathon, no perfeccionismo"
```
- Inyectar instrucción DESPUÉS del siguiente tool call
- No interrumpe el flujo actual
- Útil para corregir dirección sin reiniciar

---

## 📊 MONITOREO Y CONTROL

### Insights de Uso
```
/insights
```
- Tokens usados por sesión
- Costos estimados
- Patrones de uso

### Usage en Tiempo Real
```
/usage
```
- Rate limits actuales
- Tokens consumidos en esta sesión

### Estado del Sistema
```
/status
/agents
/platforms
```
- Info de sesión, subagentes activos, plataformas conectadas

---

## 🛠️ GESTIÓN DE SKILLS

### Buscar e Instalar
```
/skills search keyword
/skills install nombre
/skills list
```

### Mantenimiento Automático
```
/curator status     # Ver estado de skills
/curator run        # Ejecutar mantenimiento
/curator archive vieja-skill  # Archivar
```

### Recargar
```
/reload-skills      # Después de instalar nuevas
/reload-mcp         # Recargar servidores MCP
```

---

## ⚡ PRODUCTIVIDAD

### Queue (Encolar)
```
/queue "Revisa el email de cliente X"
```
- Encolar prompt para siguiente turno
- No interrumpe conversación actual

### Cron (Programar)
```
/cron list
/cron add "0 9 * * *" "Enviar reporte diario"
```
- Tareas programadas recurrentes
- Syntax estándar cron

### Kanban (Tablero)
```
/kanban list
/kanban add "Terminar video hackathon" --priority high
```
- Tablero colaborativo multi-perfil
- Tasks, links, comments

---

## 🎛️ CONFIGURACIÓN RÁPIDA

### Personalidad
```
/personality creative    # Para brainstorming
/personality professional # Para clientes
```

### Razonamiento
```
/reasoning low      # Respuestas rápidas
/reasoning medium   # Default
/reasoning high     # Análisis profundo
```

### Fast Mode
```
/fast               # Toggle modo rápido
```

### YOLO Mode
```
/yolo               # Skip todas las aprobaciones
```
- Útil para tareas confiables y repetitivas
- CUIDADO: no pide confirmación en comandos peligrosos

---

## 🆘 RECUPERACIÓN

### Undo y Retry
```
/undo               # Borrar último intercambio
/retry              # Reintentar último mensaje
```

### Comprimir Contexto
```
/compress           # Manualmente en sesiones largas
```

### Stop y Clear
```
/stop               # Matar procesos background
/clear              # Nueva sesión limpia
/new                # Fresh session ID
```

---

## 📁 ARCHIVOS RELACIONADOS

- `~/.hermes/HERMES-61-FEATURES.md` — Mapeo completo
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/SKILL.md` — Esta skill
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/references/proceso-descubrimiento-features.md` — Cómo descubrir features ocultas
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/references/diario-construccion-2026-05-01.md` — Diario real de construcción autónoma
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/scripts/verificar-sistema.sh` — Script de verificación
- `~/.hermes/PROJECTS.md` — Proyectos activos

---

## 🎬 USO PARA VIDEO / DEMOSTRACIÓN / EXPERIMENTO DE LABORATORIO

Esta skill documenta un caso real de **auto-mejora de agente**:
- Descubrimiento de capacidades ocultas
- Activación sistemática
- Documentación del proceso
- Resultados medibles
- Pivot de estrategia cuando goal ya no es alcanzable

**Ideal para:** 
- Hackathons (demostrar auto-mejora)
- Demos de producto (mostrar 61 features)
- Case studies de WS Capital (experimento de laboratorio)
- Documentación interna (cómo descubrir features nuevas)

---

*Creado: 2026-05-01 | Versión: 1.2 | Última actualización: sesión de construcción autónoma + pivot*
*Próxima revisión: cuando se activen más features o se descubran nuevas*
| Hackathon (competencia externa) | Experimento de laboratorio (aprendizaje interno) |
| Video para judges | Documentación para nosotros |
| Ganar premio | Construir sistema |
| Deadline presión | Iteración continua |

**Lección:** Cuando un goal ya no es alcanzable, no abandonar. Reframe. El valor real está en el sistema construido, no en el concurso.

---

## 📊 ESTADÍSTICAS REALES DE LA SESIÓN DE CONSTRUCCIÓN

**Fecha de construcción:** 2026-05-01
**Duración:** ~1 hora
**Modo:** Autónomo (Hermes tomó control completo)

### Resultados concretos:
| Métrica | Valor |
|---------|-------|
| Features mapeadas | 61 |
| Skills verificadas | 116 (en 31 categorías) |
| Skills críticas auditadas | 6 |
| Cron jobs activos | 9 (8 previos + 1 nuevo) |
| Documentos creados | 4 (diario, monólogo, mapeo, skill) |

## 📁 ARCHIVOS RELACIONADOS

- `~/.hermes/HERMES-61-FEATURES.md` — Mapeo completo
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/SKILL.md` — Esta skill
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/references/proceso-descubrimiento-features.md` — Cómo descubrir features ocultas
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/references/diario-construccion-2026-05-01.md` — Diario real de construcción autónoma
- `~/.hermes/skills/hermes-system-maintenance/hermes-61-features/scripts/verificar-sistema.sh` — Script de verificación
- `~/.hermes/PROJECTS.md` — Proyectos activos

---

## 🎬 USO PARA VIDEO / DEMOSTRACIÓN / EXPERIMENTO DE LABORATORIO

Esta skill documenta un caso real de **auto-mejora de agente**:
- Descubrimiento de capacidades ocultas
- Activación sistemática
- Documentación del proceso
- Resultados medibles
- Pivot de estrategia cuando goal ya no es alcanzable

**Ideal para:** 
- Hackathons (demostrar auto-mejora)
- Demos de producto (mostrar 61 features)
- Case studies de WS Capital (experimento de laboratorio)
- Documentación interna (cómo descubrir features nuevas)

---

*Creado: 2026-05-01 | Versión: 1.2 | Última actualización: sesión de construcción autónoma + pivot*
*Próxima revisión: cuando se activen más features o se descubran nuevas*
