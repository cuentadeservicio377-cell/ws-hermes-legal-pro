#!/bin/bash
# Script de verificación del sistema Hermes-Max
# Uso: bash scripts/verificar-sistema.sh
# Verifica: skills, documentación, estado del sistema

echo "=== HERMES-MAX VERIFICACIÓN DE SISTEMA ==="
echo "Fecha: $(date)"
echo ""

# 1. Verificar versión de Hermes
echo "1. Versión de Hermes:"
hermes --version 2>/dev/null || echo "   hermes CLI no disponible"
echo ""

# 2. Contar skills
echo "2. Skills disponibles:"
SKILLS_COUNT=$(find ~/.hermes/skills/ -name "SKILL.md" -type f 2>/dev/null | wc -l)
echo "   Total: $SKILLS_COUNT skills"
echo ""

# 3. Verificar skill hermes-61-features
echo "3. Skill hermes-61-features:"
if [ -f ~/.hermes/skills/hermes-system-maintenance/hermes-61-features/SKILL.md ]; then
    echo "   ✅ Instalada"
else
    echo "   ❌ No encontrada"
fi
echo ""

# 4. Verificar archivos de documentación
echo "4. Documentación del sistema:"
for file in HERMES-61-FEATURES.md HERMES-MAX-DIARIO-2026-05-01.md HERMES-MAX-MONOLOGO.md PROJECTS.md; do
    if [ -f ~/.hermes/$file ]; then
        echo "   ✅ $file"
    else
        echo "   ❌ $file"
    fi
done
echo ""

# 5. Verificar directorios de skills por categoría
echo "5. Categorías de skills:"
ls ~/.hermes/skills/ | grep -v "^\." | while read dir; do
    count=$(find ~/.hermes/skills/$dir -name "SKILL.md" -type f 2>/dev/null | wc -l)
    if [ $count -gt 0 ]; then
        echo "   $dir: $count skills"
    fi
done
echo ""

# 6. Verificar memoria persistente
echo "6. Archivos de memoria:"
ls -la ~/.hermes/memory* 2>/dev/null | awk '{print "   " $9 " (" $5 " bytes)"}'
echo ""

echo "=== VERIFICACIÓN COMPLETADA ==="
echo "Para más detalles, revisar:"
echo "  - ~/.hermes/HERMES-61-FEATURES.md (mapeo completo)"
echo "  - ~/.hermes/PROJECTS.md (proyectos activos)"
echo "  - ~/.hermes/logs/ (logs del sistema)"
