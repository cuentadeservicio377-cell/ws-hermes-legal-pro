---
name: admin-ops-pm-evolution
description: "Evolución documentada del sistema de Project Management de WS Capital. Control de cambios, versiones, propuestas de mejora, lecciones aprendidas."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [pm, evolution, changelog, admin-ops, ws, improvement]
---

# Admin & Ops — PM Evolution

Sistema de evolución continua del PM de WS Capital.

## Principio

**Todo cambio se documenta. Toda mejora se propone. Toda versión se guarda.**

## Archivos de evolución

| Archivo | Ubicación | Para qué |
|---------|-----------|----------|
| PM-EVOLUTION-LOG.md | `admin-ops/PM-EVOLUTION-LOG.md` | Registro de cambios, propuestas, lecciones |
| Git repo | `admin-ops/.git/` | Control de versiones del sistema |
| Skills | `~/.hermes/skills/` | Procedimientos documentados como skills |

## Proceso de cambio

### 1. Detectar necesidad de cambio

Puede venir de:
- Pablo solicita algo nuevo
- Hermes detecta fricción/oportunidad
- Cron de proactividad sugiere mejora
- Brain-dump revela nuevo patrón

### 2. Documentar propuesta

Agregar entrada en PM-EVOLUTION-LOG.md sección "Propuestas Pendientes":

```markdown
| ID | Área | Prioridad | Propuesta | Por | Fecha |
```

### 3. Decidir

- Si Pablo aprueba → implementar
- Si es técnico menor → Hermes implementa directo
- Si es estructural → esperar aprobación de Pablo

### 4. Implementar y documentar

- Hacer el cambio en Excel/script/skill
- Agregar entrada en "Cambios Recientes"
- Mover propuesta de "Pendientes" a "Implementadas" (o marcar como done)
- Hacer commit git con mensaje descriptivo

### 5. Comunicar

- Notificar a Pablo qué cambió y por qué
- Actualizar instrucciones si el cambio afecta uso

## Control de versiones con Git

```bash
cd /mnt/c/Users/DELL/Documents/repos/hermes-ops/admin-ops

# Ver estado
git status

# Ver historial
git log --oneline

# Hacer commit de cambios
git add -A
git commit -m "vX.Y.Z — Qué cambió"

# Ver diferencias
git diff HEAD~1

# Regresar a versión anterior (si algo se rompe)
git log --oneline          # ver commits
git checkout <commit-id>   # regresar a ese punto
```

## Pitfalls descubiertos en producción

### Excel lock files
Cuando el Excel está abierto en Windows, se crea un archivo `~$nombre.xlsx` que bloquea escritura. Soluciones:
- Cerrar Excel antes de que Hermes escriba
- O usar un script separado que Pablo ejecute manualmente
- O escribir en una copia y pedir a Pablo que reemplace

### openpyxl en WSL
Si `openpyxl` no está instalado:
```bash
pip install openpyxl --break-system-packages
# O en venv:
python3 -m pip install openpyxl
```

### Nombres de hojas con emojis
Si usas emojis en nombres de hojas (`📁 Proyectos`), el script Python debe referenciarlos exactamente igual:
```python
# Correcto:
ws = wb["📁 Proyectos"]
# Incorrecto:
ws = wb["Proyectos"]  # KeyError
```

### Fechas mixtas en Excel
Las fechas pueden venir como `str` o `datetime` dependiendo de cómo se ingresaron. Siempre parsear ambos casos:
```python
if isinstance(fecha, str):
    fecha = datetime.strptime(fecha, "%Y-%m-%d").date()
elif isinstance(fecha, datetime):
    fecha = fecha.date()
```

## Versionado semántico

- **v1.0.0** — Release inicial
- **v1.1.0** — Nueva funcionalidad (ej: nueva hoja en Excel)
- **v1.0.1** — Fix menor (ej: corrección de datos)
- **v2.0.0** — Cambio estructural mayor (ej: migración a NocoDB)

## Proactividad de Hermes

Hermes debe:
1. Revisar periódicamente el PM-EVOLUTION-LOG
2. Detectar propuestas viejas sin implementar
3. Sugerir mejoras basadas en patrones de uso
4. Proponer optimizaciones antes de que sean problemas

## Ejemplos de propuestas proactivas

- "He notado que la hoja de Tareas tiene muchas entradas de Brain-Dump. ¿Quieres que creemos un proyecto específico para esas tareas sueltas?"
- "El área de Ventas no tiene proyectos. ¿Es momento de cargar el pipeline?"
- "Hay 3 tareas vencidas en Build. ¿Necesitamos ajustar deadlines o asignar más recursos?"
- "He visto que siempre capturamos ideas de Growth. ¿Quieres que cree un sistema de evaluación más formal?"
