---
name: ws-growth-operational-batch
description: Build the first operational content batch for WS Capital from local thesis, strategy, and Growth Vault notes; output prompts, drafts, calendar, and status updates.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ws, growth, content, obsidian, operations, marketing, anti-genericity]
---

# WS Growth Operational Batch

Use this when a task says to continue WS Capital / Hermes content work from local files only and convert strategy into executable content outputs.

## Goal
Turn existing WS Capital strategy notes into an initial content-operations batch without inventing generic marketing.

## Read first
Always read these before drafting:
- `docs/growth-blueprint.md`
- `docs/growth-runbook.md`
- `docs/growth-starter-pack.md`
- `docs/growth-checklist.md`
- `docs/growth-templates.md`
- `WS Capital - Objetivo mayor.md`
- `WS Capital - Tesis Madre.md`
- `WS Capital - Anti Genericidad.md`
- month strategy note
- vertical strategy notes
- founder dump
- offer/recorrido, audiences, structural problems, and relevant vertical thesis/case notes

## Outputs to create
In `hermes-ops/docs`:
1. prompt library batch
2. operational batch with real drafts
3. simple execution calendar

In Growth Vault:
1. general batch note under `03_Campanas`
2. readable mirror notes for any docs-only operational assets that a human should review directly (at minimum: prompt library and execution calendar)
3. vertical piece notes under each relevant vertical folder
4. update experiment log with a prepared experiment if nothing has run yet
5. update package/status notes so it is obvious content-operations started

## Working rules
- Source every claim from founder dump, thesis, anti-genericity, case notes, or current vault notes.
- Avoid leading with tools, AI hype, automation buzzwords, or agency language.
- Keep the general thesis separate from vertical proof cases.
- Prefer 5-8 strong drafts over a large empty batch.
- Include at least one general piece, one method piece, and vertical pieces.
- Include DMs/outreach only as a support layer, not the whole batch.

## Minimum batch shape
- 3 general WS Capital drafts
- 2 event drafts if events are active
- 2 legal drafts if legal is active
- 1 prompt library
- 1 two-week execution calendar
- 1 prepared experiment entry

## Status updates
Patch existing status docs to move language from:
- “strategy created / ready to execute”

to something like:
- “content-operations started with first batch drafted”

Also update the vault state note and package note so the new assets are visible.

## Pitfalls
- Do not rewrite strategy notes from scratch when the task is to operationalize them.
- Do not create fake experiment results.
- Do not claim specialized legal expertise beyond the current thesis.
- Do not turn the Paola case into generic “event marketing”.
- Do not leave status docs saying execution has not started if drafts were created.
- Do not let a batch pass if it only explains the thesis in broad terms without a concrete operating scene.
- Do not let general, events, and legal pieces all reuse the same argument skeleton with only cosmetic changes.

## If previous outputs felt too generic
When continuing an existing Growth/content lane and the complaint is that prior drafts felt generic, do **not** just make small wording edits. Add a short restructuring pass first.

Create a critique/restructure doc that identifies:
1. what was too macro or interchangeable
2. where concrete operating scenes were missing
3. where founder dependency / memory loss / reconstruction / continuity loss were underplayed
4. where verticals leaned too much on the general thesis instead of the live pain point
5. what the new operating rule will be for the next batch

Then rebuild the next batch around this sequence:
- source note
- concrete operating scene
- dependency on founder / key person / memory
- fracture or cost created by that dependency
- contrast with the false market fix
- WS Capital entry point
- explicit statement of what is **not** being promised yet

For sharper batch rewrites, prefer 5–8 assets total and allow a 6-piece structure like:
- 2 general
- 2 events
- 2 legal

The strongest anti-generic angles learned here were:
- general: memory-secuestrada, reconstrucción constante, founder dependency
- eventos: verdad final perdida, aprobaciones/versiones sin rastro, Paola as proof that the founder's head can be translated
- legal: continuity loss, chasing the one person who has context, fragility from concentrated operational knowledge

When you do this kind of rewrite, create/update all of these layers together:
- critique/restructure doc in `hermes-ops/docs`
- revised operational batch in `hermes-ops/docs`
- revised prompt library in `hermes-ops/docs`
- revised execution calendar in `hermes-ops/docs`
- readable mirrors in Growth Vault
- vertical piece notes in Growth Vault
- status docs so batch N is visible
- experiment log as `prepared/pending`, never executed unless there was live market action

## Verification
Before finishing:
- confirm created files exist
- confirm status docs mention that the first batch is drafted
- confirm experiment log says prepared/pending rather than executed if no market action happened
- report created assets, remaining review work, and whether Pablo can evaluate the batch
