---
name: ws-department-activation
description: "Activate or formalize a WS Capital department when detected via Telegram topic, voice note, or explicit request. Enriches the department operating contract, updates cross-references, creates operational artifacts, and handles infrastructure/tooling proposals."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ws-capital, department, operations, activation, formalization, contract, pm]
---

# WS Department Activation

Use this skill when Pablo activates a department via Telegram topic, voice note, or explicit request (e.g., "📁 Admin & Ops", "necesito infraestructura para esta área", etc.).

## Goal

Turn a department topic activation into a formal, operational unit within WS Capital's empresa-sistema with:
- Updated department operating contract
- Aligned cross-references in all authority docs
- Operational artifacts (checklists, templates)
- Infrastructure/tooling proposal (if requested)

## Trigger conditions

- Telegram topic message with department emoji/name
- Voice note mentioning a department's role or needs
- Explicit request to "formalizar", "crear", or "infraestructura para" a department
- Topic detected automatically (e.g., `#️⃣ Admin & Ops`)

## Activation workflow

### Step 1: Detect and confirm the department
1. Identify the department name from the topic or user message
2. Check if it already exists in `ws-neo-department-operating-contract-v1.md`
3. If it exists but the user's framing is richer, treat this as **enrichment**, not creation
4. If it doesn't exist, treat this as **new department formalization**

### Step 2: Load authority docs in parallel
Read these files simultaneously:
- `hermes-ops/docs/ws-neo-department-operating-contract-v1.md`
- `hermes-ops/docs/contract-operativo-unificado.md`
- `hermes-ops/docs/operating-model.md`

### Step 3: Compare and enrich the department definition
For the target department, check each field:
- **Mission**: Does the user's framing add specificity? (e.g., "quién hace qué y cuándo")
- **Boundaries**: Is the scope clearer in the new framing?
- **Inputs/Outputs**: Are there new categories the user expects?
- **Session fields**: Are new fields needed (responsable, tarea, proceso)?
- **Handoffs**: Are incoming/outgoing departments complete?
- **Escalation**: Is the escalation trigger clear?
- **Relation with Hermes**: How does Hermes interact with this department specifically?

Enrich the definition. If renaming (e.g., `Administración / PM` → `Admin & Ops`), do a full rewrite.

### Step 4: Patch all authority docs
Apply consistent changes to:
1. `ws-neo-department-operating-contract-v1.md` — the department definition itself
2. `contract-operativo-unificado.md` — department list and any references
3. `operating-model.md` — department list and any references

Use `patch` with sufficient context to ensure uniqueness.

### Step 5: Create operational artifacts
Create department-specific checklists and operational docs:
- `{dept}-checklists.md` — operational checklists for the department
- Typical checklists: intake, task tracking, handoff, checkpoint, blocker detection, task closure, cycle start
- Store in `hermes-ops/docs/`

### Step 6: Handle infrastructure/tooling requests (if any)
If the user asks for infrastructure, tools, or PM systems for the department:

#### 6a. Discover existing local infrastructure first
Before proposing tools, check what's already running on the machine:
- `docker ps` — containers, databases, services
- `ss -ltnp` — listening ports
- `which sqlite3` / Postgres availability
- Existing skills that might serve as tooling (Linear, Notion, GitHub, etc.)

This prevents proposing redundant infrastructure and reveals integration opportunities.

#### 6b. Attempt external research
- Try `browser_navigate` for PM tooling landscape
- Try `curl` for specific tool research
- Try `search_files` in local docs for prior tooling discussions

#### 6c. If external research fails — pivot to synthesis
External research frequently fails or gets blocked. The fallback is NOT to ask the user to wait — synthesize from:
- Existing tool skills (Linear, Notion, GitHub Issues)
- Domain knowledge of WS Capital architecture (Hermes/Onyx/OpenCode/Workspace)
- Local authority docs and operating model

#### 6d. Propose tooling options with a local-first path

**Default proposal (SaaS path):** Hub & Spoke model
- **Linear** → projects, tasks, technical milestones
- **Notion** → clients, ideas, CRM, proposals  
- **Onyx** → documents, retrieval, knowledge
- **Hermes** → orchestration, routing, alerts, cron

**Local-first alternative (when user rejects SaaS/cuentas):**
Many users reject external accounts. Have a local alternative ready:

| Need | SaaS | Local Alternative |
|------|------|-------------------|
| Project tracking | Linear | **Excel + Python/openpyxl** |
| Client CRM | Notion | **Excel sheet** |
| Task management | Linear issues | **Excel sheet + Python script** |
| Knowledge/docs | Notion | **Obsidian Vault / Onyx** |
| Automation | Linear API | **Python cron scripts** |

**Excel + Python PM pattern (proven):**
1. Create `ws-{dept}-master.xlsx` with sheets:
   - Dashboard (KPIs with formulas)
   - Clientes / Projects / Tareas / Ideas
   - Áreas_Actividades (recurring activities per area)
   - Seguimiento_Semanal
   - Handoffs
2. Create `pm_reader.py` script with:
   - `load_wb()` / `save_wb()` helpers
   - Read functions: `get_proyectos()`, `get_tareas()`, `get_clientes()`, etc.
   - Write functions: `agregar_proyecto()`, `agregar_tarea()`, etc.
   - Report generator: `generar_reporte_estado()`
   - Compliance auditor: `verificar_cumplimiento_area(area)`
3. Hermes calls the script via `terminal` or `execute_code`
4. Pablo edits the Excel directly; Hermes reads changes

**Installing openpyxl:**
- System Python may need: `pip install openpyxl --break-system-packages`
- Hermes venv may not have pip available at expected path
- Verify with `python3 -c "import openpyxl"` before building

#### 6e. Document the proposal
Create `{dept}-pm-infrastructure-proposal-v1.md` (SaaS path) or `{dept}-pm-local-proposal-v2.md` (local path) with:
- Current infrastructure discovered
## Excel + Python PM Build Pattern (Proven)

When a user rejects SaaS/cuentas or explicitly requests Excel, this pattern has been proven end-to-end for WS Capital.

### Phase 1: Design the Excel structure

Create `ws-{dept}-master.xlsx` with these sheets (order matters for UX):

| # | Sheet | Purpose |
|---|-------|---------|
| 1 | **📖 Instrucciones** | Complete user guide inside the Excel |
| 2 | **📊 Dashboard** | KPI cards, area status, quick nav, blockers |
| 3 | **🏢 Resumen_Areas** | Transversal visibility of all departments |
| 4 | **👥 Clientes** | CRM: clients, prospects, partners |
| 5 | **📁 Proyectos** | Projects by department with progress, deadlines |
| 6 | **✅ Tareas** | Tasks linked to projects with auto-color states |
| 7 | **💡 Ideas** | Brain-dumps captured and classified |
| 8 | **📅 Actividades** | Recurring activities per area (compliance audit) |
| 9 | **📈 Seguimiento_Semanal** | Weekly tracking by area |
| 10 | **🔄 Handoffs** | Cross-department transfers |

### Design principles
- **Corporate palette**: Ink Blue #1B365D, Corp Blue #2F5496, Success #548235, Warning #FFC000, Alert #C00000
- **KPI cards**: Big numbers, colored backgrounds, formulas (COUNTIF, COUNTIFS)
- **Semáforos**: 🟢 Hecho/Activo/Completado, 🟡 En progreso/Pendiente/Backlog, 🔴 Bloqueado/Vencido/Cancelado
- **Conditional formatting**: Auto-applied to status columns
- **Navigation**: Hyperlink buttons on Dashboard to jump between sheets
- **AutoFilter**: On all data tables
- **Clean borders**: Thin #CCCCCC borders, consistent row heights

### Phase 2: Build `pm_reader.py`

The script must have:

```python
EXCEL_PATH = "/path/to/ws-{dept}-master-v2.xlsx"

def load_wb(): return openpyxl.load_workbook(EXCEL_PATH)
def save_wb(wb): wb.save(EXCEL_PATH)

# READ functions
def get_proyectos(estado=None, departamento=None):
    # Return list of dicts from Proyectos sheet

def get_tareas(estado=None, area=None, vencidas=False):
    # Return list of dicts from Tareas sheet
    # Handle date parsing for vencidas=True

def get_clientes(): ...
def get_ideas(estado=None): ...
def get_handoffs(estado=None): ...
def get_actividades_por_area(area=None): ...

# REPORT functions
def generar_reporte_estado():
    # Full status report with KPIs, active projects, overdue tasks, handoffs

def generar_snapshot_transversal():
    # Cross-department snapshot with 🟢🟡🔴 indicators

def verificar_cumplimiento_area(area):
    # Audit recurring activities for an area

# WRITE functions
def agregar_proyecto(...): ...
def agregar_tarea(...): ...
def agregar_idea(...): ...
def actualizar_estado_tarea(tarea_id, nuevo_estado): ...
def registrar_handoff(...): ...

# BRAIN-DUMP
def capturar_brain_dump(items, fuente="Voice note"):
    # items: list of dicts {texto, tipo, area, deadline, prioridad}
    # Types: tarea, idea, proyecto, handoff, recordatorio
    # Auto-classifies and writes to correct sheet

def generar_resumen_brain_dump(resumen):
    # Formatted confirmation message

# CHECKPOINT
def checkpoint_cierre(area="Admin & Ops", hechos=None, pendientes=None, 
                      bloqueos=None, aprendizajes=None, git_commit=True):
    # Session close checkpoint with git commit
```

### Phase 3: Install openpyxl

```bash
# System Python (NOT venv — venv pip may be missing)
python3 -m pip install openpyxl --break-system-packages
# Verify
python3 -c "import openpyxl; print(openpyxl.__version__)"
```

### Phase 4: Create skills for the department

| Skill | Purpose |
|-------|---------|
| `{dept}-brain-dump` | Capture weekly loose tasks/ideas |
| `{dept}-pm-evolution` | Track changes, versions, proposals |
| `ws-interconnected-ops` | Connect all department topics |
| `session-close-checkpoint` | Auto session close with git commit |
| `ws-excel-pm-design` | Visual design patterns for Excel PM |

### Phase 5: Configure cron jobs

| Schedule | Purpose |
|----------|---------|
| `0 21 * * 0` (Sun 9pm) | Brain-dump: "What do you have in mind?" |
| `0 8 * * 1` (Mon 8am) | Weekly summary across all areas |
| `0 10 * * 3` (Wed 10am) | Proactivity: suggest improvements |
| `0 18 * * 5` (Fri 6pm) | Compliance check: what got done? |

### Phase 6: Initialize git tracking

```bash
cd hermes-ops/{dept}/
git init
git add -A
git commit -m "v1.0.0 — {Dept} PM system initial"
```

Track all artifacts: Excel, scripts, docs, evolution log.

### Phase 7: Create PM-EVOLUTION-LOG.md

```markdown
# PM Evolution Log — {Dept}

## v1.0.0 — {date} — Initial system
- What was built
- State of each area
- Initial blockers

## Propuestas Pendientes
| ID | Area | Priority | Proposal | By | Date |

## Lecciones Aprendidas

## Cambios Recientes
```

### Phase 8: Document everything

Create:
- `README.md` — Complete system guide
- `PM-EVOLUTION-LOG.md` — Change tracking
- `📖 Instrucciones` sheet inside Excel — Quick visual guide

---

## Session Close Checkpoint Pattern

When a user says "listo", "terminamos", "cerramos", or "eso es todo", execute:

1. **Detect department** from topic/thread ID
2. **Summarize session**: done, pending, blockers, learnings
3. **Update Excel**: mark completed tasks, add new ones
4. **Register in Evolution Log**: changes, proposals, lessons
5. **Git commit**: `Session checkpoint {area} {date}: {summary}`
6. **Notify user**: compact confirmation with system status

The `checkpoint_cierre()` function in `pm_reader.py` automates steps 2-5.

---

## Interconnected Topics Architecture

All 7 WS Capital topics must be mapped:

| Thread ID | Topic | Department | Primary Vault |
|-----------|-------|------------|---------------|
| 1 | #️⃣ General | Dirección / Orquestación | System |
| 2 | 💡 Socio Operativo | Pablo's Second Brain | System + Growth |
| 5 | 💻 Build & Tech | Fábrica de Software | Build |
| 8 | 📈 Growth & Marketing | Growth | Growth |
| 22 | ✏️ Willow Legal | Jurídico / Willow | Onyx + System |
| 23 | 📁 Admin & Ops | COO / PM | Excel PM + System |
| 24 | 💲 Ventas & Plantillas | Comercial | Growth + Excel PM |

Admin & Ops (Topic 23) has **read access to all areas** — it's the PM hub.

---

## Environment Limitation: Hermes Workspace on WSL+NTFS

**Hermes Workspace** (`hermes-workspace` repo) does NOT install reliably on this WSL+NTFS setup.

**Symptom:** `pnpm install` and `npm install` both hang/timeout indefinitely when resolving 986+ packages.

**Root cause:** Likely NTFS filesystem overhead + large node_modules tree.

**Workaround:** Do NOT attempt to install Hermes Workspace for model switching. Use `hermes model set` CLI instead:
```bash
hermes model set <provider>/<model>
```

**Status:** Hermes gateway/dashboard runs fine via systemd (`hermes gateway run`), just the frontend workspace does not install.