#!/usr/bin/env python3
"""Check if a Google API is available and which token to use.

Usage:
  check_api.py --api youtube          # Check YouTube Data API
  check_api.py --api ads              # Check Google Ads API
  check_api.py --api analytics        # Check Analytics Data API
  check_api.py --api search-console   # Check Search Console API
  check_api.py --api vision           # Check Cloud Vision API
  check_api.py --api slides           # Check Google Slides API
  check_api.py --api workspace        # Check base Workspace APIs
  check_api.py --list-all             # List all available APIs

Returns JSON with availability, scopes, token path, and status.
"""

import argparse
import json
import sys
from pathlib import Path

try:
    from hermes_constants import get_hermes_home
except ModuleNotFoundError:
    HERMES_AGENT_ROOT = Path(__file__).resolve().parents[4]
    if HERMES_AGENT_ROOT.exists():
        sys.path.insert(0, str(HERMES_AGENT_ROOT))
    from hermes_constants import get_hermes_home

HERMES_HOME = get_hermes_home()
TOKEN_BASE = HERMES_HOME / "google_token.json"
TOKEN_EXTENDED = HERMES_HOME / "google_token_extended.json"

# API definitions: name -> {scopes: [...], token: "base"|"extended"|"either", area: "shared"|"growth"|"legal"|"ops"}
API_REGISTRY = {
    # === SHARED / COMPARTIDAS ===
    "gmail": {
        "scopes": ["https://www.googleapis.com/auth/gmail.readonly", "https://www.googleapis.com/auth/gmail.send", "https://www.googleapis.com/auth/gmail.modify"],
        "token": "either",
        "area": "shared",
        "description": "Send, read, and modify emails"
    },
    "calendar": {
        "scopes": ["https://www.googleapis.com/auth/calendar"],
        "token": "either",
        "area": "shared",
        "description": "Read and create calendar events"
    },
    "drive": {
        "scopes": ["https://www.googleapis.com/auth/drive.readonly"],
        "token": "either",
        "area": "shared",
        "description": "Read files from Google Drive"
    },
    "sheets": {
        "scopes": ["https://www.googleapis.com/auth/spreadsheets"],
        "token": "either",
        "area": "shared",
        "description": "Read and write Google Sheets"
    },
    "docs": {
        "scopes": ["https://www.googleapis.com/auth/documents.readonly"],
        "token": "either",
        "area": "shared",
        "description": "Read Google Docs"
    },
    "contacts": {
        "scopes": ["https://www.googleapis.com/auth/contacts.readonly"],
        "token": "either",
        "area": "shared",
        "description": "Read Google Contacts"
    },
    "slides": {
        "scopes": ["https://www.googleapis.com/auth/presentations"],
        "token": "extended",
        "area": "shared",
        "description": "Create and edit Google Slides"
    },
    "vision": {
        "scopes": ["https://www.googleapis.com/auth/cloud-vision"],
        "token": "extended",
        "area": "shared",
        "description": "OCR and image analysis via Cloud Vision"
    },
    "cloud-platform": {
        "scopes": ["https://www.googleapis.com/auth/cloud-platform"],
        "token": "extended",
        "area": "shared",
        "description": "Access to Cloud Platform services (Gemini, Vertex AI, Agent Platform)"
    },
    "workspace": {
        "scopes": [],
        "token": "either",
        "area": "shared",
        "description": "All base Workspace APIs (Gmail, Calendar, Drive, Sheets, Docs, Contacts)"
    },
    # === GROWTH SPECIFIC ===
    "youtube": {
        "scopes": ["https://www.googleapis.com/auth/youtube", "https://www.googleapis.com/auth/youtube.upload"],
        "token": "extended",
        "area": "growth",
        "description": "YouTube Data API and upload"
    },
    "ads": {
        "scopes": ["https://www.googleapis.com/auth/adwords"],
        "token": "extended",
        "area": "growth",
        "description": "Google Ads API (requires linked Ads account)"
    },
    "analytics": {
        "scopes": ["https://www.googleapis.com/auth/analytics", "https://www.googleapis.com/auth/analytics.edit"],
        "token": "extended",
        "area": "growth",
        "description": "Google Analytics Data and Admin"
    },
    "search-console": {
        "scopes": ["https://www.googleapis.com/auth/webmasters", "https://www.googleapis.com/auth/webmasters.readonly"],
        "token": "extended",
        "area": "growth",
        "description": "Google Search Console API"
    },
    "indexing": {
        "scopes": ["https://www.googleapis.com/auth/indexing"],
        "token": "extended",
        "area": "growth",
        "description": "Web Search Indexing API"
    },
}


def _load_token_scopes(token_path: Path) -> set:
    """Load scopes from a token file."""
    try:
        data = json.loads(token_path.read_text())
        raw = data.get("scopes") or data.get("scope", "")
        if isinstance(raw, str):
            return set(s.strip() for s in raw.split() if s.strip())
        elif isinstance(raw, list):
            return set(str(s).strip() for s in raw if str(s).strip())
        return set()
    except Exception:
        return set()


def check_api(api_name: str) -> dict:
    """Check if an API is available."""
    api_name = api_name.lower().replace("_", "-")
    
    if api_name not in API_REGISTRY:
        return {
            "available": False,
            "error": f"Unknown API: {api_name}. Run --list-all to see available APIs.",
            "known_apis": sorted(API_REGISTRY.keys())
        }
    
    info = API_REGISTRY[api_name]
    required_scopes = set(info["scopes"])
    token_type = info["token"]
    
    # Determine which token(s) to check
    if token_type == "base":
        token_paths = [("base", TOKEN_BASE)]
    elif token_type == "extended":
        token_paths = [("extended", TOKEN_EXTENDED)]
    else:  # either
        token_paths = [("base", TOKEN_BASE), ("extended", TOKEN_EXTENDED)]
    
    # Check each token
    for token_label, token_path in token_paths:
        if not token_path.exists():
            continue
        granted = _load_token_scopes(token_path)
        if required_scopes.issubset(granted):
            return {
                "available": True,
                "api": api_name,
                "area": info["area"],
                "description": info["description"],
                "token_path": str(token_path),
                "token_type": token_label,
                "scopes": sorted(required_scopes),
            }
    
    # Not available
    return {
        "available": False,
        "api": api_name,
        "area": info["area"],
        "description": info["description"],
        "reason": "No valid token with required scopes found",
        "required_scopes": sorted(required_scopes),
        "token_type_needed": token_type,
    }


def list_all() -> dict:
    """List all APIs and their availability."""
    results = {}
    base_scopes = _load_token_scopes(TOKEN_BASE) if TOKEN_BASE.exists() else set()
    extended_scopes = _load_token_scopes(TOKEN_EXTENDED) if TOKEN_EXTENDED.exists() else set()
    
    for api_name, info in sorted(API_REGISTRY.items()):
        required = set(info["scopes"])
        
        if info["token"] == "base":
            available = required.issubset(base_scopes)
            token_used = "base" if available else None
        elif info["token"] == "extended":
            available = required.issubset(extended_scopes)
            token_used = "extended" if available else None
        else:  # either
            available_base = required.issubset(base_scopes)
            available_extended = required.issubset(extended_scopes)
            available = available_base or available_extended
            token_used = "base" if available_base else ("extended" if available_extended else None)
        
        results[api_name] = {
            "available": available,
            "area": info["area"],
            "description": info["description"],
            "token_type": token_used or info["token"],
        }
    
    return {
        "token_base_exists": TOKEN_BASE.exists(),
        "token_extended_exists": TOKEN_EXTENDED.exists(),
        "apis": results,
    }


def main():
    parser = argparse.ArgumentParser(description="Check Google API availability for WS Capital")
    parser.add_argument("--api", help="API name to check (e.g., youtube, ads, analytics)")
    parser.add_argument("--list-all", action="store_true", help="List all APIs and their status")
    args = parser.parse_args()
    
    if args.list_all:
        result = list_all()
    elif args.api:
        result = check_api(args.api)
    else:
        parser.print_help()
        sys.exit(1)
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
