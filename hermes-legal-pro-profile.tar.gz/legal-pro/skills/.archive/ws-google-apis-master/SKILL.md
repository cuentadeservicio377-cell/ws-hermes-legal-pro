---
name: ws-google-apis-master
description: Skill maestra de APIs Google para WS Capital. Documenta qué APIs están disponibles, qué scopes tienen, qué áreas/departamentos las usan, y cómo acceder a ellas desde cualquier skill. Centraliza el conocimiento de Google Cloud APIs para evitar que cada skill reinvente la autenticación.
version: 1.0.0
author: WS Capital
license: MIT
metadata:
  hermes:
    tags: [Google, APIs, OAuth, Workspace, Growth, Legal, Ops, YouTube, Ads, Analytics, SEO]
    related_skills: [google-workspace, ws-growth-orchestrator, ws-campaign-planner, ws-performance-reviewer, ws-video-machine, willow-legal-complete, ws-interconnected-ops]
---

# WS Google APIs Master

Centraliza el acceso a todas las APIs de Google Cloud que WS Capital tiene habilitadas. Esta skill NO ejecuta APIs directamente — documenta qué está disponible, quién lo usa, y cómo cada skill especializada debe acceder.

## Estado de Autenticación

| Token | Ubicación | Estado | Scopes |
|-------|-----------|--------|--------|
| Base | `~/.hermes/google_token.json` | ✅ Activo | Gmail, Calendar, Drive, Contacts, Sheets, Docs |
| Extendido | `~/.hermes/google_token_extended.json` | ✅ Activo | 19 scopes incluyendo YouTube, Ads, Analytics, Search Console, Vision, Cloud Platform |

**Regla:** Si una skill necesita APIs extendidas, debe usar `google_token_extended.json`. Si solo necesita Workspace básico, puede usar `google_token.json`.

## APIs por Área / Departamento

### 🔵 APIs COMPARTIDAS (Todas las áreas)

| API | Scope | Uso típico | Token |
|-----|-------|-----------|-------|
| Gmail | `gmail.readonly`, `gmail.send`, `gmail.modify` | Email, notificaciones, parsing | Base o Extendido |
| Calendar | `calendar` | Scheduling, recordatorios | Base o Extendido |
| Drive | `drive.readonly` | Almacenamiento, plantillas | Base o Extendido |
| Sheets | `spreadsheets` | PM, datos, reportes | Base o Extendido |
| Docs | `documents.readonly` | Documentos, contratos | Base o Extendido |
| Contacts | `contacts.readonly` | CRM básico | Base o Extendido |
| Slides | `presentations` | Pitch decks, presentaciones | Extendido |
| Cloud Vision | `cloud-vision` | OCR, análisis de imágenes | Extendido |
| Cloud Platform | `cloud-platform` | Gemini API, Agent Platform, Vertex AI | Extendido |

### 🟢 APIs GROWTH (Marketing, SEO, Contenido)

| API | Scope | Uso típico | Skills que la usan |
|-----|-------|-----------|-------------------|
| YouTube Data | `youtube`, `youtube.upload` | Subir videos, analytics de canal | `ws-video-machine`, `youtube-content` |
| Google Ads | `adwords` | Campañas, keywords, presupuestos | `ws-campaign-planner`, `ws-growth-orchestrator` |
| Analytics Data | `analytics` | Métricas de sitio, conversiones | `ws-performance-reviewer`, `ws-growth-orchestrator` |
| Analytics Admin | `analytics.edit` | Configurar propiedades, goals | `ws-growth-orchestrator` |
| Search Console | `webmasters`, `webmasters.readonly` | SEO, rankings, clicks | `ws-growth-orchestrator`, SEO/GEO engine |
| Web Search Indexing | `indexing` | Indexar URLs nuevas | SEO/GEO engine |

### 🟡 APIs LEGAL (Willow)

| API | Scope | Uso típico | Skills que la usan |
|-----|-------|-----------|-------------------|
| Cloud Vision | `cloud-vision` | OCR de documentos escaneados | `willow-legal-complete`, `ocr-and-documents` |
| Drive + Docs + Sheets | Base | Gestión documental de expedientes | `willow-legal-complete` |
| Slides | `presentations` | Presentaciones para clientes | `powerpoint` |

### 🟠 APIs OPS / ADMIN

| API | Scope | Uso típico | Skills que la usan |
|-----|-------|-----------|-------------------|
| Sheets | `spreadsheets` | Excel PM maestro, tracking | `ws-excel-pm-design`, `admin-ops-pm-evolution` |
| Calendar | `calendar` | Scheduling de reuniones | `google-workspace` |
| Drive | `drive.readonly` | Organización de archivos | `ws-interconnected-ops` |
| Cloud Vision | `cloud-vision` | Procesamiento de documentos | `ocr-and-documents` |

## Cómo usar desde otras Skills

### Patrón de acceso recomendado

```python
# En cualquier script de skill, detectar qué token necesita:
import json
from pathlib import Path

HERMES_HOME = Path.home() / ".hermes"

# Si necesitas APIs extendidas (YouTube, Ads, Analytics, etc.):
TOKEN_PATH = HERMES_HOME / "google_token_extended.json"

# Si solo necesitas Workspace básico:
# TOKEN_PATH = HERMES_HOME / "google_token.json"

# Cargar credenciales
with open(TOKEN_PATH) as f:
    token_data = json.load(f)

# Usar con google-api-python-client
from google.oauth2.credentials import Credentials
creds = Credentials.from_authorized_user_info(token_data)
```

### Verificar disponibilidad antes de usar

```bash
# Script de verificación que cualquier skill puede llamar:
python ~/.hermes/skills/ws-capital/ws-google-apis-master/scripts/check_api.py --api youtube
# Returns: {"available": true, "scopes": ["youtube", "youtube.upload"], "token": "extended"}
```

## APIs que requieren configuración adicional

| API | ¿OAuth listo? | ¿Necesita más? | Qué falta |
|-----|--------------|----------------|-----------|
| Gemini API | ✅ `cloud-platform` | ⚠️ API Key | Generar API key en Google Cloud Console → APIs & Services → Credentials |
| Google Ads API | ✅ `adwords` | ⚠️ Cuenta vinculada | Vincular cuenta de Google Ads al proyecto de desarrollador |
| YouTube Data API | ✅ `youtube` | ⚠️ Cuota | 10,000 unidades/día por defecto; solicitar aumento si se necesita |
| Search Console API | ✅ `webmasters` | ✅ Listo | — |
| Analytics Data API | ✅ `analytics` | ✅ Listo | — |

## Troubleshooting por Área

### Growth
- **"Access Not Configured" para YouTube/Ads/Analytics** → Verificar que la API esté habilitada en Google Cloud Console
- **Cuota excedida en YouTube** → Solicitar aumento en Cloud Console o implementar rate limiting
- **Google Ads sin acceso** → La cuenta de Ads debe estar vinculada; no basta con el scope OAuth

### Legal
- **OCR falla con documentos grandes** → Cloud Vision tiene límite de 20MB por imagen; dividir o comprimir
- **Drive no encuentra archivos de cliente** → Verificar que los archivos estén compartidos con la cuenta de servicio

### Ops
- **Sheets no actualiza** → Verificar que el spreadsheet tenga permisos de edición para la cuenta
- **Token expirado** → El refresh token debería funcionar automáticamente; si falla, re-autorizar

## Changelog

- **2025-04-25 v1.0** — Setup inicial con 19 scopes. Tokens: base + extendido.
