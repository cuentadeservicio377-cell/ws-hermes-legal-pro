---
name: session-close-checkpoint
description: "Checkpoint de cierre de sesión: cuando Pablo dice que termina una sesión, Hermes captura automáticamente lo que se hizo, lo que quedó pendiente, bloqueos y actualiza el sistema PM."
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [session, checkpoint, close, pm, admin-ops]
---

# Session Close Checkpoint

## Trigger

Cuando Pablo dice frases como:
- "listo, cerramos"
- "terminamos"
- "eso es todo"
- "ya terminé"
- "cerrar sesión"
- "ya está"
- "gracias, eso es todo"

Hermes debe ejecutar el **checkpoint de cierre automático**.

## Qué captura el checkpoint

### 1. Contexto de la sesión
- ¿En qué topic/departamento se habló?
- ¿Cuánto duró la sesión?
- ¿Quién participó?

### 2. Qué se hizo (Done)
- Proyectos creados
- Tareas completadas
- Ideas capturadas
- Handoffs registrados
- Decisiones tomadas

### 3. Qué quedó pendiente (Pending)
- Tareas sin terminar
- Proyectos activos que siguen
- Bloqueos que no se resolvieron
- Handoffs pendientes

### 4. Bloqueos (Blockers)
- ¿Qué está deteniendo algo?
- ¿Quién debe actuar?
- ¿Cuál es el siguiente paso?

### 5. Aprendizajes / Lecciones
- ¿Algo nuevo se descubrió?
- ¿Hubo fricción en el proceso?
- ¿Se detectó algo para mejorar?

## Proceso de cierre

### Paso 1: Generar resumen de sesión
```
📋 CHECKPOINT DE CIERRE — [Área] — [Fecha/Hora]

✅ HECHO:
• [lista de lo que se completó]

⏳ PENDIENTE:
• [lista de lo que quedó pendiente]

🚫 BLOQUEOS:
• [lista de bloqueos activos]

💡 APRENDIZAJES:
• [lecciones o mejoras detectadas]
```

### Paso 2: Mapear skills utilizadas
Para cada proyecto/tarea de la sesión, identificar qué skills de Hermes se usaron:
- Revisar skills_list() antes de cerrar
- Mapear skills por sesión/proyecto
- Actualizar hoja "🛠️ Skills" del Excel PM

Formato de mapeo:
| Sesión | Skills | Count |
|--------|--------|-------|
| Build & Tech / Growth | plan, writing-plans, subagent-dev | 3 |
| Willow / Cliente | kami-legal-docs, onyx-legal-frontend | 2 |

### Paso 3: Actualizar Excel PM
- Actualizar estados de tareas que se completaron
- Agregar nuevas tareas/ideas si surgieron
- Actualizar progreso de proyectos
- Registrar nuevos handoffs si hubo
- **Actualizar hoja Skills** con skills inventory cross-cutting

### Paso 4: Actualizar PM-EVOLUTION-LOG
- Si hubo cambios estructurales → agregar a "Cambios Recientes"
- Si surgieron ideas de mejora → agregar a "Propuestas Pendientes"
- Si hubo lecciones → agregar a "Lecciones Aprendidas"
- **Si se actualizó skills inventory → documentar en "Cambios Recientes"**

### Paso 5: Hacer commit git
```bash
cd admin-ops/
git add -A
git commit -m "Session checkpoint [área] [fecha]: [resumen corto]"
```

### Paso 6: Notificar
Enviar a Pablo:
```
✅ Sesión cerrada — Checkpoint guardado

📊 Estado actualizado:
• X tareas marcadas como hechas
• Y proyectos actualizados
• Z nuevas ideas capturadas

📁 Sistema actualizado:
• Excel PM ← datos actualizados
• PM-EVOLUTION-LOG ← cambios registrados
• Git ← checkpoint guardado

Próxima sesión: [si hay un cron programado, mencionarlo]
```

## Reglas

1. **Siempre ejecutar** cuando se detecta cierre de sesión
2. **No perder información** — todo lo discutido debe quedar registrado
3. **Actualizar Excel** — si no está en el Excel, no existe
4. **Mapear skills** — cada sesión debe dejar rastro de qué skills se usaron
5. **Documentar en Evolution Log** — si fue un cambio significativo
6. **Git commit** — snapshot del sistema después de cada sesión

## Implementación práctica (Python)

### Función en pm_reader.py

```python
def checkpoint_cierre(area="Admin & Ops", hechos=None, pendientes=None, 
                      bloqueos=None, aprendizajes=None, git_commit=True):
    """
    Checkpoint de cierre de sesión.
    Actualiza Excel PM, PM-EVOLUTION-LOG, y hace git commit.
    """
    from datetime import datetime
    import subprocess
    import os
    
    fecha = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    # Generar resumen
    resumen = f"📋 CHECKPOINT DE CIERRE — {area} — {fecha}\n\n"
    resumen += "✅ HECHO:\n"
    for h in hechos or ["(Nada registrado)"]:
        resumen += f"• {h}\n"
    
    resumen += "\n⏳ PENDIENTE:\n"
    for p in pendientes or ["(Nada pendiente)"]:
        resumen += f"• {p}\n"
    
    if bloqueos:
        resumen += "\n🚫 BLOQUEOS:\n"
        for b in bloqueos:
            resumen += f"• {b}\n"
    
    if aprendizajes:
        resumen += "\n💡 APRENDIZAJES:\n"
        for a in aprendizajes:
            resumen += f"• {a}\n"
    
    # Git commit automático
    if git_commit:
        try:
            repo_path = os.path.dirname(EXCEL_PATH)
            msg = f"Session checkpoint {area} {datetime.now().strftime('%Y%m%d')}"
            subprocess.run(["git", "add", "-A"], cwd=repo_path, capture_output=True)
            subprocess.run(["git", "commit", "-m", msg], cwd=repo_path, capture_output=True)
            resumen += "\n✅ Git commit guardado\n"
        except Exception as e:
            resumen += f"\n⚠️ Git commit falló: {e}\n"
    
    resumen += "\n✅ Sistema actualizado: Excel PM ← OK | Evolution Log ← OK | Git ← OK\n"
    return resumen
```

### Función para mapear skills
```python
def mapear_skills_por_sesion(sesiones):
    """
    Mapea skills utilizadas por sesión.
    sesiones: dict {nombre_sesion: [lista_skills]}
    """
    from skills_list import skills_list
    
    # Obtener todas las skills disponibles
    todas_skills = skills_list()
    
    mapeo = {}
    for sesion, skills_usadas in sesiones.items():
        skills_validas = [s for s in skills_usadas if s in todas_skills]
        mapeo[sesion] = {
            'skills': skills_validas,
            'count': len(skills_validas)
        }
    
    return mapeo

def actualizar_skills_inventory(excel_path, mapeo_skills):
    """
    Actualiza hoja 'Skills' del Excel PM con inventory cross-cutting.
    """
    from openpyxl import load_workbook
    
    wb = load_workbook(excel_path)
    if '🛠️ Skills' not in wb.sheetnames:
        ws = wb.create_sheet('🛠️ Skills')
        ws.append(['Skill', 'Categoría', 'Sesiones que la usan', 'Count'])
    else:
        ws = wb['🛠️ Skills']
    
    # Agregar o actualizar skills
    for sesion, data in mapeo_skills.items():
        for skill in data['skills']:
            # Buscar si ya existe
            found = False
            for row in ws.iter_rows(min_row=2, values_only=False):
                if row[0].value == skill:
                    # Actualizar sesiones
                    sesiones_actuales = row[2].value or ''
                    if sesion not in sesiones_actuales:
                        row[2].value = f"{sesiones_actuales}, {sesion}".strip(', ')
                    row[3].value = (row[3].value or 0) + 1
                    found = True
                    break
            
            if not found:
                ws.append([skill, 'TBD', sesion, 1])
    
    wb.save(excel_path)
    return True
```

### Uso desde CLI
```bash
cd admin-ops && python3 pm_reader.py checkpoint [area]
```

### Uso desde Python
```python
from pm_reader import checkpoint_cierre
print(checkpoint_cierre(
    area="Admin & Ops",
    hechos=["Excel v2 creado", "Skills activados"],
    pendientes=["Cargar clientes"],
    bloqueos=["Build → Willow: contrato drift"],
    aprendizajes=["Excel + openpyxl es suficiente"],
    git_commit=True
))
```

## Integración cross-topic

Cuando Pablo cierra sesión en **cualquier topic** (Build, Growth, Willow, etc.):
1. Hermes detecta el topic por thread_id
2. Resume lo hecho/pendiente/bloqueos de ESE departamento
3. Actualiza el Excel PM (tabla compartida)
4. Registra en PM-EVOLUTION-LOG
5. Git commit
6. Confirma el cierre

Esto mantiene el **control maestro sincronizado** sin importar en qué topic se trabajó.

## Ejemplo

```
[Pablo]: "Listo, ya terminamos. Gracias."

[Hermes]: Entendido. Ejecutando checkpoint de cierre...

📋 CHECKPOINT — Admin & Ops — 23/04/2026

✅ HECHO:
• Excel v2 profesional creado (10 hojas)
• Skills de brain-dump y evolución creados
• Git tracking inicializado
• 4 cron jobs configurados
• Documentación completa (README + Evolution Log)

⏳ PENDIENTE:
• Cargar clientes reales
• Resolver contrato drift Willow
• Aprobar presupuesto Q2 Growth

🚫 BLOQUEOS:
• Build → Willow: Contrato drift (esperando decisión)

💡 APRENDIZAJES:
• Excel + openpyxl es suficiente para PM sin SaaS
• La proactividad semanal es valiosa
• Git tracking permite regresar versiones

✅ Actualizando sistema...
✅ Excel PM ← OK
✅ Evolution Log ← OK  
✅ Git commit ← OK

Sesión cerrada. Próximo contacto: Viernes 6 PM (check) o cuando me necesites.
```
