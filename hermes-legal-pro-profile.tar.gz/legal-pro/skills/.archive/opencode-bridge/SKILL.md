---
name: opencode-bridge
description: Integración de OpenCode Go con Hermes Neo. Acceso a 100+ modelos (OpenAI, NVIDIA, Kimi, DeepSeek) para visión, generación de texto/imagen/código, y análisis.
version: 1.0.0
author: WS Capital
license: MIT
---

# OpenCode Bridge — Integración con Hermes Neo

## Propósito
Conectar Hermes Neo con OpenCode Go para acceso ilimitado a modelos de IA:
- **Visión:** Análisis de imágenes (llama-3.2-11b-vision)
- **Generación:** Imágenes (Flux), texto (GPT-5.4, Kimi), código (Codex)
- **Análisis:** Estrategia, marketing, diseño

## Trigger Words
- "usa opencode"
- "con opencode"
- "genera con opencode"
- "analiza con opencode"
- "modelo de opencode"

## Configuración

### API Key
Archivo: `~/.hermes/.env.opencode`
```
OPENCODE_API_KEY=sk-Q0QpvTFvTQF4xYREGyQIObJhKxbMvHdv7Sc02gsrwcnimUsDYu8fRAIrbFRZChiW
```

### Modelos Disponibles
| Uso | Modelo | Provider |
|-----|--------|----------|
| Visión | nvidia/meta/llama-3.2-11b-vision-instruct | NVIDIA |
| Texto | openai/gpt-5.4 | OpenAI |
| Texto rápido | openai/gpt-5.4-mini | OpenAI |
| Imagen | nvidia/black-forest-labs/flux.1-dev | NVIDIA |
| Código | openai/gpt-5.4-codex | OpenAI |
| Kimi | opencode-go/kimi-k2.6 | OpenCode |
| DeepSeek | nvidia/deepseek-ai/deepseek-v4-pro | NVIDIA |

## Uso

### 1. Análisis de Imagen (Funciona ✅)
```bash
python ~/.hermes/scripts/opencode_bridge.py analyze <image_path> [prompt]
```

### 2. Generación de Imagen (⚠️ Limitado)
**IMPORTANTE — Estado real del pipeline:**
- `image_generate` (tool nativo de Hermes) → apunta a **Fal.ai** (agotado sin balance)
- `opencode_bridge.py generate-image` → llama a `opencode-cli.exe` que **NO devuelve archivos de imagen**, solo texto conversacional
- **NVIDIA API** (`NVIDIA_API_KEY`) → solo tiene modelos de **chat/visión** (llama-3.2-vision), **NO tiene Flux ni generación de imágenes**

**Alternativas viables para generar imágenes:**
1. **NVIDIA API directa** con modelos de visión para análisis de imágenes locales
2. **Crear assets con código** (Python/PIL, FFmpeg) para tipografía, formas, efectos
3. **Usar fotos reales** + efectos visuales con FFmpeg (enfoque "Human-First")
4. **OpenCode Go web** (opencode.ai) como interfaz manual para generación con Flux

### 3. Generación de Texto (Funciona ✅)
```bash
python ~/.hermes/scripts/opencode_bridge.py generate-text "prompt" [model]
```

### 4. Generación de Código (Funciona ✅)
```bash
python ~/.hermes/scripts/opencode_bridge.py generate-code "prompt" [language]
```

## Flujo de Trabajo

### Para Campañas Visuales (ej: Eleutheria)
1. **Analizar fotos:** `analyze-batch ./fotos/`
2. **Generar assets:** `generate-image` para hero, backgrounds, logo
3. **Crear narración:** `generate-text` para guion
4. **Producir video:** SmartCut + FFmpeg

### Para Desarrollo
1. **Generar código:** `generate-code` con especificaciones
2. **Revisar:** Hermes + Claude Code
3. **Integrar:** Git + testing

## Reglas
1. Siempre preferir OpenCode cuando se necesiten modelos de visión o generación de imágenes
2. Usar Kimi (opencode-go/kimi-k2.6) como fallback cuando OpenAI esté saturado
3. Guardar todos los assets generados en la bóveda de campaña
4. Documentar uso de tokens en el Excel de PM

## Dependencias
- Python 3.11+
- requests (`pip install requests --break-system-packages` en WSL)
- python-dotenv (`pip install python-dotenv --break-system-packages` en WSL)
- OpenCode CLI instalado en Windows (con auth)

## Notas
- OpenCode CLI corre en Windows, accesible desde WSL via path
- La API key permite acceso a todos los modelos listados
- **Los límites de uso dependen del plan de OpenCode**
- **⚠️ GAP CRÍTICO:** `image_generate` tool nativo de Hermes está bloqueado en Fal.ai sin balance. No hay generación de imágenes automática disponible actualmente.
- **✅ NVIDIA API** funciona para análisis de visión (llama-3.2-vision) pero **NO** para generación de imágenes
- **Workaround para assets visuales:** Usar Python/PIL para crear tipografía/efectos, o FFmpeg para composición visual
