---
name: backend-spa-fallback
title: Backend-Served SPA Fallback
description: When a Next.js/React frontend build is blocked by dependency/permission issues, rapidly build a standalone HTML/JS SPA served directly from the FastAPI backend, wiring it to real API endpoints for full functionality.
triggers:
  - Next.js build fails repeatedly with missing dependencies
  - WSL/NTFS permission issues block npm/pnpm
  - Need a functional UI surface immediately while native frontend is being fixed
  - Docker frontend rebuild would take too long for the current iteration
---

# Backend-Served SPA Fallback

## When to use this

The main frontend (Next.js, React, etc.) cannot build due to:
- Missing or broken transitive dependencies in `node_modules`
- WSL/NTFS file permission issues during `npm install`
- Long Docker rebuild cycles blocking iteration
- Need to validate backend endpoints NOW, not after a 10-minute build

## Approach

1. **Abandon the broken frontend build temporarily**
2. **Create a standalone HTML/JS SPA** — single `index.html` with embedded CSS/JS
3. **Serve it from the existing FastAPI backend** using `StaticFiles` mount
4. **Wire every UI action to real backend endpoints** — no mocks, no placeholders
5. **Keep the native frontend code updated** in parallel so it can be compiled later

## FastAPI integration

```python
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

app = FastAPI()

SPA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "spa")
if os.path.isdir(SPA_DIR):
    app.mount("/spa", StaticFiles(directory=SPA_DIR, html=True), name="spa")

@app.get("/")
def root():
    if os.path.isfile(os.path.join(SPA_DIR, "index.html")):
        return FileResponse(os.path.join(SPA_DIR, "index.html"))
    return {"status": "API running"}
```

## SPA design rules

- **Single file** (`index.html`) with embedded `<style>` and `<script>`
- **Dark theme by default** — matches modern dev dashboards
- **No external dependencies** — pure vanilla JS, no bundler needed
- **Modular JS sections** inside the same `<script>` tag:
  - `api()` wrapper for `fetch` with error handling
  - `loadXxx()` functions for each data type
  - `openXxx()` / `closeXxx()` for modal state
  - Event handlers attached inline or via `onclick`
- **CSS custom properties** for consistent theming without a preprocessor

## What to wire

Always connect to real backend endpoints, never mock:

| Feature | Backend endpoint | SPA action |
|---------|------------------|------------|
| List items | `GET /api/items` | Render cards/table |
| Create item | `POST /api/items` | Modal form → POST → refresh list |
| Detail view | `GET /api/items/{id}` | Modal with tabs (Overview, Chat, Files, etc.) |
| Chat integration | `POST /api/items/{id}/chat-sessions` | Create real chat session, open in main app with `?chatId=` |
| File upload | `POST /api/items/{id}/files` | `<input type="file">` → FormData → POST |
| Document generation | `POST /api/generate` | Select template → POST → render + download |
| Agent/persona list | `GET /api/agents` | Render cards with links to main app chat |

## Key UX patterns

- **Modals** for create forms and detail views (no page navigation needed)
- **Tabs** inside detail modal for sub-features (chat, files, contracts)
- **Inline loaders** — `.loader` CSS spinner on buttons while async operations run
- **Toast/alerts** — simple `alert()` or custom toast div for errors
- **External links** — for chat, link out to the main app (`/chat?projectId=X&chatId=Y`)

## Docker deployment

```bash
# Copy SPA into running container and restart
docker cp ./spa my-api-container:/app/spa
docker cp ./api.py my-api-container:/app/api.py
docker restart my-api-container
```

## Recovery path

Once the native frontend build is fixed:
1. The backend endpoints already exist and are tested
2. The native frontend components can call the same endpoints
3. Remove or deprecate the SPA route
4. The SPA served valuable dual purpose: **validated the API** + **gave users a working surface immediately**

## Pitfalls

- **CORS**: if SPA is served from a different port than API, ensure `CORSMiddleware` is configured
- **File upload size limits**: FastAPI default is fine for most docs; increase if needed
- **UUID generation**: use `uuid.uuid4()` in Python, not client-side, for DB inserts
- **Onyx chat_session schema**: requires `deleted`, `shared_status`, `onyxbot_flow` columns even if not used
- **Project linkage**: creating a matter should also create a `user_project` in Onyx so chat sessions can attach to it

## Verification checklist

- [ ] SPA loads at `/`
- [ ] List endpoint populates the UI
- [ ] Create form works end-to-end
- [ ] Chat creates a real session and opens in the main app
- [ ] File upload creates real DB records and project links
- [ ] Document generation returns real content with variable substitution
- [ ] Agent seeding creates real persona rows in Onyx DB