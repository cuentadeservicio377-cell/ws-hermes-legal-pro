---
name: ws-growth-rescue
description: Diagnóstico y reparación de campañas de marketing fallidas o departamentos de growth con resultados pobres. Trigger cuando Pablo dice que una campaña dio "pésimos resultados", "lamentable", "necesitamos arreglarlo", o cualquier señal de frustración con resultados de marketing/growth.
compatibility: [hermes-agent]
author: WS Capital
version: 1.0.0
---

# WS Growth Rescue

## Misión
Convertir la frustración de Pablo con resultados de marketing en un diagnóstico accionable y un plan de reparación estructurado. No culpar. No inventar excusas. Identificar qué se rompió y cómo arreglarlo.

## Trigger
- "La campaña dio pésimos resultados"
- "El resultado es lamentable"
- "Necesitamos arreglar [departamento/growth/marketing]"
- "Esto no funcionó"
- Cualquier expresión de frustración con métricas, assets, o entregables de marketing

## Inputs
- Nombre de la campaña o departamento afectado
- Qué assets/entregables se produjeron
- Qué se esperaba vs. qué se obtuvo
- `marketing-context.md`
- Campaign brief original (si existe)
- Status del departamento (si existe)

## Outputs
1. **Diagnóstico honesto** — tabla plan vs. realidad con gaps cuantificados
2. **Problemas raíz** — máximo 5, clasificados en: infraestructura, proceso, recursos, estrategia
3. **Plan de reparación en fases** — con decisiones claras para Pablo
4. **Lecciones para memory** — para prevenir repetición

## Workflow

### Paso 0: Mapeo del Sistema Global (NUEVO — antes de diagnosticar la campaña)
**Crítico:** Antes de diagnosticar una campaña específica, verificar que el agente tiene visibilidad del sistema completo. El problema "pésimos resultados" a menudo viene de herramientas rotas, skills desconectadas, o infraestructura sin arrancar — no solo de la campaña.

Verificar:
- **Skills disponibles:** `skills_list()` — ¿Cuántas? ¿Qué categorías? ¿Están actualizadas?
- **Servicios activos:** Onyx (:3000), Paola (:8080), OpenCode (:11435), Onyx Marketing (:3003/3004)
- **APIs configuradas:** NVIDIA, Fal.ai, OpenCode Go, Codex — ¿Cuáles funcionan?
- **Repos externos clonados:** ¿Hay repos de marketing en `/root/` o `~/.hermes/` que no están integrados?
- **Marketing-context.md:** ¿Cuándo se actualizó por última vez? ¿Refleja la tesis actual de WS Capital?
- **Onyx Marketing:** ¿Está construido pero sin arrancar? (común)
- **Ecosystem Map:** ¿Existe `WS_CAPITAL_ECOSYSTEM_MAP.md`? ¿Está actualizado?

**Regla de oro:** Si el diagnóstico de campaña no incluye el estado del sistema global, el diagnóstico está incompleto.

**Regla de oro #2:** Si Pablo dice "el problema es más profundo" o "lo ves técnicamente, no estratégicamente", pivotar inmediatamente de diagnóstico de campaña a diagnóstico del departamento/sistema. El problema rara vez es la campaña; usualmente es que el departamento no tiene estrategia, contexto, o infraestructura operativa.

### Paso 1: Recolectar evidencia de la campaña
- Buscar archivos de la campaña en carpetas de WS-Campaigns
- Leer campaign brief original
- Leer marketing-context.md
- Buscar resúmenes de producción (RESUMEN-V1.md, etc.)
- Revisar sesiones previas con session_search
- Listar assets que se dijeron tener vs. assets realmente usados
- **NUEVO:** Verificar si repos externos fueron clonados pero NO integrados (común con coreyhaines31/marketingskills, goabstract/Marketing-for-Engineers, etc.)

### Paso 2: Construir tabla Plan vs. Realidad
| Aspecto | Plan | Realidad | Gap |
|---------|------|----------|-----|
| Concepto | ... | ... | ... |
| Assets | ... | ... | ... |
| Subagentes/Pipeline | ... | ... | ... |
| Entrega | ... | ... | ... |
| Infraestructura | ... | ... | ... |

### Paso 3: Diagnosticar problemas raíz
Clasificar cada gap en:
- **Infraestructura:** Fal.ai bloqueado, OpenCode 403, NVIDIA sin imagen, APIs caídas, Onyx Marketing sin arrancar, repos clonados pero no integrados
- **Proceso:** Subagentes definidos pero nunca activados, pipeline documentado pero no ejecutable, skills aisladas sin cross-references
- **Recursos:** Falta de fotos, falta de narración, falta de presupuesto, falta de contexto estratégico actualizado
- **Estrategia:** marketing-context desactualizado, mensaje desalineado con realidad del negocio, objetivo de campaña no definido antes de ejecutar

**NUEVO — Regla de profundidad:** Si Pablo dice "el problema es más profundo" o "lo estás viendo técnicamente, no estratégicamente", pivotar inmediatamente:
- Dejar de diagnosticar la campaña
- Diagnosticar el departamento/infraestructura/sistema
- Preguntar: "¿Cuál es el objetivo de negocio #1?" antes de proponer fixes tácticos

Regla: Nunca más de 5 problemas raíz. Si hay más, agrupar.

### Paso 4: Proponer plan de reparación en fases
Estructura obligatoria:

**FASE 0: Fundamentos Estratégicos (Antes de todo)**
- Definir/actualizar la tesis de WS Capital (una oración)
- Definir objetivo de negocio #1 (¿leads? ¿revenue? ¿brand?)
- Definir ICP específico
- Actualizar `marketing-context.md` con la tesis real
- **NUEVO:** Crear/actualizar Strategic Memory (brain-dumps estratégicos, no solo preferencias)

**FASE 1: Sistema Global (Hoy)**
- Auditar estado real de herramientas (OpenCode, Codex, Fal.ai, NVIDIA)
- Verificar Onyx Marketing: ¿construido? ¿arrancado?
- Verificar repos externos: ¿clonados? ¿integrados?
- Mapear skills actuales vs. skills necesarias
- Documentar gaps en tabla honesta

**FASE 2: Infraestructura de Skills (Esta semana)**
- Integrar repos externos con skills actuales (no reescribir desde cero)
- Definir cross-skill routing (orquestador v2)
- Implementar modos de ejecución (quick | standard | deep)
- Agregar evals/quality gates a skills críticas

**FASE 3: Ejecución con Sistema Reparado (Próxima semana)**
- Rehacer campaña con pipeline real
- Medir desde el inicio con KPIs definidos
- Documentar lecciones en Strategic Memory

Cada fase debe tener decisiones claras para Pablo: "¿Aprobamos esto? ¿Empezamos ahora?"

**NUEVO — Regla de integración de repos:** Si Pablo proporciona repos externos (ej: coreyhaines31/marketingskills, goabstract/Marketing-for-Engineers, draftdev/startup-marketing-checklist, BrianRWagner/ai-marketing-claude-code-skills):
1. Clonarlos con subagentes paralelos (máx 3 concurrentes)
2. Auditar estructura: ¿skills? ¿frameworks? ¿templates? ¿evals?
3. Mapear a skills actuales de WS Capital (no reescribir, adaptar)
4. Integrar como "contexto procedural" que alimenta las skills existentes
5. Documentar en marketing-knowledge-base

**NUEVO — Regla de Strategic Memory:** Cuando Pablo articula insights estratégicos en brain-dumps (pivots, tesis, lecciones de campañas), guardarlos en formato:
> **YYYY-MM-DD | Tipo:** Descripción de la decisión/insight + implicación para próxima campaña.

No guardar como "User prefiere X" (genérico). Guardar como "2026-04-29 | Pivot estratégico: WS Capital evolucionó de 'firma legal' a 'laboratorio de empresas'. Próximo departamento: agencia marketing."

### Paso 5: Actualizar memory
Si se identificó un problema sistémico (ej: "Fal.ai siempre bloqueado", "marketing-context desactualizado desde hace meses"), guardar en memory para prevenir repetición.

## Reglas críticas
1. **Nunca decir "todo funciona" sin verificar runtime.** Si algo se dice operativo, confirmar que realmente lo está.
2. **Nunca asumir que los subagentes se activaron solo porque están documentados.** Verificar logs, outputs, archivos generados.
3. **Separar correlation de causation.** Usar "parece que" cuando no hay certeza absoluta.
4. **Si no hay datos, decir "no hay suficientes datos para concluir X"** en lugar de inventar.
5. **Siempre proponer decisiones a Pablo, no imponer el plan.** El diagnóstico es del sistema; la decisión es de Pablo.
6. **NUEVO:** Siempre mapear el sistema global antes de diagnosticar una campaña. Si Onyx Marketing no arrancó, si repos externos no están integrados, si APIs están caídas — eso es parte del diagnóstico.
7. **NUEVO:** Cuando Pablo dice "el problema es más profundo" o "lo ves técnicamente, no estratégicamente", pivotar inmediatamente a diagnóstico estratégico del departamento, no de la campaña.
8. **NUEVO:** Si Pablo proporciona repos externos, auditarlos con subagentes paralelos e integrarlos con skills actuales. No ignorarlos ni reescribir desde cero.

## Anti-patrones a evitar
- ❌ "Hicimos lo que pudimos con lo que teníamos" → es evasión
- ❌ "La próxima vez será mejor" → sin plan concreto, es vacío
- ❌ "Faltó tiempo" → sin decir cuánto se necesita y por qué
- ❌ "Fal.ai falló" → sin proponer fallback sostenible

## Next Handoff
- Si el plan se aprueba → `ws-growth-orchestrator` para ejecutar fases
- Si se identifican problemas de infraestructura → `ws-system-repair` o `opencode-bridge`
- Si el marketing-context está desactualizado → `ws-content-drafter` para reescribirlo
- Si Onyx Marketing no está arrancado → `ws-department-activation`

## Lecciones de la campaña Hackathon (ejemplo tipo)
- marketing-context.md desactualizado desde abril 2026 (solo habla de legal, no de WS Capital)
- Subagentes documentados pero nunca activados para producción real
- Fal.ai bloqueado desde antes del hackathon; fallback "human-first" fue reactivo, no estratégico
- Onyx Marketing Agency construido pero nunca ejecutado (setup.sh pendiente)
- Sin KPIs definidos antes de la campaña → imposible medir "pésimos resultados" objetivamente
- **NUEVO (29abr2026):** 4 repos externos clonados (coreyhaines31/marketingskills, goabstract/Marketing-for-Engineers, draftdev/startup-marketing-checklist, BrianRWagner/ai-marketing-claude-code-skills) pero NO integrados con skills actuales
- **NUEVO (29abr2026):** Sistema global no mapeado antes de diagnosticar → se propusieron fixes tácticos cuando el problema era estratégico/infraestructural
- **NUEVO (29abr2026):** Brain-dumps estratégicos de Pablo se perdieron en memoria genérica → el sistema no aprendió la evolución de WS Capital de "firma legal" a "laboratorio de empresas"
- **NUEVO (29abr2026):** Growth & Marketing no es un departamento operativo, es una colección de skills aisladas sin pipeline real, sin métricas, sin arranque

## Lecciones de reparación departamental profunda (29abr2026)

### Hipótesis del brain-dump estratégico perdido
Cuando Pablo hace brain-dumps con insights estratégicos (pivots, tesis, lecciones), el sistema captura versiones genéricas y pierde el "por qué". Esto causa que el agente repita errores en sesiones futuras porque nunca aprendió la lección que Pablo ya había articulado.

**Fix:** Implementar "Strategic Memory" — formato diferente a user preferences:
> **YYYY-MM-DD | Tipo de decisión:** Descripción del insight/pivot + implicación para próxima campaña.

### Arquitectura "Marketing OS" vs Onyx Marketing
Onyx Marketing (stack Docker completo) es "nice to have", no "must have" para WS Capital en etapa actual. Hermes + scripts de automatización + skills bien integrados son suficientes cuando:
- No hay clientes externos de agencia
- No se necesita dashboard web
- Hay menos de 5 campañas activas
- No se necesita separar datos de múltiples clientes

**Regla de decisión:** ¿Construir Onyx Marketing? Solo si: clientes externos > 0, campañas simultáneas > 5, o necesidad de UI web para clientes. De lo contrario: Hermes como Marketing OS.

### El "Director de Departamento" concepto
Cuando un departamento está roto a nivel estratégico (no táctico), no se arregla con más skills ni más automatización. Se necesita un agente que:
1. Razone, no ejecute templates predefinidos
2. Haga preguntas cuando no sepa algo
3. Evolucione con cada interacción
4. Mejore su propio razonamiento
5. Comunique ideas complejas de forma simple

Esto no es una skill. Es un **perfil de agente** que opera como verdadero director. Se implementa como skill con SOUL.md embebido, no como pipeline de subagentes.

### Integración de repos externos (patrón general)
Cuando Pablo proporciona repos de marketing externos:
1. **No reescribir skills desde cero** — es desperdicio
2. **No ignorar los repos** — es desperdicio de conocimiento
3. **Usar repos como "contexto procedural"** — frameworks, templates, evals alimentan skills existentes
4. **Mecanismo:** Cada skill v2 tiene carpeta `references/` con frameworks relevantes de repos
5. **Auditoría:** Subagentes paralelos (máx 3) revisan estructura de cada repo
6. **Mapeo:** skills actuales de WS Capital ← frameworks de repos externos

### Patrón "Agentic vs Workflow" — Cuándo romper la caja

**Fuente:** Anthropic Research — "Building Effective Agents" (2024)
**Hallazgo clave:** Los mejores sistemas agenticos usan patrones simples y componibles, no frameworks complejos.

**La diferencia:**

| Workflow (caja) | Agent (sin caja) |
|-----------------|-------------------|
| Pasos predefinidos 1-2-3 | LLM decide dinámicamente cómo proceder |
| Subagentes con timeout | LLM principal hace directo |
| Tablas, bullets, estructuras | Fluido, adaptativo en tiempo real |
| "¿Aprobamos esto?" | "Acá está, ajustá si querés" |
| Orquestador separado | El LLM es el orquestador |

**Regla de decisión para WS Capital:**
- ¿Pablo dice "haz X"? → **Agent mode**: Hacer X directo, mostrar resultado, ajustar según feedback
- ¿Pablo dice "planifica una campaña de 3 meses"? → **Workflow mode**: Solo si se pide explícitamente
- Default: **Agent mode**. La caja no existe.

**Implicación práctica:**
- Eliminar skills complejos con pipelines de 5+ pasos
- Eliminar orquestadores separados que delegan a subagentes
- Operar como LLM augmentado (retrieval + tools + memory) sin abstracciones intermedias
- El building block es: LLM + transcripciones de Pablo + herramientas disponibles + memoria

**Anti-patrón detectado en esta sesión:**
- `ws-growth-orchestrator` con 5 subagentes → timeout, nada se ejecuta
- `ws-campaign-planner` con 8 fases → Pablo nunca llega a la fase 1
- `ws-market-researcher` con investigación web → no hay mercado en LATAM para investigar

**Fix aplicado:**
- Eliminar los 3 skills complejos
- Operar como agente flexible: Pablo → Yo → Resultado → Ajuste
- Tiempo: minutos, no horas

### Patrón "despedir y contratar nuevo departamento"
Cuando un departamento tiene:
- Skills que nunca se ejecutan
- Infraestructura construida pero sin arrancar
- Métricas que no existen
- Contexto desactualizado desde hace meses
- Brain-dumps estratégicos perdidos

La solución NO es parchear. Es **reinicio estratégico:**
1. Definir tesis de negocio (1 oración)
2. Definir ICP específico
3. Definir objetivo #1 de growth
4. Definir canal #1
5. Definir métrica norte
6. Recién ahí: reconstruir skills, automatización, ejecución

### Anti-patrón: "Hacer campaña ahora, estrategia después"
Cuando Pablo detecta resultados pobres y el agente propone "rehacer la campaña", es tentador saltar a ejecución. El verdadero fix es:
- Pausar ejecución
- Diagnosticar departamento (no campaña)
- Definir estrategia
- Recién ahí: ejecutar con sistema reparado
