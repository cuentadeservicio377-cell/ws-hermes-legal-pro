#!/bin/bash
# Hermes Chrome Zombie Killer
# Limpia procesos Chrome zombie cada 30 min
# Instalado: 2026-04-28 tras crisis de 47 zombies

ZOMBIES=$(ps aux | grep "[c]hrome.*<defunct>" | wc -l)
if [ "$ZOMBIES" -gt 0 ]; then
    for ppid in $(ps aux | awk '$8 ~ /Z/ && $11 ~ /chrome/ {print $3}' | sort -u); do
        kill -9 $ppid 2>/dev/null
    done
fi

# Matar también procesos Chrome colgados (>30 min sin actividad)
for pid in $(ps aux | grep "[c]hrome" | awk '$10 ~ /[0-9]+:[0-9]{2}/ {split($10,a,":"); if(a[1]*60+a[2]>30) print $2}' | sort -u); do
    kill -9 $pid 2>/dev/null
done