---
name: hermes-system-cleanup
description: Sesión completa de limpieza y reparación del sistema Hermes tras crisis de procesos zombie Chrome.
triggers:
  - Crisis de sistema Hermes bloqueado
  - Procesos zombie Chrome acumulados
  - Memoria saturada / swap alto
  - Herramientas de browser fallando repetidamente
---

# Hermes System Cleanup & Repair

## Diagnóstico rápido

```bash
# Ver procesos zombie
ps aux | grep defunct | grep -v grep

# Ver memoria
free -h

# Ver load
cat /proc/loadavg

# Ver procesos Chrome
ps aux | grep chrome | wc -l
```

## Reparación de emergencia

### 1. Matar zombies (padres primero)
```bash
# Listar PIDs padre de zombies
ps aux | awk '$8 ~ /Z/ {print $3}' | sort -u

# Matar padres de zombies
for ppid in $(ps aux | awk '$8 ~ /Z/ {print $3}' | sort -u); do
    kill -9 $ppid 2>/dev/null
done

# Verificar
ps aux | grep defunct | grep -v grep
```

### 2. Limpiar Chrome residual
```bash
killall -9 chrome chromium chromium-browser 2>/dev/null
sleep 2
ps aux | grep chrome | grep -v grep
```

### 3. Liberar swap
```bash
sudo swapoff -a && sudo swapon -a
free -h
```

## Instalación de protección permanente

### Script anti-zombie
```bash
mkdir -p ~/.hermes/scripts
cat > ~/.hermes/scripts/chrome-zombie-killer.sh << 'EOF'
#!/bin/bash
# Limpia procesos Chrome zombie cada 30 min
ZOMBIES=$(ps aux | grep "[c]hrome.*<defunct>" | wc -l)
if [ "$ZOMBIES" -gt 0 ]; then
    for ppid in $(ps aux | awk '$8 ~ /Z/ && $11 ~ /chrome/ {print $3}' | sort -u); do
        kill -9 $ppid 2>/dev/null
    done
fi
EOF
chmod +x ~/.hermes/scripts/chrome-zombie-killer.sh
```

### Cron jobs
```bash
# Editar crontab
crontab -e

# Añadir:
*/30 * * * * /home/pablo/.hermes/scripts/chrome-zombie-killer.sh >> /tmp/zombie-killer.log 2>&1
0 4 * * 1 /home/pablo/.hermes/scripts/chrome-zombie-killer.sh >> /tmp/hermes-monday-restart.log 2>&1
```

### Config.yaml límites browser
```yaml
browser:
  timeout: 60
  max_sessions: 3
  auto_cleanup: true
  kill_on_timeout: true
```

## Verificación post-reparación

```bash
# Todos los servicios
for port in 3000 8080 9119; do
    curl -s -o /dev/null -w "%{http_code}" http://localhost:$port
done

# Estado final
free -h && cat /proc/loadavg && ps aux | grep defunct | grep -v grep
```

## Lecciones aprendidas

- **Causa raíz:** Browser agent de Hermes no cierra Chromium limpiamente. Cada `browser_navigate`/`browser_click`/`browser_vision` deja instancias zombie.
- **Impacto:** En 1 día intenso se acumulan 47+ zombies, saturando memoria (7.7GB→229MB), swap (38%), CPU (load 1.09).
- **Síntomas:** Herramientas fallan, spawn de procesos bloqueado, respuestas lentas o timeouts.
- **Prevención:** Script auto cada 30 min + límites en config + reinicio semanal.