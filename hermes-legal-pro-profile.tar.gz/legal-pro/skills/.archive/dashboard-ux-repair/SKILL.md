---
name: dashboard-ux-repair
category: software-development
description: >
  Diagnose and repair broken interactivity in FastAPI + vanilla JS dashboard SPAs.
  When the user says "can't interact with the dashboard" or "buttons don't work",
  systematically check for missing JavaScript functions, duplicate definitions,
  broken event handlers, and backend-frontend mismatches. Then document a redesign
  plan when the UI doesn't reflect real business workflows (timeline-driven actions,
  agent alignment, etc.).
trigger: >
  Use when:
  1. User reports dashboard/SPA buttons or tabs not responding to clicks
  2. JavaScript console shows "function not defined" or similar errors
  3. User provides voice/text feedback that UI actions don't match business workflow
  4. Need to align frontend agent concepts with actual backend agent architecture
  5. Timeline-based or milestone-driven business logic needs UI representation
author: Hermes Neo / WS Capital
version: 1.0.0
---

# Dashboard UX Repair — Skill de Hermes

## Contexto

Los dashboards de WS Capital (FastAPI backend + vanilla JS SPA frontend) pueden perder interactividad por errores de edición en el HTML/JS: funciones que desaparecen, definiciones duplicadas, o event handlers que no llaman a las funciones correctas. Además, la UI puede quedar desalineada con la lógica de negocio real si se diseña sin validar el flujo de trabajo real del cliente.

## Diagnóstico Rápido (checklist)

Cuando el usuario dice "no puedo interactuar con el dashboard":

### 1. Verificar backend está vivo
```bash
curl -s http://localhost:8080/api/health 2>&1 | head -5
curl -s http://IP_WSL:8080/ 2>&1 | wc -c
```

### 2. Verificar JavaScript crítico en el HTML servido
```bash
# Funciones que DEBEN existir
curl -s http://IP:8080/ | grep -o "function switchTab" | wc -l    # Debe ser 1
curl -s http://IP:8080/ | grep -o "function renderAgentes" | wc -l # Debe ser 1
curl -s http://IP:8080/ | grep -o "function renderEventos" | wc -l  # Debe ser 1
curl -s http://IP:8080/ | grep -o "function init" | wc -l          # Debe ser 1
```

### 3. Verificar balance de tags `<script>`
```bash
curl -s http://IP:8080/ | grep -o "<script>" | wc -l
curl -s http://IP:8080/ | grep -o "</script>" | wc -l
# Deben ser iguales
```

### 4. Verificar que switchTab llama a renderers específicos
La función `switchTab(tab)` debe incluir:
```javascript
if (tab === 'catalogo') renderCatalogo();
if (tab === 'agentes') renderAgentes();
```

## Problemas Comunes y Fixes

### Problema 1: Función `switchTab` desaparecida
**Síntoma:** Clics en pestañas no hacen nada. Console: `switchTab is not defined`.
**Causa:** Ediciones previas con patch/replace eliminaron la función.
**Fix:** Agregar `switchTab` al final del `<script>`, antes de `DOMContentLoaded`:
```javascript
function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
    document.getElementById(`tab-${tab}`).classList.remove('hidden');
    
    if (tab === 'catalogo') renderCatalogo();
    if (tab === 'agentes') renderAgentes();
}
```

### Problema 2: Funciones duplicadas
**Síntoma:** Comportamiento inconsistente, la última definición "gana".
**Causa:** Múltiples patches agregaron la misma función en diferentes partes del archivo.
**Fix:** Buscar con `grep -n "function renderEventos"` y eliminar duplicados, dejando solo la versión correcta.

### Problema 3: `switchTab` no llama a renderers
**Síntoma:** La pestaña cambia de color pero el contenido no se actualiza.
**Causa:** `switchTab` solo cambia clases CSS pero no invoca las funciones de renderizado.
**Fix:** Agregar llamadas condicionales a los renderers dentro de `switchTab`.

### Problema 4: Backend escucha solo en localhost
**Síntoma:** Dashboard funciona en WSL pero no desde Windows.
**Causa:** `uvicorn.run(app, host="127.0.0.1", port=8080)` en vez de `host="0.0.0.0"`.
**Fix:** Cambiar a `host="0.0.0.0"` y usar IP de WSL (`172.31.35.200` o similar) desde Windows.

## Metodología de Rediseño UX (cuando la UI no refleja el negocio)

Cuando el usuario da feedback de voz/texto diciendo "esto está al revés", "debería ser diferente":

### Paso 1: Escuchar y documentar hallazgos
- El usuario describe el flujo de trabajo REAL (no el que imaginamos)
- Identificar: qué acciones son duplicadas, qué falta, qué sobra
- Ejemplo: "Generar docs y Ver docs son lo mismo → debería ser timeline con hitos"

### Paso 2: Auditar backend para entender agentes reales
```bash
grep -n "agentes_disponibles" app.py
grep -n "class.*Agente\|def.*agente" ejecutor_real.py
```
**Regla:** Los agentes del frontend DEBEN coincidir con los del backend. No inventar agentes que no existen.

### Paso 3: Crear plan de reparación documentado
Archivo: `PLAN_REPARACION_DASHBOARD_v{X}.{Y}.md` con:
1. Resumen del problema
2. Agentes reales del sistema (según backend)
3. Hallazgos por sección (Dashboard, Eventos, Catálogo, Agentes)
4. Arquitectura de datos requerida
5. Flujo de interacción ideal
6. Tareas de implementación por fase
7. Decisiones tomadas

### Paso 4: Implementar por fases
1. Backend API (nuevos endpoints)
2. Frontend Dashboard (rediseño de componentes)
3. Frontend Vista Detalle (nuevas pantallas)
4. Agentes (redefinir y conectar)
5. Catálogo/otros (futuro)

## Decisiones Clave de Diseño

1. **Timeline como centro:** En negocios con hitos temporales (eventos, proyectos), el timeline debe ser la pieza central de la UI, no botones genéricos.
2. **Un documento por hito:** Cada hito (D-60, D-45, etc.) tiene UN documento entregable. No hay "generar docs" genérico.
3. **Agentes = roles backend:** Los agentes mostrados en el frontend deben ser exactamente los que existen en `/api/agentes/estado`.
4. **Personas ≠ Agentes:** Coordinadores humanos (Natalia) no son agentes del sistema. Son usuarios que operan el sistema.
5. **Catálogo placeholder:** Si un módulo no es útil operativamente ahora, mantenerlo como placeholder y anotar para futuro.

## Verificación Post-Reparación

```bash
# 1. Backend responde
curl -s http://IP:8080/api/health

# 2. HTML tiene funciones críticas
curl -s http://IP:8080/ | grep -c "function switchTab"      # == 1
curl -s http://IP:8080/ | grep -c "function renderAgentes" # == 1
curl -s http://IP:8080/ | grep -c "function renderEventos"  # == 1

# 3. Tags balanceados
curl -s http://IP:8080/ | grep -o "<script>" | wc -l
curl -s http://IP:8080/ | grep -o "</script>" | wc -l

# 4. Acciones ejecutan scripts reales
# Probar POST a /api/agentes/{id}/accion con payload real
```

## Problema 5: Backend devuelve datos pero frontend muestra "vacío"
**Síntoma:** El usuario ve "Sin eventos próximos", "0 resultados", o listas vacías a pesar de que el backend tiene datos reales.
**Causa raíz (tres variantes):**

### Variante A: Clave JSON faltante en respuesta del backend
El endpoint `/api/dashboard` o similar no incluye la clave que el frontend espera. Ejemplo: el backend devuelve `{"kpi": {...}, "proximos_eventos": [...]}` pero falta `"eventos": [...]`. El frontend hace `data.eventos || []` y obtiene array vacío.

**Diagnóstico:**
```bash
curl -s http://IP:8080/api/dashboard | python3 -m json.tool | grep -E '"eventos"|"proximos"'
# Si no aparece "eventos", el backend no la envía
```

**Fix:** Agregar la clave faltante en el `return` del endpoint FastAPI:
```python
# ❌ WRONG — frontend recibe undefined para data.eventos
return {
    "kpi": {...},
    "proximos_eventos": [...],
}

# ✅ CORRECT
return {
    "kpi": {...},
    "proximos_eventos": [...],
    "eventos": eventos,  # ← clave que el frontend espera
}
```

### Variante C: Renderer no precargado en `init()`
El tab funciona cuando el usuario interactúa con un selector (ej: cambiar evento en un `<select>`), pero aparece completamente vacío en el primer click. El backend responde correctamente, los contenedores DOM existen, y `switchTab` llama al renderer — pero el renderer nunca fue ejecutado antes de que el usuario abriera el tab.

**Diagnóstico:**
```bash
# Verificar que init() llama al renderer
grep -A10 "async function init()" /path/to/spa/index.html
# Si no aparece renderFinanzas() o similar, el renderer no se precarga

# Verificar que el renderer existe
grep -n "function renderFinanzas" /path/to/spa/index.html
```

**Fix:** Agregar la llamada al renderer en `init()` junto a los otros renderers:
```javascript
// ❌ WRONG — finanzas tab vacío hasta que usuario interactúe
async function init() {
    const data = await apiGet('/api/dashboard');
    AppState.eventos = data.eventos || [];
    renderDashboard();
    renderEventos();
    renderCalendario();
    // renderFinanzas() ← FALTA
}

// ✅ CORRECT — todos los tabs precargados
async function init() {
    const data = await apiGet('/api/dashboard');
    AppState.eventos = data.eventos || [];
    renderDashboard();
    renderEventos();
    renderCalendario();
    renderFinanzas(); // ← Precargar tab oculto
}
```

**Regla de oro:** Todo renderer que pueda ser activado por `switchTab()` debe ser llamado al menos una vez en `init()`, incluso si su tab está oculto inicialmente. Esto evita que el usuario vea contenido vacío al hacer click en un botón discreto (como un icono de engranaje ⚙️ que abre un dashboard financiero oculto).

### Variante B: Mismatch de nombres de campo (Excel → backend → frontend)
Los datos vienen de una fuente externa (Excel, base de datos) con nombres de campo diferentes a lo que el frontend espera. Ejemplo: Excel tiene `dias_para_evento` y `total_cotizado`, pero el frontend espera `dias_restantes` y `total`.

**Diagnóstico:**
```bash
# Ver qué campos envía el backend
curl -s http://IP:8080/api/dashboard | python3 -c "import sys,json; d=json.load(sys.stdin); e=d.get('eventos',[{}])[0]; print(list(e.keys()))"

# Ver qué campos usa el frontend
grep -o "e\.[a-z_]*" /path/to/spa/index.html | sort | uniq
```

**Fix:** Transformar los campos en el backend antes de enviarlos:
```python
eventos = []
for e in raw_eventos:
    dias = calcular_dias(e["fecha"])
    eventos.append({
        "pao_id": e["pao_id"],
        "nombre": e["nombre"],
        "fecha": e["fecha"],
        "status": e["status"],
        "venue": e["venue"],
        "invitados": e["invitados"],
        # Mapeo de campos: fuente → frontend
        "total": e["total_cotizado"] or 0,        # Excel: total_cotizado → frontend: total
        "dias_restantes": dias,                    # calculado → frontend: dias_restantes
        # Preservar originales si otros endpoints los necesitan
        "total_cotizado": e["total_cotizado"],
        "dias_para_evento": e["dias_para_evento"],
    })
```

**Regla de oro:** El backend debe servir al frontend, no al revés. Si el frontend espera `dias_restantes`, el backend debe calcularlo y enviarlo, no esperar que el frontend lo derive.

## Pitfalls

- **No asumir que `switchTab` existe:** Siempre verificar con `grep` después de múltiples patches.
- **No inventar agentes:** Siempre revisar `/api/agentes/estado` antes de definir agentes en el frontend.
- **xdg-open no funciona en WSL root:** Para abrir carpetas desde el dashboard, usar mecanismo Windows/WSL, no `xdg-open`.
- **Funciones async vs sync en FastAPI:** Si se mezclan `def` y `async def` en endpoints, pueden aparecer `RuntimeWarning: coroutine 'Request.json' was never awaited`.
- **Missing `async` on POST handlers:** If a POST endpoint uses `request.json()` without `await`, or is defined as `def` instead of `async def`, it returns a coroutine object. The fix: change `def` to `async def` and add `await` before `request.json()`. Example:
  ```python
  # ❌ WRONG — returns coroutine, never awaited
  @app.post("/api/agentes/{id}/accion")
  def ejecutar_accion(id: str, request: Request):
      data = request.json()  # ← coroutine, not dict
      tipo = data.get("tipo")  # ← AttributeError: 'coroutine' object has no attribute 'get'
  
  # ✅ CORRECT
  @app.post("/api/agentes/{id}/accion")
  async def ejecutar_accion(id: str, request: Request):
      try:
          data = await request.json()
      except Exception:
          data = {}
      tipo = data.get("tipo", "")
  ```
- **Always verify server actually running after restart:** Use `curl http://IP:8080/api/health` and check `uptime_seconds`. A command may be issued but the server may crash immediately due to syntax or import errors.
- **Port zombie after restart:** If `address already in use` occurs, the old process is binding to `127.0.0.1:8080` even if the new code says `0.0.0.0`. Find PID with `lsof -i :8080` or `ss -tlnp | grep 8080`, then `kill -9 <PID>`.
- **WSL IP changes after reboot:** The WSL IP (`172.31.x.x`) is not static. After a system restart, verify with `ip addr show eth0 | grep "inet "` and update bookmarks accordingly. For a more stable setup, use `localhost` forwarding via `netsh interface portproxy` on Windows.
- **Optional argument defaulting to empty string in file paths:** When a backend function like `verificar_documentos(carpeta, safe_nombre, pao_id="")` has an optional `pao_id` that defaults to empty string, and the caller omits it, the function silently builds paths like `Pedido_Flor_.pdf` instead of `Pedido_Flor_PAO-002.pdf`. The symptom is "document not found" even though it was generated. The fix is one line at the call site: pass `pao_id` as the third argument. Always verify call sites match function signatures after adding optional parameters.
  ```python
  # ❌ WRONG — pao_id defaults to "", builds "Pedido_Flor_.pdf"
  documentos = verificar_documentos(carpeta, safe_nombre)
  
  # ✅ CORRECT — passes pao_id, builds "Pedido_Flor_PAO-002.pdf"
  documentos = verificar_documentos(carpeta, safe_nombre, pao_id)
  ```
  **Detection:** Check API response for filenames ending in `_.pdf` or `_.xlsx` — that's the telltale sign of a missing pao_id in path construction.
- **Frontend POST endpoints must call real scripts, not simulate:** Create a separate `ejecutor_real.py` module that uses `subprocess.run()` to execute actual Python scripts. Map action types to script names. The backend endpoint should import and call functions from this module, capturing stdout/stderr and returncode. See `dashboard-interactivity-pattern` Step 16 for full pattern.

## Ejemplo de flujo completo

```
Usuario: "No puedo interactuar con el dashboard"
  ↓
Hermes:
  1. curl /api/health → OK
  2. curl / → buscar "function switchTab" → NO EXISTE
  3. grep -n "function renderEventos" → 2 definiciones (duplicado)
  4. Leer HTML completo, identificar que switchTab se perdió en patch previo
  5. Restaurar switchTab al final del <script>
  6. Eliminar renderEventos duplicado
  7. Verificar: curl / | grep -c "function switchTab" → 1
  8. Confirmar con usuario: "Ahora sí responde al clic"
  ↓
Usuario: "Sí responde, pero las acciones no funcionan bien"
  ↓
Hermes:
  1. Escuchar feedback de voz: "debería ser timeline con hitos"
  2. Auditar backend: grep agentes en app.py
  3. Documentar plan: PLAN_REPARACION_DASHBOARD_v2.2.md
  4. Presentar plan al usuario para aprobación
```
