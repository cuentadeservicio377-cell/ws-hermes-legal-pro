---
name: ws-marketing-excel-control
description: "Build a professional offline marketing control system (Excel + file structure + documents) as an alternative or complement to cloud dashboards like Onyx. Used when the user wants tangible deliverables they can review, edit, and share."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [marketing, excel, control, dashboard, deliverables, ws-capital]
---

# WS Marketing Excel Control System

Use this when the user wants an **offline alternative to a cloud marketing dashboard**, or when the automated pipeline is not fully operational and you need to produce tangible deliverables NOW.

## Trigger

- User says: "quiero una ruta alternada", "dashboard alternativo a ONIX", "control en Excel"
- User is frustrated with "chatbot" behavior and wants to SEE deliverables
- Cloud department exists but LLM/API is failing (401, timeout, etc.)
- User needs to share/review deliverables with stakeholders

## Anti-pattern: Do NOT

- Ask the user for answers they don't have ("¿cómo se llama el producto?")
- Generate a simple list and call it done
- Create a barebones Excel without formulas, formatting, or navigation

## Pattern: DO

1. **Generate complete deliverables immediately** using available context (DB, memory, voice memos)
2. **Build professional Excel** with formulas, conditional formatting, hyperlinks, charts
3. **Create file system** with numbered folders matching the content pipeline
4. **Write client-facing documents** (Propuesta, Plan Editorial, Borradores) as markdown
5. **Link everything together** — Excel cells reference file paths

## Folder Structure

```
WS_Capital_Growth_Marketing/
├── 01_Control_Maestro/          ← Excel + JSON plans
├── 02_Clientes/
│   ├── {Client_Name}/           ← Per-client folder
│   └── Plantilla_Cliente/       ← Template for new clients
├── 03_Campanas/
│   ├── {Campaign_1}/
│   ├── {Campaign_2}/
│   └── {Campaign_3}/
├── 04_Contenido/
│   ├── Borradores/              ← Drafts for review
│   ├── Calendario/              ← Calendar views
│   └── Publicados/              ← Published pieces + metrics
├── 05_Entregables/
│   ├── Propuestas/              ← Strategy documents
│   ├── Reportes/                ← Monthly reports
│   └── Presentaciones/          ← Slide decks
├── 06_Research/
│   ├── {Vertical_1}/
│   └── {Vertical_2}/
├── 07_Metricas/Mensuales/
└── 08_Voz_Marca/                ← Voice profile + brand assets
```

## Excel Structure (11 Sheets)

### Sheet 1: 📖 Instrucciones
- What this Excel is, how to use it, color legend
- Link back to Dashboard

### Sheet 2: 📊 Dashboard
- **KPI Cards**: 6 metrics with big numbers, target, % progress
  - Formula: `=IF(J5=0,0,K5/J5)` for percentage
  - Color: green ≥80%, yellow ≥40%, red >0%, gray =0%
- **Campaigns table**: Active campaigns with status
- **Navigation buttons**: Hyperlinks to every other sheet
  ```python
  cell.hyperlink = f"#'{sheet_name}'!A1"
  cell.font = Font(color="2F5496", underline="single")
  ```
- **Weekly calendar**: 7-day view with status colors

### Sheet 3: 👥 Clientes
- Multi-tenant client database
- Columns: ID, Name, Slug, Industry, Plan, Retainer, Status, Date, Contact
- **Data validation dropdowns** for Status (Activo/Pausado/Inactivo) and Plan
- **Conditional formatting** on status column
- **AutoFilter** enabled

### Sheet 4: 🎯 Campañas
- Campaign control with SMART objectives
- Columns: ID, Name, Client, Vertical, Objective, SMART, Status, Start, End, Leads Obj, Leads Act, Conv Obj, Conv Act
- **Formula columns**:
  - `% Leads = IF(J5=0,0,K5/J5)` with number_format = '0%'
  - `% Conv = IF(L5=0,0,M5/L5)` with number_format = '0%'
- Conditional formatting on status

### Sheet 5: 📅 Calendario Editorial
- Weekly content calendar (4+ weeks)
- Columns: Week, Day, Date, Campaign, Product, Type, Format, Channel, Theme/Hook, CTA, Status, Draft Link, Published Link, Reach
- Each week is a merged header section
- Status colors: Borrador=green, Planeado=yellow, Publicado=blue, Aprobado=dark-green

### Sheet 6: 📝 Contenido
- Content pipeline tracking: Borrador → Revisión → Aprobado → Publicado
- Columns: ID, Campaign, Format, Theme, Status, Created, Approved, Published, Link, Notes
- Same conditional formatting as calendar

### Sheet 7: 📊 Métricas
- Monthly metrics database for training/analysis
- Columns: Month, Campaign, Pieces, Reach, Impressions, Engagement, Leads, Calls, Conversions, Revenue, ROI
- **SUM formula row** at bottom: `=SUM(C6:C11)`
- **Bar chart** showing leads by campaign

### Sheet 8: 🏢 {Client Name}
- Complete client profile
- Sections: Info, Products/Verticals, Monthly History (for ML training)
- Products table: #, Name, Vertical, Status, Active Clients, Price Range, Description

### Sheet 9: 🔬 Research
- Market research tracking
- Columns: ID, Vertical, Query, Sources, Status, Start, End, Findings

### Sheet 10: 🎤 Voice Profile
- Tone attributes table
- Anti-AI-Slop rules (banned words, structures, CTAs)
- Signature moves (required elements per piece)
- Confidence scores

### Sheet 11: 📦 Inventario
- Complete deliverable inventory linking Excel to file system
- Columns: ID, Name, Type, Campaign, Status, File Path, Date, Notes

## Paleta Corporativa WS Capital

| Color | Hex | Usage |
|-------|-----|-------|
| Ink Blue | #1B365D | Main headers, titles |
| Corporate Blue | #2F5496 | Secondary headers |
| Success Green | #548235 | Done/Active/OK |
| Warning Yellow | #FFC000 | In progress/Pending |
| Alert Red | #C00000 | Blocked/Overdue |
| Light Blue | #D9E2F3 | KPI card backgrounds |
| Light Gray | #F2F2F2 | Alternating rows, section headers |

## Document Templates (Markdown)

### 1. Propuesta Estratégica
- Executive summary
- Diagnosis (market, audience, pain points)
- Strategy (ORB Framework: Owned/Borrowed/Rented)
- Content calendar overview
- KPIs and metrics
- Next steps with deadlines
- Annex references

### 2. Plan Editorial Detallado
- Week-by-week table (day, date, campaign, format, theme, CTA, status)
- Publishing rules (Anti-AI-Slop)
- Voice rules

### 3. Borradores de Contenido
- Multiple posts with metadata (day, campaign, format, status)
- Each post includes: hook, scene, break, solution, CTA
- Editor notes per piece
- Review checklist
- Space for client feedback

## Key Implementation Details

### openpyxl Patterns

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.chart import BarChart, Reference
from openpyxl.worksheet.datavalidation import DataValidation

# Standard fills
FILL_HEADER = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
FILL_SUCCESS = PatternFill(start_color="548235", end_color="548235", fill_type="solid")
FILL_WARNING = PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid")
FILL_ALERT = PatternFill(start_color="C00000", end_color="C00000", fill_type="solid")
FILL_LIGHT = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
FILL_KPI = PatternFill(start_color="D9E2F3", end_color="D9E2F3", fill_type="solid")

# Standard border
BORDER_THIN = Border(
    left=Side(style='thin', color='CCCCCC'),
    right=Side(style='thin', color='CCCCCC'),
    top=Side(style='thin', color='CCCCCC'),
    bottom=Side(style='thin', color='CCCCCC')
)

# Conditional formatting for status
ws.conditional_formatting.add('E5:E100',
    CellIsRule(operator='equal', formula=['"Activa"'], fill=FILL_SUCCESS))
ws.conditional_formatting.add('E5:E100',
    CellIsRule(operator='equal', formula=['"Pausada"'], fill=FILL_WARNING))
ws.conditional_formatting.add('E5:E100',
    CellIsRule(operator='equal', formula=['"Cancelada"'], fill=FILL_ALERT))

# Data validation dropdown
dv = DataValidation(type="list", formula1='"Activo,Pausado,Inactivo"')
ws.add_data_validation(dv)
dv.add('G5:G100')

# Navigation hyperlink
cell.hyperlink = f"#'📊 Dashboard'!A1"
cell.font = Font(color="2F5496", underline="single")

# AutoFilter
ws.auto_filter.ref = "A4:L50"
```

### Critical Rules

1. **NEVER ask the user for information they already gave in voice memos.** Extract it programmatically and fill the Excel/docs.
2. **Use formulas, not static values**, for calculated columns (%, totals, counts).
3. **Every status cell must have conditional formatting** so the user sees color immediately.
4. **Every sheet must have a "← Volver al Dashboard" link** at the top.
5. **File paths in Excel must match the actual folder structure** so the user can navigate.
6. **Create documents as if delivering to a client** — professional headers, version numbers, dates.

## Integration with Onyx Marketing Department

This Excel system is NOT a replacement for the cloud department. It is:
- A **fallback** when APIs fail
- A **review surface** for the founder
- A **client deliverable** format
- A **local backup** of cloud data

When the cloud department is operational:
1. Sync data from Onyx DB → Excel (read via bridge API)
2. User edits in Excel → push back to Onyx via bridge API
3. Use Excel for reporting/presentations, Onyx for execution

## Pitfall: Emoji in Sheet Names

If using emoji in sheet names (e.g., `📊 Dashboard`), scripts that reference them must use the exact name:
```python
# ❌ KeyError
ws = wb["Dashboard"]

# ✅ Correct
ws = wb["📊 Dashboard"]
```

Or centralize sheet names in constants:
```python
SHEETS = {
    "dashboard": "📊 Dashboard",
    "clientes": "👥 Clientes",
    "campanas": "🎯 Campañas",
}
```
