---
name: ws-video-social
description: "Skill para crear videos cortos verticales (Reels, TikTok, Shorts) desde cero. Toma assets de la carpeta de deposito, genera lo que falta, ensambla en SmartCut, renderiza, scorea viralidad, y entrega MP4 + thumbnail + copy. Siempre invocable con lenguaje natural."
version: 1.0.0
author: WS Capital
license: MIT
metadata:
  hermes:
    tags: [video, social, reels, tiktok, shorts, vertical]
---

# WS Video Social — Reels / TikTok / Shorts

## Propósito
Crear videos cortos verticales (9:16, 1080x1920) para redes sociales. Desde un tema o descripción hasta MP4 final entregable.

## Trigger Words (cómo invocar este skill)
Dime cualquiera de estas frases y activo este skill:
- "haz un reel", "genera un short", "video para TikTok"
- "contenido vertical", "video rápido para redes"
- "crea un reel de [tema]", "short sobre [tema]"
- "video de 30 segundos para Instagram"

## Estructura de Carpetas

```
C:\Users\DELL\Documents\WS-Capital\Video-Studio\
├── 00-Assets\              ← Depósito de ingredientes
│   ├── Imagenes\
│   ├── Audio\
│   ├── Video-Raw\
│   ├── Music\
│   └── Branding\          ← Logos, colores, fonts de WS/Willow/Paola
│
└── 01-Social-Reels\
    ├── 01-Briefs\         ← brief.md con brief aprobado
    ├── 02-Assets-Generados\ ← imágenes, voz, música generados
    ├── 03-Edicion-SmartCut\ ← proyecto del editor
    ├── 04-Renders-Finales\  ← MP4 final
    └── 05-Entregas\         ← MP4 + thumbnail + copy + hashtags
```

## Flujo Completo

### Paso 1: BRIEF (Hermes entiende qué necesitas)
**Input:** Tema o descripción en lenguaje natural
**Output:** `01-Briefs/YYYY-MM-DD_[tema]/brief.md`

Contenido del brief:
- Tema central
- Plataforma objetivo (TikTok, Reels, Shorts)
- Tono (profesional, divertido, educativo)
- Duración objetivo (default: 15-30s)
- Target audience
- CTA (call to action)

### Paso 2: REVISAR ASSETS (Hermes revisa depósito)
**Input:** Carpeta `00-Assets/`
**Output:** Lista de assets disponibles + lista de lo que falta

Revisar:
- `00-Assets/Branding/[marca]/` → logos, colores, fonts
- `00-Assets/Imagenes/` → fotos relevantes
- `00-Assets/Music/` → tracks disponibles
- `00-Assets/Video-Raw/` → footage existente

### Paso 3: GENERAR ASSETS (Hermes crea lo que falta)
**Tools:** `image_generate`, `text_to_speech`
**Output:** Guardado en `02-Assets-Generados/`

Generar:
- 3-5 imágenes de escena (una por escena del guion)
  - **Opción 1:** `image_generate` nativo de Hermes (cuando disponible)
  - **Opción 2:** Fal.ai (SOLO si balance confirmado)
  - **Opción 3:** OpenCode Go (backup teórico — Cloudflare 403 en WSL)
  - **NO usar NVIDIA API** para generación de imagen — no disponible en este entorno
- Narración de voz (español/inglés según necesidad)
  - `text_to_speech` nativo de Hermes
  - Edge TTS (gratis, activo)
- Música de fondo (si no hay en depósito)

### Paso 4: GUION (estructura hook-first)
**Formato:**
```
Escena 1 (0-3s): HOOK — pregunta provocadora o dato impactante
Escena 2 (3-10s): PROBLEMA/BENEFICIO — qué resuelve
Escena 3 (10-20s): PRUEBA/SOLUCIÓN — cómo funciona
Escena 4 (20-30s): CTA — "sigue para más", "link en bio", etc.
```

### Paso 5: ENSAMBLAR EN SMARTCUT
**Input:** Assets generados + guion
**Output:** Proyecto en `03-Edicion-SmartCut/`

Hermes:
1. Crea proyecto SmartCut (JSON)
2. Importa imágenes en timeline
3. Añade voz como pista de audio
4. Añade música de fondo (bajo volumen)
5. Añade transiciones (default: fade rápido)
6. Configura duración por escena

**SmartCut URL:** `http://localhost:3000`

### Paso 6: REVISIÓN (tú revisas en SmartCut)
Hermes te dice: "Revisa el proyecto en SmartCut. ¿Aprobado o necesitas cambios?"

Si necesitas cambios:
- "Haz el hook más corto" → Hermes ajusta timing
- "Cambia la música" → Hermes reemplaza track
- "Añade zoom en escena 2" → Hermes añade efecto

### Paso 7: RENDER
**Tool:** ffmpeg (local) + Python PIL/OpenCV para efectos
**Output:** `04-Renders-Finales/YYYY-MM-DD_[tema].mp4`

Formato: 1080x1920, 30fps, H.264

**Alternativa si ffmpeg no es suficiente:**
- `maquina social` (video-machine pipeline) si está instalado
- SmartCut para edición manual

### Paso 8: VIRAL SCORE
**Tool:** `maquina viral_score`
**Output:** Score Tribe v2 (0-100)

Si score < 60:
- Rehacer hook (escena 1)
- Re-ensamblar
- Re-scorear
- Máximo 3 iteraciones

### Paso 9: ENTREGA
**Output:** Carpeta `05-Entregas/YYYY-MM-DD_[tema]/`

Contenido:
- `video-final.mp4` — Video renderizado
- `thumbnail.png` — Thumbnail generado
- `copy-linkedin.txt` — Copy para LinkedIn
- `copy-instagram.txt` — Copy para Instagram
- `hashtags.txt` — Hashtags optimizados
- `score-report.txt` — Reporte de viralidad

### Paso 10: ARCHIVAR
**Output:** Copiar a `99-Repositorio/YYYY-MM/Social/`
**Dashboard:** Actualizar `99-Control-Maestro/dashboard.html`

## Comandos Rápidos

```bash
# Crear nuevo proyecto social
maquina social --brief "[descripción]" --platform tiktok

# Generar assets
maquina social --generate-assets --brief "[descripción]"

# Renderizar desde proyecto SmartCut
maquina social --render ./03-Edicion-SmartCut/proyecto.json

# Score viral
maquina viral_score ./04-Renders-Finales/video.mp4
```

## Dependencias
- video-machine instalado y funcionando
- SmartCut corriendo en localhost:3000
- API keys configuradas (OpenAI para guionización, opcional)
- Assets en 00-Assets/ (si no hay, Hermes genera todo)

## Notas
- Si no hay assets en depósito, Hermes genera TODO desde cero
- Si hay assets, Hermes los usa y genera solo lo que falta
- Siempre guardar en estructura de carpetas para que el dashboard funcione
- El score viral es opcional pero recomendado
