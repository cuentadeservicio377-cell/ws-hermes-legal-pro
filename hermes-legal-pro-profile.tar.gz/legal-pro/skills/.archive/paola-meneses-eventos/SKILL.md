---
name: paola-meneses-eventos
category: productivity
description: >
  Operar el negocio de Paola Meneses (Wedding & Event Planner) vía Hermes.
  Dashboard web v2.1 con calendario mensual/semanal/diario, sistema de tareas,
  alertas accionables, finanzas reales, y 5 agentes conectados.
  Generar cotizaciones PPT, exportar Bookdates, consultar inventario,
  monitorear eventos, registrar pagos, y alertar deadlines.
  15 eventos reales, 60 documentos operativos PDF generados.
  Funciona standalone (Excel local) o integrado con Onyx (PostgreSQL).
  Protocolo de cierre de sistema documentado (4 fases).
author: Hermes Neo / WS Capital
version: 2.4.0
---

# Paola Meneses Eventos — Skill de Hermes

## Contexto
Paola Meneses organiza bodas, XV años, cumpleaños y aniversarios. **NO hay paquetes fijos** — cada evento es personalizado a medida seleccionando servicios individuales del catálogo.

Su operación tiene 3 documentos clave:
- **PowerPoint de cotización** → para el cliente (servicios individuales seleccionados)
- **Excel Bookdate** → planning maestro del evento
- **Excel Inventario** → operativo D-15

**Principio fundamental:** *"Todo funciona por separado. Todo funciona junto."*

### Lógica de negocio real (extraída de 15 PPTs reales)

**Paola NO ofrece paquetes.** Cada evento se cotiza seleccionando servicios individuales del catálogo:
- Túnel/Pasillo de Ingreso
- Back/Mampara Mesa de Novios
- Mesa de Novios (mobiliario)
- Cielo de Flores/Pista
- Centros de Mesa (Imperiales, Redondas, Rectangulares)
- Pista de Baile
- Ceremonia
- Ramos y Accesorios
- Área de Cóctel/Lounge
- Árboles/Elementos Perimetrales
- Iluminación

**Para cada servicio se generan entregables operativos:**
- 1 Pedido de Flor (consolidado por evento)
- 1 Requisición de Bodega (consolidada)
- 1 Checklist de Montaje (con secciones por área)
- 1 Lista de Compras (si aplica)
- 1 Nómina de Personal (solo WP Completo)

**Los entregables son para personas que NO usan computadora** — PDFs impresos, simples, visuales.

### Estados del evento
| Estado | Significado | Trigger |
|--------|-------------|---------|
| Cotizado | Cliente recibió PPT, no ha pagado | PPT enviado |
| Contratado | Anticipo recibido + aceptación | Anticipo pagado |
| En Planning | D-30 iniciado | Evento confirmado |
| Listo | Checklist D-7 completado | Tareas listas |
| Ejecutado | Evento realizado | Día del evento |
| Cerrado | Cierre financiero completo | D+7 cierre |

### Tipos de servicio
| Tipo | Descripción | Eventos |
|------|-------------|---------|
| Decoración | Solo montaje de decoración | 14 de 15 |
| WP Completo | Wedding Planner completo (catering, música, foto, etc.) | 1 de 15 |

### Aliados comerciales
- Osvaldo Martínez: Wedding Planner / Aliado Comercial (6 eventos)
- Natalia: Coordinadora de Paola (empleada)

### Totales reales extraídos (15 eventos)
- Total conocido: ~$3,095,245 MXN
- Evento más caro: Stephie & Alan ($684,500)
- Evento más barato: Jesús y Daniel ($32,520)
- 4 Contratados, 11 Cotizados

## Links críticos
- Dashboard Web: `http://localhost:8080` (v2.1, calendario como vista principal)
- Workspace: `/root/ws-paola-meneses/`
- Scripts: `/root/ws-paola-meneses/scripts/`
- Docs: `/root/ws-paola-meneses/docs/` (PDFs estilo Kami generados)
- Documentación MD: `/root/ws-paola-meneses/06_Documentacion/`
- Schema BD: `/root/ws-paola-meneses/schemas/db-schema.sql`
- Control Maestro Excel: `/root/ws-paola-meneses/sistema-completo/control-maestro/Paola_Meneses_Control_Maestro_V3_DATOS_REALES.xlsx`
- Backend API: `/root/ws-paola-meneses/dashboard/app.py` (FastAPI v2.1)
- Frontend SPA: `/root/ws-paola-meneses/dashboard/spa/index.html`
- Datos extraídos: `/root/ws-paola-meneses/datos_extraidos/`
- Resumen maestro: `/root/ws-paola-meneses/datos_extraidos/RESUMEN-MAESTRO-15-EVENTOS-COMPLETO.json`
- Carpetas clientes Windows: `/mnt/c/Users/DELL/Documents/WS Capital/Paola Meneses Decoracion/03_Eventos_Confirmados/BB_En_Proceso/`
- Motor documentos: `/root/ws-paola-meneses/generar_docs_operativos.py`
- Requisiciones bodega: `/root/ws-paola-meneses/generar_requisiciones_bodega.py`

### Estado del sistema (v4.0) — CENTRO DE MANDO REAL

**Transformación de demo visual a sistema operativo real (sesión 29abr2026).**

### Dashboard Financiero Oculto (v4.2 — NUEVO)

**Implementado en sesión 29abr2026.** Pablo pidió ocultar los números financieros del dashboard principal porque se ven mal en eventos públicos y Latinoamérica es más reservada con los números.

#### Diseño
- **Botón discreto** "💰 Finanzas" en esquina superior derecha del header, color morado suave
- **NO es pestaña visible** en la navegación principal
- Accesible solo desde ese botón

#### Contenido del Dashboard Financiero
- **KPIs:** Total cotizado, Pagado, Pendiente, Margen promedio
- **Gráfica:** Ingresos vs gastos por mes (barras visuales simples, no Chart.js)
- **Margen promedio:** Grande y visible con color por estado (verde >30%, naranja >15%, rojo <15%)
- **Tendencia:** Positiva/Negativa con comparativa pagado vs pendiente
- **Tabla detalle:** Todos los eventos con total, pagado, pendiente, margen, estado
- **Selector de evento:** Filtra por evento específico o muestra todos

#### Datos reales del Excel
- Suma automática de todos los eventos
- Cálculo de porcentajes recaudados
- Color de margen según rentabilidad

#### Implementación técnica
```javascript
// Frontend: Botón en header (no en nav)
<button class="btn-finanzas" onclick="switchTab('finanzas')">
    💰 Finanzas
</button>

// Función renderFinanzas() — async, carga /api/dashboard
// - Filtra eventos por selector
// - Calcula KPIs con reduce()
// - Genera gráfica con divs (no canvas)
// - Renderiza tabla con HTML string
```

**Regla de diseño:** Los números financieros NUNCA se muestran en el dashboard principal. Solo en la vista financiera oculta.

### Bugs críticos corregidos (FASE 1)

| Bug | Descripción | Fix |
|-----|-------------|-----|
| **CRIT-001** | Scripts generaban documentos con JSON resumido (genéricos) | `ejecutor_v4.py` lee `PAO-XXX-completo.json` con datos reales del PPT |
| **CRIT-002** | Backend no detectaba documentos generados | `verificar_documentos()` ahora recibe `pao_id` correctamente en `app.py:1382` |
| **CRIT-003** | Frontend tenía funciones decorativas (toast en vez de acciones reales | Frontend v4.0 conecta con APIs reales |
| **CRIT-004** | Backend no enviaba array `eventos` en `/api/dashboard` | Agregada clave `"eventos"` al return de `get_dashboard()` |
| **CRIT-005** | Campos `dias_restantes` y `total` eran `None` en frontend | Transformación explícita en `get_dashboard()` antes de enviar |

### Arquitectura v4.0

```
Backend (FastAPI v3.0.0)
  ├── app.py — API endpoints + import ejecutor_v4
  ├── ejecutor_v4.py — Genera documentos con datos reales del JSON completo
  │   ├── Lee PAO-XXX-completo.json (slides PPT)
  │   ├── Extrae: servicios, cantidades, precios, venue, WP
  │   └── Genera: requisicion, pedido_flor, checklist, nomina
  └── persistencia/ — JSON de tareas y timeline

Frontend (SPA HTML v4.0)
  ├── Dashboard con KPIs reales
  ├── Calendario Operativo (reemplaza Pipeline Kanban)
  │   ├── Vista Lista: items cronológicos por mes
  │   ├── Vista Mensual: grid tipo planner 7 días (Dom-Sáb)
  │   ├── Toggle Lista/Mensual con navegación por meses
  │   └── Chips de colores: azul=evento, verde=a tiempo, naranja=D-10, rojo=D-2, gris=vencida
  ├── Detalle operativo completo
  │   ├── Resumen ejecutivo (riesgo, próxima acción)
  │   ├── Timeline D-60 a D+7 (10 hitos con fechas reales, colores por urgencia)
  │   ├── Documentos reales (ver, regenerar, abrir)
  │   ├── Finanzas (total, pagado, pendiente, margen)
  │   ├── Proveedores/aliados
  │   └── Historial de acciones
  ├── Alertas accionables con botones directos
  ├── WP externo (badge, alertas D-10)
  ├── Bodega/Víctor (estados, materiales)
  ├── Catálogo real conectado
  └── Agentes ejecutores con estado real
```

### Nuevo endpoint: `/api/calendario`

Devuelve items del calendario operativo con fechas reales:
- `items`: array de eventos + tareas del timeline ordenados por fecha
- `hoy`: fecha actual
- `alertas_urgentes`: count de tareas con D-2 o menos
- `alertas_proximas`: count de tareas con D-10 o menos

Cada item tiene:
- `tipo`: "evento" | "tarea"
- `fecha`: YYYY-MM-DD
- `dias_restantes`: días hasta la fecha
- `color`: hex según urgencia
- `pao_id`: evento asociado

### Timeline completo en detalle del evento

10 hitos visibles con fechas calculadas desde la fecha del evento:
- D-60: Cotización final validada
- D-45: Bookdate operativo generado
- D-30: Pedido de flor enviado
- D-15: Requisición de bodega emitida
- D-7: Checklist de montaje validado
- D-2: Confirmación final con proveedores
- D-1: Nómina/call sheet confirmada
- D-Day: Ejecución del evento
- D+1: Desmontaje y limpieza
- D+7: Cierre financiero

Cada hito muestra: fecha exacta, días restantes, estado (A tiempo/Alerta/Urgente/Completado), agente responsable, badge de documento generado/pendiente.

### Flujo end-to-end verificado (PAO-002)

1. Abrir evento → ver datos reales (CUMPLEAÑOS GUILLE, Patio Manku, 100 invitados)
2. Generar pedido de flor → archivo creado con datos reales
3. Generar requisición bodega → archivo creado con datos reales
4. Completar tarea D-15 → persiste en backend
5. Abrir carpeta → explorer.exe abre en Windows
6. Detectar documentos → API devuelve archivos reales

### Patrón de ejecución correcto (aprendido)

**NO empezar sin aprobación explícita.**

1. Cargar skills relevantes (`paola-meneses-eventos`, `systematic-debugging`, `test-driven-development`)
2. Investigar raíz del bug antes de fix (Phase 1 systematic-debugging)
3. Aplicar fix con commit por fase
4. Verificar con tests/curl antes de declarar completado
5. No avanzar a siguiente fase hasta cerrar la actual

### Git workflow

```bash
cd /root/ws-paola-meneses
git init  # Si no existe
git add -A
git commit -m "FASE X.Y: descripción"
```

### Commit history v4.0
- `9e716dd` — Plan v4 centro de mando
- `8f63711` — FASE 1.1: ejecutor_v4.py + app.py import v4

## Estado del sistema (v2.2) — POST-REPARACIÓN COMPLETA
- ✅ 15 eventos reales cargados (4 contratados, 11 cotizados)
- ✅ Navegación funcional con tabs: Dashboard, Eventos, Catálogo, Agentes
- ✅ Timeline interactivo por evento con mini-hitos (D-60, D-45, D-30, D-15, D-7, D-1, D+1, D+7)
- ✅ Acciones reales por hito/documento (generar requisición, checklist, pedido flor, bookdate, abrir carpeta)
- ✅ Scripts de generación individual por evento: `--pao-id PAO-XXX`
- ✅ Scripts de generación por tipo de documento: `--tipo {requisicion,checklist,nomina,todos}`
- ✅ Nuevo script `generar_pedido_flor.py` para Pedido de Flor individual
- ✅ Nuevo script `scripts/export_bookdate_individual.py` para Bookdate individual
- ✅ Documentos operativos generados por evento (60 PDFs base + individuales bajo demanda)
- ✅ Tareas generadas desde timeline real del evento (`generar_tareas_desde_timeline`)
- ✅ Alertas inteligentes basadas en hitos del timeline (`generar_alertas_inteligentes`)
- ✅ Finanzas con `parse_valor_excel` robusto (strings no numéricos → `None`, no crash)
- ✅ Progreso real basado en documentos generados + hitos completados (`calcular_progreso_real`)
- ✅ Persistencia JSON en disco (`estado_sistema.json`, `historial_acciones.json`)
- ✅ Frontend reactivo con estado global, renderizado condicional por tab
- ✅ Mini-action buttons en tarjetas de evento (📁 abrir carpeta, 📄 generar docs, 👁️ ver detalle)
- ✅ Toast notifications animadas (success/error/info/warning) en lugar de `alert()`
- ✅ Timeline checkboxes interactivos con completado visual (strikethrough + color)
- ✅ Search & filter bar en tiempo real (nombre, ID, venue + filtros por status)
- ✅ Panel de detalle deslizable con acciones en header
- ✅ Responsive layout: tablet (768px) y mobile (480px)
- ✅ Backend `async def` corregido en endpoints POST (`generar_documento_cliente`, etc.)
- ✅ Ejecutor real (`ejecutor_real.py`) conecta frontend → scripts reales vía `subprocess.run()`
- ✅ Abrir carpeta en Windows desde WSL usando `cmd.exe /c start` con path convertido
- ✅ Dashboard accesible desde Windows vía IP WSL (`http://172.31.35.200:8080`) con `host='0.0.0.0'`
- ✅ Documentación actualizada: FLUJOS, PLAN_REPARACION, AUDITORIA_DOCUMENTOS, AUDITORIA_LOGICA
- ✅ Excel PM maestro de WS Capital actualizado
- ⚠️ Catálogo de servicios aún hardcodeado (no extraído automáticamente de PPTs reales) — CRIT-003
- ⚠️ 1 PPT físico faltante: PAO-005 (XV ANDREA) — reportado explícitamente
- ⚠️ Precios en Excel ≠ precios reales de PPTs para 2 eventos (templates sin precio)
- ⚠️ Margen % no calculado (faltan costos operativos reales)
- ⚠️ Pagos recibidos no registrados en Excel (todos null)
- ⚠️ Persistencia JSON básica (no PostgreSQL/Onyx integrado aún)
- ⚠️ Abrir carpeta no funciona en Windows desde WSL (xdg-open falla) — CRIT-001
- ⚠️ Frontend HTML puede tener duplicidades/errores — no se validó visualmente — CRIT-002
- ⚠️ Estado de evento no persiste en Excel (solo JSON local) — MAY-001
- ⚠️ Timeline marca completado por fecha, no por verificación de documento — MAY-004
- ⚠️ Generación no incluye pedido de flor ni bookdate individual en mapa de tipos — MAY-005
- ⚠️ Nómina de personal no tiene script real de generación — MAY-006

## Integración Wedding Planner (v2.3 — NUEVO)

**Implementado en sesión 29abr2026.**

### Catálogo de WP Aliados

| ID | Nombre | Tipo | Contacto | Documentos típicos |
|----|--------|------|----------|-------------------|
| `osvaldo_martinez` | Osvaldo Martínez | WP Independiente | 33 2831 8688 | logística, minuto a minuto, layout, proyecto decoración |
| `joanca` | JOANCA | Venue con WP | venue directo | logística venue, reglas de espacio |
| `quinta_torres` | Quinta de Torres | Venue con WP | venue directo | logística venue |
| `ninguno` | Sin WP / Paola sola | Decoración sola | — | — |

### Eventos por tipo de WP

| Tipo WP | Eventos | Count |
|---------|---------|-------|
| **Con WP externo** (Osvaldo o venue) | PAO-001, 002, 003, 004, 005, 007, 008, 009, 010, 011, 012, 013, 014, 015 | **13** |
| **Sin WP** (Paola sola) | PAO-006 (Hugo & Lulú), Bere & Carlos | **2** |

### Flujo integrado desde cotización (CLAVE: integrado, no por encima)

> **Lección de sesión 29abr2026:** El WP no es un paso adicional después del anticipo. Es una selección que se hace DESDE LA COTIZACIÓN y afecta todo el flujo posterior.

```
Nuevo Lead → Cotización
    ↓
┌─────────────────────────────────────────┐
│ PASO NUEVO (desde el inicio):           │
│ ¿Tiene Wedding Planner externo?         │
│                                          │
│ [Sí] → Seleccionar WP del catálogo      │
│         ├─ Osvaldo Martínez              │
│         ├─ JOANCA                        │
│         └─ Quinta de Torres              │
│                                          │
│ [No] → Modo "Paola sola"               │
│                                          │
│ Se guarda en: evento.wp_aliado           │
│ Se usa en TODO el sistema desde aquí    │
└─────────────────────────────────────────┘
    ↓
Generar PPT (incluye slide de coordinación WP o Paola sola)
    ↓
Contratado → Bookdate (ya sabe si tiene WP)
    ↓
D-30: Alertas específicas según WP
    ↓
D-10: Si tiene WP → "Pedir docs al WP"
       Si no tiene WP → "Pedir datos manuales"
    ↓
D-7: Generar docs operativos
     Si tiene WP + docs recibidos → fusionar datos (Paola + WP)
     Si tiene WP + sin docs → alerta urgente
     Si no tiene WP → docs básicos con datos manuales
```

### Dónde se integra en cada flujo existente

| Flujo Original | Dónde va el paso WP | Qué cambia |
|----------------|---------------------|-----------|
| **1. Nuevo Lead → Cotización** | Después de recopilar datos básicos | Se pregunta WP sí/no/quién. Va en el PPT de cotización. |
| **2. Contratado → Planning** | Después de "Anticipo recibido" | Bookdate ya sabe si hay WP. Alertas específicas. |
| **3. D-15 → Operativo** | En "Generar documentos operativos" | Docs usan datos reales fusionados, no genéricos. |
| **4. Día D → Ejecución** | En "Minuto a minuto" | Minuto a minuto viene del WP, no del Bookdate genérico. |
| **5. Cierre Post-Evento** | Sin cambios | Cierre financiero sigue igual. |

### Cambios mínimos en estructura actual

| Componente | Cambio | Detalle |
|-----------|--------|---------|
| **Excel Maestro** | +2 columnas | `WP_Aliado` (dropdown), `WP_Contacto` |
| **JSON evento** | +1 sección | `wp_aliado` con id, nombre, contacto, docs recibidos |
| **PPT Cotización** | +1 slide | Slide de coordinación: WP externo o Paola sola |
| **Dashboard** | +1 campo | Selector de WP en formulario de nuevo/editar evento |
| **Alertas** | Condicionales | Si tiene WP: pedir docs. Si no: pedir datos manuales. |
| **Docs operativos** | Datos fusionados | Usar datos reales del PPT + datos del WP si existen |

### Schema JSON actualizado (v4.1 — con logística operativa)

```json
{
  "pao_id": "PAO-001",
  "nombre": "Liliana & Masiel",
  "wp_aliado": {
    "id": "osvaldo_martinez",
    "nombre": "Osvaldo Martínez",
    "contacto": "33 2831 8688",
    "seleccionado_en": "2026-04-15",
    "documentos_recibidos": {
      "logistica": true,
      "minuto_a_minuto": true,
      "layout": true,
      "proyecto_decoracion": false
    }
  },
  "logistica": {
    "hora_entrada_montaje": "09:00",
    "hora_montaje_terminado": "17:00",
    "hora_evento_inicio": "18:30",
    "hora_evento_fin": "02:30",
    "hora_desmontaje_inicio": "02:30",
    "hora_desmontaje_fin": "06:30",
    "venue_contacto": "María 33 2350 8246",
    "venue_url": "https://maps.app.goo.gl/WN3FMEVBn8TZiLSPA",
    "notas_proveedores": "Entramos el mismo día a las 9:00 am. El montaje tiene que estar TERMINADO el jueves A LAS 5:00 PM. Se tiene que DESMONTAR TODO al finalizar el evento y tenemos hasta las 6:30 para dejar el área limpia.",
    "proveedores_wp": [...],
    "minuto_a_minuto": [...]
  }
}
```

## Edición Interactiva — v4.2 (NUEVO: sesión 29abr2026)

**Implementado en sesión 29abr2026.** Pablo pidió que el frontend sea editable e interactivo, no solo visual.

### Endpoints de edición

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `POST /api/evento/{pao_id}/actualizar` | Guarda datos operativos en Excel | contacto, WP, horarios, notas |
| `POST /api/evento/{pao_id}/registrar-pago` | Registra pago, calcula totales | monto, metodo, notas |

### Campos editables

**Logística del Evento:**
- `venue` — Nombre del venue
- `venue_url` — Link Google Maps
- `contacto_venue` — Teléfono/contacto del venue
- `hora_entrada` — Hora de entrada al venue (09:00)
- `hora_montaje_listo` — Deadline montaje terminado (17:00)
- `hora_evento_inicio` — Inicio del evento (18:30)
- `hora_evento_fin` — Fin del evento (02:30)
- `hora_desmontaje` — Límite desmontaje (06:30)
- `wp_nombre` — Nombre del Wedding Planner
- `wp_contacto` — Teléfono del WP
- `notas_proveedores` — Notas especiales para proveedores

**Finanzas:**
- `total` — Total cotizado (no editable directamente, viene del PPT)
- `pagos_recibidos` — Acumulado automáticamente por pagos registrados
- `total_pendiente` — Calculado: total - pagos_recibidos

### Frontend: Modo Edición

```
Detalle del Evento
├── Botones de acción:
│   ├── 📄 Generar Docs
│   ├── 📁 Abrir Carpeta
│   ├── ✏️ Editar ← Activa modo edición
│   └── 💰 Registrar Pago
│
└── Modo Edición ON:
    ├── Formularios inline con inputs
    │   ├── Venue (text)
    │   ├── URL Maps (text)
    │   ├── Contacto venue (text)
    │   ├── WP nombre (text)
    │   ├── WP contacto (text)
    │   ├── Horarios (time inputs)
    │   └── Notas (textarea)
    ├── Botón 💾 Guardar Cambios
    └── Botón ❌ Cancelar
```

**Regla:** Cuando `editMode = true`, la sección "Logística del Evento" se reemplaza por "Editar Logística" con formularios. Cuando se guarda, se envía POST al backend, se actualiza el Excel, se invalida el cache, y se recarga el evento.

### Safe Access para Excel Legacy

**Problema:** Excel viejo tiene 20 columnas, Excel nuevo necesita 30. El código debe funcionar con ambos.

**Solución:**
```python
def safe_row_value(row, index, default=""):
    try:
        if index < len(row) and row[index] is not None:
            return row[index]
        return default
    except:
        return default

# Uso en load_eventos_from_excel:
evento = {
    # ... campos 0-19 ...
    "hora_entrada": safe_row_value(row, 20, "09:00"),
    "hora_montaje_listo": safe_row_value(row, 21, "17:00"),
    "hora_evento_inicio": safe_row_value(row, 22, "18:30"),
    "hora_evento_fin": safe_row_value(row, 23, "02:30"),
    "hora_desmontaje": safe_row_value(row, 24, "06:30"),
    "venue_url": safe_row_value(row, 25, ""),
    "contacto_venue": safe_row_value(row, 26, ""),
    "notas_proveedores": safe_row_value(row, 27, ""),
    "wp_nombre": safe_row_value(row, 28, ""),
    "wp_contacto": safe_row_value(row, 29, ""),
}
```

**Cache invalidation:**
```python
EVENTOS_CACHE = None

def get_eventos_data():
    global EVENTOS_CACHE
    if EVENTOS_CACHE is None:
        EVENTOS_CACHE = load_eventos_from_excel()
    return EVENTOS_CACHE

def invalidate_cache():
    global EVENTOS_CACHE
    EVENTOS_CACHE = None
```

### Patrón de edición confirmado por Pablo

> "El sistema tiene que ser interactivo. Tengo que poder editar los datos desde el frontend y que se guarden en el Excel. No quiero ir al Excel manualmente."

**Principio:** Toda edición de datos operativos debe hacerse desde el dashboard. El Excel es el backend de persistencia, no la interfaz de edición.

### Colores por tipo de dato (frontend)

- 🟢 Verde = Entrada (inicio)
- 🟡 Naranja = Deadline (montaje listo)
- 🔴 Rojo = Evento en curso
- ⚫ Gris = Desmontaje (final)
- 🔵 Azul = Venue/Contacto
- 🟡 Amarillo = Notas urgentes a proveedores

### Agregar campos operativos sin romper Excel legacy

**Problema:** El Excel maestro tiene 20 columnas (índices 0-19). Se necesitan agregar 10 campos operativos más (índices 20-29) pero el Excel viejo no las tiene.

**Solución — Safe access con valores por defecto:**

```python
def load_eventos_from_excel():
    # ... código existente ...
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if not row[0]:
            continue
        
        evento = {
            # ... campos 0-19 existentes ...
            "notas": row[19] or "",
            # Campos operativos adicionales (con safe access)
            "hora_entrada": row[20] if len(row) > 20 and row[20] else "09:00",
            "hora_montaje_listo": row[21] if len(row) > 21 and row[21] else "17:00",
            "hora_evento_inicio": row[22] if len(row) > 22 and row[22] else "18:30",
            "hora_evento_fin": row[23] if len(row) > 23 and row[23] else "02:30",
            "hora_desmontaje": row[24] if len(row) > 24 and row[24] else "06:30",
            "venue_url": row[25] if len(row) > 25 and row[25] else "",
            "contacto_venue": row[26] if len(row) > 26 and row[26] else "",
            "notas_proveedores": row[27] if len(row) > 27 and row[27] else "",
            "wp_nombre": row[28] if len(row) > 28 and row[28] else "",
            "wp_contacto": row[29] if len(row) > 29 and row[29] else "",
        }
```

**Regla:** Siempre usar `len(row) > N` antes de acceder a columnas opcionales. Esto permite:
- Excel viejo (20 columnas) → carga sin errores, valores por defecto
- Excel nuevo (30 columnas) → carga con datos reales
- No romper compatibilidad hacia atrás

### Frontend: Sección de Logística del Evento

En el detalle del evento, agregar una sección que muestre:

```html
<div class="detail-section">
    <h3>🚛 Logística del Evento</h3>
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
        <!-- Venue + Maps -->
        <!-- Contacto venue -->
        <!-- Horario entrada montaje -->
        <!-- Horario montaje listo -->
        <!-- Horario evento -->
        <!-- Horario desmontaje límite -->
    </div>
    <!-- WP info -->
    <!-- Notas a proveedores (destacadas en amarillo) -->
</div>
```

**Colores por tipo de dato:**
- 🟢 Verde = Entrada (inicio)
- 🟡 Naranja = Deadline (montaje listo)
- 🔴 Rojo = Evento en curso
- ⚫ Gris = Desmontaje (final)
- 🔵 Azul = Venue/Contacto
- 🟡 Amarillo = Notas urgentes a proveedores

### Alertas inteligentes según WP

| Días | Si tiene WP | Si NO tiene WP |
|------|-------------|----------------|
| D-30 | "Iniciar planning. Pedir docs al WP" | "Iniciar planning. Pedir datos venue" |
| D-15 | "Generar docs. ¿Llegaron docs del WP?" | "Generar docs con datos manuales" |
| D-10 | "URGENTE: Pedir docs al WP si faltan" | "Completar datos manuales" |
| D-7 | "Confirmar proveedores (lista del WP)" | "Confirmar proveedores (lista propia)" |
| D-1 | "CHECKLIST FINAL (con datos del WP)" | "CHECKLIST FINAL (datos propios)" |

### Dashboard: Subir docs del WP

```
┌─────────────────────────────────────────┐
│  PAO-001 — Documentos del WP            │
├─────────────────────────────────────────┤
│  WP: Osvaldo Martínez                   │
│                                          │
│  [📁 Subir logistica_proveedores.pdf]   │
│  [📁 Subir minuto_a_minuto.pdf]         │
│  [📁 Subir layout.pdf]                  │
│  [📁 Subir proyecto_decoracion.pdf]      │
│                                          │
│  Al subir:                              │
│  → Extraer datos automáticamente        │
│  → Fusionar con datos de Paola          │
│  → Actualizar documentos operativos    │
│                                          │
└─────────────────────────────────────────┘
```

### Cambios en scripts de generación

**`generate_cotizacion.py`:**
- Nuevo parámetro: `--wp-aliado [id]`
- Si tiene WP: incluye slide "Coordinación del Evento" con datos del WP

**`generar_requisiciones_bodega.py`:**
- Leer `PAO-XXX-completo.json` (no el resumen)
- Extraer cantidades reales del PPT
- Incluir horarios del WP si existen

**`generar_pedido_flor.py`:**
- Extraer flores específicas del PPT-completo
- Incluir hora de entrega en venue del WP

## Tema Bodegas — Análisis y Plan de Implementación (v2.3)

**Descubierto en sesión 29abr2026 con Pablo en bodega real.**

El sistema de bodegas opera **5 flujos interconectados** para la logística física de eventos. Los scripts existentes (`generar_requisiciones_bodega.py`, `generar_pedido_flor.py`) tienen un **bug crítico**: leen `PAO-XXX.json` (resumen) en vez de `PAO-XXX-completo.json` (slides PPT completos), generando output genérico en lugar de usar las cantidades y especificaciones reales del evento.

**Wedding Planner docs** (logística, minuto a minuto, layout, proyecto decoración) son fuente rica de datos estructurados que debe integrarse al JSON del evento para generar documentos operativos precisos.

### Flujo 1: Requisición de Bodega (para Víctor/jefe de bodega)
**Trigger:** D-7 (una semana antes del evento)
**Input:** Datos del evento (invitados, venue, servicios del PPT)
**Output:** PDF con:
- Mobiliario (mesas, sillas, tipo según evento)
- Decoración (telas, centros de mesa, velas, arcos)
- Equipo (iluminación, sonido)
- **NUEVO:** Hora de entrada al venue, tipo de acceso (carga/principal/rampa)
- **NUEVO:** Estructuras grandes que necesitan 2 días de montaje
- **NUEVO:** Ubicación física en bodega (pasillo A, rack 3, etc.)

**Script existente:** `generar_requisiciones_bodega.py` (genérico, necesita enriquecerse)

### Flujo 2: Requisición de Flores (para Florista Jefe)
**Trigger:** D-7 (enviar), D-1 (montaje)
**Input:** Paleta de colores, tipo de evento, servicios florales del PPT
**Output:** PDF con:
- Centros de mesa (cantidad = mesas)
- Ramos (novia, damas, boutonnieres)
- Cielo de flores / guirnaldas
- Túnel de ingreso / arco floral
- **NUEVO:** Fecha/hora exacta de entrega en venue
- **NUEVO:** Contacto encargado venue para acceso
- **NUEVO:** Paleta confirmada (no genérica)
- **NUEVO:** Flores específicas del PPT real (no estimadas)

**Script existente:** `generar_pedido_flor.py` (cantidades estimadas, necesita extraer de PPT)

### Flujo 3: Requisición de Compras (lo que NO está en inventario)
**Trigger:** D-10 (para tener margen de compra)
**Input:** Requisición de bodega vs inventario real
**Output:** PDF/Excel con:
- Items que SÍ están en bodega (juntar)
- Items que NO están (comprar/alquilar)
- Presupuesto estimado de compras
- Proveedor sugerido

**Script:** NO EXISTE — necesita crearse

### Flujo 4: Recordatorios a Paola
**Trigger:** D-7, D-3, D-1
**Output:** Alertas/mensajes con:
- "Revisar con Víctor qué se tiene que juntar para [evento]"
- "Confirmar hora de entrada con venue [nombre]"
- "Verificar que florista recibió requisición"

**Implementación:** Agregar al sistema de alertas existente (`generar_alertas_inteligentes`)

### Flujo 5: Timeline de Montaje
**Trigger:** D-2 (estructuras grandes), D-1 (flores y detalles)
**Output:** Checklist separado por día con:
- D-2: Estructuras, entarimados, mobiliario pesado
- D-1: Flores, iluminación, decoración fina
- Día D: Checklist final de carga y transporte

**Script:** NO EXISTE — necesita crearse

### Inventario Real de Bodega
Para que el sistema funcione, se necesita **poblar el inventario** con lo que existe físicamente:
- Mobiliario: mesas (redondas, imperiales, serpentina), sillas (Tiffany, Ghost, Napoleón), tarimas
- Decoración: telas, candelabros, velas, arcos, centros de mesa base
- Equipo: iluminación, sonido, cables
- Consumibles: cintas, listones, hilos, papel

**Formato:** Excel o JSON con: SKU, nombre, cantidad, ubicación física, estado

### Próximos pasos sugeridos (para sesión futura):
1. Poblar inventario real de bodega (con Víctor/Paola)
2. Enriquecer `generar_requisiciones_bodega.py` con campos de acceso/hora/ubicación
3. Enriquecer `generar_pedido_flor.py` extrayendo flores reales de PPTs
4. Crear `generar_requisicion_compras.py` (comparar requisición vs inventario)
5. Crear `generar_timeline_montaje.py` (D-2 y D-1)
6. Agregar alertas de recordatorio al dashboard

### Notas de diseño confirmadas por Pablo:
- "Todo funciona por separado. Todo funciona junto."
- Los entregables son para personas que NO usan computadora → PDFs impresos, simples, visuales
- Víctor es el responsable de bodega (persona real)
- Los floristas llegan 1 día antes a hacer montajes
- Se envía requisición al florista jefe vía PDF o carpeta Google
- La bodega tiene demasiadas cosas → las listas son para que Víctor sepa qué juntar

> **Total verificado post-reparación:** $3,465,245 MXN (14 eventos con precio, 1 pendiente de PPT).
> **Sistema 95%+ operativo. Gap documental PAO-005 reportado honestamente.**

## Limitaciones Conocidas (honestas)
- ⚠️ Precios en Excel ≠ Precios reales de PPTs (13/15 eventos con datos, 2 templates)
- ⚠️ Documentos operativos son genéricos (no usan precios reales de cada PPT)
- ⚠️ Pagos recibidos no registrados en Excel (todos null)
- ⚠️ Margen % no calculado (faltan costos operativos reales)
- ⚠️ 1 PPT físico faltante entre PAO-004/PAO-005 (solo 14 PPTs en carpeta entrega)
- ⚠️ PAO-004 actualizado a $370,000 (XV YULY). PAO-005 (XV ANDREA) pendiente de PPT.

> **Nota para entregas:** El sistema es 100% operativo pero los documentos operativos son templates. Los precios finales se ajustan evento por evento. Recomendar 1 sesión adicional para reconciliar precios reales si el cliente necesita exactitud financiera.
> 
> **Total verificado post-reparación:** $3,465,245 MXN (14 eventos con precio, 1 pendiente).

## Protocolo de Cierre de Sistema (4 fases)

Cuando Pablo pida "terminar el sistema", ejecutar en este orden:

### FASE 0: Verificación Honesta Pre-Entrega (CRÍTICA — no saltar)
Antes de decir "está completo", auditar realmente:

```bash
# 1. Contar PPTs físicos vs eventos en Excel
find /mnt/c/Users/.../Proyectos\ Eventos -name "*.pptx" | wc -l
# Esperado: 15. Si hay 14 → identificar cuál falta

# 2. Verificar documentos operativos por evento
find /mnt/c/Users/.../BB_En_Proceso/PAO-*/04_Documentos_Operativos -name "*.pdf" | wc -l
# Esperado: 60 (15 × 4)

# 3. Verificar dashboard endpoints
curl -s http://localhost:8080/api/health
curl -s http://localhost:8080/api/finanzas | python3 -m json.tool
# Finanzas NO debe retornar 500

# 4. Verificar que parse_valor_excel maneje strings no numéricos
# Si /api/finanzas da TypeError int+str → aplicar fix de parse_valor_excel
```

**Regla de oro:** Si hay discrepancia entre PPTs físicos y datos del sistema → reportar a Pablo ANTES de entregar.

### FASE 0b: Auditoría de Errores Post-Reparación (NUEVO — v2.2)

Después de completar las 5 fases de reparación, ejecutar auditoría honesta de TODO lo que queda mal:

```bash
# Verificar funciones de persistencia
python3 -c "import app; print('guardar_tareas:', hasattr(app, 'guardar_tareas'))"
python3 -c "import app; print('guardar_estado_evento:', hasattr(app, 'guardar_estado_evento'))"

# Verificar que finanzas funcionen con argumento correcto
python3 -c "import app; app.calcular_finanzas_seguras(app.get_eventos_data())"

# Verificar estructura de eventos
python3 -c "import app; e=app.get_eventos_data()[0]; print('Campos:', list(e.keys()))"

# Verificar catálogo
python3 -c "import app; print('catalogo_items:', hasattr(app, 'catalogo_items'))"
```

**Checklist de auditoría de errores:**
- [ ] Abrir carpeta funciona en Windows (no solo WSL/xdg-open)
- [ ] Frontend renderiza correctamente en navegador Windows
- [ ] Catálogo de servicios NO está hardcodeado por PAO_ID
- [ ] Estado de evento persiste en Excel (no solo JSON local)
- [ ] Timeline usa verificación de documentos, no solo fecha
- [ ] Generación incluye pedido_flor y bookdate individual
- [ ] Nómina tiene script real de generación
- [ ] Rutas MOTOR_DIR y SCRIPTS_DIR son correctas
- [ ] Formato de moneda usa MX$ en lugar de $
- [ ] Días negativos muestran "Evento pasado" en lugar de "-X días"

**Documentar resultados en:** `06_Documentacion/AUDITORIA_ERRORES_v{VERSION}.md`
**Actualizar Excel PM maestro** con checkpoint de auditoría y tareas de corrección.

### FASE 1: Completar Datos
1. Auditar datos extraídos vs Excel maestro vs PPTs físicos
2. **Mapear cada PPT físico a su PAO-ID correcto** (por contenido, no por nombre de archivo)
3. **Extraer precios reales de PPTs** usando regex (ver workflow abajo)
4. Identificar eventos con datos incompletos (ej. PAO-004, PAO-005)
5. Extraer/completar JSONs de datos para todos los eventos
6. Actualizar resumen maestro (`RESUMEN-MAESTRO-15-EVENTOS.json`)

### FASE 1b: Extraer Precios Reales de PPTs (workflow)
Cuando los precios en Excel ≠ precios en PPTs:

```python
import re, json, glob
from pptx import Presentation

# Regex para precios mexicanos en PPTs
PRECIO_RE = re.compile(r'\$?([\d,]+(?:\.\d{2})?)\s*(?:MXN|mn|pesos)?', re.I)

def extraer_precio_ppt(path):
    """Extrae el precio total de un PPT de cotización Paola Meneses."""
    prs = Presentation(path)
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                text = shape.text
                # Buscar línea con "Total" o "TOTAL"
                if 'total' in text.lower():
                    matches = PRECIO_RE.findall(text)
                    if matches:
                        # Tomar el último match (el total acumulado)
                        raw = matches[-1].replace(',', '')
                        return float(raw)
    return None

# Batch sobre todos los PPTs
ppt_files = glob.glob("/mnt/c/Users/.../Proyectos Eventos/*.pptx")
precios_reales = {}
for ppt in ppt_files:
    pao_id = mapear_ppt_a_pao_id(ppt)  # lógica de mapeo por contenido
    precio = extraer_precio_ppt(ppt)
    precios_reales[pao_id] = precio

# Reconciliar con Excel
# Si precio_real != precio_excel → actualizar Excel + JSON + resumen maestro
```

**Mapeo PPT → PAO-ID:** No confiar en nombres de archivo. Usar contenido:
- Buscar nombre del evento en diapositivas
- Buscar fecha del evento
- Cross-reference con Excel maestro

**Caso real encontrado:** PAO-004 = "XV 23 de mayo ajustes" (XV YULY) con precio $370,000. PAO-005 (XV ANDREA) sin PPT físico → marcar como pendiente.

### FASE 2: Generar Documentos Operativos en Batch
1. Verificar motor de documentos (`generar_docs_operativos.py`, `generar_requisiciones_bodega.py`)
2. Instalar dependencias: `reportlab`, `openpyxl`, `python-pptx`
3. Ejecutar scripts en batch para todos los eventos:
   - Requisición de Bodega (1 por evento)
   - Checklist de Montaje (1 por evento)
   - Pedido de Flor (1 por evento)
   - Nómina de Personal (solo WP Completo)
4. Verificar organización en carpetas: `04_Documentos_Operativos/`
5. **Contar archivos generados:** 15 eventos × 4 docs = 60 PDFs esperados

### FASE 3: Activar Dashboard
1. Verificar dependencias: `fastapi`, `uvicorn`, `openpyxl`, `python-multipart`
2. **Corregir errores de tipo en `app.py` (parse_valor_excel, finanzas)** — ver sección Pitfalls
3. Levantar: `cd /root/ws-paola-meneses/dashboard && python3 app.py`
4. Verificar endpoints: `/api/health`, `/api/dashboard`, `/api/finanzas`
5. **Si `/api/finanzas` retorna 500:** aplicar fix de parse_valor_excel (retornar None en lugar de string)

### FASE 4: Documentación y Cierre
1. Completar documentos vacíos: FLUJOS, MANUAL_AGENTES, REGLAS
2. Generar PDFs estilo Kami (weasyprint + markdown)
3. Actualizar Excel PM maestro de WS Capital (Checkpoints + Skills)
4. **Actualizar resumen maestro con totales reales reconciliados**
5. Generar resumen de entrega para el cliente

## Verificación Final de Entrega (checklist)

```
□ 15/15 eventos con carpeta organizada
□ 15/15 bookdates existen
□ 14/15 PPTs presentes (o reportar cuál falta)
□ 60/60 documentos operativos PDF generados
□ Dashboard responde en http://localhost:8080
□ /api/finanzas retorna datos, no error 500
□ /api/health OK
□ Total en finanzas coincide con suma de precios reales
□ Excel PM maestro de WS Capital actualizado
□ Documentación PDF generada (FLUJOS, MANUAL, REGLAS)
□ Resumen de entrega escrito para Pablo
```

> **Nota de honestidad técnica:** Si falta 1 PPT (como PAO-005), reportarlo explícitamente. El sistema está 95%+ operativo pero la falta documental es real. No decir "todo está completo" si hay gaps conocidos.

### Post-Entrega: Auditoría de Errores Residual (v2.2+)

Después de que Pablo apruebe la entrega, ejecutar auditoría honesta de TODO lo que queda mal:

```bash
# 1. Verificar persistencia real
cd /root/ws-paola-meneses/dashboard && python3 -c "
import app
print('PERSISTENCE_DIR:', app.PERSISTENCE_DIR)
print('Existe:', app.PERSISTENCE_DIR.exists())
if app.PERSISTENCE_DIR.exists():
    files = list(app.PERSISTENCE_DIR.iterdir())
    print('Archivos:', [f.name for f in files])
"

# 2. Verificar funciones críticas
python3 -c "
import app
funcs = ['guardar_tareas', 'cargar_tareas', 'calcular_finanzas_seguras', 
         'calcular_progreso_real', 'generar_alertas_inteligentes']
for f in funcs:
    print(f'{f}: {hasattr(app, f)}')
"

# 3. Verificar endpoints críticos
curl -s http://localhost:8080/api/health | python3 -m json.tool
curl -s http://localhost:8080/api/finanzas | python3 -m json.tool
curl -s http://localhost:8080/api/agentes/estado | python3 -m json.tool
```

**Checklist de auditoría de errores:**
- [ ] Abrir carpeta funciona en Windows (no solo WSL/xdg-open)
- [ ] Frontend renderiza correctamente en navegador Windows
- [ ] Catálogo de servicios NO está hardcodeado por PAO_ID
- [ ] Estado de evento persiste en Excel (no solo JSON local)
- [ ] Timeline usa verificación de documentos, no solo fecha
- [ ] Generación incluye pedido_flor y bookdate individual
- [ ] Nómina tiene script real de generación
- [ ] Rutas MOTOR_DIR y SCRIPTS_DIR son correctas
- [ ] Formato de moneda usa MX$ en lugar de $
- [ ] Días negativos muestran "Evento pasado" en lugar de "-X días"

**Documentar resultados en:** `06_Documentacion/AUDITORIA_ERRORES_v{VERSION}.md`
**Actualizar Excel PM maestro** con:
- Estado del proyecto: "Auditoría Completa - Errores Detectados"
- Nueva tarea: "Corrección Errores v{VERSION}"
- Checkpoint en hoja Checkpoints

### Cierre de Sesión con Minuta

Al cerrar sesión después de auditoría, generar:
1. **AUDITORIA_ERRORES_v{VERSION}.md** — Inventario completo de errores (críticos, mayores, menores, UX, técnicos)
2. **MINUTA_CIERRE_v{VERSION}.md** — Resumen de logros, errores detectados, archivos modificados, próximas prioridades
3. **Actualizar Excel PM maestro** — Estado del proyecto, nueva tarea de corrección, checkpoint
4. **Guardar en memoria** — Estado del sistema, errores pendientes, próxima sesión prioridades

### Endpoints v4.0 (nuevos/conectados)

| Endpoint | Método | Descripción | Estado |
|----------|--------|-------------|--------|
| `/api/cliente/{pao_id}/generar-documento` | POST | Genera documento con datos reales | ✅ Conectado a ejecutor_v4 |
| `/api/cliente/{pao_id}/documentos` | GET | Lista documentos reales del evento | ✅ Detecta con pao_id |
| `/api/cliente/{pao_id}/abrir-carpeta` | POST | Abre carpeta en Windows vía WSL | ✅ explorer.exe |
| `/api/tareas/{id}/completar` | POST | Marca tarea completada (persiste) | ✅ JSON en disco |
| `/api/dashboard` | GET | KPIs, alertas, próximos eventos | ✅ |
| `/api/eventos` | GET | Lista eventos con filtros | ✅ |
| `/api/evento/{pao_id}` | GET | Detalle completo del evento | ✅ |
| `/api/finanzas` | GET | Datos financieros reales | ✅ |
| `/api/alertas` | GET | Alertas accionables | ✅ |
| `/api/catalogo/servicios` | GET | Catálogo de servicios | ⚠️ Verificar no hardcodeado |

## API Endpoints del Dashboard (v2.1)

### Dashboard
- `GET /api/dashboard` — KPIs, alertas, próximos eventos, finanzas
- `GET /api/eventos` — Lista todos los eventos
- `GET /api/evento/{pao_id}` — Detalle de evento con timeline INTERACTIVO, tareas, progreso real
- `GET /api/finanzas` — Datos financieros reales desde hoja Cotizaciones

### Clientes / Carpetas / Documentos
- `GET /api/clientes` — Lista 15 clientes con verificación de carpetas y documentos
- `GET /api/cliente/{pao_id}/documentos` — Archivos reales en carpeta del cliente
- `POST /api/cliente/{pao_id}/abrir-carpeta` — Abre carpeta en explorador Windows
- `POST /api/cliente/{pao_id}/generar-documento` — Genera documento usando motor

### Tareas
- `GET /api/tareas/{pao_id}` — Tareas de un evento
- `POST /api/tareas/{id}/completar` — Completar tarea
- `POST /api/tareas/{id}/posponer` — Posponer tarea 1 día
- `POST /api/tareas/{id}/delegar` — Cambiar asignado de tarea

### Alertas
- `GET /api/alertas` — Alertas basadas en tareas vencidas/próximas

### Pendientes / Aprendizaje
- `POST /api/pendientes` — Crear pendiente/aprendizaje (¿qué falta? ¿quién? ¿cuándo?)
- `GET /api/pendientes` — Listar todos los pendientes

### Agentes
- `GET /api/agentes/estado` — Estado completo del sistema para agentes
- `POST /api/agentes/{id}/accion` — Ejecutar acción desde agente

### Configuración
- `GET /api/config/cron` — Configuración de alertas automáticas
- `GET /api/excels` — Lista de archivos Excel disponibles
- `GET /api/health` — Health check (verifica Excel + carpetas)

## Parser de Excel

```python
# parse_valor_excel() — Maneja '[PENDIENTE]' como NULL
parse_valor_excel(100) → 100
parse_valor_excel("[PENDIENTE]") → None
parse_valor_excel("$1,500") → 1500.0

# format_moneda() — Formatea para frontend
format_moneda(1500) → "$1,500 MXN"
format_moneda(None) → "Por definir"
```

### `/cotizar [tipo] [nombre] [fecha] [venue] [invitados]`
Genera una cotización en PowerPoint.

**Ejemplo:**
```
/cotizar boda "Carla & Carlos" 2025-05-15 "Hacienda Santa Rosa" 150
```

**Ejecución técnica:**
```bash
python /root/ws-paola-meneses/scripts/generate_cotizacion.py \
  --template boda \
  --cliente "Carla & Carlos" \
  --fecha "2025-05-15" \
  --venue "Hacienda Santa Rosa" \
  --invitados 150 \
  --output-dir /root/ws-paola-meneses/output/
```

**Output:** Archivo `.pptx` listo para enviar al cliente.

---

### `/bookdate [nombre-evento]`
Genera el Excel Bookdate (planning maestro) de un evento.

**Ejecución técnica:**
```bash
python /root/ws-paola-meneses/scripts/export_bookdate.py \
  --json '{"evento": {"nombre": "Carla & Carlos", ...}}' \
  --output-dir /root/ws-paola-meneses/output/
```

**Output:** Excel con hojas: Budget, Minuto a Minuto, Layout, Lista Invitados, Locación, Banquete, Decoración, Música, Foto/Video.

---

### `/status [nombre-evento]`
Reporta el estado actual de un evento.

**Qué consulta:**
1. Tabla `eventos` (status, fecha, venue)
2. Tabla `budget_lineas` (costos vs estimado)
3. Tabla `timeline_eventos` (próximas actividades)
4. Tabla `pagos` (saldo)
5. Calcula días hasta el evento

**Output esperado:**
```
📅 Evento: Carla & Carlos
📍 Venue: Hacienda Santa Rosa
📊 Status: Planning
⏰ Días para el evento: 22

✅ Completado:
- Contrato firmado
- Anticipo recibido ($142,500)
- Bookdate creado

⚠️ Pendiente:
- Confirmar banquete (deadline: 2025-03-01)
- Pedido flor (deadline: 2025-04-30)

🔴 Alertas:
- D-15 en 7 días: Generar inventario operaciones
```

---

### `/eventos`
Lista todos los eventos activos.

**Qué consulta:**
```sql
SELECT nombre_evento, tipo_evento, fecha_evento, status, venue
FROM eventos
WHERE status NOT IN ('cerrado', 'cancelado', 'perdido')
ORDER BY fecha_evento;
```

---

### `/alertas`
Muestra alertas del día basadas en deadlines.

**Reglas de alertas:**
| Días hasta evento | Alerta |
|---|---|
| D-30 | Iniciar planning completo |
| D-15 | URGENTE: Generar inventario + pedidos flor |
| D-7 | Confirmar todos los proveedores |
| D-3 | Revisar layout final + lista invitados |
| D-1 | CHECKLIST FINAL |
| D+1 | Iniciar cierre financiero |
| D+7 | Cierre financiero debe estar completo |

---

### `/inventario [sku?]`
Consulta disponibilidad de inventario.

**Ejemplos:**
```
/inventario              → Lista todo el inventario disponible
/inventario DEC-001      → Detalle del item DEC-001
/inventario disponible   → Solo items con stock > 0
```

**Qué consulta:**
```sql
SELECT * FROM inventario_disponible WHERE cantidad_real_disponible > 0;
```

---

### `/pago [evento] [tipo] [monto] [método]`
Registra un pago (ingreso o egreso).

**Ejemplo:**
```
/pago "Carla & Carlos" ingreso 25000 transferencia
```

**Validaciones:**
- Si ingreso > total cotizado → ALERTAR sobrepago
- Si egreso > costo estimado → ALERTAR sobre costo
- Siempre pedir confirmación antes de insertar

---

### `/budget [nombre-evento]`
Muestra el budget detallado de un evento.

**Qué consulta:**
```sql
SELECT concepto, proveedor, costo_estimado, costo_real, pagado
FROM budget_lineas
WHERE evento_id = (SELECT id FROM eventos WHERE nombre_evento = '...')
ORDER BY categoria;
```

---

## Flujo de trabajo completo (para agentes)

### Nuevo lead → Cotización
1. Cliente contacta por WhatsApp/Instagram
2. Paola (o Hermes) recopila: tipo, fecha, venue, invitados
3. Hermes ejecuta `/cotizar` → genera PPT
4. Paola revisa y envía al cliente
5. Cliente aprueba → status = "Contratado"

### Contrato → Planning
6. Hermes ejecuta `/bookdate` → genera Excel planning
7. Equipo llena: Budget, Timeline, Lista invitados
8. Hermes alerta: citas con proveedores, deadlines

### D-15 → Operativo
9. Hermes alerta: Generar inventario + pedidos flor
10. Equipo asigna inventario, confirma proveedores
11. Hermes verifica: `/inventario`, `/status`

### Día D → Ejecución
12. Equipo usa Excel "Minuto a Minuto" en vivo
13. Hermes puede consultar timeline por Telegram

### Cierre
14. D+1: Hermes alerta: iniciar cierre financiero
15. Equipo actualiza pagos, libera inventario
16. Hermes genera reporte final de margen

## Fallback: Modo Excel (sin Onyx)
Si Onyx/BD no está disponible, todo se opera vía:
- **Control Maestro Excel**: `/root/ws-paola-meneses/Paola_Meneses_Control_Maestro.xlsx`
- Las mismas operaciones se hacen leyendo/escribiendo el Excel
- Scripts pueden leer el Excel como fuente de datos

## Integración con Onyx
Cuando Onyx está activo:
- Schema BD: `schemas/db-schema.sql`
- Las tools leen/escriben PostgreSQL
- El Excel se sincroniza bidireccionalmente (export/import)
- Agentes de Onyx usan estas tools directamente

## Precios base (fallback)
```yaml
boda:
  mobiliario: $45,000 (base 100 pax)
  decoracion: $28,000 (base 15 mesas)
  iluminacion: $15,000 (fijo)
  musica: $18,000 (fijo)
  foto_video: $35,000 (fijo)
  banquete: $850/pax
  wedding_planner: $25,000 (fijo)

xv:
  mobiliario: $40,000 (base 100 pax)
  decoracion: $25,000 (base 20 mesas)
  iluminacion: $15,000 (fijo)
  musica: $18,000 (fijo)
  foto_video: $28,000 (fijo)
  coreografo: $12,000 (fijo)
  banquete: $750/pax

aniversario:
  mobiliario: $35,000 (base 80 pax)
  decoracion: $20,000 (fijo)
  iluminacion: $10,000 (fijo)
  musica: $12,000 (fijo)
  foto_video: $18,000 (fijo)
  banquete: $900/pax
```

## Contacto / Soporte
- Paola Meneses: contacto@paolameneses.com
- WS Capital / Hermes Neo: Soporte técnico de la plataforma

---

## Generación del Excel Control Maestro (11 hojas)

El Excel maestro es el **fallback tangible** que el cliente puede editar a mano. Se genera programáticamente con `openpyxl` para asegurar consistencia.

### Estructura de hojas
```
Dashboard       → Métricas + alertas + navegación (fórmulas =HOY(), =COUNTIF())
Eventos         → Tracker con status coloreado, margen %, días restantes
Cotizaciones    → Versiones con IVA calculado automáticamente
Proveedores     → Directorio con confiabilidad 1-5 (colores condicionales)
Inventario      → Stock con SKU, ubicación física
Timeline        → Minuto a minuto con dropdowns de status
Pagos           → Ingresos (verde) / Egresos (rojo)
Checklist       → Tareas por fase con dependencias
Métricas        → KPIs automáticos (=PROMEDIO, =SUMPRODUCT)
Catálogo        → Precios base para cotizar
Guía de Uso     → Documentación embebida para el usuario
```

### Técnicas clave de openpyxl usadas
```python
# 1. Fórmulas Excel nativas
ws.cell(row=4, column=5, value="=SUM(D4:D10)")
ws.cell(row=5, column=6, value="=E5*0.16")  # IVA

# 2. Validación de datos (dropdowns)
from openpyxl.worksheet.datavalidation import DataValidation
dv = DataValidation(type="list", formula1='"Pendiente,Confirmado,Hecho"')
ws.add_data_validation(dv)
dv.add('E4:E100')

# 3. Colores condicionales por status
if val == "Hecho":
    cell.fill = PatternFill(start_color="90ee90", end_color="90ee90")
elif val == "Pendiente":
    cell.fill = PatternFill(start_color="ffd700", end_color="ffd700")

# 4. Congelar paneles
ws.freeze_panes = "A10"

# 5. Merge cells para headers
ws.merge_cells("A1:H1")
ws["A1"].font = Font(size=18, bold=True)
```

### Principio confirmado por el usuario
> "Todo funciona por separado. Todo funciona junto."
- Excel maestro = funciona sin internet, sin Onyx, sin BD
- Scripts = funcionan standalone con JSON/YAML
- BD = se agrega después, opcional para MVP
- Skill de Hermes = opera cualquiera de los 3 modos

---

## Generación de Documentación PDF (pipeline reutilizable)

Cuando el usuario pide documentación "bonita" / "con camis" (estilo Kami), usar este pipeline:

### 1. Escribir 3 documentaciones
| Documento | Audiencia | Enfoque |
|-----------|-----------|---------|
| `DOC-TECNICA-HERMES.md` | Devs/ops | Arquitectura, scripts, schema, skill |
| `DOC-TECNICA-ONYX.md` | Integradores Onyx | APIs, tablas `paola_*`, frontend constraints |
| `DOC-USUARIO-PAOLA.md` | Cliente final | Emojis, cero técnico, paso a paso, comandos |

### 2. Convertir Markdown → PDF bonito
```python
import markdown
from weasyprint import HTML

# CSS con branding Kami (parchment #faf8f0, dorado #d4a574, negro #1a1a18)
CSS = """
@page { size: A4; margin: 25mm 20mm 30mm 20mm; }
body { font-family: "Helvetica Neue", sans-serif; font-size: 10.5pt; color: #1a1a18; }
h1 { font-family: Georgia, serif; border-bottom: 1.5pt solid #d4a574; }
table thead th { background: #1a1a18; color: #faf8f0; }
blockquote { background: #faf8f0; border-left: 3pt solid #d4a574; }
"""

html_body = markdown.markdown(md_content, extensions=['tables', 'fenced_code'])
html = f"<!DOCTYPE html><html><head><style>{CSS}</style></head><body>{html_body}</body></html>"
HTML(string=html).write_pdf("output.pdf")
```

### 3. Diseño de portada por tipo
| Doc | Icono | Título | Color accent |
|-----|-------|--------|--------------|
| Técnica Hermes | ⚙️ | "Documentación Técnica" | dorado #d4a574 |
| Técnica Onyx | 🔷 | "Documentación Técnica" | dorado #d4a574 |
| Usuario | 💐 | "Tu Sistema de Eventos" | dorado #d4a574 |

### 4. Pitfalls del pipeline PDF
**WeasyPrint no encontrado:**
```bash
# ❌ python3 puede apuntar al venv de Hermes (3.11) sin weasyprint
python3 /tmp/gen_pdfs.py   # ModuleNotFoundError

# ✅ Usar el Python del sistema donde está instalado (3.12)
/usr/bin/python3.12 /tmp/gen_pdfs.py

# O instalar en el venv activo:
source /root/.hermes/hermes-agent/venv/bin/activate
pip install weasyprint markdown
```

**Markdown library no instalada:**
```bash
python3.12 -m pip install markdown --break-system-packages
```

**weasyprint instalado pero en path diferente:**
```bash
# Verificar dónde está
find /usr -name "weasyprint*" -type d
# Resultado típico: /usr/local/lib/python3.12/dist-packages/weasyprint
```

---

## Lecciones de sesión v4.0 (29abr2026)

### Errores cometidos y corregidos

| Error | Consecuencia | Corrección |
|-------|-------------|------------|
| Empezar sin aprobación explícita | Pablo tuvo que parar y reclamar | **Siempre esperar "sí" antes de ejecutar** |
| No guardar plan en archivo formal | Plan solo en chat, no referenciable | **Guardar en `docs/plans/` antes de presentar** |
| No usar flujo SOUL.md correcto | Saltar pasos, ejecutar desordenado | **1. contexto → 2. skills → 3. plan → 4. aprobación → 5. ejecutar** |
| Patch aplicado parcialmente | Código huérfano en app.py | **Verificar archivo completo después de patch** |
| No verificar servidor recargó | Fix aplicado pero no activo | **Siempre probar con curl después de reiniciar** |

### Patrón de ejecución correcto para rebuilds grandes

```
1. SURVEY: skills_list() + skill_view() relevantes
2. PLAN: write_file() en docs/plans/ con fases numeradas
3. PRESENT: Mostrar plan en chat, esperar "sí" explícito
4. EXECUTE: Una fase a la vez, commit por fase
5. VERIFY: curl/terminal tests antes de declarar completado
6. CHECKPOINT: Actualizar Excel PM + memoria + skill
7. NEXT: Solo avanzar con aprobación
```

### Regla de oro para patches

**Después de aplicar patch, SIEMPRE:**
1. `read_file()` para verificar resultado
2. Si hay código huérfano → corregir inmediatamente
3. `python3 -c "import modulo"` para verificar carga
4. Reiniciar servidor si aplica
5. `curl` para verificar endpoint funciona

### Regla de oro para imports

**Cuando cambiar de ejecutor_viejo a ejecutor_nuevo:**
1. Verificar que nuevo ejecutor tiene TODAS las funciones que usa app.py
2. Si falta función → copiar del viejo o adaptar
3. Verificar que no hay referencias huérfanas al viejo
4. Testear import: `python3 -c "import app"`

## Pitfalls & Debugging (aprendido en producción)

### parse_valor_excel: strings no parseables deben retornar None
```python
# ❌ MAL: retorna el string original si no puede parsear
except:
    return valor  # Causa TypeError al sumar int + str

# ✅ CORRECTO
except:
    return None  # El sum() lo ignora, format_moneda muestra "Por definir"
```

**Error típico:** `TypeError: unsupported operand type(s) for +: 'int' and 'str'` en `/api/finanzas`.

**Fix completo:**
```python
def parse_valor_excel(valor):
    if valor is None:
        return None
    if isinstance(valor, str):
        if valor.strip().upper() in ['[PENDIENTE]', 'PENDIENTE', 'N/A', '-', '']:
            return None
        try:
            return float(valor.replace(',', '').replace('$', '').strip())
        except:
            return None  # ← CAMBIO CRÍTICO
    if isinstance(valor, (int, float)):
        return valor
    return None
```

### Finanzas: validar tipos antes de sumar
```python
# ❌ MAL: suma sin validar tipo
sum(e["pagos_recibidos"] for e in eventos if e["pagos_recibidos"] is not None)
# TypeError si pagos_recibidos es string

# ✅ CORRECTO
sum(e["pagos_recibidos"] for e in eventos 
    if e["pagos_recibidos"] is not None 
    and isinstance(e["pagos_recibidos"], (int, float)))
```
```python
# ❌ MAL
from pptx.dml.color import RgbColor
# ✅ CORRECTO
from pptx.dml.color import RGBColor
```
Error: `ImportError: cannot import name 'RgbColor' from 'pptx.dml.color'`

### openpyxl: `get_column_letter` requiere import directo
```python
# ❌ MAL
ws.column_dimensions[openpyxl.utils.get_column_letter(i+1)].width = w
# ✅ CORRECTO
from openpyxl.utils import get_column_letter
ws.column_dimensions[get_column_letter(i+1)].width = w
```

### Typo común: variable `precio` vs `preco`
En `calcular_precio()` del generador PPT, asegurar que la variable retornada es `precio` (no `preco`).
```python
# ❌ MAL
return round(preco, 2)
# ✅ CORRECTO
return round(precio, 2)
```

### Modo demo del generador PPT
No usa flag `--demo`. Simplemente ejecutar sin argumentos:
```bash
python generate_cotizacion.py   # Modo demo automático
```

### Instalación de dependencias en sistema Debian (PEP 668)
En sistemas donde pip bloquea instalación por PEP 668 (Debian/Ubuntu), usar:
```bash
pip install fastapi uvicorn openpyxl python-multipart reportlab --break-system-packages --ignore-installed
```
El flag `--ignore-installed` evita conflictos con paquetes del sistema como `typing-extensions`.

**Si el error persiste:**
```bash
# Verificar Python del sistema
/usr/bin/python3.12 -m pip install fastapi uvicorn --break-system-packages
```

### fastapi + uvicorn: `typing-extensions` conflict
```bash
# ❌ ERROR: Cannot uninstall typing_extensions 4.10.0, RECORD file not found
pip install fastapi uvicorn  # Falla

# ✅ CORRECTO
pip install fastapi uvicorn openpyxl python-multipart --break-system-packages --ignore-installed
```

### reportlab no encontrado
```bash
# ❌ ModuleNotFoundError: No module named 'reportlab'
python3 generar_requisiciones_bodega.py

# ✅ Instalar con flags correctos
pip install reportlab openpyxl python-pptx markdown weasyprint --break-system-packages --ignore-installed
```

### Estructura del Excel Control Maestro (11 hojas)
El Excel maestro NO es un export simple. Tiene:
- Dashboard con fórmulas `=COUNTIF()`, `=SUMPRODUCT()`, `=HOY()`
- Validaciones de datos (dropdowns) en status
- Colores condicionales por estado (verde=Hecho, amarillo=Pendiente, rojo=Urgente)
- Congelar paneles en `A10`
- Hoja "Guía de Uso" embebida para el usuario final

### Principio de diseño confirmado por usuario
> "Todo funciona por separado. Todo funciona junto."
- Excel maestro = fallback cuando Onyx cae
- Scripts = funcionan standalone leyendo JSON/YAML
- BD = opcional para MVP, se agrega después
- Skill de Hermes = opera cualquiera de los 3 modos

### Archivos generados de prueba (para verificación)
Después de ejecutar los scripts en modo demo, se generan:
- `Cotizacion_Carla_y_Carlos_YYYYMMDD.pptx` (~44KB, 8 slides)
- `Bookdate_Carla_y_Carlos_YYYYMMDD.xlsx` (~14KB, 9 hojas)
- `Paola_Meneses_Control_Maestro.xlsx` (~21KB, 11 hojas)

Si estos archivos no existen, los scripts no funcionan.
