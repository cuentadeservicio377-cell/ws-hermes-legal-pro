---
name: onyx-integration-technical-reference
description: "Technical reference for integrating custom features and LLM providers into Onyx (Danswer). Covers frontend TypeScript constraints, LLM provider database configuration, and common build pitfalls discovered through iterative debugging."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [onyx, danswer, llm-provider, nextjs, typescript, frontend-constraints, database-config]
---

# Onyx Integration Technical Reference

Use this when building custom frontend pages or configuring LLM providers in Onyx (formerly Danswer). This skill captures non-obvious constraints discovered through iterative build debugging and database configuration.

## Frontend TypeScript Constraints (Next.js 16 + Opal Design System)

Onyx uses a custom design system (Opal) with strict TypeScript types. Common patterns that work in standard React will fail the build.

### Text Component — `as` prop restrictions

The `Text` component from `@/refresh-components/texts/Text` ONLY accepts:
- `"p"` (default)
- `"span"`
- `"li"`

**These will FAIL type checking:**
```tsx
<Text as="h1">Title</Text>    // ❌ Type '"h1"' is not assignable
<Text as="h2">Subtitle</Text> // ❌ Same error
<Text as="h3">Section</Text>  // ❌ Same error
```

**Correct pattern:**
```tsx
<Text as="p" className="text-3xl font-semibold">Title</Text>       // ✅
<Text as="p" className="text-xl font-semibold">Subtitle</Text>     // ✅
```

### Button Component — no `className` prop

The Opal `Button` component does NOT accept `className`. Use a wrapper `<div>` instead.

**This will FAIL:**
```tsx
<Button className="mt-2" prominence="primary">Click</Button>  // ❌
```

**Correct pattern:**
```tsx
<div className="mt-2">
  <Button prominence="primary">Click</Button>  // ✅
</div>
```

### Divider Component — no `className` prop

Same restriction as Button.

**This will FAIL:**
```tsx
<Divider paddingPerpendicular="fit" className="my-5" />  // ❌
```

**Correct pattern:**
```tsx
<div className="my-5">
  <Divider paddingPerpendicular="fit" />  // ✅
</div>
```

### LegalMatterRail — type mismatch fix

When `matter.id` is `number` and `selectedMatterId` is `string | undefined`, the comparison `matter.id === selectedMatterId` fails type checking.

**Fix:** Convert both to strings:
```tsx
const selected = String(matter.id) === String(selectedMatterId);
```

### LegalPageScaffold — prop type conversion

When the route parameter is a string but the context expects a number:
```tsx
const numericMatterId = selectedMatterId ? parseInt(selectedMatterId, 10) : undefined;
return (
  <LegalContextProvider selectedMatterId={numericMatterId}>
    ...
  </LegalContextProvider>
);
```

## LLM Provider Database Configuration

Onyx stores LLM provider configuration across three tables that must be configured together.

### Table Overview

| Table | Purpose |
|-------|---------|
| `llm_provider` | Provider identity, API base, auth |
| `model_configuration` | Available models per provider |
| `llm_model_flow` | Which model is default for each flow type |

### Critical: Case-Sensitive Enum Values

The `llm_model_flow_type` column uses an application-level enum. Values MUST be UPPERCASE:

```sql
-- ✅ Correct
INSERT INTO llm_model_flow (llm_model_flow_type, is_default, model_configuration_id)
VALUES ('CHAT', true, 1);

-- ❌ Wrong — causes "No default LLM model found" runtime error
INSERT INTO llm_model_flow (llm_model_flow_type, is_default, model_configuration_id)
VALUES ('chat', true, 1);
```

Valid values: `CHAT`, `VISION`, `CONTEXTUAL_RAG`

### Complete Provider Setup (NVIDIA Example)

```sql
-- 1. Create provider (use 'openai' as provider type for OpenAI-compatible APIs)
INSERT INTO llm_provider (name, api_base, provider, is_default_provider, is_public, is_auto_mode, default_model_name)
VALUES (
  'nvidia',
  'https://integrate.api.nvidia.com/v1',
  'openai',  -- ← Must be 'openai' for NVIDIA's OpenAI-compatible endpoint
  true,
  true,
  false,
  'meta/llama-3.3-70b-instruct'
)
ON CONFLICT (name) DO UPDATE SET
  api_base = EXCLUDED.api_base,
  provider = EXCLUDED.provider,
  is_default_provider = true,
  default_model_name = EXCLUDED.default_model_name;

-- 2. Add API key (MIT version uses plaintext encoding, not real encryption)
UPDATE llm_provider 
SET api_key = 'nvapi-XXXX'::bytea 
WHERE name = 'nvidia';

-- 3. Create model configurations
WITH provider AS (SELECT id FROM llm_provider WHERE name = 'nvidia')
INSERT INTO model_configuration (llm_provider_id, name, is_visible, max_input_tokens, supports_image_input, display_name)
SELECT provider.id, 'meta/llama-3.3-70b-instruct', true, 128000, false, 'Llama 3.3 70B'
FROM provider
ON CONFLICT (llm_provider_id, name) DO UPDATE SET is_visible = true;

-- 4. Set default model flows (MUST be uppercase)
INSERT INTO llm_model_flow (llm_model_flow_type, is_default, model_configuration_id)
VALUES ('CHAT', true, (SELECT id FROM model_configuration WHERE name = 'meta/llama-3.3-70b-instruct'));

INSERT INTO llm_model_flow (llm_model_flow_type, is_default, model_configuration_id)
VALUES ('VISION', true, (SELECT id FROM model_configuration WHERE name = 'meta/llama-3.3-70b-instruct'));
```

### Key Columns Reference

**`llm_provider` table:**
| Column | Notes |
|--------|-------|
| `name` | Unique identifier, e.g. `'nvidia'` |
| `provider` | Protocol type: `'openai'`, `'anthropic'`, `'azure'`, etc. |
| `api_base` | Full base URL including `/v1` if needed |
| `api_key` | `bytea` type. MIT version stores plaintext, not encrypted |
| `is_default_provider` | `true` for fallback when no persona override |
| `is_public` | `true` = accessible to all users |

**`model_configuration` table:**
| Column | Notes |
|--------|-------|
| `llm_provider_id` | FK to `llm_provider.id` |
| `name` | Model ID string, e.g. `'meta/llama-3.3-70b-instruct'` |
| `is_visible` | `true` to show in UI |
| `max_input_tokens` | Context window size |
| `supports_image_input` | `true` for vision models |
| `display_name` | Human-readable label |

**`llm_model_flow` table:**
| Column | Notes |
|--------|-------|
| `llm_model_flow_type` | **UPPERCASE**: `'CHAT'`, `'VISION'`, `'CONTEXTUAL_RAG'` |
| `is_default` | Only one default per flow type |
| `model_configuration_id` | FK to `model_configuration.id` |

### User Permissions for Admin Panel

Users need permissions stored in `effective_permissions` JSONB to access LLM admin endpoints:

```sql
UPDATE "user" 
SET effective_permissions = '[
  "basic", "read:connectors", "read:document_sets", "read:agents", "read:users",
  "add:agents", "manage:agents", "manage:document_sets", "add:connectors",
  "manage:connectors", "manage:llms", "read:agent_analytics", "manage:actions",
  "read:query_history", "manage:user_groups", "create:user_api_keys",
  "create:service_account_api_keys", "create:slack_discord_bots", "admin"
]'::jsonb
WHERE email = 'user@example.com';
```

### Persona Model Override

To assign a default model to a persona:

```sql
UPDATE persona 
SET default_model_configuration_id = (
  SELECT mc.id 
  FROM model_configuration mc 
  JOIN llm_provider p ON mc.llm_provider_id = p.id 
  WHERE p.name = 'nvidia' AND mc.name = 'meta/llama-3.3-70b-instruct'
)
WHERE name = 'Your Agent Name';
```

## Backend Legal API Pattern

When building a legal API that integrates with Onyx:

### Persona / Agent sync pattern for custom runtimes

For product-specific personas (like Willow legal agents), do **not** hardcode the full agent set inline in a one-off seed function forever. A better pattern is:

1. Store the persona definitions in a runtime-local JSON file (for example `runtime/legal_agents_phase1.json`)
2. Have the API load that file on demand
3. Make the seed endpoint **idempotent and migratory**:
   - create missing personas
   - update prompts/descriptions/starter messages for existing personas
   - support alias-based rename migration (`old name -> new name`)
   - rebind tools on every sync so the runtime stays declarative
4. Return tool metadata from the agents endpoint so the frontend can show capabilities

Example structure for the JSON definitions:

```json
[
  {
    "name": "Despacho Legal",
    "aliases": ["Despacho Legal"],
    "description": "Orquestador dominante del despacho...",
    "system_prompt": "Eres Despacho Legal de Willow...",
    "starter_messages": [
      {"name": "Resumen del despacho", "message": "Dame el estado del despacho..."}
    ],
    "tool_ids": [1, 9, 10]
  }
]
```

Example helper pattern in the API:

```python
from pathlib import Path
import json

AGENTS_CONFIG_PATH = Path(__file__).with_name("legal_agents_phase1.json")


def load_legal_agent_definitions():
    with AGENTS_CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)
```

### Tool binding lives in `persona__tool`

Onyx already supports binding tools to personas via the `persona__tool` join table. You do **not** need a parallel custom tool-assignment system.

Useful validation query:

```sql
SELECT p.name AS persona, t.display_name AS tool, t.in_code_tool_id
FROM persona__tool pt
JOIN persona p ON p.id = pt.persona_id
JOIN tool t ON t.id = pt.tool_id
ORDER BY p.id, t.id;
```

### Practical runtime lesson: return tools from `/api/legal/agents`

If the legal/home runtime needs to explain what each agent can do, expand the agents query to join `persona__tool` and aggregate tool metadata:

```sql
SELECT p.id, p.name, p.description,
       COALESCE(
         json_agg(
           json_build_object(
             'id', t.id,
             'name', t.name,
             'display_name', t.display_name,
             'in_code_tool_id', t.in_code_tool_id
           ) ORDER BY t.id
         ) FILTER (WHERE t.id IS NOT NULL),
         '[]'::json
       ) AS tools
FROM persona p
LEFT JOIN persona__tool pt ON pt.persona_id = p.id
LEFT JOIN tool t ON t.id = pt.tool_id
...
```

This is especially useful for later UX work because the UI can render agent capability cards without guessing.

### Creating Matters with Onyx Projects

```python
# Matter creation should auto-create an Onyx user_project
with engine.begin() as conn:
    project_result = conn.execute(text("""
        INSERT INTO user_project (user_id, name, description, created_at)
        VALUES (:user_id, :name, :description, NOW())
        RETURNING id
    """), {
        "user_id": user_id,
        "name": matter_name,
        "description": "Legal matter managed by Willow"
    })
    project_id = project_result.fetchone()[0]
    
    # Then create the legal matter with project_id FK
    result = conn.execute(text("""
        INSERT INTO willow_legal_matter (project_id, client_name, ...)
        VALUES (:project_id, :client_name, ...)
        RETURNING *
    """), {**matter_data, "project_id": project_id})
```

### Creating Onyx Chat Sessions for Matters

```python
# chat_session requires: deleted=false, shared_status='private', onyxbot_flow=false
conn.execute(text("""
    INSERT INTO chat_session (
        id, user_id, persona_id, description, project_id, 
        time_created, time_updated, deleted, shared_status, onyxbot_flow
    )
    VALUES (
        :id, :user_id, :persona_id, :description, :project_id,
        NOW(), NOW(), false, 'private', false
    )
"""), {...})
```

### File Upload to Matters

Files need two records:
1. `user_file` — the file metadata
2. `project__user_file` — links file to the matter's project

```python
# 1. Create user_file
conn.execute(text("""
    INSERT INTO user_file (id, user_id, name, file_id, file_type, created_at, status)
    VALUES (:id, :user_id, :name, :file_id, :file_type, NOW(), 'COMPLETED')
"""), {...})

# 2. Link to project
conn.execute(text("""
    INSERT INTO project__user_file (project_id, user_file_id)
    VALUES (:project_id, :user_file_id)
"""), {"project_id": project_id, "user_file_id": file_id})
```

## Build Verification Commands

```bash
# Check all containers
docker ps | grep -E "onyx|willow"

# Restart Onyx stack
cd /path/to/onyx/deployment/docker_compose
docker compose -f docker-compose.yml -f docker-compose.onyx-lite.yml up -d

# Check API health
curl http://localhost:3000/api/health

# Check legal API
curl http://localhost:3001/api/legal/health

# Login via API (saves cookie for subsequent calls)
curl -c /tmp/onyx_cookie.txt -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user@example.com&password=password"

# Test admin LLM endpoint
curl -b /tmp/onyx_cookie.txt http://localhost:3000/api/admin/llm/provider

# Test chat
curl -b /tmp/onyx_cookie.txt -X POST http://localhost:3000/api/chat/send-chat-message \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "chat_session_id": "...", "parent_message_id": null}'
```

## Pitfalls Summary

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Using `as="h2"` on Text | Build fails: Type '"h2"' not assignable | Use `as="p"` with Tailwind classes |
| Adding `className` to Button | Build fails: Property 'className' does not exist | Wrap in `<div className="...">` |
| Lowercase flow type | Runtime: "No default LLM model found" | Use UPPERCASE: `'CHAT'`, `'VISION'` |
| Missing `llm_model_flow` | Runtime: "No default LLM model found" | Insert both `model_configuration` AND `llm_model_flow` |
| Wrong `provider` value | NVIDIA endpoint fails | Use `'openai'` for OpenAI-compatible APIs |
| Missing `deleted`/`shared_status` | DB error: violates not-null constraint | Include `deleted=false, shared_status='private'` |
| User lacks permissions | 403 INSUFFICIENT_PERMISSIONS | Update `effective_permissions` JSONB |

## Related Skills
- `willow-legal-migration-five-phase` — broader Willow → Onyx migration strategy
- `onyx-first-legal-surface-repair` — Onyx-first UI architecture decisions
- `willow-paperclip-to-onyx-port` — direct Paperclip → Onyx porting guide
