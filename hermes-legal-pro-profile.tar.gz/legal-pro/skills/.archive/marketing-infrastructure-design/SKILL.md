---
name: marketing-infrastructure-design
description: Build a reusable marketing capability system for WS Capital/Hermes from source repos, playbooks, and agent frameworks instead of jumping straight to copy generation.
version: 1.3.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [marketing, infrastructure, growth, prompts, capability-map, obsidian, ws-capital]
---

# Marketing Infrastructure Design

Use this when the user says the marketing output is weak/generic and the real problem is missing infrastructure, not missing prompts.

## Goal

Turn scattered marketing references (repos, articles, playbooks, agent systems) into a durable marketing capability stack with:
- capability map
- prompt/agent roles
- output types
- handoffs
- vault routing
- build plan

## When to use

Trigger when the user wants things like:
- "build our own marketing infrastructure"
- "this content isn't good enough"
- "we need the equivalent of OpenCode but for marketing"
- "use these repos/articles to build the best marketing team possible"
- "terminar con la construcción del marketing" / "never finish doing all the marketing work"
- "quiero que queden completos y perfectamente ruteados" / "I want them complete and perfectly routed"

**Critical:** During the first intake conversation, proactively probe for the founder's personal content creation bottlenecks. Ask about:
- How hard is it to create content? (production friction)
- Does the content sound like them or like a generic AI template? (voice fidelity)
- How hard is lead generation? (distribution friction)
- How hard is it to explain ideas in writing vs. speaking? (translation friction)

These personal bottlenecks often matter more than abstract "marketing strategy" and should drive the capability map. If the founder says "content sounds like a template, not like me," the #1 capability is not "content-drafter" — it is "founder-voice-capture."

**Also critical:** When the founder says "I never finish doing all the marketing work" or "marketing never ends," the real problem is usually **undefined "done"** — no infrastructure exists to declare the department "built." The solution is to define a **10-element infrastructure checklist** and build it systematically, then transition to campaign execution.

**10-Element Marketing Infrastructure Checklist:**
1. Principios Rectores (what we do / don't do, in founder's words)
2. Marketing Context v2 (voice, tone, message, anti-genericidad)
3. Evolución (how we evolve, what "evolve" means)
4. Skill ws-growth-director (loads governance docs before acting)
5. Ruteo entre skills (skill routing table with handoffs)
6. Orchestrator operativo (ws-growth-orchestrator with real context)
7. Memory estratégica (decisions, learnings, corrections — verbatim quotes)
8. Experiment log (all campaigns are experiments, everything documented)
9. Growth Vault estructurado (5-folder vault: campaigns, content, experiments, assets, briefs)
10. Cron jobs (automated weekly content review + experiment review)

**Class of task this triggers:** "Build marketing department infrastructure from founder voice transcripts" — when the founder has voice recordings/bóvedas that contain the company's identity, and the agent must extract governance documents, update skills, create vaults, and set up automation before any campaigns can run.

## Working method

#### 0. Pre-flight: verify local workspace before external actions
Before cloning repos, running setup scripts, or starting a new build, always check the local workspace for existing artifacts from previous sessions. Department infrastructure is often already partially or fully built in:
- `/root/.hermes/hermes-ops/<department>/`
- `/root/<project>/`
- `/mnt/c/<project>/`

Also verify ambiguous voice transcriptions against known local projects. Names like "OpenCode" and "Onyx" are easily confused by Whisper and both refer to real WS Capital tools. Confirm the intended target before executing external operations.

**Concrete workspace locations for Onyx Marketing:**
- Infrastructure design: `/root/.hermes/hermes-ops/onyx-marketing/`
- Onyx source code: `/root/onyx-marketing-source/` (backend + web)
- Key files:
  - `setup/docker-compose.marketing.yml` — full stack
  - `setup/docker-compose.minimal.yml` — DB + Bridge only (quick validation)
  - `bridge-api/main_v2_agency.py` — Bridge API (agency multi-tenant)
  - `bridge-api/main.py` — Bridge API (single-tenant)
  - `db/marketing_schema_v2_agency.sql` — agency schema
  - `db/agents_seed_v2_agency.sql` — agent seed data
  - `scripts/setup.sh` — automated setup
  - `tools/pixelle/` — video engine stub
  - `tools/huashu/` — design engine stub  
  - `tools/openframe/` — ad engine stub

**Common discovery:** The `tools/` subdirectories are often empty from design sessions. Create minimal stubs before running `docker compose up`:
- Pixelle: `requirements.txt` + `api_server.py` (FastAPI on port 8001)
- Huashu: `package.json` + `server.js` (Express on port 8002)
- OpenFrame: `requirements.txt` + `api_server.py` (FastAPI on port 8003)

**CUDA misconception:** If the LLM provider is NVIDIA cloud API (`integrate.api.nvidia.com`), CUDA toolkit is NOT required on the host. The API key calls remote inference. Only install CUDA if running local embedding models.

**Docker compose env injection:** The compose files use `${VAR:-default}` syntax. Create a `.env` file in the project root (`/root/.hermes/hermes-ops/onyx-marketing/.env`) and load it before `docker compose up`. The existing compose may have `***` placeholder values that must be replaced with real credentials.

#### When the user provides GitHub repos to audit

1. **Get repo metadata** via GitHub API `/repos/{owner}/{repo}` — stars, language, description, URL.
2. **List root contents** via `/repos/{owner}/{repo}/contents` — understand project structure at a glance.
3. **Read the README** via `/repos/{owner}/{repo}/readme` (base64 decode) — full scope and positioning.
4. **Explore `skills/` or `docs/` directories** via `/contents/{path}` — find `SKILL.md` files, scripts, references, templates.
5. **Read `SKILL.md` files** via API (base64 decode) — extract: name, description, compatibility, triggers, workflow steps, critical rules, writing style rules, setup checks, context loading patterns, handoff targets.
6. **Read architecture docs** (e.g., `VISION.md`, contributor guides) if present — understand multi-agent architecture, design philosophy, roadmap.
7. **Classify** each repo by type (agent/pipeline, skill/plugin, playbook/curated, connector, multi-agent).
8. **Log everything** in the intake note with: repo name, stars, type, key files found, patterns extracted, what is reusable for WS Capital.

This audit method reveals architectural patterns (setup-check → load-context → execute → optional connectors) that reading READMEs alone misses. It also prevents missing `SKILL.md` files buried in subdirectories.

**Example:** In this workflow, auditing `coreyhaines31/marketingskills` revealed 35 granular skills, a mandatory `product-marketing-context` root, and a skill cross-reference graph — none of which was obvious from the README alone.

#### GitHub ecosystem research workflow (Hermes/agentskills.io)
When researching what the agent ecosystem already has for a domain, follow this pattern:
1. **Search GitHub API** for `<domain> hermes agent`, `<domain> agentskills`, and `<domain> ai agent`.
2. **Inspect top repos** by stars + relevance. Record: full name, stars, description, URL.
3. **Read README** of promising repos to understand scope.
4. **Explore directory structure** via GitHub API `/contents`. Look for `SKILL.md` files, `skills/` folders, `scripts/`, `references/`.
5. **Read SKILL.md files** directly via API (base64 decode). Extract: name, description, inputs, outputs, step structure, critical rules, writing style rules.
6. **Classify each source** by type (agent system, skill/plugin, playbook, connector, multi-agent).
7. **Log everything** in the intake note before designing anything.

This prevents reinventing skills that already exist and reveals architectural patterns (e.g., setup-check → load-context → execute → optional connectors).

### 2. Separate source types
Classify sources by what they are actually good for:
- **agent/pipeline systems** → role structure, orchestration, critique loops, typed outputs
- **skill/plugin systems** → commands, sub-skills, connectors, packaging
- **marketing playbooks** → channel tactics, founder workflows, GTM sequencing
- **checklists** → chronological execution and recurring operations
- **swarm systems** → tiering/layering, but treat enterprise paid-media systems cautiously

Do not copy any source literally. Extract the pattern.

### 3. Extract capabilities, not slogans
For each source ask:
- what role/capability does this imply?
- what input does it expect?
- what output does it produce?
- what review loop does it use?
- what is reusable for WS Capital?

**Also ask:** what founder bottleneck does this source address? If a source is a "LinkedIn post generator," it assumes the founder already has a clear idea and brief. If the founder's real problem is "I have ideas but can't turn them into briefs," the capability map needs a `founder-voice-capture` layer *before* the drafter.

Good capability examples discovered in this workflow:
- market research
- audience/problem analysis
- positioning/offer architecture
- campaign planning
- brand/voice review
- **founder-voice-capture** (extract ideas from voice/unstructured text into structured briefs)
- content drafting
- experiment design
- performance review

### 4. Use a context-root artifact
Before final prompts, define a root context doc similar to `product-marketing-context`:
- objective mayor
- tesis madre
- oferta
- verticales activas
- audiencias y problemas
- anti-genericidad
- tono/lenguaje prohibido
- criterios de aprobación

Everything else should read this first.

### 5. Build a capability map
Write a note that defines:
- orchestrator role
- core capabilities
- tactical/channel layer
- memory layer
- prompt architecture
- what to build first vs later

Keep it multiparte: marketing is one system layer among several, not the whole WS Capital contract.

### 6. Then write the build plan
Turn the capability map into phases:
1. root context
2. core prompts/roles
3. typed output artifacts
4. vault/doc routing
5. first real operation

Delay external connectors until prompt/output/review loops are solid.

### 7. Start execution with real infrastructure artifacts, not more notes
After the build plan exists, the next reusable move is to create the first operational layer immediately:
- a durable `marketing-context` artifact as the root context
- role docs (as Hermes skills in `~/.hermes/skills/growth-marketing/`) for at least:
  - `growth-orchestrator` — entry point, loads context, despacha jobs
  - `founder-voice-capture` — captures founder ideas from voice/unstructured text into structured briefs. **Priority #0 if the founder struggles to create content or the output sounds generic.**
  - `market-researcher` — intelligence with mandatory citations
  - `content-drafter` — channel-specific drafts with self-check and founder-voice mode
  - `campaign-planner` — integrated briefs with calendar, KPIs, experiments
  - `performance-reviewer` — metrics, learnings, memory updates

Each role doc should follow the OpenDirectory runbook pattern:
1. mission
2. inputs
3. outputs
4. what it must not do
5. quality rules
6. next handoff
7. where results are stored

**Founder-voice-capture skill design:**
When building this skill (because the founder's content sounds generic), the skill must:
- Accept voice/text input without polishing the voice away
- Extract: idea core, problem named, operative scene, counterintuitive break, WS Capital entry point, what is NOT promised yet
- Ask clarifying questions BEFORE drafting if anything is ambiguous
- Hand off a structured brief to `content-drafter`, not a raw prompt
- Include a `voice-profile.md` that accumulates from each session (phrases the founder uses, metaphors, tone, Mexicanisms, etc.)
- Include anti-template rules: no "5 tips," no "future of," no "leverage AI," no definitions-first openings
- Require an operative scene in every piece
- End with conversation CTAs (reply, DM, book call) not passive "follow us" CTAs

### 7b. When the user wants a FULL OPERATIONAL DEPARTMENT (not just skills)

**Critical pivot:** If the founder says "esto está muy simple, quiero un departamento real" or wants everything runnable as a system (not just prompts), you must pivot from Hermes skills to an **independent Onyx instance** as the department runtime.

This is what happened in the evolution of this skill: Hermes skills were built first, then the user said "quiero un Onyx independiente, un departamento real con todo conectado."

**Operational startup checklist (from live deployment experience):**

1. **Verify project location** — The Onyx Marketing department may already exist at `~/.hermes/hermes-ops/onyx-marketing/`. Check there before cloning anything.
2. **Check external tools folders** — `tools/pixelle/`, `tools/huashu/`, `tools/openframe/` may be empty placeholders. If the docker-compose references them, create minimal stubs (FastAPI/Express hello-world) or the build will fail.
3. **CUDA is optional for cloud-LLM setups** — If the LLM provider is NVIDIA API (`integrate.api.nvidia.com`), local CUDA/cuDNN is NOT required. The API key calls remote inference. Only install CUDA if running local embedding models.
4. **Start with minimal stack first** — DB + Bridge API + MinIO validates the architecture in ~3 minutes. Only then build the heavy Onyx Web/API images (~15 min). This follows the same pattern as Willow: validate core before UI.
5. **Env vars from `.env`** — Place `NVIDIA_API_KEY` and `GEMINI_API_KEY` in `~/.hermes/hermes-ops/onyx-marketing/.env`, then use `docker compose --env-file .env` to inject them.
6. **LLM provider failure fallback** — If `NVIDIA_API_KEY` returns 401/403, the department must NOT block. The Bridge API's `call_llm()` helper will fail, but Hermes can still generate content by reading stored context directly from PostgreSQL (`marketing_context`, `marketing_client_voice`, `marketing_campaign`) and using its own LLM connection. The DB is the source of truth; the LLM provider is just one executor.

**The Onyx Department Stack pattern:**

Build a completely independent Onyx instance (separate Docker containers, separate DB, separate port) that replicates how Willow (legal) already works:

```
marketing-web:3004       → Next.js frontend (chat-first)
marketing-api:3002       → Python backend (Onyx API clone)
marketing-bridge:3003    → FastAPI (department-specific logic)
marketing-db:5433        → PostgreSQL (independent schema)
marketing-minio:9000     → Object storage
pixelle:8001             → External tool: video engine
huashu:8002              → External tool: design engine
openframe:8003           → External tool: ad engine (optional)
```

**Practical startup workflow:**
1. `cd /root/.hermes/hermes-ops/onyx-marketing/`
2. Create `.env` with `NVIDIA_API_KEY` (and optionally `GEMINI_API_KEY`)
3. Verify tools/ have stubs (create if empty)
4. Choose compose variant:
   - **Minimal** (`docker-compose.minimal.yml`): DB + Bridge + MinIO only. Fast startup (~2 min). Good for API validation.
   - **Full** (`docker-compose.marketing.yml`): All services including Onyx web, API, external tools. Slow startup (~10-15 min build).
5. Export env vars: `export $(grep -v '^#' .env | xargs)`
6. Build bridge: `docker compose -f setup/docker-compose.minimal.yml build --no-cache marketing-bridge`
7. Start DB first, wait for health, then full stack
8. Verify: `curl http://localhost:3003/api/marketing/health`
9. Check seeded agents: `docker exec marketing-db-1 psql -U postgres -d marketing -c "SELECT name FROM persona WHERE deleted = false;"`

**WS Capital as client #1 pattern:**
When the user confirms agency multi-tenant with WS Capital as the first client:
```sql
INSERT INTO client (name, slug, industry, plan, status)
VALUES ('WS Capital', 'ws-capital', 'Venture Studio / Legal Tech', 'internal', 'active');
```
All agents must then load context dynamically per `client_id`. Never hardcode "Pablo" or "WS Capital" in agent system prompts when using agency mode.

**Founder voice intake → Campaign registration workflow:**
When the founder describes products/audience/strategy via voice memo (common in Telegram-first operations), the agent must immediately structure this into the DB:

1. **Update `client` record** — Ensure WS Capital exists with correct industry/plan
2. **Create `marketing_campaign` rows** — One per product/vertical the founder describes:
   - `name`: Human-readable campaign name (e.g., "Willow - Clones para Abogados")
   - `slug`: URL-friendly identifier
   - `vertical`: product category (legal-tech, event-tech, etc.)
   - `objective`: one-sentence campaign goal
   - `objective_smart`: JSONB with S-M-A-R-T breakdown
   - `channel_mix`: JSONB with channel weights
   - `kpi_targets`: JSONB with numeric goals
   - `positioning_note`: Value prop in founder's own words
3. **Update `marketing_context`** — Insert the root context for this client:
   - `objective`: Company-level objective
   - `thesis`: Mother thesis (why this company exists)
   - `verticals`: JSONB array of active products
   - `icp_definitions`: JSONB array of audience segments with pains/channels
   - `anti_genericity`: JSONB with banned words, banned structures, rules
   - `voice_tokens`: JSONB with tone, sentence style, mexicanisms flag
4. **Seed `marketing_client_voice`** — Extract signature phrases from the voice memo:
   - `attribute`: 'tone' | 'phrases' | 'anti_patterns' | 'signature_moves'
   - `examples`: Direct quotes from founder
   - `patterns`: Structural patterns observed
   - `confidence_score`: Start at 60%, raise to 90%+ when real written samples provided
5. **Propose content calendar** — Based on founder's stated cadence (e.g., "5 piezas por producto, 2-3 de marca"), map to a concrete weekly calendar and ask for approval

**Critical:** Do NOT wait for perfect voice samples before registering campaigns. Capture everything from the voice memo into structured DB rows immediately. The voice profile can be refined later with written samples. The DB is the source of truth — if it's not in the DB, the agents can't access it.

**Anti-pattern to avoid:** Letting the founder ramble about products without immediately structuring into campaigns. Every product description should become a row in `marketing_campaign` within the same session.

**Before building — verify server resources:**
```bash
free -h          # RAM (need ~4GB minimum, 8GB comfortable)
df -h /          # Disk (need ~20GB free)
nproc            # CPU cores (2+ minimum)
docker ps --size # See current container sizes
```
If RAM is tight (<4GB free), start with DB + Bridge API only, add web/tools later.

**What to build:**

1. **Docker Compose** (`docker-compose.marketing.yml`) with:
   - All Onyx base services (web, api, db, nginx, minio)
   - Bridge API service (FastAPI)
   - External tool services (Pixelle, huashu, OpenFrame as separate containers)
   - Independent ports (3002-3004, 5433, 8001-8003, 9000-9001)
   - Independent volume names (`marketing_postgres_data`, not `onyx_postgres_data`)
   - **LLM Provider: NVIDIA** — match existing Onyx instance (e.g., Willow). Use same `llm_provider` config:
     ```sql
     INSERT INTO llm_provider (name, provider, api_base, is_default_provider, default_model_name)
     VALUES ('nvidia', 'openai', 'https://integrate.api.nvidia.com/v1', true, 'meta/llama-3.3-70b-instruct');
     ```
     This ensures the new department uses the same API keys/credentials the user already has.

2. **PostgreSQL Schema** — Two schema variants exist:
   
   **a) Single-tenant** (`marketing_schema.sql`) — For WS Capital's own marketing only. One implicit "client."
   
   **b) Agency multi-tenant** (`marketing_schema_v2_agency.sql`) — **Use this if the user says "es una agencia" or "múltiples clientes."** Every table has `client_id`:
   ```sql
   CREATE TABLE client (
       id SERIAL PRIMARY KEY,
       name VARCHAR(255), slug VARCHAR(255), industry VARCHAR(100),
       plan VARCHAR(50), monthly_retainer NUMERIC, status VARCHAR(50)
   );
   -- All marketing tables reference client_id:
   -- marketing_campaign, marketing_content_piece, marketing_lead,
   -- marketing_experiment, marketing_research, marketing_analytics,
   -- marketing_icp, marketing_client_voice, etc.
   ```
   
   Agency model requires:
   - Every endpoint requires `client_id` (query param or body)
   - Agent system prompts ask "¿Para qué cliente?" before acting
   - Context loading per client: `SELECT * FROM marketing_context WHERE client_id = X`
   - Voice profile per client: `marketing_client_voice` table
   - Never mix data between clients

3. **Bridge API** (`main.py` or `main_v2_agency.py`) with endpoints integrating ALL audited repos:
   - `/api/marketing/founder-voice` (single-tenant) or `/api/marketing/client-voice` (agency) — Pipeline: raw input → brief extraction → draft generation → critic review (5 dimensions) → fixes
   - `/api/marketing/campaigns` — CRUD with ORB Framework, SMART objectives
   - `/api/marketing/content/*` — Content pipeline with approve/publish/repurpose
   - `/api/marketing/research` — Multi-source research with background execution
   - `/api/marketing/leads` — Lead pipeline with outreach sequence generation
   - `/api/marketing/competitors/profile` — URL-based competitor profiling
   - `/api/marketing/experiments` — A/B test design and tracking
   - `/api/marketing/lead-magnets` — Lead magnet design with landing page copy
   - `/api/marketing/analytics` — Performance metrics aggregation
   - `/api/marketing/launches` — Launch planning with ORB Framework
   - `/api/marketing/tools/{pixelle,huashu,openframe}` — Asset generation via external tools
   - `/api/marketing/knowledge` — Searchable knowledge base from all repos
   - `/api/marketing/icp` — ICP definitions per client (agency)
   - `/api/marketing/clients/*` — Client CRUD (agency)

4. **Agent Seeding** (`agents_seed.sql`) — 5+ agents in `persona` table:
   - **Single-tenant:** Agents can reference the founder by name (Pablo). System prompts are specific.
   - **Agency:** Agents must be **generic**. Ask "¿Para qué cliente?" before acting. Load client's context/voice/ICP dynamically. Never hardcode a founder's name.
   - Each agent's `system_prompt` integrates patterns from MULTIPLE repos
   - Include `starter_messages` JSONB for chat UI
   - Link tools via `persona__tool` join table
   - Example agents: Estratega de Growth, Researcher de Mercado, Creador de Contenido, Generador de Leads, Analista de Performance

5. **Setup Script** (`setup.sh`) — Automated installation:
   - Checks Docker, env vars (NVIDIA_API_KEY, GEMINI_API_KEY), ports
   - Creates persistent data directories
   - Builds images, starts DB first, waits for health
   - Starts full stack, verifies health of each service
   - Reports which agents were seeded

**How the Bridge API integrates external repos:**

| Repo | Integration in Bridge API |
|------|--------------------------|
| marketingskills | Skills translated into `system_prompt` fragments. `product-marketing-context` → `marketing_context` table. Frameworks (PAS, ORB, Searchable vs Shareable) embedded in endpoints. |
| Marketing-for-Engineers / Founders | Playbooks ingested into `marketing_knowledge` table. Tactics surfaced via `/api/marketing/knowledge` search. |
| huashu-design | Anti-AI-slop checklist in critic review. 5-dimension review framework in performance reviewer. |
| Pixelle-Video | `/api/marketing/tools/pixelle` endpoint. Brief → video pipeline. |
| OpenFrame AI | `/api/marketing/tools/openframe` endpoint. Critic+revise pattern in content generation. |
| OpenDirectory | Outreach sequences, Reddit ICP monitor, LinkedIn post patterns in respective endpoints. |

**Connection to Hermes (Neo):**
- Hermes remains the **orchestrator externo** from Telegram
- Hermes calls Bridge API endpoints (e.g., POST founder-voice with Pablo's voice transcript)
- Hermes receives results and delivers back to Pablo via Telegram
- Hermes does NOT do the content generation itself — it delegates to Onyx Marketing agents

**Connection between departments (e.g., Marketing ↔ Willow):**
- API-to-API bridge when needed
- `willow-legal-api:3001` ↔ `marketing-bridge:3003`
- No shared DB, no shared containers

### 7c. Dual documentation pattern (agent + user)

When building a department that serves multiple users (founder + team + clients), create **two documentation layers**:

1. **Agent Operator Documentation** (`DOCUMENTACION_NEO.md`) — How the AI agent (Neo/Hermes) uses the Bridge API:
   - Which endpoints to call for each job type
   - How to pass `client_id` in every request
   - How to poll for background task completion
   - Error handling and fallback flows
   - This doc lives in `hermes-ops/docs/`

2. **End-User Documentation** (`DOCUMENTACION_USUARIO_INDIVIDUAL.md`) — How a human user operates the department directly:
   - Web UI URLs and navigation
   - API curl examples for common tasks
   - Dashboard views and what each shows
   - Troubleshooting commands
   - This doc lives in the department's `docs/` folder

This separation prevents confusion: the agent doesn't need to know about "clicking the sidebar," and the user doesn't need to know about `delegate_task` fan-out patterns.

### 7d. Critical architectural decision: single-tenant vs agency

**Choose single-tenant when:**
- The department serves only WS Capital's internal operations
- One founder, one voice, one set of ICPs
- Simpler schema, simpler agent prompts

**Choose agency multi-tenant when:**
- The user explicitly says "es una agencia" or "múltiples clientes"
- The department will sell marketing services to external businesses
- Each client needs isolated data, voice, campaigns, and analytics
- The user says "como seguramos una agencia"

**If the user pivots from single-tenant to agency mid-session** (as happened here), do NOT try to patch the schema incrementally. Rebuild the schema with `client_id` on every table, update the Bridge API to require `client_id` on every endpoint, and rewrite agent prompts to be client-generic. The migration is cheaper when done early.

### 8. Dual-write rule: authority docs + reviewable mirrors
When execution starts:
- save operational authority docs in `hermes-ops/docs`
- save reviewable mirror copies in the appropriate Obsidian vault
  - usually `Growth Vault/03_Campanas` for context and role docs
  - `System Vault/00_System` for execution/status notes

This keeps software-style authority separate from human review surfaces.

### 9. Status transition rule
Once the first real artifacts exist, patch the status docs so the system reflects that marketing infrastructure moved from architecture to execution.
At minimum update:
- intake/architecture note
- build plan state
- growth/system status docs that describe readiness or pending work

The key state change is:
- from "planned / architecture only"
- to "execution started with operational artifacts v1"

---

### Critical Rule: Generate, Don't Ask

**Trigger:** When the user says things like "yo no sé, por eso te pido ayuda", "estás actuando como un chatbot", "necesito que pongas más de tu parte", or any variation of "I don't know, that's why I'm asking you."

**The problem:** If the founder could answer all your questions, they wouldn't need a marketing department. Asking 10 clarifying questions feels like a chatbot. Generating a complete deliverable with best-guess assumptions and letting them correct it feels like a department.

**What to do instead:**
1. Use what you already have (DB context, voice profile, past sessions, skills)
2. Generate the best possible version with current information
3. Present it as a deliverable: "Aquí está lo que construí con lo que tengo. ¿Qué ajustamos?"
4. Let the user correct specific items, not fill blanks

**Never ask the founder for:**
- Their voice (extract it from voice memos and past messages)
- Their target audience (infer from product descriptions and context)
- Their keywords (research them yourself)
- Their content calendar (propose one based on best practices)

**Always generate first, then iterate.** The founder buys when they "ven las cosas hechas."

---

### 10. SEO/GEO Scoring Engine (Python)

Build a lightweight Python scoring engine for content quality. This runs locally, no API calls needed.

**`content_analyzer.py`** — 5-dimension scoring (0-100 each, weighted overall):

```python
class ContentAnalyzer:
    def __init__(self):
        self.banned_words = ["leverage", "synergy", "disrupt", "ai-powered", "future of"]
        self.banned_structures = ["5 tips", "10 ways", "definicion", "que es"]
    
    def analyze(self, content: str, primary_keyword: str = "") -> dict:
        return {
            "seo_score": self._seo_score(content, primary_keyword),      # 25% weight
            "readability_score": self._readability_score(content),       # 20% weight
            "geo_score": self._geo_score(content),                       # 25% weight
            "anti_ai_slop": self._anti_ai_slop_score(content),           # 20% weight
            "voice_match": self._voice_match_score(content),             # 10% weight
            "overall": 0,
            "recommendations": []
        }
    
    def _seo_score(self, content, keyword):
        # Word count, keyword in first 100 words, headings, internal links
        score = 50
        words = content.split()
        if len(words) >= 2000: score += 15
        first_100 = " ".join(words[:100]).lower()
        if keyword and keyword.lower() in first_100: score += 10
        h2_count = len(re.findall(r'^## ', content, re.MULTILINE))
        if h2_count >= 4: score += 10
        internal_links = len(re.findall(r'\[.*?\]\(.*?\)', content))
        if internal_links >= 3: score += 10
        return min(100, score)
    
    def _readability_score(self, content):
        # Sentence length, paragraph length
        sentences = re.split(r'[.!?]+', content)
        avg_words = len(content.split()) / len(sentences) if sentences else 0
        if avg_words <= 15: score = 90
        elif avg_words <= 20: score = 80
        elif avg_words <= 25: score = 70
        else: score = 60
        return min(100, score)
    
    def _geo_score(self, content):
        # Direct answer, structured data, numbers, author attribution, E-E-A-T
        score = 40
        sentences = re.split(r'[.!?]+', content)
        if len(sentences) >= 2:
            first_two = " ".join(sentences[:2])
            if len(first_two) > 50 and any(c.isdigit() for c in first_two):
                score += 15
        list_items = len(re.findall(r'^[\-•]', content, re.MULTILINE))
        if list_items >= 3: score += 15
        numbers = len(re.findall(r'\b\d+%?\b', content))
        if numbers >= 3: score += 10
        if any(w in content.lower() for w in ["yo", "mi", "estuve", "construí"]):
            score += 10
        return min(100, score)
    
    def _anti_ai_slop_score(self, content):
        # Detect banned words, generic structures, template patterns
        score = 100
        content_lower = content.lower()
        for word in self.banned_words:
            if word in content_lower: score -= 10
        for struct in self.banned_structures:
            if struct in content_lower: score -= 10
        if re.search(r'\d+\s+(tips|ways|steps)', content_lower):
            score -= 15
        return max(0, score)
    
    def _voice_match_score(self, content):
        # Personal references, short sentences, questions, conversational CTA
        score = 50
        content_lower = content.lower()
        personal = ["yo", "estuve", "construí", "diseñé", "aprendí"]
        score += sum(1 for p in personal if p in content_lower) * 5
        sentences = re.split(r'[.!?]+', content)
        short = sum(1 for s in sentences if 3 <= len(s.split()) <= 12)
        if sentences and short / len(sentences) >= 0.3:
            score += 15
        questions = len(re.findall(r'[¿?]', content))
        if questions >= 2: score += 10
        if any(cta in content_lower for cta in ["dm", "platiquemos", "comenta"]):
            score += 10
        return min(100, score)
```

**`keyword_researcher.py`** — Simple keyword DB per vertical:

```python
class KeywordResearcher:
    def __init__(self):
        self.keyword_db = {
            "vertical_slug": {
                "primary": "main keyword",
                "variations": ["alt1", "alt2"],
                "long_tail": ["specific query 1", "specific query 2"],
                "intent_map": {"keyword": "informational/commercial/transactional"}
            }
        }
    
    def research(self, topic: str, vertical: str) -> dict:
        data = self.keyword_db.get(vertical, {})
        return {
            "primary_keyword": data.get("primary", ""),
            "variations": data.get("variations", []),
            "long_tail": data.get("long_tail", []),
            "intent": data["intent_map"].get(topic, "informational"),
            "content_type": self._content_type_from_intent(...),
            "recommended_length": self._recommended_length(...)
        }
```

**Usage in generation pipeline:**
1. Research keywords for topic
2. Generate content with keyword in first 100 words, H2s, natural density
3. Run `analyzer.analyze(content, keyword)`
4. If score < 80, apply recommendations and regenerate
5. Log score in Excel tracking sheet

---

### 11. Rebuild from Scratch as Validation Test

**Trigger:** When the user says "elimina todo y hazlo de nuevo", "quiero ver que todo funciona", "haz una prueba final", or wants to validate the system works end-to-end.

**The workflow:**

1. **Clean slate** — Delete all old content, documents, Excel files. Keep only infrastructure (DB, Bridge API, context files).

2. **Build/verify the engine** — Create or verify:
   - `content_analyzer.py` — Scoring engine
   - `keyword_researcher.py` — Keyword research engine
   - Context files (7 files in `08_Voz_Marca/`)

3. **Generate all content** — Using the engine and context:
   - 2 pillar pages (3000-5000 words each)
   - 8-12 supporting articles per pillar (1500-2500 words)
   - 3-5 brand posts per week
   - Total: 20-30 pieces for a 4-week campaign

4. **Score everything** — Run every piece through the analyzer:
   - Target: overall score 80-100
   - GEO score: 70-100
   - SEO score: 70-100
   - Anti-AI-Slop: 80-100
   - Track scores in Excel

5. **Build Excel v2** — Update control master with:
   - Dashboard with KPIs
   - Calendario Editorial (all pieces with scores)
   - Contenido tracking (all pieces with links)

6. **Verify everything** — Automated checklist:
   - All files exist
   - All scores are logged
   - Excel has correct links
   - Engine runs without errors

7. **Deliver** — Present the complete package to the user

**Success signal:** User opens Excel, sees scores and color-coded status, clicks to a markdown file, and says "esto sí lo puedo revisar."

---

### 12. Offline Deliverable Workspace (Alternative to Onyx UI)

**Trigger:** Use this when the user says "necesito una ruta alternada de trabajo", "quiero un dashboard alternativo a Onyx", "quiero ver archivos, no un chatbot", or when the Onyx web UI is not running but the bridge API/DB is operational.

Pablo explicitly asked for an alternative to the Onyx dashboard: a folder structure with Excel control masters and markdown documents formatted as "entregables para cliente." This pattern bridges the gap between the department running in Docker and tangible files the user can review, edit, and approve.

**Why this matters:** The founder buys when they "ven las cosas hechas." A web dashboard they can't touch feels abstract. Files on disk feel real.

#### Folder structure (mirror the department organization)

Create a root folder on the filesystem (e.g., `/mnt/c/{Client}_Growth_Marketing/` or `~/Documents/WS_Capital_Growth_Marketing/`):

```
{Client}_Growth_Marketing/
├── 01_Control_Maestro/              ← Excel master + JSON plans
│   └── Control_Maestro_{Dept}.xlsx
├── 02_Clientes/
│   ├── {Client_Slug}/               ← Ficha cliente + historial mensual
│   └── Plantilla_Cliente/           ← Template para nuevos clientes
├── 03_Campanas/
│   ├── {Campana_1}/
│   ├── {Campana_2}/
│   └── ...
├── 04_Contenido/
│   ├── Borradores/                  ← Posts en desarrollo
│   ├── Calendario/                  ← Vistas calendario (PDF/PNG)
│   └── Publicados/                  ← Posts ya publicados (copia + métricas)
├── 05_Entregables/
│   ├── Propuestas/                  ← Documentos maestros (estrategia, plan, borradores)
│   ├── Reportes/                    ← Reportes mensuales
│   └── Presentaciones/              ← Decks para cliente
├── 06_Research/
│   ├── Mercado_{Vertical_1}/
│   └── Mercado_{Vertical_2}/
├── 07_Metricas/
│   └── Mensuales/                   ← CSV/Excel por mes
└── 08_Voz_Marca/                    ← Voice profile + activos de marca
```

#### Excel Master Control (7+ sheets)

Build with `openpyxl`. Each sheet serves a specific control function:

| Hoja | Propósito | Datos clave |
|------|-----------|-------------|
| **Dashboard** | Vista ejecutiva | KPIs (objetivo/actual/%), campañas activas, calendario de esta semana, status con colores |
| **Clientes** | Base de datos | ID, nombre, slug, industria, plan, retainer, status, contacto, notas. Validación dropdown para status. |
| **Calendario Editorial** | Planificación | Día, fecha, campaña, producto, tipo, formato, canal, tema/hook, CTA, status, link borrador, link publicado, reach, engagement |
| **Control Campañas** | Seguimiento de campañas | ID, nombre, cliente, vertical, objetivo, SMART (JSON desglosado), status, fechas, leads obj/act, conversiones obj/act |
| **Métricas** | Histórico mensual | Mes, campaña, piezas publicadas, reach, impressions, engagement, leads, calls, conversiones, ROI est. Plantilla vacía para llenar. |
| **{Cliente}** | Ficha específica | Info completa del cliente, campañas asociadas, historial mensual (base de entrenamiento para ML futuro) |
| **Inventario Entregables** | Tracking de documentos | ID, nombre, tipo, campaña, status, ruta archivo, fecha creación, notas. Links directos a archivos. |

**Formato visual obligatorio:**
- Header rows: fondo `#1F4E78`, texto blanco, negrita
- Status "✅ Listo" → celda verde (`C6EFCE`)
- Status "⏳ Pendiente" → celda amarilla (`FFEB9C`)
- Status "🔴 Bloqueado" → celda roja (`FFC7CE`)
- Anchos de columna ajustados al contenido
- Alineación centrada para status, izquierda para textos largos
- Texto wrap en celdas con descripciones

#### Markdown Deliverables (formato "entregable para cliente")

Create professional markdown documents that look like client deliverables, not internal notes. Structure:

```markdown
# {TÍTULO DEL DOCUMENTO}
## {Cliente} — {Período}

---

**Cliente:** {nombre}  
**Departamento:** Growth & Marketing  
**Fecha:** {DD/MM/YYYY}  
**Versión:** {X.Y}  
**Preparado por:** Departamento de Marketing {Cliente}  

---

## 1. RESUMEN EJECUTIVO
...

## 2. DIAGNÓSTICO / CONTEXTO
...

## 3. ESTRATEGIA
...

## 4. MÉTRICAS Y KPIs
| KPI | Objetivo | Actual | % Avance |
...

## 5. PRÓXIMOS PASOS
| # | Acción | Responsable | Fecha límite |
...

## 6. ANEXOS
...

---
*Documento preparado por el Departamento de Growth & Marketing de {Cliente}.*
```

**Types of deliverable documents:**
- **Propuesta Estratégica** — Diagnóstico + estrategia ORB + KPIs + calendario + próximos pasos
- **Plan Editorial Detallado** — Semana por semana, día por día, con temas/hooks/CTAs/formatos
- **Borradores de Contenido** — Posts individuales con:
  - Metadatos (día, campaña, formato, canal)
  - Contenido completo
  - Nota del editor (por qué funciona esta estructura)
  - Checklist de revisión (✓ hook, ✓ escena operativa, ✓ break, ✓ CTA, ✓ anti-AI-slop)
  - **Acción requerida** con checkboxes: ☐ Aprobar ☐ Ajustes ☐ Rechazar
  - **Espacio para comentarios del cliente** (líneas en blanco)

#### Integration with the Bridge API

The offline workspace is NOT a replacement for the Bridge API database — it's a **tangible mirror** of what's in the DB.

**Workflow:**
1. Hermes reads campaign/context data from PostgreSQL (via Bridge API or direct `docker exec psql`)
2. Hermes generates content (using the DB context as source of truth)
3. Hermes saves markdown deliverables to `05_Entregables/Propuestas/`
4. Hermes updates Excel links to point to the new file paths
5. Hermes delivers the file paths to the user via Telegram
6. User reviews files, adds comments/checks boxes
7. Hermes reads user feedback, updates DB status, and regenerates if needed

**Fallback when LLM provider fails:**
If `call_llm()` returns 401/403 (NVIDIA key issue), the agent must still generate content by:
1. Reading `marketing_context`, `marketing_client_voice`, and `marketing_campaign` directly from PostgreSQL
2. Using the voice tokens and anti-genericidad rules as constraints
3. Writing content manually (as a human copywriter would) rather than delegating to LLM
4. Saving to markdown files for human review

The DB context is the source of truth. The LLM is just one executor. Never block on LLM failure.

**Success signal:** The user opens the Excel, sees color-coded status, clicks through to markdown deliverables, and says "esto sí lo puedo revisar y mover" — that's the moment the offline workspace has replaced the abstract dashboard.

## Output set to produce
At minimum create:
- `Marketing Infrastructure - Intake y Source Review.md` — log all sources with classification
- `Marketing Infrastructure - Source Review 01.md` — first batch of sources audited
- `Marketing Infrastructure - Source Review 02.md` — second batch (user-provided repos or Hermes ecosystem)
- `Marketing Infrastructure - Capability Map v1.md` — capabilities with Related Skills cross-references
- `Marketing Infrastructure - Build Plan v1.md`
- `marketing-context.md` — the root context artifact with **YAML frontmatter** containing machine-readable voice/tone/quality tokens, plus markdown prose with objective mayor, tesis madre, verticales, audiencias, anti-genericidad, banned words, tone rules, criterios de aprobación, and founder personal bottlenecks as operational inputs

**When building from founder voice vault (bóveda de voz):**
- `principios-rectores.md` — extracted verbatim from voice transcripts, not interpreted
- `marketing-context-v2.md` — rewritten in founder's voice, not marketing-speak
- `evolucion.md` — what "evolve" means in founder's words
- `memory.md` — decisions, learnings, corrections with verbatim quotes
- `experiments.md` — experiment log with hypothesis/results format
- `ESTADO_ACTUAL.md` — current state, next step, updated per session
- `MANUAL-OPERACION.md` — how the department operates step by step
- `pablo-voice-vault/` — exact transcripts, never edited, never summarized
- `vault/` — 5-folder production vault (campaigns, content, experiments, assets, briefs)

## Prompt architecture rule
Every prompt/agent role should define:
1. mission
2. expected inputs
3. exact outputs
4. what it must not do
5. quality rules
6. next handoff
7. where results are stored
8. **Related Skills** — which other capabilities this one references or hands off to

## Source-specific lessons from this workflow

### OpenFrame AI
Do not copy the ad engine. Reuse:
- multi-agent specialization
- fan-out / fan-in
- critic + revise loop
- stage-specific outputs

### knowledge-work-plugins/marketing
Reuse:
- command-per-task structure
- skills by function
- brand review separate from drafting
- planning separate from execution
- connectors as later layer

### Hermes Atlas / hermes-ecosystem
Reuse:
- specialization via isolation
- skills as durable units
- profiles/capabilities with handoffs
- memory + workflow loops over ad hoc prompting

### marketingskills
Treat as strongest source for skill graph design:
- granular capabilities
- context-root artifact
- CRO/copy/SEO/revops/research/pricing breakdown

### Marketing-for-Engineers / Marketing-for-Founders
Use for tactical library and founder-channel patterns, especially:
- early users
- no-budget GTM
- founder-led channels
- outreach
- SEO/content/social launch tactics

### startup-marketing-checklist
Use for chronological and recurring execution structure:
- pre-launch
- post-launch
- recurring

### ai-marketing-claude
Useful for:
- command suite structure
- audit outputs
- sub-skill orchestration
- templates/reports

### ruvnet/marketing
Use cautiously for inspiration only:
- tiered swarm architecture
- specialist layer naming
- not a direct fit for WS Capital's current stage

### OpenDirectory / agentskills.io ecosystem
The strongest practical reference for skill design patterns. Each skill follows a consistent runbook structure:
1. **YAML frontmatter** — name, description, compatibility, triggers
2. **Setup check** — verify env vars and required files before execution
3. **Context loading** — read `docs/icp.md`, `docs/accounts/*.md`, or ask the user if missing
4. **Step-by-step execution** — numbered steps, not a giant prompt
5. **Critical rules** — explicit prohibitions (e.g., "never invent post URLs", "only `{{first_name}}` as variable")
6. **Writing style rules** — active voice, banned words list, sentence length, formatting rules per channel
7. **Optional connectors** — Composio, Ghost, APIs. Skill works in output-only mode if connectors missing.

**Reuse this structure literally** when building new skills for WS Capital.

### marketingskills (coreyhaines31) — Skill graph architecture
The most influential skill library for marketing (23K+ stars). Key architectural patterns to reuse:
- **Context-root is mandatory** — Every skill starts with "Check for product marketing context first." If `.agents/product-marketing-context.md` exists, read it before asking anything.
- **Skill graph with cross-references** — Each skill lists Related Skills. The graph looks like: `product-marketing-context` at root → SEO & Content, CRO, Content & Copy, Paid & Measurement, Growth & Retention, Sales & GTM, Strategy as branches. Skills cross-reference each other (e.g., `copywriting` ↔ `page-cro` ↔ `ab-test-setup`).
- **When building a capability map, add Related Skills to each capability** — this creates a navigable graph instead of isolated units.
- **Frameworks to integrate into content-drafter:** PAS (Problem-Agitate-Solve), Before-After-Bridge, Story-Problem-Solution.
- **Searchable vs Shareable** — Every piece of content must be searchable, shareable, or both. Prioritize search traffic as foundation.
- **ORB Framework for campaign planning** — Owned channels (email, blog, community) → Borrowed channels (guest posts, partnerships) → Rented channels (ads, social algo). Start with Owned.
- **Lead magnet principle** — Lead magnet = "sample of the product," not generic content.
- **Digital watering holes** — Mine Reddit, G2, forums, communities for voice-of-customer.

### design.md (Google Labs) — Machine-readable context format
Google Labs' format for describing visual identity to coding agents. Reuse for the marketing context root:
```md
---
name: Heritage
colors:
  primary: "#1A1C1E"
typography:
  h1:
    fontFamily: Public Sans
    fontSize: 3rem
---

## Overview
Architectural Minimalism meets Journalistic Gravitas...
```
**Lesson:** Add YAML frontmatter with machine-readable tokens to `marketing-context.md`:
- `tokens.voice.tone`, `tokens.voice.sentence_style`, `tokens.voice.banned_structures`
- `tokens.anti_genericidad.banned_words`
- `tokens.quality.approval_checklist`
This lets agents parse the context programmatically instead of extracting rules from prose.

### huashu-design — Anti-AI-slop and expert review
Skill for HTML-native design with quality guardrails. Patterns to adapt for marketing content:
- **Anti-AI-slop checklist** — Explicit list of structures/patterns that make output feel generic. Not just banned words, but banned *structures* (e.g., "definitions as opening", "generic lists", "5 tips format").
- **Fact verification before creation** — "Any factual claim about a product, version, or timeline: WebSearch first, never assert from training data." Apply to `market-researcher` and any content that cites facts.
- **Expert review of 5 dimensions** — Adapt for content quality review:
  1. Philosophy consistency (aligned with tesis madre?)
  2. Visual hierarchy / structure clarity
  3. Detail execution (banned words? active voice?)
  4. Functionality (CTA works? lead generated?)
  5. Innovation (new angle? learning?)

### Pixelle-Video — "One sentence → finished asset" pipeline
AI short-video engine: input a topic → auto-write script → generate images/video → synthesize voice → add BGM → compose video.
**Lesson for marketing:** The founder-voice pipeline should feel like this. One voice message from the founder → structured brief → draft → review → ready to publish. The UX goal is "input simple, output complex."

### OpenFrame AI — Multi-agent quality pipeline
7 specialized agents + Critic + Reviser in a LangGraph DAG.
**Lessons to replicate with Hermes `delegate_task`:**
- **Fan-out / fan-in** — Launch parallel subagents for independent tasks, then collect.
- **Critic + Reviser as standard** — Every significant output goes through a critique subagent before delivery. Not optional.
- **Per-agent model selection** — Use cheaper models for simple tasks, powerful models for creative/review tasks. Configurable via `delegation.model` in Hermes.
- **No black boxes** — User sees every node/agent in the pipeline. Apply by making handoffs visible in status docs.

### Connector skills (e.g., hermes-facebook-skill)
Pattern for connecting Hermes to external platforms:
- `SKILL.md` — definition and orchestration
- `scripts/connector.py` — API client logic (Meta Graph API, LinkedIn API, etc.)
- `references/` — templates, reply patterns, bilingual copies
- `.env.example` — required credentials documented

Keep connectors separate from content/prompt skills. A connector should post what a drafter wrote, not write itself.

## Vault routing rule
- `System Vault` → architecture, methodology, capability map, backlog, operating priorities
- `Growth Vault` → market-facing thesis, campaigns, pieces, experiments, prompts for review
- `Build Vault` → software/research/writer/builder implementation memory

## Anti-patterns
- do not start by generating final copy
- do not create one giant "marketing agent"
- do not let Growth absorb every memory lane
- do not confuse tactical resource libraries with architecture
- do not assume Twitter/indie hacker channels are the user's actual customer base

## Success criteria
This skill worked if you end with:
- a real capability map
- a phased build plan
- prompt-role definitions to implement next
- routing across vaults/docs
- a system that can later generate better content because infrastructure exists
