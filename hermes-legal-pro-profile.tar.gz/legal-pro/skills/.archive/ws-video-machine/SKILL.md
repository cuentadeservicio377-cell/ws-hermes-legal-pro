---
name: ws-video-machine
description: "Operar el sistema de generación de video de WS Capital. Genera videos cortos para redes sociales (LinkedIn, Instagram, TikTok) a partir de scripts, imágenes o prompts. Integrado con APIs de video (FAL, Runway, Pika, etc.) y flujo de producción automatizado."
version: 1.0.0
author: WS Capital
license: MIT
metadata:
  hermes:
    tags: [video, generation, content, marketing, shorts, reels, tiktok]
---

# WS Video Machine — Sistema de Generación de Video

## Propósito
Generar videos cortos para redes sociales de forma automatizada a partir de scripts, imágenes o prompts de texto. Integrado con el ecosistema WS Capital (Growth Marketing, Onyx, Hermes).

## Estado del Proyecto
✅ **REPO CLONADO** — `/mnt/c/Users/DELL/Documents/repos/projects/active/video-machine/`
- Origen: `https://github.com/cuentadeservicio377-cell/video-machine`
- Stack: Python 3.12+ (pipelines, AI, orquestación) + TypeScript/Node.js 18+ (rendering, UI)
- CLI: `maquina` (17+ comandos)
- **Pendiente:** Instalar dependencias y configurar API keys

## Arquitectura Objetivo

```
┌─────────────────────────────────────────────────────────────┐
│  WS Video Machine                                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │  Input       │  │  Engine      │  │  Output          │  │
│  │  • Script    │  │  • FAL API   │  │  • MP4 final     │  │
│  │  • Imágenes  │  │  • Runway    │  │  • Thumbnail     │  │
│  │  • Prompt    │  │  • Pika      │  │  • Subtítulos    │  │
│  │  • URL/blog  │  │  • Local     │  │  • Metadata      │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────────────┘  │
│         │                  │                                  │
│  ┌──────▼──────────────────▼──────────────────────────┐     │
│  │  Pipeline de Producción                            │     │
│  │  1. Parse input → extract assets                   │     │
│  │  2. Generate scenes → image/video per scene        │     │
│  │  3. Compose → transitions, music, voiceover        │     │
│  │  4. Render → MP4 con subtítulos opcionales         │     │
│  └────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## Flujo de Trabajo

### 1. Input (múltiples fuentes)
- **Script de contenido:** Texto plano con marcas de tiempo [0:00], [0:05]
- **Post/blog existente:** URL o texto → extraer puntos clave
- **Prompt libre:** "Video de 30s sobre beneficios de Willow para abogados"
- **Imágenes:** Carpeta con assets visuales

### 2. Generación de Escenas
- Cada escena = 1 imagen/video generado
- Duración por escena configurable (default: 5s)
- Transiciones entre escenas (fade, slide, zoom)

### 3. Composición
- **Música:** Librería royalty-free o generada
- **Voiceover:** TTS (ElevenLabs, OpenAI) o grabación
- **Subtítulos:** Auto-generados con timestamps
- **Branding:** Logo WS Capital al inicio/final

### 4. Render y Entrega
- Formato: MP4 1080x1920 (vertical) o 1920x1080 (horizontal)
- Duración: 15-90 segundos
- Metadata: título, descripción, hashtags para cada plataforma

## Integraciones

| Servicio | Uso | Estado |
|----------|-----|--------|
| **FAL AI** | Generación de video/image-to-video | ⚠️ Sin balance — verificar antes de usar |
| **Runway ML** | Video generation, green screen | Pendiente config |
| **Pika Labs** | Text-to-video corto | Pendiente config |
| **ElevenLabs** | Voiceover TTS | Configurado en Hermes |
| **OpenAI TTS** | Voiceover alternativo | Configurado |
| **Hermes nativo** | `image_generate`, `text_to_speech` | ✅ Disponible |
| **ffmpeg** | Ensamblaje local | ✅ Instalado |
| **NVIDIA API** | Chat de texto (NO imagen/video) | ✅ Activa para LLM |

## Fallback Strategy: When AI Generation Services Are Unavailable

**Trigger:** FAL AI returns "Exhausted balance", `image_generate` fails, or any video generation API is down.

**Immediate pivot:** Use real user photos + FFmpeg effects instead of waiting for AI generation.

### Why this works:
- Authenticity > AI-perfection for founder-led brands
- No dependency on external API balance
- Faster production cycle
- Aligns with WS Capital's value prop: "liberation to live real moments"

### Technical implementation:
1. Source photos from user's existing library (family, travel, work)
2. Apply FFmpeg filters for stylistic cohesion:
   - Color grading (lut3d, colorbalance)
   - Glitch/scanline effects (geq, drawgrid)
   - Ken Burns zoom/pan (zoompan filter)
   - Text overlays with drawtext
3. Generate typography with PIL/Python when needed
4. Assemble with FFmpeg concat + transitions

### Example FFmpeg command for photo montage with effects:
```bash
ffmpeg -loop 1 -i photo.jpg -vf "zoompan=z='min(zoom+0.0015,1.5)':d=125:s=1920x1080, colorbalance=rs=.2:bs=.2" -t 5 -c:v libx264 photo-scene.mp4
```

### When to use fallback vs. wait:
- **Use fallback immediately if:** Hackathon deadline < 48h, or user has quality real photos
- **Wait for AI if:** Product doesn't exist yet (needs renders), or specific aesthetic is critical
- **Hybrid approach:** Generate 1-2 hero images with NVIDIA API (free tier) + real photos for lifestyle scenes

## Priority de herramientas (ACTUALIZADO 29abr2026):

1. **Primera opción:** Hermes nativo (`image_generate` + `text_to_speech` + ffmpeg)
2. **Segunda opción:** Fal.ai (SOLO si balance confirmado)
3. **NO usar:** OpenCode Go como principal — Cloudflare 403 en WSL
4. **NO usar:** NVIDIA API para imagen/video — no disponible en este entorno
5. **Fallback siempre:** Fotos reales + ffmpeg + PIL/OpenCV

## Estructura del Repo

```
video-machine/
├── maquina/              # Código fuente Python (CLI + Web API)
│   ├── cli.py            # CLI principal (17+ comandos)
│   └── web_api.py        # API REST para integración
├── web/                  # Frontend TypeScript/React
├── pipeline_defs/        # Definiciones de pipelines YAML
│   ├── demo.yaml
│   ├── marketing.yaml
│   └── social.yaml
├── skills/               # Skills de agentes (Markdown)
├── tools/                # Herramientas individuales (8 categorías)
├── docs/                 # Documentación completa
│   ├── cli-reference.md
│   ├── architecture.md
│   └── guia-creadores.md
├── config.yaml           # Configuración central
├── pyproject.toml        # Dependencias Python
└── requirements.txt
```

## Comandos Principales

### Pipelines completos
```bash
# 📱 Social Media — video de celular → Reel/TikTok/Short
maquina social ./video.mp4 --platform tiktok --style hook_first

# 📢 Marketing — imágenes + descripción → video publicitario
maquina marketing --description "Producto XYZ" --images ./img1.jpg --style modern

# 💻 Demo — descripción de software → video demo
maquina demo --description "App de gestión legal" --recording screen
```

### Herramientas individuales
```bash
maquina transcribe ./video.mp4              # Transcripción con timestamps
maquina script --topic "beneficios Willow"  # Generar guion
maquina cut ./video.mp4 --segments "0:5,10:15"  # Corte y concatenación
maquina caption ./video.mp4 --style tiktok  # Subtítulos SRT/ASS/JSON
maquina render ./project/ --format mp4      # Render final FFmpeg
maquina post --platform linkedin            # Generar post para social
```

### Análisis de viralidad (Tribe v2)
```bash
maquina viral_score ./video.mp4             # Score viral general
maquina viral_hook ./video.mp4              # Análisis del hook (7 dimensiones)
maquina viral_arc ./video.mp4               # Arco emocional
maquina viral_ab-test ./video.mp4 --variants 3  # Variantes A/B
maquina viral_segments ./video.mp4          # Scoring por segmentos cerebrales
```

## Instalación

```bash
cd /mnt/c/Users/DELL/Documents/repos/projects/active/video-machine
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pip install openai faster-whisper
cd web && npm install
```

## Configuración de API Keys

Crear `.env` en la raíz:
```
OPENAI_API_KEY=sk-...
ELEVENLABS_API_KEY=...     # opcional
```

## Integraciones

| Servicio | Uso | Estado |
|----------|-----|--------|
| **OpenAI** | Guionización, transcripción | Requiere API key |
| **ElevenLabs** | Voiceover TTS | Opcional |
| **Faster Whisper** | Transcripción local | Instalado |
| **FFmpeg** | Render y post-producción | Requerido |
| **Tribe v2** | Motor de viralidad | Incluido |
| **Cognee** | Memoria persistente | Incluido |

## Relación con Otros Proyectos WS Capital

- **Growth Marketing (`ws-growth-orchestrator`)** → Video-Machine consume briefs de contenido y genera videos para campañas
- **Onyx** → Almacena catálogo de videos, metadatos, y analytics de viralidad
- **Hermes Desktop Assistant** → Trigger rápido "genera video de este post" desde la PC
- **Scrapling (`scrapling-scraper`)** → Extrae contenido de URLs para convertir en scripts de video

## Pendientes para Activar

1. ✅ ~~Clonar repo~~ → **HECHO** (2026-04-24)
2. ✅ ~~Instalar dependencias Python~~ → **HECHO** (2026-04-24)
3. ✅ ~~Instalar dependencias Node.js~~ → **HECHO** (2026-04-24)
4. ⬜ Configurar API keys (OpenAI, ElevenLabs) — opcional para transcribir/guionizar
5. ✅ ~~Verificar FFmpeg~~ → **HECHO** (v6.1.1 disponible)
6. ⬜ Prueba de pipeline `maquina social` con video de prueba
7. ⬜ Integrar con Growth Orchestrator para producción automática
8. ⬜ Conectar con Onyx para almacenar catálogo de videos
