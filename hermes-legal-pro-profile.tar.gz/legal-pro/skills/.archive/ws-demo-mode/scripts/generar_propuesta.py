#!/usr/bin/env python3
"""
Script para generar propuesta PDF desde template HTML.
Uso:
  python generar_propuesta.py --data data.json --output /ruta/salida.pdf

El archivo JSON debe contener:
{
  "nombre_prospecto": "Juan Perez",
  "empresa": "Empresa XYZ",
  "fecha": "25 de Abril, 2026",
  "resumen_ejecutivo": "texto...",
  "situacion_actual": "texto...",
  "dolor_principal": "texto...",
  "objetivos": "texto...",
  "pruebas_realizadas": "HTML de pruebas...",
  "capability_cards": "HTML de cards...",
  "roadmap": "HTML de roadmap..."
}
"""

import argparse
import json
import os
import sys
import subprocess

# Intentar importar weasyprint
try:
    from weasyprint import HTML, CSS
    WEASYPRINT_AVAILABLE = True
except ImportError:
    WEASYPRINT_AVAILABLE = False
    print("WARNING: WeasyPrint no instalado. Intentando instalar...")


def install_weasyprint():
    """Instala weasyprint si no esta disponible."""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "weasyprint", "-q"])
        print("WeasyPrint instalado. Reiniciando...")
        return True
    except Exception as e:
        print(f"Error instalando WeasyPrint: {e}")
        return False


def render_html_template(template_path, data):
    """Remplaza placeholders en el template HTML."""
    with open(template_path, 'r', encoding='utf-8') as f:
        html = f.read()
    
    # Reemplazar todos los placeholders {{KEY}}
    for key, value in data.items():
        placeholder = f"{{{{{key.upper()}}}}}"
        html = html.replace(placeholder, str(value))
    
    return html


def generate_pdf(html_content, output_path):
    """Genera PDF desde HTML usando WeasyPrint."""
    global WEASYPRINT_AVAILABLE
    
    if not WEASYPRINT_AVAILABLE:
        if not install_weasyprint():
            # Fallback: guardar HTML y notificar
            html_path = output_path.replace('.pdf', '.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f"PDF no generado (WeasyPrint no disponible). HTML guardado en: {html_path}")
            return html_path
        
        # Reintentar importar
        try:
            from weasyprint import HTML as WPHTML, CSS
            global HTML
            HTML = WPHTML
            WEASYPRINT_AVAILABLE = True
        except ImportError:
            html_path = output_path.replace('.pdf', '.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f"PDF no generado. HTML guardado en: {html_path}")
            return html_path
    
    from weasyprint import HTML
    HTML(string=html_content).write_pdf(output_path)
    print(f"PDF generado: {output_path}")
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Generar propuesta WS Capital PDF')
    parser.add_argument('--data', required=True, help='Ruta al archivo JSON con datos')
    parser.add_argument('--output', required=True, help='Ruta de salida del PDF')
    parser.add_argument('--template', default=None, help='Ruta al template HTML (opcional)')
    args = parser.parse_args()
    
    # Cargar datos
    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Template por defecto
    if args.template is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        args.template = os.path.join(script_dir, '..', 'templates', 'propuesta-template.html')
    
    # Renderizar HTML
    html_content = render_html_template(args.template, data)
    
    # Generar PDF
    result = generate_pdf(html_content, args.output)
    
    return result


if __name__ == '__main__':
    main()
