#!/usr/bin/env python3
"""
Script para entregar demo: crea carpeta en Drive, sube archivos, comparte.
Uso:
  python entregar_demo.py \
    --prospecto "Juan Perez" \
    --email "juan@email.com" \
    --propuesta "/ruta/propuesta.pdf" \
    --pruebas "/ruta/pruebas/" \
    --pablo-email "pablo@wsc.lat"
"""

import argparse
import os
import sys
import json
from datetime import datetime

# Añadir path para importar skills de Google APIs
sys.path.insert(0, os.path.expanduser('~/.hermes/skills/ws-capital/ws-google-apis-master/scripts'))

try:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    GOOGLE_AVAILABLE = True
except ImportError:
    GOOGLE_AVAILABLE = False
    print("WARNING: Google API client no disponible")


def get_drive_service():
    """Obtiene servicio de Drive autenticado."""
    token_path = os.path.expanduser('~/.hermes/google_token.json')
    if not os.path.exists(token_path):
        token_path = os.path.expanduser('~/.hermes/google_token_extended.json')
    
    creds = Credentials.from_authorized_user_file(token_path)
    return build('drive', 'v3', credentials=creds)


def get_gmail_service():
    """Obtiene servicio de Gmail autenticado."""
    token_path = os.path.expanduser('~/.hermes/google_token.json')
    if not os.path.exists(token_path):
        token_path = os.path.expanduser('~/.hermes/google_token_extended.json')
    
    creds = Credentials.from_authorized_user_file(token_path)
    return build('gmail', 'v1', credentials=creds)


def create_folder(service, name, parent_id=None):
    """Crea carpeta en Drive."""
    metadata = {
        'name': name,
        'mimeType': 'application/vnd.google-apps.folder'
    }
    if parent_id:
        metadata['parents'] = [parent_id]
    
    folder = service.files().create(body=metadata, fields='id,webViewLink').execute()
    return folder


def upload_file(service, file_path, folder_id, name=None):
    """Sube archivo a carpeta de Drive."""
    if name is None:
        name = os.path.basename(file_path)
    
    metadata = {
        'name': name,
        'parents': [folder_id]
    }
    
    media = MediaFileUpload(file_path, resumable=True)
    file = service.files().create(body=metadata, media_body=media, fields='id,webViewLink').execute()
    return file


def share_folder(service, folder_id, email):
    """Comparte carpeta con email."""
    permission = {
        'type': 'user',
        'role': 'reader',
        'emailAddress': email
    }
    service.permissions().create(fileId=folder_id, body=permission).execute()


def send_email(gmail_service, to, subject, body, from_email=None):
    """Envia email via Gmail API."""
    from email.mime.text import MIMEText
    import base64
    
    message = MIMEText(body, 'html')
    message['to'] = to
    message['subject'] = subject
    if from_email:
        message['from'] = from_email
    
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
    
    gmail_service.users().messages().send(
        userId='me',
        body={'raw': raw}
    ).execute()


def main():
    parser = argparse.ArgumentParser(description='Entregar demo WS Capital')
    parser.add_argument('--prospecto', required=True, help='Nombre del prospecto')
    parser.add_argument('--email', required=True, help='Email del prospecto')
    parser.add_argument('--propuesta', required=True, help='Ruta al PDF de propuesta')
    parser.add_argument('--pruebas', default=None, help='Carpeta con archivos de pruebas')
    parser.add_argument('--pablo-email', default='pablo@wsc.lat', help='Email de Pablo')
    args = parser.parse_args()
    
    if not GOOGLE_AVAILABLE:
        print("ERROR: Google API client no disponible. Instalar con:")
        print("pip install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client")
        return 1
    
    fecha = datetime.now().strftime('%Y-%m-%d')
    folder_name = f"WS_Demo_{args.prospecto.replace(' ', '_')}_{fecha}"
    
    print(f"[1/5] Creando carpeta en Drive: {folder_name}")
    drive = get_drive_service()
    folder = create_folder(drive, folder_name)
    folder_id = folder['id']
    folder_link = folder['webViewLink']
    
    print(f"[2/5] Subiendo propuesta...")
    upload_file(drive, args.propuesta, folder_id, f"Propuesta_WS_Capital_{args.prospecto.replace(' ', '_')}.pdf")
    
    if args.pruebas and os.path.isdir(args.pruebas):
        print(f"[3/5] Subiendo archivos de pruebas...")
        for filename in os.listdir(args.pruebas):
            file_path = os.path.join(args.pruebas, filename)
            if os.path.isfile(file_path):
                upload_file(drive, file_path, folder_id)
                print(f"      Subido: {filename}")
    
    print(f"[4/5] Compartiendo carpeta...")
    share_folder(drive, folder_id, args.email)
    share_folder(drive, folder_id, args.pablo_email)
    
    print(f"[5/5] Enviando emails...")
    gmail = get_gmail_service()
    
    # Email al prospecto
    body_prospecto = f"""
    <html>
    <body style="font-family: monospace; background: #f0f0f0; padding: 20px;">
        <div style="max-width: 600px; margin: 0 auto; background: white; border: 2px solid black; padding: 20px;">
            <h2 style="font-family: 'Courier New', monospace;">WS CAPITAL // DEMO COMPLETADA</h2>
            <p>Hola {args.prospecto},</p>
            <p>Gracias por tu tiempo en la sesion de demostracion con Hermes.</p>
            <p>Aqui tienes tu propuesta personalizada y los archivos que generamos juntos:</p>
            <p style="text-align: center; margin: 20px 0;">
                <a href="{folder_link}" style="background: #0000D0; color: white; padding: 10px 20px; text-decoration: none; font-family: monospace;">
                    VER CARPETA DEMO
                </a>
            </p>
            <p>Si tienes preguntas o quieres avanzar, responde a este email.</p>
            <p style="margin-top: 30px; font-size: 0.8rem; color: #666;">
                WS Capital | AI Lab & Venture Capital Hybrid<br>
                wsc.lat
            </p>
        </div>
    </body>
    </html>
    """
    
    send_email(gmail, args.email, f"Tu demostracion WS Capital — {args.prospecto}", body_prospecto)
    
    # Email a Pablo
    body_pablo = f"""
    <html>
    <body style="font-family: monospace;">
        <h2>DEMO COMPLETADA: {args.prospecto}</h2>
        <p><strong>Prospecto:</strong> {args.prospecto}</p>
        <p><strong>Email:</strong> {args.email}</p>
        <p><strong>Fecha:</strong> {fecha}</p>
        <p><strong>Carpeta:</strong> <a href="{folder_link}">{folder_link}</a></p>
        <p>Revisa la carpeta para ver la propuesta y archivos generados.</p>
    </body>
    </html>
    """
    
    send_email(gmail, args.pablo_email, f"[Demo] {args.prospecto} — Carpeta lista", body_pablo)
    
    print(f"\n✅ Demo entregada exitosamente!")
    print(f"   Carpeta: {folder_link}")
    print(f"   Prospecto: {args.email}")
    print(f"   Pablo: {args.pablo_email}")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
