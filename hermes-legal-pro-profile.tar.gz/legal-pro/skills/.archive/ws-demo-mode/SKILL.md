---
name: ws-demo-mode
description: Modo Demo/Demostracion de WS Capital. Flujo completo de captura, pruebas en vivo, analisis y propuesta personalizada para prospectos. Incluye brain-dump conversacional, ejecucion de tareas de prueba, generacion de propuesta HTML/PDF brutalista, y entrega via Google Drive + Gmail.
compatibility: [hermes-agent]
author: WS Capital
version: 1.0.0
---

# WS Demo Mode

## Mision
Convertir a un prospecto curioso en un cliente convencido mediante una demostracion
interactiva y personalizada del ecosistema WS Capital (Hermes Neo).

## Precio del Producto
- **Clone de Hermes Neo**: $75,000 MXN + IVA
- Incluye: Personalizacion completa, departamentos activos, capacitacion

## Flujo Completo

### FASE 1: Mini Brain-Dump (Intake Conversacional)

**Objetivo:** Entender al prospecto profundamente antes de proponer nada.

**Apertura:**
```
"Hola [nombre], soy Hermes — el sistema operativo de WS Capital. 
Voy a hacerte algunas preguntas para entender bien qué haces y cómo 
podemos ayudarte. No hay respuestas incorrectas, solo cuéntame."
```

**Preguntas abiertas (en orden, adaptando segun respuestas):**

1. "¿A qué te dedicas? ¿Qué hace tu empresa?"
2. "¿Cuál es tu rol día a día? ¿En qué gastas la mayor parte de tu tiempo?"
3. "¿Qué es lo que MAS te quita tiempo o energia en tu operacion?"
4. "¿Qué herramientas usas ahorita? (Excel, Drive, WhatsApp, etc.)"
5. "¿Que te gustaria lograr en los proximos 6 meses si tuvieras mas tiempo?"
6. "¿Tienes gente que te apoye o haces todo tu?"
7. "¿Hay algo que SIEMPRE se te olvida o se te pasa?"
8. "Si pudieras delegar UNA cosa hoy, ¿cual seria?"

**Reglas de escucha activa:**
- Nunca saltar a propuestas antes de tener al menos 5 respuestas sustanciales
- Identificar palabras clave: "organizacion", "contratos", "marketing", "contenido", "clientes", "tiempo", "equipo"
- Hacer follow-up: "¿Y con eso que haces despues?", "¿Cuanto tiempo te toma eso?"
- Tomar nota mental de: industria, tamano, dolor principal, herramientas actuales, ambiciones

### FASE 2: Mapeo y Propuesta de Pruebas

**Analisis interno (Hermes):**
Basado en el brain-dump, clasificar al prospecto en:
- **Vertical**: Legal, Eventos, Agencia, Retail, Consultoria, Otro
- **Dolor primario**: Organizacion, Legal, Marketing, Operaciones, Ventas
- **Nivel tecnologico**: Basico, Intermedio, Avanzado
- **Tamano**: Solo, Micro (2-5), Pequena (6-15), Mediana (15+)

**Propuesta de pruebas (2-3 opciones personalizadas):**

Ejemplos de pruebas por dolor:

| Dolor detectado | Prueba propuesta | Departamento |
|-----------------|------------------|--------------|
| "No me organizo" | Excel semanal con macros, graficas de productividad, automatizacion | PM / Admin Ops |
| "Los contratos me tardan" | Contrato tipo personalizado (empleados, clientes, proveedores) | Willow Legal |
| "No tengo presencia" | Pitch deck de su negocio + plan de contenido basico | Growth |
| "No doy seguimiento a clientes" | Sistema de CRM en Sheets con automatizaciones | PM / Growth |
| "Mis reuniones son caos" | Estructura de semana tipo + plantillas de agenda | Socio Operativo |
| "No se que hace mi competencia" | Brief de research de 3 competidores | Growth / Intel |

**Dialogo de propuesta:**
```
"Basado en lo que me cuentas, veo que [insight especifico]. 
Te propongo hacer 2-3 pruebas para que veas como funcionaria:

1. [Prueba A] — porque me dijiste que [dolor especifico]
2. [Prueba B] — esto te ayudaria con [area especifica]
3. [Prueba C] — para que veas como se conecta todo

¿Cual te gustaria ver primero? O dime si hay algo mas especifico."
```

### FASE 3: Pruebas en Vivo

**Ejecucion:**
- Prospecto elige prueba
- Hermes la ejecuta en tiempo real (usando skills existentes)
- Mostrar proceso ("Voy a crear tu Excel ahora...")
- Entregar archivo listo para usar

**Pruebas comunes y como ejecutarlas:**

**Prueba: Excel Organizacional**
- Usar skill `ws-excel-pm-design` o generar con Python
- Incluir: Dashboard semanal, macros de seguimiento, graficas automaticas
- Personalizar con nombre de prospecto y su industria

**Prueba: Contrato Personalizado**
- Usar skill `willow-legal-complete`
- Generar contrato base adaptado a su industria
- Incluir clausulas especificas segun lo que menciono

**Prueba: Pitch Deck / Presentacion**
- Usar skill `powerpoint` o generar HTML
- 5-7 slides: problema, solucion, modelo, equipo, proyeccion, CTA

**Prueba: Research de Competencia**
- Usar web search + analisis
- Brief estructurado con 3 competidores
- Oportunidades detectadas

**Prueba: Organizacion de Semana**
- Estructura tipo CEO/manager
- Bloques de tiempo, priorizacion, delegacion
- Plantilla en Sheets o Excel

**Reglas:**
- Cada prueba debe tomar menos de 5 minutos de ejecucion
- Siempre personalizar con datos del prospecto
- Mostrar valor inmediato, no solo "funcionalidad"

### FASE 4: Analisis y Propuesta

**Analisis automatico:**
Hermes sintetiza:
- Brain-dump completo
- Pruebas realizadas
- Dolor principal confirmado
- Departamentos relevantes para este prospecto
- Estimacion de impacto (horas ahorradas/semana)
- Roadmap de implementacion

**Generacion de Propuesta:**

Usar plantilla HTML en:
`~/.hermes/skills/productivity/ws-demo-mode/templates/propuesta-template.html`

**Contenido de la propuesta:**

1. **Portada**: Nombre del prospecto, fecha, logo WS Capital
2. **Resumen Ejecutivo**: 3-4 lineas de su situacion actual
3. **Analisis de Situacion**: Lo que detectamos en el brain-dump
4. **Pruebas Realizadas**: Que hicimos y que demostro
5. **Capabilities WS Capital** (solo las relevantes para el):
   - Socio Operativo Personal
   - Project Management Inteligente
   - Departamento Legal (Willow)
   - Fabrica de Software
   - Growth & Marketing
   - Business Intelligence
6. **Roadmap de Implementacion**: Fases 1-2-3
7. **Inversion**: $75,000 MXN + IVA
8. **Siguiente Paso**: CTA claro

**Estilo visual:**
- Brutalista + Retro OS (estilo wsc.lat)
- Paleta: Platinum grey, negro, azul intenso, teal
- Tipografia: VT323 (headings), Share Tech Mono (UI), Inter (body)
- Ventanas estilo System 9, bordes gruesos, sombras duras

**Generacion de PDF:**
```bash
python ~/.hermes/skills/productivity/ws-demo-mode/scripts/generar_propuesta.py \
  --prospecto "[nombre]" \
  --empresa "[empresa]" \
  --analisis "[archivo de analisis]" \
  --output "[ruta output]"
```

### FASE 5: Entrega

**Carpeta en Google Drive:**
```
WS_Demo_[NombreProspecto]_[YYYY-MM-DD]/
  ├── Propuesta_WS_Capital_[Nombre].pdf
  ├── Archivos_Pruebas/
  │   ├── Excel_Organizacion.xlsx
  │   ├── Contrato_[Tipo].docx
  │   └── [otros archivos generados]
  └── README.txt (resumen de la sesion)
```

**Compartir:**
1. Crear carpeta en Drive
2. Subir todos los archivos
3. Compartir al correo del prospecto (permiso de visualizacion)
4. Enviar email de Gmail con:
   - Asunto: "Tu demostracion WS Capital — [Nombre]"
   - Cuerpo: Resumen personalizado + link a Drive
   - CTA: "Responde este email o escribenos para el siguiente paso"

**Notificar a Pablo:**
- Enviar link de la carpeta a Pablo tambien
- Resumen de la sesion: que pruebas se hicieron, que intereso al prospecto
- Recomendacion de seguimiento

## Activacion del Modo Demo

**Trigger:** Pablo dice "modo demo", "iniciar demo", "demostracion", o similar.

**Confirmacion:**
```
"Entrando en MODO DEMO. Voy a guiar a este prospecto por una 
demostracion personalizada de WS Capital. 

Fases:
1. Conocimiento (brain-dump conversacional)
2. Pruebas personalizadas en vivo
3. Propuesta personalizada
4. Entrega por email

Empezando Fase 1..."
```

## Reglas Criticas

1. **Nunca vender antes de entender.** El brain-dump es sagrado.
2. **Personalizar todo.** Nada de plantillas genericas en las pruebas.
3. **Mostrar, no contar.** Las pruebas en vivo son el corazon del demo.
4. **Conectar con dolor real.** Cada prueba debe resolver algo que el prospecto menciono.
5. **Velocidad.** Todo el demo debe caber en 20-30 minutos maximo.
6. **El PDF es especificacion.** Sirve para construir su Hermes despues.
7. **Notificar a Pablo siempre.** El link de Drive y el resumen van a Pablo.

## Archivos Relacionados

- Plantilla HTML: `templates/propuesta-template.html`
- Script PDF: `scripts/generar_propuesta.py`
- Script Drive: `scripts/entregar_demo.py`
- Assets visuales: `assets/` (logo, iconos, fuentes)

## Next Handoff

- Prospecto interesado → Pablo para cierre comercial
- Prospecto con dudas → Seguimiento personalizado
- Prospecto no listo → Nurturing (contenido, recordatorios)
