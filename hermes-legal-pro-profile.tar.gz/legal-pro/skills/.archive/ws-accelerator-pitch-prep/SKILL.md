---
name: ws-accelerator-pitch-prep
description: Prepare and structure startup accelerator applications (YC, EF, etc.) including research, narrative framing, pitch vault creation, and founder interview frameworks.
triggers:
  - Apply to Y Combinator
  - Apply to Entrepreneur First
  - Pitch deck for investors
  - Accelerator application
  - Startup fundraising prep
  - YC interview prep
---

# WS Accelerator Pitch Preparation

Prepare a winning accelerator application by researching the program, mapping the business model to their criteria, and creating a structured pitch vault.

## Trigger
User wants to apply to Y Combinator, Entrepreneur First, or similar accelerators.

## Step 1: Research the Program(s)

### Primary sources (avoid generic search summaries):
1. **YC:** Scrape `ycombinator.com/apply`, `/faq`, `/rfs` directly
2. **EF:** Scrape `joinef.com`, `/what-we-look-for/`, `/locations/`
3. **Other:** Always go to the official application page first

### Key data to extract:
- Current batch name and deadline
- Decision timeline
- Investment terms
- Location requirements (in-person vs hybrid)
- What they explicitly look for (FAQ, RFS)

### Method:
- Subagents often fail to return structured web data. **Use `curl` directly** to scrape official pages.
- Look for JSON data embedded in React apps (YC pages often have page data in `data-page` attributes).
- Parse `<meta name="description">` and OG tags for official positioning.

## Step 2: Map Business Model to Program Fit

### Critical insight: Check YC's "Requests for Startups" (RFS)
- If the business matches an RFS category, that's the **primary angle**.
- Example: WS Capital (AI-powered agency builder) matched YC Spring 2026 RFS "AI-Native Agencies" — this reframes the entire pitch.

### YC vs EF comparison matrix:

| Dimension | YC | EF |
|---|---|---|
| Prerequisite | Company/team/idea formed | Individual talent |
| Cofounder | Already have one | Help you find one |
| Focus | Company acceleration | Talent-first matching |
| Location | San Francisco | Multiple hubs (SG, UK, etc.) |
| Fit signal | Revenue, users, growth | Potential, exceptionalism |

## Step 3: Create Pitch Vault in Obsidian

Create a structured vault at `Documents/WS Capital/Pitch Vault/`:

```
Pitch Vault/
├── 00_Index.md
├── 01_Programas/
│   ├── Y Combinator.md
│   └── Entrepreneur First.md
├── 02_Nuestra Empresa/
│   ├── Narrativa.md
│   ├── Métricas y Tracción.md
│   ├── Equipo.md
│   └── Ventaja Competitiva.md
├── 03_Pitch Deck/
│   ├── Estructura Pitch Deck.md
│   ├── One Liner.md
│   └── Story Arc.md
├── 04_Preguntas Clave/
│   ├── Preguntas para Founder.md
│   └── Preguntas Interview.md
├── 05_Video Pitch/
│   ├── Script.md
│   └── Setup.md
└── 99_Archivo/
    └── Links útiles.md
```

Use Obsidian wikilinks (`[[Note Name]]`) to interlink.

## Step 4: Generate Founder Interview Questions

Create `04_Preguntas Clave/Preguntas para Founder.md` with 8 blocks:

1. **La Gran Promesa** — One-liner, problem, why now
2. **El Modelo** — Revenue model, current numbers, margins, ticket
3. **Tracción** — Users, growth, retention, LOIs, "wow metric"
4. **El Equipo** — Founders, backgrounds, why this team wins
5. **El Mercado** — TAM, beachhead, defensibility
6. **El Producto** — 30-sec pitch for each product, service vs software split
7. **La Visión** — 10-year picture, company #3, scale machine
8. **Logística** — Which program, willing to relocate, video ready

## Step 5: Build Interview Prep Doc

Create `04_Preguntas Clave/Preguntas Interview.md` with the 10 most common YC questions:

1. What does your company do? (10 words max)
2. How many users do you have? (exact number)
3. How do you know people want this? (customer story)
4. Who are your competitors? (name 2-3, show market knowledge)
5. How will you make money? (clear model)
6. Why you? (domain expertise)
7. How will you get users? (specific channel)
8. What's the hardest thing you've faced? (resilience story)
9. Why now? (market timing)
10. What do you need from us? (specific ask, not "money")

## Step 6: Pitch Deck Structure (10 Slides)

1. Title / One Liner
2. The Problem
3. The Solution
4. The Product (screenshots, demos)
5. Traction (most important slide)
6. Market Size (TAM/SAM/SOM)
7. Business Model (unit economics)
8. Competition + Why We Win
9. Team
10. The Ask (runway, milestones)

## Pitfalls

- **Don't inflate numbers.** YC partners follow up immediately. One lie kills the application.
- **Don't say "no competition."** That signals ignorance.
- **Don't use subagents for structured web data.** They often return summaries without the specific deadlines/terms you need. Scrape directly.
- **Don't skip the video.** YC requires a 1-minute founder video. It doesn't need to be professional — authentic > polished.
- **Don't apply solo if you need a cofounder.** EF may be a better fit than YC for single founders.

## Verification Checklist

- [ ] Deadlines confirmed from official site
- [ ] RFS alignment checked
- [ ] Vault created with all sections
- [ ] Founder questions delivered
- [ ] Interview questions documented
- [ ] Pitch deck structure ready
- [ ] Video script drafted
- [ ] Application submitted before deadline

## Resources
- YC Apply: https://apply.ycombinator.com/home
- YC RFS: https://www.ycombinator.com/rfs
- YC FAQ: https://www.ycombinator.com/faq
- EF Apply: https://apply.joinef.com
