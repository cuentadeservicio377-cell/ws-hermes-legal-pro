---
name: admin-ops-brain-dump
description: "Brain-dump de pendientes, tareas sueltas y recordatorios semanales para Admin & Ops. Captura el caos de la cabeza de Pablo y lo convierte en tareas, ideas o proyectos estructurados en el Excel de PM."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [brain-dump, admin-ops, pendientes, weekly, pm, tasks]
---

# Admin & Ops Brain-Dump

Use this skill when Pablo quiere hacer un brain-dump de **pendientes, tareas sueltas, recordatorios o ideas operativas** de la semana. También cuando llega el cron de domingo en la noche y Pablo dice "esto es lo que tengo en la cabeza".

## Goal

Convertir el caos mental semanal en:
- Tareas concretas en el Excel de PM
- Ideas capturadas para evaluación
- Proyectos nuevos si el pendiente es grande
- Recordatorios programados

## Trigger phrases

- "tengo en la cabeza..."
- "esto es lo que necesito hacer..."
- "mis pendientes de la semana..."
- "brain dump"
- "recordatorio"
- "no me olvido de..."
- "tengo que..."
- "necesito que..."

## Working method

### Paso 1: Escuchar sin filtrar
Dejar que Pablo suelte TODO. No interrumpir. No estructurar todavía.

### Paso 2: Clasificar cada item
Cada pendiente cae en una de estas categorías:

| Tipo | Ejemplo | Destino en Excel |
|------|---------|------------------|
| **Tarea puntual** | "Llamar al contador" | Tabla `Tareas` → Proyecto "Operaciones Semanales" |
| **Idea nueva** | "Podríamos ofrecer servicio X" | Tabla `Ideas` → estado "Capturada" |
| **Proyecto** | "Rehacer el website" | Tabla `Proyectos` → estado "Backlog" |
| **Recordatorio recurrente** | "Cada viernes revisar métricas" | Tabla `Áreas_Actividades` o cron job |
| **Handoff** | "Necesito que Build haga X" | Tabla `Handoffs` |
| **Información** | "El cliente dijo Y" | Tabla `Notas` o nota en Vault |

### Paso 3: Estructurar y confirmar

Presentar a Pablo:
```
🧠 Brain-dump capturado — X items

📋 Tareas (van a Tareas):
• [ ] Llamar al contador → Deadline: ?
• [ ] Revisar contrato Paola → Deadline: ?

💡 Ideas (van a Ideas):
• Ofrecer servicio X → Growth

🚀 Proyectos (van a Proyectos):
• Rehacer website → Fábrica de Software

🔄 Handoffs:
• Build: Necesito feature Y

⏰ Recordatorios:
• Cada viernes: revisar métricas

¿Confirmas? ¿Algún deadline o responsable que ajustar?
```

### Paso 4: Escribir en Excel

Usar `pm_reader.py` para:
- Agregar tareas con `agregar_tarea()`
- Agregar ideas con `agregar_idea()`
- Agregar proyectos con `agregar_proyecto()`
- Agregar handoffs con `registrar_handoff()`

#### Patrón: Proyecto contenedor "Brain-Dump Semanal"

Las tareas del brain-dump no se sueltan sueltas. Van ligadas a un proyecto contenedor llamado **"Brain-Dump Semanal"** en la tabla `Proyectos`. Esto evita que las tareas sueltas contaminen la lista de proyectos reales, pero sigue trackeándose en el sistema.

```python
# En pm_reader.py, la función capturar_brain_dump() busca o crea:
# Proyecto "Brain-Dump Semanal" → todas las tareas del dump van ahí
```

### Paso 5: Programar recordatorios

Si Pablo dijo "recuérdame el martes" o "cada viernes", crear cron job o nota.

## Dominguero: Recordatorio de pendientes

Cada domingo en la noche, Hermes envía:

```
🌙 Domingo de brain-dump

Esta semana tienes:
• 5 tareas pendientes
• 2 proyectos activos
• 1 handoff bloqueado

¿Qué tienes en la cabeza para esta semana?
Dime todo: pendientes, preocupaciones, ideas, recordatorios...
Yo lo estructuro.
```

## Output format

### Para cada brain-dump:

```
### 🧠 Brain-dump capturado — [fecha]

**Items totales:** X

#### 📋 Tareas → Excel/Tareas
| # | Pendiente | Área | Deadline |
|---|-----------|------|----------|
| 1 | ... | ... | ... |

#### 💡 Ideas → Excel/Ideas
| # | Idea | Depto |
|---|------|-------|
| 1 | ... | ... |

#### 🚀 Proyectos → Excel/Proyectos
| # | Proyecto | Depto |
|---|----------|-------|
| 1 | ... | ... |

#### 🔄 Handoffs → Excel/Handoffs
| # | De | Para | Qué |
|---|----|------|-----|
| 1 | ... | ... | ... |

#### ⏰ Recordatorios
• ...

**¿Algo más? ¿Confirmamos?**
```

## Rules

- No perder ni un item del brain-dump. Todo se captura.
- Si no está claro si es tarea o idea, preguntar una sola vez.
- Los deadlines son importantes: si Pablo no dice uno, preguntar.
- Si una tarea es "urgente" o "importante", marcar prioridad Alta.
- El brain-dump de domingo es un ritual. No saltarlo.
- Después del dominguero, generar resumen para la semana.

## Cron schedule

- **Domingo 9:00 PM:** "¿Qué tienes en la cabeza para esta semana?"
- **Lunes 8:00 AM:** Resumen de la semana + pendientes del brain-dump
- **Viernes 6:00 PM:** "¿Cumpliste tus pendientes? ¿Qué queda?"
