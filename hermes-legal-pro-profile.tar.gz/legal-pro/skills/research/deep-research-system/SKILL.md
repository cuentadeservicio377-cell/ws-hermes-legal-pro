# DEEP RESEARCH SYSTEM — ORQUESTACIÓN EUGEN SWARMS
## WS Capital | 28 Abril 2026
## Skill de orquestación para investigación profunda

---

## 🎯 PROPÓSITO

Orquestar investigaciones de mercado, competencia y análisis profundo usando múltiples agentes en paralelo. No es solo buscar en web — es investigación estructurada con múltiples fuentes, análisis cruzado, y reporte accionable.

---

## 🤖 AGENTES DEL SISTEMA

**Motor de subagentes:** OpenAI Codex (gpt-5.3-codex) vía Copilot ACP
**Máximo concurrente:** 3 agentes
**Comando ACP:** `copilot`

### Agente 1: Investigador Web (Principal)
**Función:** Búsqueda general, fuentes primarias
**Tools:** web, browser, search
**Skills:** ws-market-researcher
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Buscar en Google, Bing, DuckDuckGo
- Extraer datos de sitios oficiales
- Identificar competidores directos e indirectos
- Buscar reviews, foros, Reddit

### Agente 2: Analista de Datos (Secundario)
**Función:** Análisis numérico, tendencias, métricas
**Tools:** web, search, file
**Skills:** ws-market-researcher
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Buscar datos de mercado (TAM, SAM, SOM)
- Extraer precios, pricing de competidores
- Identificar métricas clave del sector
- Buscar reportes de industria

### Agente 3: Analista de Sentimiento (Secundario)
**Función:** Opinión pública, dolor del cliente, reviews
**Tools:** web, browser, search
**Skills:** ws-market-researcher
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Buscar en Reddit, Twitter/X, foros
- Extraer quejas y pain points
- Identificar deseos no satisfechos
- Buscar testimonios y case studies

### Agente 4: Síntesis y Reporte (Orquestador)
**Función:** Consolidar hallazgos, generar reporte estructurado
**Tools:** file, skills
**Skills:** ws-content-drafter
**Modelo:** gpt-5.3-codex @ openai-codex
**Instrucciones:**
- Usar `delegate_task` con `acp_command="copilot"`
- Recibir hallazgos de los 3 agentes
- Cruzar información y validar
- Identificar patrones y oportunidades
- Generar reporte con:
  - Resumen ejecutivo
  - Hallazgos clave
  - Datos de mercado
  - Análisis de competencia
  - Oportunidades identificadas
  - Recomendaciones accionables
  - Fuentes citadas

---

## 📋 FLUJO DE TRABAJO

```
Entrada: "Investiga el mercado de [X] en México"
    ↓
Orquestador (Agente 4) recibe la tarea
    ↓
Descompone en 3 subtareas paralelas:
    ├─ Agente 1: "Busca competidores de [X] en México"
    ├─ Agente 2: "Busca datos de mercado de [X]"
    └─ Agente 3: "Busca opiniones de clientes sobre [X]"
    ↓
3 agentes trabajan en paralelo (max_concurrent_children: 3)
    ↓
Orquestador recibe resultados
    ↓
Síntesis:
    ├─ Validar datos cruzados
    ├─ Identificar inconsistencias
    ├─ Extraer insights
    └─ Generar reporte
    ↓
Salida: Reporte estructurado + fuentes + recomendaciones
```

---

## 📝 FORMATO DE REPORTE

```markdown
# Research Report: [Tema]
## Fecha: [Fecha]
## Agente: Hermes Neo — Deep Research System

### 1. Resumen Ejecutivo
[2-3 párrafos con los hallazgos más importantes]

### 2. Mercado
- TAM: [Total Addressable Market]
- SAM: [Serviceable Addressable Market]
- SOM: [Serviceable Obtainable Market]
- CAGR: [Compound Annual Growth Rate]
- Tendencias: [3-5 tendencias clave]

### 3. Competencia
| Competidor | Producto | Precio | Fortaleza | Debilidad |
|------------|----------|--------|-----------|-----------|
| [Nombre] | [Desc] | [Precio] | [Fort] | [Deb] |

### 4. Opinión del Cliente
- Pain points: [Lista]
- Deseos no satisfechos: [Lista]
- Sentimiento general: [Positivo/Negativo/Neutro]

### 5. Oportunidades
1. [Oportunidad 1]
2. [Oportunidad 2]
3. [Oportunidad 3]

### 6. Recomendaciones
1. [Recomendación 1]
2. [Recomendación 2]
3. [Recomendación 3]

### 7. Fuentes
- [Fuente 1]
- [Fuente 2]
- [Fuente 3]

### 8. Próximos Pasos
- [Paso 1]
- [Paso 2]
```

---

## ⚙️ CONFIGURACIÓN TÉCNICA

### Para usar este sistema:

1. **Cargar skill:** `skill_view("deep-research-system")`
2. **Delegar:** `delegate_task` con los 3 agentes
3. **Tiempo estimado:** 5-10 minutos por investigación
4. **Costo:** Usa NVIDIA para simples, Kimi/OpenCode para complejos

### Parámetros:
- **max_iterations:** 50 (por agente)
- **timeout:** 300 segundos (por agente)
- **max_concurrent_children:** 3
- **modelo orquestador:** kimi-for-coding
- **modelo agentes:** nvidia/deepseek-v4-pro (económico)

---

## 🎯 EJEMPLOS DE USO

### Ejemplo 1: "Investiga el mercado de wedding planners en CDMX"
- Agente 1: Busca wedding planners en CDMX (lista, precios, servicios)
- Agente 2: Busca datos de mercado de bodas en México (gasto promedio, tendencias)
- Agente 3: Busca opiniones de novias en Reddit/foros (qué les gusta, qué odian)

### Ejemplo 2: "Investiga competidores de Willow Legal"
- Agente 1: Busca firmas legales tech en México (Legalio, Lexly, etc.)
- Agente 2: Busca datos de mercado legal tech en LATAM
- Agente 3: Busca opiniones de abogados sobre automatización

### Ejemplo 3: "Investiga oportunidades de contenido para Paola Meneses"
- Agente 1: Busca influencers de wedding en México (seguidores, engagement)
- Agente 2: Busca tendencias de contenido wedding 2026
- Agente 3: Busca qué buscan las novias en Google/tendencias

---

## 🔧 INTEGRACIÓN CON WS CAPITAL

### Conexiones:
- **Growth Marketing:** Alimenta ws-campaign-planner y ws-content-drafter
- **Ventas:** Genera inteligencia para propuestas y demos
- **Build:** Identifica oportunidades de producto
- **Admin:** Guarda reportes en Excel PM y Obsidian

### Automatización:
- **Cron:** Investigar mercado semanalmente (domingos 10AM)
- **Trigger:** Cuando Pablo mencione "investiga", "research", "mercado"
- **Output:** Reporte guardado en Obsidian + alerta en Telegram

---

## 📁 ARCHIVOS

- **Skill:** `~/.hermes/skills/research/deep-research-system/SKILL.md`
- **Template:** `~/.hermes/skills/research/deep-research-system/templates/report.md`
- **Scripts:** `~/.hermes/skills/research/deep-research-system/scripts/orchestrator.py`

---

*Deep Research System — Eugen Swarms para WS Capital*
*Investigación profunda, estructurada, accionable.*
