# scrapling-scraper

**Hermes Agent skill** para web scraping con bypass anti-bot automático usando [Scrapling](https://github.com/D4Vinci/Scrapling).

Úsala cuando `requests` o `httpx` fallan con 403, cuando el sitio tiene Cloudflare o WAF, o cuando necesitás scrape de MercadoLibre y sitios similares.

---

## ¿Qué hace?

- Selecciona automáticamente el fetcher correcto según el sitio (`Fetcher`, `StealthyFetcher`, `DynamicFetcher`)
- Bypasea anti-bot, Cloudflare Turnstile y WAFs sin configuración extra
- Extrae datos con selectores CSS/XPath
- Incluye lógica de fuzzy matching para búsquedas con similitud
- Descarga imágenes en bulk desde resultados de scraping
- Reintenta con query alternativa cuando el score de match es bajo

Casos de uso probados:
- Búsqueda de productos en **MercadoLibre Argentina** con extracción de título, imagen y URL
- Descarga masiva de imágenes de productos con nomenclatura por SKU
- Reintento automático sin marca cuando el match inicial es insuficiente

---

## Instalación

### 1. Instalar Scrapling en tu entorno

```bash
pip install "scrapling[fetchers]"
scrapling install   # descarga browsers (solo primera vez, ~2 min)
```

> ⚠️ El paso `scrapling install` es obligatorio. Sin él el script falla con un mensaje de Playwright pidiendo que lo ejecutes.

### 2. Instalar la skill en Hermes

```bash
# Clonar el repo
git clone https://github.com/gabogabucho/scrapling-skill.git

# Copiar al directorio de skills de Hermes
cp -r scrapling-skill ~/.hermes/skills/web/scrapling-scraper
```

O instalá directo desde GitHub con el CLI de Hermes:

```bash
hermes skills install gabogabucho/scrapling-skill
```

---

## Uso

Una vez instalada, podés invocarla desde el chat de Hermes:

```
/scrapling-scraper buscar imagen de horno electrico 30 litros en mercadolibre
```

O simplemente describí el problema — Hermes la activa automáticamente cuando detecta un 403 o bloqueo anti-bot:

```
Necesito hacer scraping de mercadolibre pero me da 403
```

---

## Errores conocidos y soluciones

Estos errores los encontramos durante el desarrollo. Si los ves, acá está el fix:

### ❌ `TypeError: 'StealthyFetcher' object does not support the context manager protocol`

**Causa:** En v0.4.x ya no se puede usar `with StealthyFetcher() as fetcher`.

**Fix:** Usar llamada estática directa:

```python
# ✗ MAL — no funciona en v0.4.x
with StealthyFetcher(headless=True) as fetcher:
    page = fetcher.fetch(url)

# ✓ BIEN
page = StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ❌ `ValueError: Unknown parser argument: "headless"; maybe you meant ('huge_tree', 'adaptive', ...)`

**Causa:** `headless` no va en `configure()` — ese método es solo para opciones del parser.

**Fix:** Mover `headless=True` dentro del `.fetch()`:

```python
# ✗ MAL
StealthyFetcher.configure(headless=True)
StealthyFetcher.fetch(url)

# ✓ BIEN
StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ❌ `[WARNING] This logic is deprecated now, and have no effect; It will be removed with v0.3.`

**Causa:** Llamar `StealthyFetcher(headless=True)` como constructor.

**Fix:** Igual que arriba — `headless` va en `.fetch()`.

---

### ❌ Browser not found / mensaje de Playwright pidiendo instalar

**Causa:** `scrapling install` no fue ejecutado.

**Fix:**
```bash
scrapling install
# o alternativamente:
playwright install
```

---

### ❌ 403 en MercadoLibre usando la API pública (`api.mercadolibre.com`)

**Causa:** La API REST de ML bloquea requests sin token o user-agent válido.

**Fix:** Usar scraping de la página de búsqueda directamente en lugar de la API:

```python
# ✗ MAL — API pública da 403 sin autenticación
requests.get("https://api.mercadolibre.com/sites/MLA/search?q=horno")

# ✓ BIEN — scraping de la página con StealthyFetcher
url = f"https://listado.mercadolibre.com.ar/{quote_plus(query)}"
page = StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ⚠️ Imágenes vacías o URLs rotas en MercadoLibre

**Causa:** ML usa lazy-load — la URL real de la imagen está en `data-src`, no en `src`.

**Fix:**

```python
img_url = img_el[0].attrib.get('data-src') or img_el[0].attrib.get('src', '')
```

Para subir la resolución del thumbnail:

```python
import re
img_url = re.sub(r'-[A-Z]\.(?:jpg|webp|png)', '-O.jpg', img_url)
```

---

### ⚠️ Conflicto de dependencias con CrewAI (`click` version mismatch)

**Causa:** CrewAI requiere `click~=8.1.7` pero Scrapling instala una versión más nueva.

**Impacto:** Ninguno — es un warning, no un error. Scrapling funciona igual.

**Fix:** Ignorar el warning. Si CrewAI falla por esto en otro momento, resolverlo por separado con un virtualenv.

---

## Estructura de la skill

```
scrapling-scraper/
├── SKILL.md                    # Definición principal (frontmatter + procedimiento)
├── README.md                   # Este archivo
├── references/
│   └── api-quick-ref.md        # Referencia rápida de selectores CSS/XPath y errores
└── templates/
    └── scraper_template.py     # Script base reutilizable para nuevos proyectos
```

---

## Versión de Scrapling probada

`v0.4.1` — las instrucciones y errores documentados corresponden a esta versión. Si actualizás Scrapling, revisá los breaking changes en el [CHANGELOG](https://github.com/D4Vinci/Scrapling/releases).

---

## Autor

Creado por [@gabogabucho](https://twitter.com/gabogabucho)

---

## Licencia

MIT License

Copyright (c) 2026 Gabriel Urrutia (@gabogabucho)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
