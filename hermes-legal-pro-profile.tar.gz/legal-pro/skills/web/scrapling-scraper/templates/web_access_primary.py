"""
web_access_primary.py
----------------------
Orquestador de acceso web para Hermes. Scrapling es el método PRINCIPAL.
Uso: from web_access_primary import fetch_page, search_and_scrape

Lógica:
  1. StealthyFetcher (con adaptive=True + Cookie Vault) como default
  2. Si falla después de 2 intentos → fallback a browser_navigate
  3. Para búsquedas generales sin URL → search toolset

Cookie Vault activado por defecto en: ~/.hermes/scrapling_storage/vault.db
"""

import os
import time
from typing import Optional, List, Dict, Any
from urllib.parse import quote_plus
from scrapling.fetchers import Fetcher, StealthyFetcher, DynamicFetcher
from scrapling.core.storage import SQLiteStorageSystem

# ─── CONFIGURACIÓN GLOBAL ────────────────────────────────────
VAULT_PATH = os.path.expanduser("~/.hermes/scrapling_storage/vault.db")
os.makedirs(os.path.dirname(VAULT_PATH), exist_ok=True)

# Activar adaptive + Cookie Vault
StealthyFetcher.adaptive = True
StealthyFetcher.storage = SQLiteStorageSystem
StealthyFetcher.storage_args = {"storage_file": VAULT_PATH}

print(f"[web_access_primary] Cookie Vault activado: {VAULT_PATH}")


def fetch_page(
    url: str,
    method: str = "auto",  # "auto", "stealthy", "dynamic", "fast"
    headless: bool = True,
    timeout: int = 60000,
    retries: int = 2,
    pause: float = 2.0,
) -> Optional[Any]:
    """
    Fetch una página web. Scrapling como método principal.
    
    Args:
        url: URL a fetch
        method: "auto" detecta, "stealthy" para anti-bot, "dynamic" para SPA, "fast" para estático
        headless: Si True, corre browser invisible
        timeout: Timeout en ms
        retries: Intentos antes de rendirse
        pause: Segundos entre reintentos
    
    Returns:
        Response object de Scrapling, o None si falla todo.
    """
    
    fetcher_map = {
        "fast": Fetcher,
        "stealthy": StealthyFetcher,
        "dynamic": DynamicFetcher,
    }
    
    # Auto-detect: default a StealthyFetcher (funciona en casi todo)
    if method == "auto":
        fetcher_cls = StealthyFetcher
    else:
        fetcher_cls = fetcher_map.get(method, StealthyFetcher)
    
    last_error = None
    
    for attempt in range(1, retries + 1):
        try:
            print(f"[fetch_page] Attempt {attempt}/{retries} with {fetcher_cls.__name__}...")
            
            kwargs = {"timeout": timeout}
            if fetcher_cls in (StealthyFetcher, DynamicFetcher):
                kwargs["headless"] = headless
            if fetcher_cls == StealthyFetcher:
                kwargs["network_idle"] = True
            
            page = fetcher_cls.fetch(url, **kwargs)
            
            if page.status < 400:
                print(f"[fetch_page] OK — Status {page.status}")
                return page
            else:
                print(f"[fetch_page] HTTP {page.status}, retrying...")
                
        except Exception as e:
            last_error = e
            print(f"[fetch_page] Error: {e}")
        
        if attempt < retries:
            time.sleep(pause)
    
    print(f"[fetch_page] FAILED after {retries} attempts. Last error: {last_error}")
    return None


def search_and_scrape(
    query: str,
    search_engine: str = "duckduckgo",
    max_results: int = 5,
) -> List[Dict[str, Any]]:
    """
    Búsqueda web + scrape de resultados. 
    NOTA: Requiere implementar search toolset o search-scraper.
    Por ahora es stub para extender.
    """
    # TODO: Integrar con search toolset para obtener URLs,
    # luego hacer fetch_page() de cada una.
    raise NotImplementedError("Integrar con search toolset primero")


def scrape_with_fallback(url: str, css_selectors: Dict[str, str]) -> Dict[str, Any]:
    """
    Scrapea una URL extrayendo campos vía CSS. 
    Si Scrapling falla, fallback a None (browser debe ser llamado externamente).
    
    Args:
        url: URL objetivo
        css_selectors: Dict {nombre_campo: selector_css}
    
    Returns:
        Dict con los datos extraídos + metadata
    """
    result = {"url": url, "status": None, "data": {}, "error": None}
    
    page = fetch_page(url, method="auto")
    
    if page is None:
        result["error"] = "Scrapling failed after retries"
        return result
    
    result["status"] = page.status
    
    for field_name, selector in css_selectors.items():
        try:
            # Intenta texto primero, luego atributo
            if "::attr(" in selector:
                value = page.css(selector).get()
            else:
                value = page.css(selector).get()
            result["data"][field_name] = value
        except Exception as e:
            result["data"][field_name] = None
            print(f"[scrape_with_fallback] Selector '{selector}' failed: {e}")
    
    return result


# ─── EJEMPLO DE USO ──────────────────────────────────────────
if __name__ == "__main__":
    # Ejemplo 1: Fetch simple
    page = fetch_page("https://example.com")
    if page:
        print("Title:", page.css("title::text").get())
    
    # Ejemplo 2: Scrape estructurado
    datos = scrape_with_fallback(
        "https://example.com",
        {
            "titulo": "h1::text",
            "parrafo": "p::text",
        }
    )
    print(datos)
