"""
scraper_template.py
--------------------
Template reutilizable para scraping con Scrapling v0.4.7.
Copiar y adaptar según el sitio objetivo.

Requiere:
    pip install "scrapling[fetchers]" pandas
    python3 -m scrapling install
"""

import os
import re
import time
import requests
import pandas as pd
from difflib import SequenceMatcher
from urllib.parse import quote_plus
from scrapling.fetchers import StealthyFetcher

# ─── CONFIGURACIÓN ────────────────────────────────────────────
QUERY           = "tu búsqueda acá"
CARPETA_OUTPUT  = "./resultados"
PAUSA_SEGUNDOS  = 3       # entre requests
MAX_RESULTADOS  = 6       # por página
MIN_SCORE       = 0.35    # similitud mínima aceptable

# Activar adaptive UNA vez al inicio
StealthyFetcher.adaptive = True

# ─── SCRAPING ─────────────────────────────────────────────────

def scrape_ml(query, max_resultados=MAX_RESULTADOS, pais='mexico'):
    """Busca en MercadoLibre y retorna resultados."""
    dominio = {'mexico': 'com.mx', 'argentina': 'com.ar', 'chile': 'cl'}.get(pais, 'com.mx')
    url = f"https://listado.mercadolibre.{dominio}/{quote_plus(query)}"
    
    try:
        page = StealthyFetcher.fetch(url, headless=True, network_idle=True, timeout=60000)
        resultados = []

        items = page.css('li.ui-search-layout__item')
        if not items:
            items = page.css('.ui-search-result')

        for item in items[:max_resultados]:
            titulo_el = item.css('h2.poly-box a, .poly-component__title, h2 a')
            img_el    = item.css('img.poly-component__picture, img.ui-search-result-image__element, img')
            link_el   = item.css('a.poly-component__anchor, a.ui-search-result__image-anchor, a')

            titulo  = titulo_el[0].text.strip() if titulo_el else ""
            img_url = ""
            if img_el:
                img_url = img_el[0].attrib.get('data-src') or img_el[0].attrib.get('src', '')
                img_url = re.sub(r'-[A-Z]\.(?:jpg|webp|png)', '-O.jpg', img_url)

            permalink = link_el[0].attrib.get('href', '') if link_el else ""

            if titulo:
                resultados.append({
                    'titulo': titulo,
                    'imagen': img_url,
                    'url': permalink,
                })

        return resultados

    except Exception as e:
        print(f"  Error: {e}")
        return []


# ─── MATCHING ─────────────────────────────────────────────────

def similitud(a, b):
    return SequenceMatcher(None, str(a).upper(), str(b).upper()).ratio()


def mejor_resultado(nombre_buscado, resultados):
    """Retorna (mejor_resultado, score)."""
    mejor, score = None, 0
    for r in resultados:
        s = similitud(nombre_buscado, r['titulo'])
        if s > score:
            score, mejor = s, r
    return mejor, score


# ─── DESCARGA ─────────────────────────────────────────────────

def descargar_imagen(url, filepath):
    """Descarga una imagen y la guarda localmente."""
    if not url:
        return False
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        r = requests.get(url, timeout=15, headers=headers)
        r.raise_for_status()
        with open(filepath, "wb") as f:
            f.write(r.content)
        return True
    except Exception as e:
        print(f"  Error descargando: {e}")
        return False


# ─── MAIN ─────────────────────────────────────────────────────

def main():
    os.makedirs(CARPETA_OUTPUT, exist_ok=True)
    
    # Adaptar esta lista según tu caso de uso
    items_a_buscar = [
        {"id": "001", "nombre": "Horno eléctrico 30 litros", "marca": "Magiclick"},
        {"id": "002", "nombre": "Freidora de aire 7 litros", "marca": "Dinax"},
    ]
    
    resultados_finales = []
    
    for i, item in enumerate(items_a_buscar, 1):
        nombre = item['nombre']
        marca  = item.get('marca', '')
        query  = f"{marca} {nombre}".strip() if marca else nombre
        
        print(f"\n[{i}/{len(items_a_buscar)}] {nombre}")
        print(f"  Query: {query}")
        
        resultados_ml = scrape_ml(query)
        
        if not resultados_ml:
            print("  Sin resultados")
            resultados_finales.append({**item, 'titulo_ml': '', 'score': 0, 
                                       'imagen': '', 'estado': 'SIN RESULTADOS'})
            time.sleep(PAUSA_SEGUNDOS)
            continue
        
        mejor, score = mejor_resultado(nombre, resultados_ml)
        
        # Reintento sin marca si score bajo
        if score < 0.65 and marca:
            print(f"  Score bajo ({score:.0%}), reintentando sin marca...")
            resultados_ml2 = scrape_ml(nombre)
            if resultados_ml2:
                mejor2, score2 = mejor_resultado(nombre, resultados_ml2)
                if score2 > score:
                    mejor, score = mejor2, score2
        
        print(f"  Match ({score:.0%}): {mejor['titulo'][:55]}")
        
        # Descargar imagen
        filepath = os.path.join(CARPETA_OUTPUT, f"{item['id']}.jpg")
        descargado = descargar_imagen(mejor['imagen'], filepath)
        
        estado = "OK" if score >= MIN_SCORE else "REVISAR"
        resultados_finales.append({
            **item,
            'titulo_ml': mejor['titulo'],
            'score': round(score, 2),
            'imagen_url': mejor['imagen'],
            'imagen_local': filepath if descargado else '',
            'permalink': mejor['url'],
            'estado': estado if descargado else 'ERROR DESCARGA',
        })
        
        time.sleep(PAUSA_SEGUNDOS)
    
    # Guardar resultados
    df = pd.DataFrame(resultados_finales)
    csv_path = os.path.join(CARPETA_OUTPUT, 'resultados.csv')
    df.to_csv(csv_path, sep=';', index=False, encoding='utf-8-sig')
    
    # Resumen
    ok      = sum(1 for r in resultados_finales if r['estado'] == 'OK')
    revisar = sum(1 for r in resultados_finales if r['estado'] == 'REVISAR')
    error   = sum(1 for r in resultados_finales if r['estado'] not in ('OK', 'REVISAR'))
    
    print(f"\n{'='*50}")
    print(f"OK: {ok} | Revisar: {revisar} | Error: {error}")
    print(f"Resultados: {csv_path}")
    print(f"Imágenes: {CARPETA_OUTPUT}/")


if __name__ == "__main__":
    main()
