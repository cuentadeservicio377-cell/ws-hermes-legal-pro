# scrapling-scraper

**Hermes Agent skill** for web scraping with automatic anti-bot bypass using [Scrapling](https://github.com/D4Vinci/Scrapling).

Use it when `requests` or `httpx` fail with 403, when a site has Cloudflare or WAF protection, or when you need to scrape MercadoLibre and similar e-commerce platforms.

---

## What it does

- Automatically selects the right fetcher for the target site (`Fetcher`, `StealthyFetcher`, `DynamicFetcher`)
- Bypasses anti-bot systems, Cloudflare Turnstile, and WAFs with no extra configuration
- Extracts data using CSS/XPath selectors
- Includes fuzzy matching logic for similarity-based searches
- Bulk downloads images from scraping results
- Retries with an alternative query when the match score is too low

Proven use cases:
- Product search on **MercadoLibre Argentina** with title, image, and URL extraction
- Bulk image download with SKU-based file naming
- Automatic retry without brand name when initial match score is insufficient

---

## Installation

### 1. Install Scrapling in your environment

```bash
pip install "scrapling[fetchers]"
scrapling install   # downloads browsers (first time only, ~2 min)
```

> ⚠️ The `scrapling install` step is mandatory. Without it the script fails with a Playwright message asking you to run it.

### 2. Install the skill in Hermes

```bash
# Clone the repo
git clone https://github.com/gabogabucho/scrapling-skill.git

# Copy to Hermes skills directory
cp -r scrapling-skill ~/.hermes/skills/web/scrapling-scraper
```

Or install directly from GitHub using the Hermes CLI:

```bash
hermes skills install gabogabucho/scrapling-skill
```

---

## Usage

Once installed, invoke it from the Hermes chat:

```
/scrapling-scraper find image of 30-liter electric oven on mercadolibre
```

Or just describe the problem — Hermes activates the skill automatically when it detects a 403 or anti-bot block:

```
I need to scrape mercadolibre but I'm getting 403 errors
```

---

## Known errors and fixes

These errors were found during development. If you run into them, here is the fix:

### ❌ `TypeError: 'StealthyFetcher' object does not support the context manager protocol`

**Cause:** In v0.4.x, `with StealthyFetcher() as fetcher` is no longer supported.

**Fix:** Use the static call directly:

```python
# WRONG — does not work in v0.4.x
with StealthyFetcher(headless=True) as fetcher:
    page = fetcher.fetch(url)

# CORRECT
page = StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ❌ `ValueError: Unknown parser argument: "headless"; maybe you meant ('huge_tree', 'adaptive', ...)`

**Cause:** `headless` does not go in `configure()` — that method is only for parser options.

**Fix:** Move `headless=True` into `.fetch()`:

```python
# WRONG
StealthyFetcher.configure(headless=True)
StealthyFetcher.fetch(url)

# CORRECT
StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ❌ `[WARNING] This logic is deprecated now, and have no effect; It will be removed with v0.3.`

**Cause:** Calling `StealthyFetcher(headless=True)` as a constructor.

**Fix:** Same as above — `headless` goes in `.fetch()`.

---

### ❌ Browser not found / Playwright message asking to install

**Cause:** `scrapling install` was not executed.

**Fix:**
```bash
scrapling install
# or alternatively:
playwright install
```

---

### ❌ 403 on MercadoLibre using the public API (`api.mercadolibre.com`)

**Cause:** ML's REST API blocks requests without a valid token or user-agent.

**Fix:** Scrape the search results page directly instead of using the API:

```python
# WRONG — public API returns 403 without auth
requests.get("https://api.mercadolibre.com/sites/MLA/search?q=oven")

# CORRECT — scrape the page with StealthyFetcher
url = f"https://listado.mercadolibre.com.ar/{quote_plus(query)}"
page = StealthyFetcher.fetch(url, headless=True, network_idle=True)
```

---

### ⚠️ Empty images or broken URLs on MercadoLibre

**Cause:** ML uses lazy-loading — the real image URL is in `data-src`, not `src`.

**Fix:**

```python
img_url = img_el[0].attrib.get('data-src') or img_el[0].attrib.get('src', '')
```

To upgrade thumbnail resolution:

```python
import re
img_url = re.sub(r'-[A-Z]\.(?:jpg|webp|png)', '-O.jpg', img_url)
```

---

### ⚠️ Dependency conflict with CrewAI (`click` version mismatch)

**Cause:** CrewAI requires `click~=8.1.7` but Scrapling installs a newer version.

**Impact:** None — it is a warning, not an error. Scrapling works fine.

**Fix:** Ignore the warning. If CrewAI breaks because of this at some point, resolve it separately using a virtualenv.

---

## Skill structure

```
scrapling-scraper/
├── SKILL.md                    # Main skill definition (frontmatter + procedure)
├── README.md                   # Spanish docs
├── README.en.md                # This file
├── LICENSE                     # MIT
├── references/
│   └── api-quick-ref.md        # Quick reference for CSS/XPath selectors and errors
└── templates/
    └── scraper_template.py     # Reusable base script for new scraping projects
```

---

## Tested Scrapling version

`v0.4.1` — the instructions and documented errors correspond to this version. If you upgrade Scrapling, check the breaking changes in the [CHANGELOG](https://github.com/D4Vinci/Scrapling/releases).

---

## Author

Created by [@gabogabucho](https://twitter.com/gabogabucho)

---

## License

MIT License

Copyright (c) 2026 Gabriel Urrutia (@gabogabucho)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
