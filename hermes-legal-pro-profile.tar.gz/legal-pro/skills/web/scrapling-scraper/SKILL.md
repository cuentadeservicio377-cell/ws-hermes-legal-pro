---
name: scrapling-scraper
description: |
  Método PRINCIPAL de acceso a la web en Hermes. Bypass automático de Cloudflare, 
  Turnstile, WAF, 403. Usar SIEMPRE antes que browser_navigate o search cuando se 
  necesite extraer datos de una URL específica. Fallback a browser/search solo si 
  Scrapling falla después de 2 intentos.
version: 2.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [scraping, web, automation, anti-bot, cloudflare, mercadolibre, requests, primary, default]
    category: web
    fallback_for_toolsets: [browser, search]
    requires_toolsets: [terminal]
---

# Scrapling Scraper — Método Principal de Web Access

## Cuándo usar (orden de prioridad)

1. **Necesito datos de una URL específica** → Scrapling PRIMERO
2. **URL devuelve 403/401/bloqueo anti-bot** → Scrapling ( StealthyFetcher )
3. **MercadoLibre, e-commerce, foros, SPAs** → Scrapling
4. **Necesito crawl multi-página** → Scrapling Spiders
5. **Solo si Scrapling falla** → fallback a `browser_navigate` o `search`

**Regla de oro:** Si la tarea implica "ir a X sitio y extraer Y datos", empezar con Scrapling.

---

## Installation

```bash
# Ya debería estar instalado en el venv de Hermes
python3 -m pip install "scrapling[fetchers]"

# Instalar browsers (una sola vez)
python3 -m scrapling install
# Si falla:
python3 -m playwright install chromium
```

---

## API v0.4.7 — Llamadas ESTÁTICAS (correcto)

```python
from scrapling.fetchers import Fetcher, StealthyFetcher, DynamicFetcher

# Fetcher rápido (sitios estáticos, APIs)
page = Fetcher.fetch('https://api.example.com/data', timeout=30000)

# StealthyFetcher (anti-bot, Cloudflare, default para la mayoría de casos)
StealthyFetcher.adaptive = True  # Re-ubica selectores si cambia el diseño
page = StealthyFetcher.fetch(
    'https://sitio-con-cloudflare.com',
    headless=True,
    network_idle=True,
    timeout=60000,
)

# DynamicFetcher (SPAs, contenido que requiere interacción JS extensiva)
page = DynamicFetcher.fetch('https://spa-react.com', headless=True)
```

**NUNCA instanciar** — `StealthyFetcher()` como constructor ya no es necesario y puede dar warnings.

---

## Features nuevas v0.4.7 que debemos usar

### Adaptive selectors (obligatorio)

```python
StealthyFetcher.adaptive = True  # Hacer esto UNA vez al inicio del script

# Luego los selectores sobreviven cambios de diseño de la página
products = page.css('.product', auto_save=True)  # Guarda estructura para adaptive

# Más tarde, si la web cambia:
products = page.css('.product', adaptive=True)  # Re-ubica automáticamente
```

### Cookie Vault / Sesiones persistentes

```python
from scrapling.fetchers import StealthyFetcher
from scrapling.core.storage import SQLiteStorageSystem

# Configurar vault UNA vez al inicio del script/session
StealthyFetcher.adaptive = True
StealthyFetcher.storage = SQLiteStorageSystem
StealthyFetcher.storage_args = {"storage_file": "~/.hermes/scrapling_storage/vault.db"}

# Login una vez, reusar cookies en futuras llamadas
page = StealthyFetcher.fetch('https://sitio.com/login', headless=True, timeout=60000)
# ... hacer login manual o automático ...

# Siguientes requests usan las mismas cookies automáticamente
page2 = StealthyFetcher.fetch('https://sitio.com/panel', headless=True, timeout=60000)
```

**Ubicación persistente en Hermes:** `~/.hermes/scrapling_storage/vault.db`

**Para logins automáticos**, combinar con:
```python
page = StealthyFetcher.fetch('https://sitio.com/login', headless=True, timeout=60000)
# Si hay formulario, interactuar vía Playwright subyacente:
# page.page.fill('#email', 'user@example.com')
# page.page.fill('#password', 'pass')
# page.page.click('button[type="submit"]')
```

---

## Decision Tree — Qué fetcher usar

```
¿Necesito extraer datos de una URL específica?
  └─ SÍ → ¿El sitio tiene Cloudflare / Turnstile / WAF / 403?
              └─ SÍ → StealthyFetcher (adaptive=True)
              └─ NO → ¿Es una SPA con mucho JS dinámico?
                          └─ SÍ → DynamicFetcher
                          └─ NO → Fetcher (más rápido)
  └─ NO → ¿Es una búsqueda general sin URL conocida?
              └─ SÍ → search toolset (Google/DuckDuckGo)
              └─ NO → browser_navigate (interacción visual necesaria)
```

---

## Procedimientos

### 1. Scrape básico con anti-bot (default)

```python
from scrapling.fetchers import StealthyFetcher

StealthyFetcher.adaptive = True
page = StealthyFetcher.fetch(
    'https://sitio.com/productos',
    headless=True,
    network_idle=True,
    timeout=60000,
)

items = page.css('li.resultado')
for item in items:
    titulo = item.css('h2::text').get()
    precio = item.css('.precio::text').get()
    print(titulo, precio)
```

### 2. MercadoLibre (caso probado)

```python
from scrapling.fetchers import StealthyFetcher
from urllib.parse import quote_plus
import re

StealthyFetcher.adaptive = True

def buscar_en_ml(query, max_resultados=6, pais='mexico'):
    dominio = {'mexico': 'com.mx', 'argentina': 'com.ar', 'chile': 'cl'}.get(pais, 'com.mx')
    url = f"https://listado.mercadolibre.{dominio}/{quote_plus(query)}"
    
    page = StealthyFetcher.fetch(url, headless=True, network_idle=True, timeout=60000)
    
    resultados = []
    items = page.css('li.ui-search-layout__item')
    if not items:
        items = page.css('.ui-search-result')
    
    for item in items[:max_resultados]:
        titulo_el = item.css('h2.poly-box a, .poly-component__title, h2 a')
        img_el    = item.css('img.poly-component__picture, img.ui-search-result-image__element, img')
        link_el   = item.css('a.poly-component__anchor, a.ui-search-result__image-anchor, a')
        
        titulo = titulo_el[0].text.strip() if titulo_el else ""
        img_url = ""
        if img_el:
            img_url = img_el[0].attrib.get('data-src') or img_el[0].attrib.get('src', '')
            img_url = re.sub(r'-[A-Z]\.(?:jpg|webp|png)', '-O.jpg', img_url)
        
        permalink = link_el[0].attrib.get('href', '') if link_el else ""
        
        if titulo:
            resultados.append({'titulo': titulo, 'imagen': img_url, 'url': permalink})
    
    return resultados
```

### 3. Crawl multi-página con Spider

```python
from scrapling.spiders import Spider, Response

class MySpider(Spider):
    name = "demo"
    start_urls = ["https://example.com/page-1"]

    async def parse(self, response: Response):
        for item in response.css('.product'):
            yield {
                "title": item.css('h2::text').get(),
                "price": item.css('.price::text').get(),
            }
        
        # Siguiente página
        next_page = response.css('a.next::attr(href)').get()
        if next_page:
            yield response.follow(next_page)

MySpider().start()
```

### 4. Descargar imágenes (una vez tenida la URL)

```python
import requests
import os

def descargar_imagen(url, filepath):
    if not url:
        return False
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    r = requests.get(url, timeout=15, headers=headers)
    if r.status_code == 200:
        with open(filepath, "wb") as f:
            f.write(r.content)
        return True
    return False
```

---

## Pitfalls

- **API v0.4.7 usa llamadas ESTÁTICAS** — `StealthyFetcher.fetch(url)` directo. No instanciar.
- **`timeout` está en MILISEGUNDOS** — `timeout=30000` = 30 segundos. `timeout=15` = 15ms (falla instantáneo).
- **No usar context manager** (`with StealthyFetcher() as f`) — obsoleto en v0.4.x.
- **`headless=True` va en `.fetch()`**, no en `configure()`.
- **Activar `adaptive = True` al inicio** para que los selectores sobrevivan cambios de diseño.
- **Imágenes de CDN descargar con requests** — no necesitan StealthyFetcher una vez tenida la URL.
- **ML lazy-load**: revisar `data-src` antes de `src`.
- **Pausa entre requests**: 2-3 segundos mínimo en sitios agresivos con rate-limiting.
- **Error de browsers**: correr `python3 -m scrapling install`.

---

## Verification

```python
from scrapling.fetchers import Fetcher, StealthyFetcher

# Test rápido básico
page = Fetcher.fetch('https://httpbin.org/get', timeout=30000)
print(page.status)  # 200

# Test stealth (requiere browsers)
StealthyFetcher.adaptive = True
page = StealthyFetcher.fetch('https://httpbin.org/headers', headless=True, timeout=30000)
print(page.status)  # 200
print(page.css('title::text').get())  # httpbin.org
```

---

## Match Quality (fuzzy matching)

```python
from difflib import SequenceMatcher

def similitud(a, b):
    return SequenceMatcher(None, str(a).upper(), str(b).upper()).ratio()

# Score > 0.65 → match confiable
# Score 0.35-0.65 → revisar manualmente
# Score < 0.35 → probablemente incorrecto
```
