# Scrapling API Quick Reference — v0.4.7

## Fetchers

| Fetcher | Cuándo usarlo | Velocidad | Syntax |
|---------|--------------|-----------|--------|
| `Fetcher` | Sitios estáticos, APIs públicas | Muy rápido | `Fetcher.fetch(url)` |
| `StealthyFetcher` | Anti-bot, Cloudflare, 403, WAF | Medio | `StealthyFetcher.fetch(url, headless=True)` |
| `DynamicFetcher` | JS dinámico, SPAs, interacción | Lento | `DynamicFetcher.fetch(url, headless=True)` |

> **v0.4.7 usa llamadas ESTÁTICAS** — no instanciar. `StealthyFetcher.fetch(url)` directo.

---

## StealthyFetcher — parámetros clave

```python
StealthyFetcher.adaptive = True   # Re-ubica selectores si cambia el diseño (hacer UNA vez)

page = StealthyFetcher.fetch(
    url,
    headless=True,        # True = invisible (default), False = ver browser
    network_idle=True,    # Esperar que termine el JS
    timeout=60000,        # MILISEGUNDOS. 30000 = 30s. ¡NUNCA 15!
    google_search=True,   # Simular referer de Google (default True)
)
```

---

## Selectores CSS

```python
page.css('selector')              # → lista de elementos
page.css('selector')[0]           # → primer elemento
page.css('h2::text').get()        # → texto del primer match
page.css('h2::text').getall()     # → lista de textos de todos los matches
page.css('a::attr(href)').get()   # → atributo href

# Adaptive (sobrevive cambios de diseño)
products = page.css('.product', auto_save=True)   # Guarda estructura
products = page.css('.product', adaptive=True)    # Re-ubica automáticamente
```

## XPath

```python
page.xpath('//h2/text()').getall()
page.xpath('//img/@src').getall()
page.xpath('//a[@class="resultado"]/@href').getall()
```

## Atributos del elemento

```python
elemento.text                         # texto limpio
elemento.attrib.get('src')            # atributo src
elemento.attrib.get('data-src')       # data attributes (lazy load)
elemento.attrib                       # dict de todos los atributos
```

## Atributos de Response

```python
page.status        # HTTP status code
page.url           # URL final (post-redirects)
page.headers       # headers de respuesta
page.request       # objeto request
```

---

## Selectores comunes de MercadoLibre

```python
# Resultados de búsqueda
'li.ui-search-layout__item'           # cada resultado (layout grid)
'.ui-search-result'                   # fallback

# Dentro de cada resultado:
'h2.poly-box a'                       # título (nuevo layout)
'.poly-component__title'              # título alternativo
'h2 a'                                # título fallback
'img.poly-component__picture'         # imagen (nuevo layout)
'img.ui-search-result-image__element' # imagen alternativo
'img'                                 # imagen fallback (siempre funciona)
'a.poly-component__anchor'            # link producto
```

## Resolución de imágenes ML

ML sirve thumbnails con sufijos como `-I.jpg` (90px), `-D.jpg`, `-O.jpg` (original).

```python
import re
img_url = re.sub(r'-[A-Z]\.(?:jpg|webp|png)', '-O.jpg', img_url)
```

---

## Errores frecuentes y fixes

| Error | Causa | Fix |
|-------|-------|-----|
| `TimeoutError: 15ms exceeded` | Timeout=15 (interpreta ms) | Usar `timeout=30000` (30s) o `timeout=60000` |
| `TypeError: object does not support context manager` | `with StealthyFetcher()` | Usar llamada estática: `StealthyFetcher.fetch(url)` |
| `ValueError: Unknown parser argument "headless"` | `configure(headless=True)` | Mover a `.fetch(url, headless=True)` |
| `[WARNING] deprecated logic` | `StealthyFetcher(headless=True)` constructor | No instanciar. Llamada estática. |
| Browser not found | `scrapling install` no ejecutado | `python3 -m scrapling install` |
| 429 / Rate limited | Requests muy frecuentes | Pausa 3-5 segundos entre requests |
| Imágenes vacías | ML lazy-load | Revisar `data-src` antes de `src` |
| Selectores rotos | Cambio de diseño del sitio | Activar `StealthyFetcher.adaptive = True` |
