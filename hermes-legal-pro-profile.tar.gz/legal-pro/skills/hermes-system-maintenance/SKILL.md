---
name: hermes-system-maintenance
description: Periodic system cleanup and maintenance for Hermes Agent — memory consolidation, skills pruning, profile hygiene, vault organization, and config drift detection. Use when the user says "limpiar", "cleanup", "organize", "repair system", or when memory is above 80%.
version: 1.0.1
author: Hermes Neo
license: MIT
metadata:
  hermes:
    tags: [hermes, maintenance, cleanup, memory, skills, profiles, organization]
    category: devops
---

# Hermes System Maintenance

Periodic cleanup prevents drift and keeps the agent responsive. Run this after major projects, profile creations, or when memory exceeds 80%.

## 1. Memory Cleanup

### Capacity rules
- Keep memory **under 80%** — consolidate proactively before adding
- Entries are §-delimited, compact, information-dense
- **Save**: environment facts, conventions, stable preferences, lessons learned
- **Skip**: session ephemera (commits, temp paths), task progress, completed work logs
- **Never save**: task outcomes, temporary TODO state

### Procedure
1. Read current entries from system prompt header (shows % and count)
2. Identify obsolete or contradictory entries (old model configs, finished projects, duplicated preferences)
3. Use `memory(action="replace")` to consolidate related entries into one compact entry
4. Use `memory(action="remove")` to eliminate session-specific or outdated entries
5. Target: both memory stores under 80% after cleanup

### Good vs bad entries
```
# Good: compact, multiple facts, durable
User runs Ubuntu 22.04, uses Docker and Podman. Shell: zsh. Editor: VS Code with Vim keybindings.

# Bad: too vague
User has a project.

# Bad: too verbose / session-specific
On January 5th, 2026, the user asked me to look at their project which is located at...
```

## 2. Skills Cleanup

### Critical pitfall
Creating a profile with `--clone` copies **all bundled skills** into the new profile. This re-pollutes the system immediately after cleanup. Always clean new profiles after creation.

### Procedure
1. Audit current profile: use `skills_list()` to see installed skills
2. Use `skill_manage(action="delete")` for obsolete skills
3. After creating any new profile, audit and clean its skills directory immediately
4. Use a reusable cleanup script for consistency across profiles

### Recommended minimal skill set (business operations)
**Core**: neo-telegram-dev-flow, opencode, codex, claude-code, hermes-agent
**GitHub**: github-auth, github-code-review, github-issues, github-pr-workflow, github-repo-management
**Dev practices**: plan, writing-plans, test-driven-development, systematic-debugging, requesting-code-review, subagent-driven-development, project-continuity-with-vaults
**Business**: aws-capital-operating-model, ws-brain-dump, ws-growth-operational-batch, marketing-infrastructure-design
**Onyx**: onyx-lite-extension-pattern, onyx-integration-technical-reference, onyx-standalone-legal-frontend
**General productivity**: obsidian, maps, ocr-and-documents, nano-pdf, notion, linear, powerpoint, google-workspace
**DevOps**: hermes-workspace-v2, hermes-openai-codex-provider, openai-auth-audit-wsl-windows, webhook-subscriptions
**Research/Web**: scrapling-scraper, blogwatcher, llm-wiki, youtube-content, xitter, xurl
**Email/MCP**: himalaya, native-mcp, mcporter

### Skills typically safe to remove
Apple ecosystem, Creative tools (ascii, manim, p5js, pixel-art, comic, infographic), Gaming, MLOps training (axolotl, trl, unsloth, vllm, diffusers), Red-teaming, Smart Home, Data Science, Leisure.

## 3. Profile Architecture

When the user needs both a **personal co-pilot** and a **business operator**, use separate profiles:

|| Profile | Purpose |
|---------|---------|
|| `default` | Personal orchestration, planning, build sessions |
|| `ws` | Business operations, client service, knowledge base data entry |
|| `willow` | Deep legal work, legal knowledge training |
|| `marketing` | Agency operations, content, SEO |

## 4. Emergency System Repair

When the system is blocked (zombie Chrome processes, memory saturated, browser tools failing):

```bash
# Diagnóstico rápido
ps aux | grep defunct | grep -v grep
free -h
cat /proc/loadavg
ps aux | grep chrome | wc -l

# Reparación de emergencia
# 1. Matar zombies (padres primero)
for ppid in $(ps aux | awk '$8 ~ /Z/ {print $3}' | sort -u); do
    kill -9 $ppid 2>/dev/null
done

# 2. Limpiar Chrome residual
killall -9 chrome chromium chromium-browser 2>/dev/null
sleep 2

# 3. Verificar memoria y procesos
free -h
ps aux | grep chrome | grep -v grep
```

For the complete WS Capital repair protocol (auditing behavior, features, structure, coherencia, OpenCode, Obsidian Vault), see `references/ws-system-repair.md`.

## 5. Diagnostics & Session Continuity

### "System works but session forgets" pattern

Each chat session starts FRESH. Infrastructure (config, auth, skills) persists, but:
- Active projects are NOT automatically loaded
- Cron job results are NOT automatically reported
- Session context is NOT automatically recovered

**Diagnostic flow:**
1. Verify infrastructure FIRST (providers, auth, subagents)
   → If broken, use emergency repair above
   → If working, continue to step 2
2. Check session continuity:
   → Ask user: "¿En qué proyecto estás trabajando?"
   → Search for project files in known locations
   → Check Obsidian Vault / repos / Documents for active projects
   → Look for checkpoint files, cron logs, pending work
3. If infrastructure OK + project exists but session unaware:
   → This is SESSION CONTINUITY GAP, not system failure
   → Load project context explicitly
   → Report: "Sistema operativo. Proyecto encontrado en [ruta]."

### System status reference

Maintain a single source of truth for what works and what doesn't:
- LLM providers and their current state
- Subagent runtime capabilities
- Video/image/media generation status
- Productivity services (Onyx, Paola, Willow)
- Research and content tools

Update this status document after any configuration change or service repair.

## 6. Hermes 61 Features Quick Reference

**Activation technique (discovered 2026-05-01):** You can send ALL Telegram commands in a single message. The gateway processes them sequentially.

**Format:**
```
/goal [texto del goal]

/background [tarea en paralelo]

/model [modelo]

/snapshot [nombre]

/steer ["mensaje"]

/insights

/kanban list

/queue ["prompt"]

/branch [nombre-experimento]
```

**Rules:**
- One command per line
- Leave blank line between commands (optional, improves readability)
- Gateway executes them sequentially
- Some require confirmation, others are immediate

**Warning:** `/yolo` at the end activates no-confirmation mode. Use with care.

For the complete 61-features mapping with full command descriptions, see `references/hermes-61-features.md`.

Each profile gets its own config, memory, skills subset, cron jobs, and identity file.

Setup:
```bash
hermes profile create ws --clone
# Edit new profile's personality file for business operator identity
# Edit config if different model needed
# Run skill cleanup on new profile immediately
```

## 4. Vault Consolidation Pattern

When multiple vaults or note folders accumulate, consolidate to **3 canonical sources**:

```
BusinessName/
├── Build Vault/          # Active projects, repos, implementations
├── Growth Vault/         # Strategy, marketing, content, campaigns
└── System Vault/         # Operating contract, runbooks, decisions
    ├── Archive/          # Completed projects, historical deliveries
    └── Operations/       # Processes, experiments
```

Rules:
- Move completed projects to Archive/
- Merge duplicate vaults into one logical path
- Never delete during consolidation — only move or merge
- Update memory entries to point to new canonical paths

## 5. Config Drift Detection

Audit these sources for contradictions:

| Source | Check |
|--------|-------|
| Main config | Provider, model, fallback model match current preference? |
| Memory | Mentions obsolete providers or models? |
| Project context files | Any project-level instruction file placed in the global home directory instead of its project folder? |
| Identity file | Voice and role match current operating model? |
| Cron jobs | Any jobs serving completed projects? Remove them. |

## 6. Cron Cleanup

Use `cronjob(action="list")` to review all jobs, then `cronjob(action="remove")` for obsolete ones.
Note: cron-run sessions cannot create new cron jobs (anti-loop protection).

## 7. Hidden Feature Discovery

Frontend routes may contain redirect hooks that hide already-built features. Always check route files for patterns like:

```typescript
// Redirect pattern that hides existing code:
beforeLoad: ({ location }) => {
  throw redirect({ to: '/other-route', replace: true })
}
```

Fix: Replace redirect with actual component render that uses the existing shell or layout. Check screen components and route definitions for hidden implementations.

## 8. Cleanup Checklist

Use this checklist when the user requests system cleanup:

- [ ] Audit memory percentage and entries (consolidate or remove)
- [ ] Audit user profile percentage and entries
- [ ] List all skills, identify obsolete categories
- [ ] Check all profiles for bundled skill pollution
- [ ] List all vaults or note folders, propose consolidation
- [ ] Check main config for model or provider drift
- [ ] Check for misplaced project context files in global directories
- [ ] List all cron jobs, identify obsolete ones
- [ ] Check for redirect routes hiding built features
- [ ] Update identity file if operating model changed
- [ ] Create or update cleanup script for future reuse
