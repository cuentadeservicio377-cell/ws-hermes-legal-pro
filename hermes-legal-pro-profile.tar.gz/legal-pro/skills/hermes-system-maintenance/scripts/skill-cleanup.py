#!/usr/bin/env python3
"""
Skill cleanup script for Hermes profiles.
Run after creating a new profile to remove bundled bloat.
Usage: python skill-cleanup.py [profile_name]
If no profile_name provided, cleans default profile.
"""
import os
import shutil
import sys

KEEP = {
    "neo-telegram-dev-flow", "opencode", "codex", "claude-code", "hermes-agent",
    "github-auth", "github-code-review", "github-issues", "github-pr-workflow", "github-repo-management",
    "plan", "writing-plans", "test-driven-development", "systematic-debugging",
    "requesting-code-review", "subagent-driven-development", "project-continuity-with-vaults",
    "backend-spa-fallback", "aws-capital-operating-model", "ws-brain-dump", "ws-growth-operational-batch",
    "marketing-infrastructure-design", "onyx-lite-extension-pattern", "onyx-integration-technical-reference",
    "onyx-standalone-legal-frontend", "obsidian", "maps", "ocr-and-documents", "nano-pdf",
    "notion", "linear", "powerpoint", "google-workspace", "hermes-workspace-v2",
    "hermes-openai-codex-provider", "openai-auth-audit-wsl-windows", "webhook-subscriptions",
    "scrapling-scraper", "blogwatcher", "llm-wiki", "youtube-content", "xitter", "xurl",
    "himalaya", "native-mcp", "mcporter", "dogfood",
}

profile = sys.argv[1] if len(sys.argv) > 1 else ""
if profile and profile != "default":
    skills_dir = os.path.expanduser(f"~/.hermes/profiles/{profile}/skills")
else:
    skills_dir = os.path.expanduser("~/.hermes/skills")

if not os.path.exists(skills_dir):
    print(f"Skills directory not found: {skills_dir}")
    sys.exit(1)

deleted = 0
for category in os.listdir(skills_dir):
    cat_path = os.path.join(skills_dir, category)
    if not os.path.isdir(cat_path) or category.startswith("."):
        continue
    for skill in os.listdir(cat_path):
        skill_path = os.path.join(cat_path, skill)
        if not os.path.isdir(skill_path):
            continue
        if skill not in KEEP:
            shutil.rmtree(skill_path)
            deleted += 1
    remaining = [d for d in os.listdir(cat_path) if os.path.isdir(os.path.join(cat_path, d))]
    if not remaining:
        os.rmdir(cat_path)

print(f"Cleaned {deleted} skills from {skills_dir}")
