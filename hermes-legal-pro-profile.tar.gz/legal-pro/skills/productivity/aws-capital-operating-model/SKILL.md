---
name: aws-capital-operating-model
description: "Operating model for AWS Capital: analyze the business, inventory reusable tools, turn projects into templates, and organize agentic workflows for clients and internal operations."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [business, operations, templates, agents, automation, portfolio]
---

# AWS Capital Operating Model

Use this skill when the user is working on AWS Capital — the business lab/operation that builds tools, automations, and reusable templates for businesses, freelancers, and small companies.

## Core idea

Treat every project as a reusable operational pattern, not as a one-off build.

The goal is to:
- understand the business and its market
- inventory all projects and tools
- identify reusable templates
- turn repeated workflows into agentic systems
- maintain separate versions for clients and internal use
- keep the system modular so tools can be recombined

## Current positioning from the website

The public site currently frames WS Capital as:
- an **AI Lab & Venture Capital Hybrid**
- focused on **Latin America**
- operating from **Guadalajara, Mexico**
- built around an **80% agentic / 20% human** execution model
- offering:
  - infrastructure transformation
  - open-source intelligence / research
  - voice assistants
  - professional extensions
  - agentic networks
- delivering high-touch transformation for a small number of companies per month

## Initial portfolio hypotheses

Likely reusable modules to inventory first:
- voice assistant templates for businesses and professionals
- admin/accounting/legal noise-reduction workflows
- research / intel tooling for founders
- agentic department replacement or augmentation kits
- internal operational brain for AWS Capital itself

## Working principles

1. **Template first**
   - Any tool that solves a common business problem should be designed as a template.
   - A template can be adapted to multiple clients with minimal changes.

2. **Inventory everything**
   - Every repo, tool, automation, and service should have a clear place in a portfolio map.
   - Track what it does, who uses it, what it depends on, and whether it is reusable.

3. **Separate the layers**
   - Business concept
   - operational workflow
   - agent/tool implementation
   - client-specific configuration

4. **Agentic by default**
   - Prefer workflows where agents can plan, execute, validate, and report.
   - Reuse the same specialist patterns across business lines when possible.

5. **Internal first, client second**
   - Build an internal version when a tool matters to the company.
   - Then adapt it for clients with the same core logic.

## What to capture when analyzing AWS Capital

When given the website, repos, or documents, extract:
- what the company does
- target customers
- current product lines
- reusable templates
- automations already built
- missing pieces
- candidate agent roles
- which tools should be standardized
- which parts should stay client-specific

## Recommended structure

For each project or tool, document:
- name
- purpose
- users
- inputs/outputs
- internal vs client version
- dependencies
- status
- reuse potential
- next improvement

## Recommended operating format

When the user shares a new AWS Capital item, respond with:
1. what it is
2. where it fits in the portfolio
3. whether it is a template or a custom implementation
4. what can be standardized
5. what should be turned into agents or automations
6. next step

## Evolution rule

This skill should be updated whenever the company strategy changes, a new product line appears, or a reusable pattern is discovered.
