---
name: ws-interconnected-ops
description: "Operación transversal de WS Capital: Hermes como sistema nervioso que conecta todos los departamentos/topics. Admin & Ops como centro de control PM."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ws, departments, topics, routing, admin-ops, pm]
---

# WS Interconnected Ops

Sistema de conexión entre todos los departamentos de WS Capital operando en topics de Telegram.

## Topics / Departamentos

| Thread ID | Topic | Departamento | Vault Primario |
|-----------|-------|--------------|----------------|
| 1 | General | Dirección / Orquestación | System Vault |
| 2 | Socio Operativo | Segundo Yo de Pablo | System + Growth |
| 5 | Build & Tech | Fábrica de Software | Build Vault |
| 8 | Growth & Marketing | Growth | Growth Vault |
| 22 | Willow Legal | Jurídico / Willow | Onyx + System |
| 23 | Admin & Ops | COO / PM | Excel PM + System |
| 24 | Ventas & Plantillas | Comercial | Growth + Excel PM |

## Reglas de Routing

1. **Hermes detecta el topic por thread_id** y aplica contexto de departamento
2. **Admin & Ops (23) ve TODO** — es el centro PM
3. **Cualquier handoff entre áreas** se registra en Excel PM
4. **Brain-dumps en cualquier topic** se clasifican y rutean al Excel correcto
5. **Los cron jobs de Admin & Ops** revisan TODAS las áreas

## Handoffs Comunes

```
Growth → Build: "Necesito landing para campaña"
Growth → Admin: "Necesito presupuesto aprobado"
Build → Admin: "Feature lista, pasa a QA"
Willow → Build: "Necesito automatización docs"
Ventas → Willow: "Cliente necesita contrato"
Ventas → Growth: "Prospecto pide caso de éxito"
Socio Op → Cualquiera: ideas, prioridades, dirección
General → Todos: reuniones, decisiones estructurales
```

## Google APIs Transversales

See `references/google-apis-master.md` for the complete Google APIs integration reference (Gmail, Calendar, Drive, Docs, Sheets authentication and usage patterns).

---

## 📋 ADMIN & OPS CAPABILITIES

The following are specialized operational functions under the Interconnected Ops umbrella. All share the same routing rules and handoff patterns above.

### 1. Brain-Dump Processing (`references/brain-dump.md`)
Converts Pablo's messy, repeated, partial, or voice-transcribed ideas into structured business thinking. Separates signal from noise, identifies repeated ideas vs new facts vs assumptions.

### 2. Admin & Ops Brain-Dump (`references/admin-ops-brain-dump.md`)
Specifically for **pendientes, tareas sueltas, and recordatorios semanales**. Captures weekly chaos and converts it into:
- Tareas concretas in Excel PM
- Ideas capturadas for evaluation
- Proyectos nuevos if the pending item is large
- Recordatorios programados or cron jobs

### 3. PM Evolution (`references/pm-evolution.md`)
Documented evolution system for the WS Capital PM. Control de cambios, versiones, propuestas de mejora, lecciones aprendidas. Every change is documented, every improvement is proposed, every version is saved.

### 4. Department Activation (`references/department-activation.md`)
Formalizes a department when detected via Telegram topic, voice note, or explicit request. Enriches the department operating contract, updates cross-references, creates operational artifacts, and handles infrastructure/tooling proposals.

### 5. Excel PM Design (`references/excel-pm-design.md`)
Professional Excel design for WS Capital PM: dashboard visual, semáforos, navegación tipo app, formato condicional, colores corporativos. Palette: Ink Blue #1B365D, Corporate Blue #2F5496, Success Green #548235, Warning Yellow #FFC000, Alert Red #C00000.

### 6. Marketing Excel Control (`references/marketing-excel-control.md`)
Offline marketing control system (Excel + file structure + documents) as alternative or complement to cloud dashboards. Used when the user wants tangible deliverables they can review, edit, and share. Creates complete file system with numbered folders matching the content pipeline.

### 7. Session Close Checkpoint (`references/session-close-checkpoint.md`)
Automatic checkpoint when Pablo says "listo, cerramos", "terminamos", "eso es todo". Captures:
- Contexto de la sesión (topic, duración, participantes)
- Qué se hizo (Done): proyectos creados, tareas completadas, ideas capturadas
- Qué quedó pendiente (Pending): tareas sin terminar, proyectos activos, handoffs
- Bloqueos (Blockers): qué está deteniendo algo, quién debe actuar, siguiente paso

Updates PROJECTS.md, Excel PM, and genera reporte de cierre.

Todas las áreas de WS Capital comparten acceso a APIs de Google. La disponibilidad se verifica centralmente.

### Verificar disponibilidad
```bash
# Ver TODAS las APIs disponibles
python ~/.hermes/skills/ws-capital/ws-google-apis-master/scripts/check_api.py --list-all

# Ver una API específica
python ~/.hermes/skills/ws-capital/ws-google-apis-master/scripts/check_api.py --api youtube
```

### APIs por Área

| Área | APIs principales | Token necesario |
|------|-----------------|-----------------|
| **Growth** | YouTube, Ads, Analytics, Search Console, Indexing, Vision, Slides | `google_token_extended.json` |
| **Willow Legal** | Vision (OCR), Drive, Docs, Sheets, Slides | Base o Extendido |
| **Build & Tech** | Cloud Platform (Gemini, Vertex), Sheets, Drive | Base o Extendido |
| **Admin & Ops** | Sheets (PM), Calendar, Drive, Gmail | `google_token.json` (base) |
| **Ventas** | Sheets, Slides (pitch decks), Calendar | Base o Extendido |
| **Socio Operativo** | Todas (orquestación) | Extendido |

### Reglas transversales
1. **Admin & Ops** puede verificar estado de cualquier API para cualquier área
2. **Growth** debe usar token extendido para la mayoría de sus APIs
3. **Willow** usa Vision para OCR de documentos legales escaneados
4. **Build** usa Cloud Platform para Gemini API y Agent Platform
5. **Cualquier handoff que requiera API** debe verificar disponibilidad antes de despachar

## Ritual de Conexión

### Diario (Admin & Ops)
- Checkpoint de TODOS los departamentos
- Revisar deadlines cross-dept
- Alertar bloqueos transversales

### Domingo
- Brain-dump con Pablo (puede ser en cualquier topic)
- Capturar pendientes de TODAS las áreas
- Planificar semana cross-dept

### Lunes
- Resumen por departamento
- Prioridades transversales
- Handoffs que necesitan atención

### Viernes
- Check de cumplimiento por área
- Revisar qué quedó pendiente
- Preparar lista para domingo

## Visibilidad Transversal

Hermes puede responder en cualquier topic preguntando sobre cualquier área:

```
[Pablo en Growth] → "¿Cómo va Build con el website?"

[Hermes]:
→ Lee Excel PM (proyectos de Build)
→ Responde: "Build tiene 2 proyectos activos: 
   Website (75%) y API (40%).
   Handoff pendiente: Growth → Build (landing page)."
```

## Acceso a Vaults por Topic

| Topic | Vaults que usa | Vaults que puede consultar |
|-------|---------------|---------------------------|
| General | System | Todos |
| Socio Op | System, Growth | Todos |
| Build | Build | System, Admin PM |
| Growth | Growth | System, Admin PM |
| Willow | Onyx, System | Admin PM |
| Admin & Ops | Excel PM, System | Todos |
| Ventas | Growth, Excel PM | Admin PM |
