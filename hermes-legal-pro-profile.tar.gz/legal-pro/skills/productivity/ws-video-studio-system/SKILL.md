---
name: ws-video-studio-system
description: WS Video Studio — Sistema completo de producción audiovisual integrado a Hermes. Dashboard v2.1, 3 skills de video, SmartCut editor, estructura de carpetas Windows.
triggers:
  - ws video studio
  - video machine
  - generar video
  - crear reel
  - dashboard video
  - fal ai
  - smartcut
  - ws-video-social
  - ws-video-marketing
  - ws-video-demo
---

# WS Video Studio — Sistema Completo

## 📁 Estructura de Carpetas (Windows)

Base: `C:\Users\DELL\Documents\WS-Capital\Video-Studio\`

```
00-Assets/              ← Depósito de ingredientes (Imagenes, Audio, Video-Raw, Music, Fonts, Branding)
01-Social-Reels/        ← Reels/TikTok/Shorts (Briefs → Assets → Edicion → Renders → Entregas)
02-Marketing/           ← Videos promocionales (misma estructura 5 fases)
03-Demos/               ← Demos de software (misma estructura 5 fases)
99-Control-Maestro/     ← Dashboard + Excel tracking
│   ├── dashboard.html              (v1 estático)
│   ├── ABRIR-DASHBOARD.bat
│   └── dashboard-v2/
│       ├── start-dashboard.bat     ← Inicia backend + abre frontend
│       ├── backend/
│       │   ├── main.py             ← FastAPI en localhost:8766
│       │   └── .env                ← API keys
│       └── frontend/
│           └── index.html          ← React dashboard
99-Repositorio/         ← Historial mensual de videos entregados
99-Plantillas/          ← Briefs, guiones, proyectos reutilizables
```

## 🖥️ Dashboard v2.1

**URL Backend:** http://localhost:8766
**Frontend:** Abrir `frontend/index.html` en navegador

### Tabs:
1. **Dashboard** — Stats, proyectos activos, últimos entregados
2. **Crear** — Generador de Imagen / Video / Audio
3. **Assets** — Explorador de 00-Assets/
4. **Proyectos** — Lista de proyectos activos con filtros
5. **Entregas** — Historial de videos entregados

---

## 🎬 VIDEO TYPE CAPABILITIES

The studio supports four distinct video production pipelines. All share the same 5-phase folder structure (Briefs → Assets → Edición → Renders → Entregas) but differ in input, creative direction, and output specs.

### 1. Social Reels / TikTok / Shorts (`references/video-social.md`)
- **Format:** Vertical 9:16 (1080×1920)
- **Input:** Topic or description in natural language
- **Trigger:** "haz un reel", "genera un short", "video para TikTok"
- **Process:** Brief → Assets generados → SmartCut → Render → Virality score
- **Output:** MP4 + thumbnail + copy + hashtags

### 2. Marketing / Promotional Videos (`references/video-marketing.md`)
- **Format:** Multi-format (16:9, 1:1, 9:16)
- **Input:** Product/service + marketing objective
- **Trigger:** "video promocional de [producto]", "spot publicitario"
- **Process:** Brief creativo → Assets del depósito → Edición → 3 formatos
- **Output:** MP4 en 3 formatos + paquete completo

### 3. Software Demos / Tutorials (`references/video-demo.md`)
- **Format:** Screen recording + zoom automático
- **Input:** Feature or functionality to demonstrate
- **Trigger:** "graba un demo de [feature]", "tutorial de [producto]"
- **Process:** THINK (plan) → RECORD (screen capture) → EDIT (SmartCut) → RENDER
- **Output:** MP4 con narración paso a paso + captions

### 4. Video Machine / Automated Generation (`references/video-machine.md`)
- **Format:** Shorts for social media from scripts/images/prompts
- **Input:** Script, images, or text prompts
- **Trigger:** "genera video automático", "video machine"
- **Process:** Input → Parse → Generate scenes → Compose → Render
- **APIs:** FAL, Runway, Pika, local rendering
- **Repo:** `/mnt/c/Users/DELL/Documents/repos/projects/active/video-machine/`

### 5. Orchestrated Production (`references/video-orchestration.md`)
For complex productions requiring multiple subagents (script writer, visual director, voiceover, editor), use the orchestration reference which defines agent roles, toolsets, and the 4-stage pipeline.

### Providers Activos (ACTUALIZADO 29abr2026):
- 🎨 Imagen: `image_generate` de Hermes (cuando disponible)
- 🔊 Voz: Edge TTS (gratis, activo)
- 🔊 Voz nativa: `text_to_speech` de Hermes
- 🧠 LLM: Kimi (principal), OpenAI Codex (subagentes)
- 🛠️ Dev: ffmpeg (local, SIEMPRE disponible)
- 🛠️ Dev: SmartCut instalado

### Providers con problemas:
- ⚠️ FAL AI: key guardada pero **SIN CRÉDITO** — verificar balance antes de usar
- ⚠️ OpenCode Go: **Cloudflare 403 en WSL** — NO usar como opción principal

### Providers que NO generan imagen/video en este entorno:
- ❌ NVIDIA API: Chat de texto únicamente — NO genera imágenes ni video aquí

### Providers Pendientes (requieren API key):
- OpenAI DALL-E, Replicate, ElevenLabs, OpenAI TTS, Groq, Runway, Pika, Kling, OpenRouter, Mistral, xAI

## 🎬 3 Skills de Video

### ws-video-social — Reels / TikTok / Shorts
**Triggers:** "haz un reel", "genera un short", "video para TikTok", "contenido vertical"
**Output:** Video 9:16, 15-30s, imágenes + voz + música, score viral Tribe v2

### ws-video-marketing — Videos Promocionales
**Triggers:** "video promocional", "video para la landing", "spot publicitario", "ad para"
**Output:** Multi-formato (16:9 + 1:1 + 9:16), 15-60s, concepto creativo + SEO

### ws-video-demo — Demos de Software
**Triggers:** "graba un demo", "tutorial de", "screen recording", "walkthrough"
**Output:** 2-5 min, screen recording + zoom + cursor highlight + captions

## 🔧 Flujo de Trabajo

1. Usuario pide video por voz/texto
2. Hermes detecta skill según trigger words
3. Revisa 00-Assets/ primero
4. Genera lo que falta (image_generate, text_to_speech)
5. Crea carpeta de proyecto en estructura 5 fases
6. Abre SmartCut (localhost:3000) con proyecto
7. Renderiza vía maquina CLI
8. Entrega en 05-Entregas/
9. Archiva en 99-Repositorio/
10. Actualiza Dashboard

## ⚡ Acciones Rápidas

**Abrir Dashboard:**
```
Doble clic en: C:\Users\DELL\Documents\WS-Capital\Video-Studio\99-Control-Maestro\dashboard-v2\start-dashboard.bat
```

**Iniciar SmartCut:**
```bash
cd /root/SmartCut && bun run dev
```

**Agregar API Key:**
- Dashboard → tab APIs → "Agregar Key" → input → Guardar → Test
- O editar archivo: `backend/.env`

## ⚠️ Pendiente Crítico (ACTUALIZADO 29abr2026)

**FAL AI sin crédito.** Recargar en https://fal.ai/dashboard/billing para activar generación de imágenes/video.

**NVIDIA API NO genera imágenes** en este entorno — solo chat de texto.

**OpenCode Go NO usar como opción principal** — Cloudflare 403 en WSL.

**Para producción de video AHORA:**
1. Usar `image_generate` nativo de Hermes (si disponible)
2. Usar ffmpeg + fotos reales de Pablo para ensamblaje
3. Usar `text_to_speech` nativo de Hermes para VO
4. Fal.ai SOLO si balance confirmado
5. NO usar NVIDIA API para generación de imagen/video

## 📚 Documentación

- `GUIA-DE-USO.md` — Manual completo en Video-Studio/
- `ESTRUCTURA.md` — Documentación de carpetas
- `README.md` — Setup inicial

## 🔑 API Keys Guardadas (ACTUALIZADO 28abr2026)

- FAL_KEY: f01cce40-8529-4ea7-bf09-49851feb37d5:4b6ff44b557828dd3842bbadccfa6393 — **SIN BALANCE**
- KIMI_API_KEY: Allegro (principal)
- NVIDIA_API_KEY: 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 — **ACTIVA, fallback principal**
- SMARTCUT_INSTALLED: /root/SmartCut
- Copilot CLI: /usr/local/bin/copilot (v1.0.39) — para subagentes OpenAI Codex

## 🧠 Memoria de Sesión

- Creado: Abril 2026
- Versión: v2.1
- Próximo test: Cuando FAL tenga crédito, generar imagen de prueba → video de prueba
- Preferencia Pablo: Dashboard unificado para TODO contenido (imagen + video + audio + copy)
