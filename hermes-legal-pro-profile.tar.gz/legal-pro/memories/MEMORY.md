Excel PM maestro WS Capital: /mnt/c/Users/DELL/Downloads/Telegram Desktop/ws-admin-ops-master-v2.xlsx. Actualizar al final de cada sesión.
§
Lección crítica 2026-05-01: NO instalar skills genéricas del hub sin auditar nuestro sistema primero. Willow Legal (23 templates, 5 agentes, Kami v3) > business-contract + tech-lawyer. Video Studio (dashboard v2.1, SmartCut) > cualquier skill de content creation. Deep Research (4 agentes paralelos) > scrapling genérico. Growth Director > ai-seo. Principio: INTEGRAR features nativas de Hermes para AMPLIFICAR nuestros sistemas superiores, no acumular skills genéricas que compitan. Prompt Maestro Pattern: include current inventory in prompt to avoid rediscovery.
§
**SISTEMA CONTINUIDAD**: PROJECTS.md en ~/.hermes/PROJECTS.md. Proyectos: Hackathon Hermes (video V2 en progreso, deadline 4may2026), Paola Meneses (:8080), Willow Legal Standalone (:8081, Motor Kami v3, 23 templates, 5 agentes Hermes).
§
GitHub account configured: cuentadeservicio377-cell (cuentadeservicio377@gmail.com). Token OAuth active in ~/.config/gh/hosts.yml. Git credential helper enabled. All agents can use gh CLI and git for repos.
§
Growth Director MODO: Agent flexible. Fuente: Pablo 2026-04-29. NO skills como caja. NO workflows. Operar desde transcripciones exactas. Leer ESTADO_ACTUAL.md al inicio de cada sesión. NO proponer genérico. Esperar instrucciones de Pablo. Hackathon V2 (30abr): Cyberpunk electronic visual. Deadline May 4 2026.
§
Railway: GraphQL v2 https://backboard.railway.app/graphql/v2. MCP timeouts frequent. Fallback: web dashboard manual. Deploy statuses: BUILDING, SUCCESS, FAILED, CRASHED, DEPLOYING.
§
Técnica instalación headless skills: echo "y" | hermes skills install <id> para contextos no-TTY. Útil cuando el prompt interactivo cancela la instalación. Descubierto 2026-05-01 durante corrección de skills innecesarias.